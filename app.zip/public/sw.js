// Service worker minimal pour usage hors ligne du mode "Lexique Strong".
// Le mode "Versets bibliques" appelle une API externe (bible.helloao.org) et
// continue de nécessiter une connexion : ce service worker ne met en cache
// que les ressources de la même origine (l'app elle-même).

const CACHE_NAME = 'quiz-lexique-strong-v1';
const APP_SHELL = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL).catch(() => {}))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const { request } = event;

  // On ne touche qu'aux requêtes GET de la même origine (l'app statique).
  // Les appels vers l'API de versets bibliques (autre origine) passent tels
  // quels, sans mise en cache, pour rester toujours à jour et respecter le
  // fait que ce mode nécessite explicitement une connexion.
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) {
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      const networkFetch = fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        })
        .catch(() => cached || caches.match('./index.html'));

      // Cache-first pour un chargement hors-ligne instantané, tout en
      // rafraîchissant le cache en arrière-plan si le réseau est disponible.
      return cached || networkFetch;
    })
  );
});
