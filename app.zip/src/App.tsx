import React from 'react';
import { initialStrongData } from './data/initialStrongData';
import { compiledLexicon } from './data/compiledLexicon';
import { expandedLexicon } from './data/expandedLexicon';
import QuizGame from './components/QuizGame';
import { Heart } from 'lucide-react';

// Application 100% statique : les entrées du lexique Strong sont importées
// directement depuis ./data (aucun appel réseau, aucune authentification,
// aucun backend requis).
//
// Trois sources sont fusionnées, par ordre de priorité décroissante en cas de
// doublon sur un même numéro Strong :
//   1. initialStrongData : 152 entrées curatées d'origine (occurrences + références)
//   2. compiledLexicon   : fiches lexicographiques compilées manuellement par
//                          l'auteur (morphologie, étymologie, sources académiques)
//   3. expandedLexicon   : lot thématique généré, complète les manques
function mergeEntries() {
  const byStrong = new Map<string, (typeof initialStrongData)[number]>();
  // Ordre d'insertion inversé : on insère d'abord la source la plus faible,
  // puis on écrase avec les sources plus fiables — le dernier set() gagne.
  for (const e of expandedLexicon) byStrong.set(e.strong, e);
  for (const e of compiledLexicon) byStrong.set(e.strong, e);
  for (const e of initialStrongData) byStrong.set(e.strong, e);
  return Array.from(byStrong.values());
}

export default function App() {
  const entries = mergeEntries();

  return (
    <div className="min-h-screen flex flex-col justify-between text-gray-800">
      {/* Dynamic Grid Background Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

      {/* Main Content Area */}
      <div className="relative z-10 w-full max-w-2xl mx-auto px-4 py-8 space-y-8 flex-1">
        {/* Header Block */}
        <header className="flex flex-col items-center gap-2 pb-6 border-b border-gray-100 text-center">
          <h1 className="text-3xl font-black font-display text-gray-900 tracking-tight">
            📖 Quiz Lexique Strong
          </h1>
          <p className="text-xs text-gray-500 font-medium">
            {entries.length} mots • Hébreu &amp; Grec biblique
          </p>
        </header>

        {/* Quiz */}
        <main>
          <QuizGame entries={entries} />
        </main>
      </div>

      {/* Footer information block */}
      <footer className="w-full bg-white border-t border-gray-100 py-6 mt-12 relative z-10 text-center text-xs text-gray-400 space-y-1 font-sans">
        <p className="flex items-center justify-center gap-1">
          Développé avec précision théologique et technologique <Heart className="h-3 w-3 text-red-500 fill-red-500" />
        </p>
      </footer>
    </div>
  );
}
