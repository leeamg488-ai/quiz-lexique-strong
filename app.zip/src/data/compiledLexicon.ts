import { StrongEntry } from '../types';

// Fiches lexicographiques compilées manuellement par l'auteur de l'app
// (morphologie, étymologie, occurrences, exemples bibliques sourcés BDB/HALOT/
// Gesenius). Complété au fur et à mesure, par lots reçus dans un ordre quelconque
// (fusion dédupliquée par numéro Strong). Couverture actuelle : H0006-H0100, H0201-H0300.
export const compiledLexicon: StrongEntry[] = [
  {
    "id": 200000,
    "strong": "H6",
    "langue": "hebreu",
    "numero": 6,
    "mot_original": "אָבַד",
    "translitteration": "ʾāḇaḏ",
    "prononciation": "ʾāḇaḏ",
    "definition": "Périr, être détruit, disparaître, s'égarer.",
    "categorie": "Verbe",
    "references": [
      "Nombres 21:29",
      "Psaume 2:12"
    ],
    "type": "verbe",
    "occurrences": 184,
    "recherche": "h6 אָבַד ʾāḇaḏ périr, être détruit, disparaître, s'égarer. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200001,
    "strong": "H7",
    "langue": "hebreu",
    "numero": 7,
    "mot_original": "אֲבַד",
    "translitteration": "ʾăḇaḏ",
    "prononciation": "ʾăḇaḏ",
    "definition": "Périr, détruire. Correspondance araméenne de l'hébreu אָבַד (H0006).",
    "categorie": "Verbe",
    "references": [
      "Jérémie 10:11",
      "Daniel 7:11"
    ],
    "type": "verbe",
    "occurrences": 7,
    "recherche": "h7 אֲבַד ʾăḇaḏ périr, détruire. correspondance araméenne de l'hébreu אָבַד (h0006). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200002,
    "strong": "H8",
    "langue": "hebreu",
    "numero": 8,
    "mot_original": "אֹבֵד",
    "translitteration": "ʾōḇēḏ",
    "prononciation": "ʾōḇēḏ",
    "definition": "Destruction, ruine ; ce qui est sur le point de périr.",
    "categorie": "Nom commun (substantif dérivé du participe",
    "references": [
      "Proverbes 31:6"
    ],
    "type": "nom commun (substantif dérivé du participe",
    "occurrences": 2,
    "recherche": "h8 אֹבֵד ʾōḇēḏ destruction, ruine ; ce qui est sur le point de périr. nom commun (substantif dérivé du participe",
    "audio": "",
    "image": null
  },
  {
    "id": 200003,
    "strong": "H9",
    "langue": "hebreu",
    "numero": 9,
    "mot_original": "אֲבֵדָה",
    "translitteration": "ʾăḇēḏāh",
    "prononciation": "ʾăḇēḏāh",
    "definition": "Chose perdue, objet égaré.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 22:3"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h9 אֲבֵדָה ʾăḇēḏāh chose perdue, objet égaré. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200004,
    "strong": "H10",
    "langue": "hebreu",
    "numero": 10,
    "mot_original": "אֲבַדֹּה",
    "translitteration": "ʾăḇaddōh",
    "prononciation": "ʾăḇaddōh",
    "definition": "Ruine, destruction, lieu de perdition.",
    "categorie": "Nom commun",
    "references": [
      "Proverbes 27:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h10 אֲבַדֹּה ʾăḇaddōh ruine, destruction, lieu de perdition. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200005,
    "strong": "H11",
    "langue": "hebreu",
    "numero": 11,
    "mot_original": "אֲבַדּוֹן",
    "translitteration": "ʾăḇaddōn",
    "prononciation": "ʾăḇaddōn",
    "definition": "Abaddon. Lieu de destruction ; personnification du monde souterrain.",
    "categorie": "Nom commun / nom propre",
    "references": [
      "Job 26:6",
      "Proverbes 15:11"
    ],
    "type": "nom commun / nom propre",
    "occurrences": 5,
    "recherche": "h11 אֲבַדּוֹן ʾăḇaddōn abaddon. lieu de destruction ; personnification du monde souterrain. nom commun / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200006,
    "strong": "H12",
    "langue": "hebreu",
    "numero": 12,
    "mot_original": "אַבְדָן",
    "translitteration": "ʾaḇdān",
    "prononciation": "ʾaḇdān",
    "definition": "Destruction, anéantissement.",
    "categorie": "Nom commun",
    "references": [
      "Esther 9:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h12 אַבְדָן ʾaḇdān destruction, anéantissement. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200007,
    "strong": "H13",
    "langue": "hebreu",
    "numero": 13,
    "mot_original": "אָבְדַן",
    "translitteration": "ʾoḇdan",
    "prononciation": "ʾoḇdan",
    "definition": "Destruction. Correspondance araméenne de l'hébreu אַבְדָן (H0012).",
    "categorie": "Nom commun",
    "references": [
      "Daniel 2:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h13 אָבְדַן ʾoḇdan destruction. correspondance araméenne de l'hébreu אַבְדָן (h0012). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200008,
    "strong": "H14",
    "langue": "hebreu",
    "numero": 14,
    "mot_original": "אָבָה",
    "translitteration": "ʾāḇāh",
    "prononciation": "ʾāḇāh",
    "definition": "Consentir, vouloir, être disposé à, accepter.",
    "categorie": "Verbe",
    "references": [
      "Deutéronome 25:7",
      "Ésaïe 1:19"
    ],
    "type": "verbe",
    "occurrences": 54,
    "recherche": "h14 אָבָה ʾāḇāh consentir, vouloir, être disposé à, accepter. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200009,
    "strong": "H15",
    "langue": "hebreu",
    "numero": 15,
    "mot_original": "אָבֶה",
    "translitteration": "ʾāḇeh",
    "prononciation": "ʾāḇeh",
    "definition": "Souhait, désir, volonté.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 23:6"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h15 אָבֶה ʾāḇeh souhait, désir, volonté. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200010,
    "strong": "H16",
    "langue": "hebreu",
    "numero": 16,
    "mot_original": "אֵבֶה",
    "translitteration": "ʾēḇeh",
    "prononciation": "ʾēḇeh",
    "definition": "Roseau, papyrus, plante aquatique.",
    "categorie": "Nom commun",
    "references": [
      "Job 9:26"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h16 אֵבֶה ʾēḇeh roseau, papyrus, plante aquatique. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200011,
    "strong": "H17",
    "langue": "hebreu",
    "numero": 17,
    "mot_original": "אֲבוֹי",
    "translitteration": "ʾăḇôy",
    "prononciation": "ʾăḇôy",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Interjection",
    "references": [
      "Proverbes 23:29"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h17 אֲבוֹי ʾăḇôy ah ! hélas ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null
  },
  {
    "id": 200012,
    "strong": "H18",
    "langue": "hebreu",
    "numero": 18,
    "mot_original": "אֵבוּס",
    "translitteration": "ʾēḇûs",
    "prononciation": "ʾēḇûs",
    "definition": "Mangeoire, crèche pour le bétail.",
    "categorie": "Nom commun",
    "references": [
      "Ésaïe 1:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h18 אֵבוּס ʾēḇûs mangeoire, crèche pour le bétail. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200013,
    "strong": "H19",
    "langue": "hebreu",
    "numero": 19,
    "mot_original": "אִבְחָה",
    "translitteration": "ʾiḇḥāh",
    "prononciation": "ʾiḇḥāh",
    "definition": "Épée, lame, pointe. Plus probablement : frayeur, terreur soudaine.",
    "categorie": "Nom commun",
    "references": [
      "Ézéchiel 21:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h19 אִבְחָה ʾiḇḥāh épée, lame, pointe. plus probablement : frayeur, terreur soudaine. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200014,
    "strong": "H20",
    "langue": "hebreu",
    "numero": 20,
    "mot_original": "אֲבַטִּיחַ",
    "translitteration": "ʾăḇaṭṭîaḥ",
    "prononciation": "ʾăḇaṭṭîaḥ",
    "definition": "Pastèque, melon d'eau (Citrullus lanatus).",
    "categorie": "Nom commun",
    "references": [
      "Nombres 11:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h20 אֲבַטִּיחַ ʾăḇaṭṭîaḥ pastèque, melon d'eau (citrullus lanatus). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200015,
    "strong": "H21",
    "langue": "hebreu",
    "numero": 21,
    "mot_original": "אֲבִי",
    "translitteration": "ʾăḇî",
    "prononciation": "ʾăḇî",
    "definition": "Abi, nom propre féminin. Mère du roi Ézéchias.",
    "categorie": "Nom propre",
    "references": [
      "2 Rois 18:2"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h21 אֲבִי ʾăḇî abi, nom propre féminin. mère du roi ézéchias. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200016,
    "strong": "H22",
    "langue": "hebreu",
    "numero": 22,
    "mot_original": "אֲבִיאֵל",
    "translitteration": "ʾăḇîʾēl",
    "prononciation": "ʾăḇîʾēl",
    "definition": "Abiel, « Dieu est mon père » ou « mon père est Dieu ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 9:1"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h22 אֲבִיאֵל ʾăḇîʾēl abiel, « dieu est mon père » ou « mon père est dieu ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200017,
    "strong": "H23",
    "langue": "hebreu",
    "numero": 23,
    "mot_original": "אֲבִיאָסָף",
    "translitteration": "ʾăḇîʾāsāp̄",
    "prononciation": "ʾăḇîʾāsāp̄",
    "definition": "Abiasaph, « mon père a rassemblé » ou « le père du rassemblement ».",
    "categorie": "Nom propre",
    "references": [
      "Exode 6:24"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h23 אֲבִיאָסָף ʾăḇîʾāsāp̄ abiasaph, « mon père a rassemblé » ou « le père du rassemblement ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200018,
    "strong": "H24",
    "langue": "hebreu",
    "numero": 24,
    "mot_original": "אָבִיב",
    "translitteration": "ʾāḇîḇ",
    "prononciation": "ʾāḇîḇ",
    "definition": "Épi mûr, épi tendre ; mois des épis (printemps).",
    "categorie": "Nom commun",
    "references": [
      "Exode 13:4"
    ],
    "type": "nom commun",
    "occurrences": 8,
    "recherche": "h24 אָבִיב ʾāḇîḇ épi mûr, épi tendre ; mois des épis (printemps). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200019,
    "strong": "H25",
    "langue": "hebreu",
    "numero": 25,
    "mot_original": "אֲבִי גִבְעוֹן",
    "translitteration": "ʾăḇî ḡiḇʿôn",
    "prononciation": "ʾăḇî ḡiḇʿôn",
    "definition": "Abi-Gibeon, « père de Gibeon ». Nom ou titre d'un personnage benjaminite.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:29"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h25 אֲבִי גִבְעוֹן ʾăḇî ḡiḇʿôn abi-gibeon, « père de gibeon ». nom ou titre d'un personnage benjaminite. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200020,
    "strong": "H26",
    "langue": "hebreu",
    "numero": 26,
    "mot_original": "אֲבִיגַיִל",
    "translitteration": "ʾăḇîḡayil",
    "prononciation": "ʾăḇîḡayil",
    "definition": "Abigaïl, « mon père est joie » ou « père de l'exultation ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 25:3"
    ],
    "type": "nom propre",
    "occurrences": 17,
    "recherche": "h26 אֲבִיגַיִל ʾăḇîḡayil abigaïl, « mon père est joie » ou « père de l'exultation ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200021,
    "strong": "H27",
    "langue": "hebreu",
    "numero": 27,
    "mot_original": "אֲבִידָן",
    "translitteration": "ʾăḇîḏān",
    "prononciation": "ʾăḇîḏān",
    "definition": "Abidan, « mon père a jugé » ou « père du jugement ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 1:11"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h27 אֲבִידָן ʾăḇîḏān abidan, « mon père a jugé » ou « père du jugement ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200022,
    "strong": "H28",
    "langue": "hebreu",
    "numero": 28,
    "mot_original": "אֲבִידָע",
    "translitteration": "ʾăḇîḏāʿ",
    "prononciation": "ʾăḇîḏāʿ",
    "definition": "Abida, « mon père a connu » ou « père de la connaissance ».",
    "categorie": "Nom propre",
    "references": [
      "Genèse 25:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h28 אֲבִידָע ʾăḇîḏāʿ abida, « mon père a connu » ou « père de la connaissance ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200023,
    "strong": "H29",
    "langue": "hebreu",
    "numero": 29,
    "mot_original": "אֲבִיָּה",
    "translitteration": "ʾăḇîyāh",
    "prononciation": "ʾăḇîyāh",
    "definition": "Abiya, Abiyahu, « YHWH est mon père ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 14:1"
    ],
    "type": "nom propre",
    "occurrences": 25,
    "recherche": "h29 אֲבִיָּה ʾăḇîyāh abiya, abiyahu, « yhwh est mon père ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200024,
    "strong": "H30",
    "langue": "hebreu",
    "numero": 30,
    "mot_original": "אֲבִיהוּא",
    "translitteration": "ʾăḇîhûʾ",
    "prononciation": "ʾăḇîhûʾ",
    "definition": "Abihu, « lui (YHWH) est mon père ».",
    "categorie": "Nom propre",
    "references": [
      "Lévitique 10:1"
    ],
    "type": "nom propre",
    "occurrences": 12,
    "recherche": "h30 אֲבִיהוּא ʾăḇîhûʾ abihu, « lui (yhwh) est mon père ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200025,
    "strong": "H31",
    "langue": "hebreu",
    "numero": 31,
    "mot_original": "אֲבִיהוּד",
    "translitteration": "ʾăḇîhûḏ",
    "prononciation": "ʾăḇîhûḏ",
    "definition": "Abihud, « mon père est majesté » ou « père de gloire ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:3"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h31 אֲבִיהוּד ʾăḇîhûḏ abihud, « mon père est majesté » ou « père de gloire ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200026,
    "strong": "H32",
    "langue": "hebreu",
    "numero": 32,
    "mot_original": "אֲבִיהַיִל",
    "translitteration": "ʾăḇîhayil",
    "prononciation": "ʾăḇîhayil",
    "definition": "Abihail, « mon père est force » ou « père de la force ».",
    "categorie": "Nom propre",
    "references": [
      "Esther 2:15"
    ],
    "type": "nom propre",
    "occurrences": 6,
    "recherche": "h32 אֲבִיהַיִל ʾăḇîhayil abihail, « mon père est force » ou « père de la force ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200027,
    "strong": "H33",
    "langue": "hebreu",
    "numero": 33,
    "mot_original": "אֲבִי הָעֶזְרִי",
    "translitteration": "ʾăḇî hāʿezrî",
    "prononciation": "ʾăḇî hāʿezrî",
    "definition": "Abiézerite, membre du clan d'Abiézer, de la tribu de Manassé.",
    "categorie": "Nom propre (gentilé)",
    "references": [
      "Juges 6:11"
    ],
    "type": "nom propre (gentilé)",
    "occurrences": 3,
    "recherche": "h33 אֲבִי הָעֶזְרִי ʾăḇî hāʿezrî abiézerite, membre du clan d'abiézer, de la tribu de manassé. nom propre (gentilé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200028,
    "strong": "H34",
    "langue": "hebreu",
    "numero": 34,
    "mot_original": "אֶבְיוֹן",
    "translitteration": "ʾeḇyôn",
    "prononciation": "ʾeḇyôn",
    "definition": "Pauvre, indigent, nécessiteux, celui qui manque de ressources.",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Exode 23:11",
      "Deutéronome 15:7"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 61,
    "recherche": "h34 אֶבְיוֹן ʾeḇyôn pauvre, indigent, nécessiteux, celui qui manque de ressources. adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200029,
    "strong": "H35",
    "langue": "hebreu",
    "numero": 35,
    "mot_original": "אֲבִיּוֹנָה",
    "translitteration": "ʾăḇîyônāh",
    "prononciation": "ʾăḇîyônāh",
    "definition": "Câpre, fruit du câprier (Capparis spinosa).",
    "categorie": "Nom commun",
    "references": [
      "Ecclésiaste 12:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h35 אֲבִיּוֹנָה ʾăḇîyônāh câpre, fruit du câprier (capparis spinosa). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200030,
    "strong": "H36",
    "langue": "hebreu",
    "numero": 36,
    "mot_original": "אֲבִיטוּב",
    "translitteration": "ʾăḇîṭûḇ",
    "prononciation": "ʾăḇîṭûḇ",
    "definition": "Abitub, « mon père est bonté » ou « père de la bonté ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:11"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h36 אֲבִיטוּב ʾăḇîṭûḇ abitub, « mon père est bonté » ou « père de la bonté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200031,
    "strong": "H37",
    "langue": "hebreu",
    "numero": 37,
    "mot_original": "אֲבִיטָל",
    "translitteration": "ʾăḇîṭāl",
    "prononciation": "ʾăḇîṭāl",
    "definition": "Abital, « mon père est rosée » ou « père de la rosée ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 3:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h37 אֲבִיטָל ʾăḇîṭāl abital, « mon père est rosée » ou « père de la rosée ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200032,
    "strong": "H38",
    "langue": "hebreu",
    "numero": 38,
    "mot_original": "אֲבִיָּם",
    "translitteration": "ʾăḇîyām",
    "prononciation": "ʾăḇîyām",
    "definition": "Abiyam, \"mon père est Yām (Mer)\" ou forme alternative de Abiya. Roi de Juda, fils de Roboam.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 14:31"
    ],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h38 אֲבִיָּם ʾăḇîyām abiyam, \"mon père est yām (mer)\" ou forme alternative de abiya. roi de juda, fils de roboam. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200033,
    "strong": "H39",
    "langue": "hebreu",
    "numero": 39,
    "mot_original": "אֲבִימָאֵל",
    "translitteration": "ʾăḇîmāʾēl",
    "prononciation": "ʾăḇîmāʾēl",
    "definition": "Abimaël, \"mon père est vraiment Dieu\" ou \"le père est de Dieu\". Descendant de Sem.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 10:28"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h39 אֲבִימָאֵל ʾăḇîmāʾēl abimaël, \"mon père est vraiment dieu\" ou \"le père est de dieu\". descendant de sem. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200034,
    "strong": "H40",
    "langue": "hebreu",
    "numero": 40,
    "mot_original": "אֲבִימֶלֶךְ",
    "translitteration": "ʾăḇîmeleḵ",
    "prononciation": "ʾăḇîmeleḵ",
    "definition": "Abimélek, \"mon père est roi\" ou \"le père (divin) est roi\".",
    "categorie": "Nom propre",
    "references": [
      "Genèse 20:2"
    ],
    "type": "nom propre",
    "occurrences": 67,
    "recherche": "h40 אֲבִימֶלֶךְ ʾăḇîmeleḵ abimélek, \"mon père est roi\" ou \"le père (divin) est roi\". nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200035,
    "strong": "H41",
    "langue": "hebreu",
    "numero": 41,
    "mot_original": "אֲבִינָדָב",
    "translitteration": "ʾăḇînāḏāḇ",
    "prononciation": "ʾăḇînāḏāḇ",
    "definition": "Abinadab, « mon père est noble » ou « père de la noblesse ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 7:1"
    ],
    "type": "nom propre",
    "occurrences": 12,
    "recherche": "h41 אֲבִינָדָב ʾăḇînāḏāḇ abinadab, « mon père est noble » ou « père de la noblesse ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200036,
    "strong": "H42",
    "langue": "hebreu",
    "numero": 42,
    "mot_original": "אֲבִינֹעַם",
    "translitteration": "ʾăḇînōʿam",
    "prononciation": "ʾăḇînōʿam",
    "definition": "Abinoam, « mon père est plaisir » ou « père de la douceur ».",
    "categorie": "Nom propre",
    "references": [
      "Juges 4:6"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h42 אֲבִינֹעַם ʾăḇînōʿam abinoam, « mon père est plaisir » ou « père de la douceur ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200037,
    "strong": "H43",
    "langue": "hebreu",
    "numero": 43,
    "mot_original": "אֶבְיָסָף",
    "translitteration": "ʾeḇyāsāp̄",
    "prononciation": "ʾeḇyāsāp̄",
    "definition": "Ebyasaph, variante orthographique de Abiasaph (H0023).",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 6:8"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h43 אֶבְיָסָף ʾeḇyāsāp̄ ebyasaph, variante orthographique de abiasaph (h0023). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200038,
    "strong": "H44",
    "langue": "hebreu",
    "numero": 44,
    "mot_original": "אֲבִיעֶזֶר",
    "translitteration": "ʾăḇîʿezer",
    "prononciation": "ʾăḇîʿezer",
    "definition": "Abiézer, « mon père est secours » ou « père du secours ».",
    "categorie": "Nom propre",
    "references": [
      "Juges 6:34"
    ],
    "type": "nom propre",
    "occurrences": 7,
    "recherche": "h44 אֲבִיעֶזֶר ʾăḇîʿezer abiézer, « mon père est secours » ou « père du secours ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200039,
    "strong": "H45",
    "langue": "hebreu",
    "numero": 45,
    "mot_original": "אֲבִי־עַלְבוֹן",
    "translitteration": "ʾăḇî-ʿalḇôn",
    "prononciation": "ʾăḇî-ʿalḇôn",
    "definition": "Abi-Albon, « père de force » ou nom composé incluant עַלְבוֹן.",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 23:31"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h45 אֲבִי־עַלְבוֹן ʾăḇî-ʿalḇôn abi-albon, « père de force » ou nom composé incluant עַלְבוֹן. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200040,
    "strong": "H46",
    "langue": "hebreu",
    "numero": 46,
    "mot_original": "אָבִיר",
    "translitteration": "ʾāḇîr",
    "prononciation": "ʾāḇîr",
    "definition": "Fort, puissant, taureau (métaphore de puissance).",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Genèse 49:24",
      "Ésaïe 1:24"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 6,
    "recherche": "h46 אָבִיר ʾāḇîr fort, puissant, taureau (métaphore de puissance). adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200041,
    "strong": "H47",
    "langue": "hebreu",
    "numero": 47,
    "mot_original": "אַבִּיר",
    "translitteration": "ʾabbîr",
    "prononciation": "ʾabbîr",
    "definition": "Puissant, fort, taureau ; coursier, destrier.",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Juges 5:22",
      "Psaume 22:13"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 17,
    "recherche": "h47 אַבִּיר ʾabbîr puissant, fort, taureau ; coursier, destrier. adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200042,
    "strong": "H48",
    "langue": "hebreu",
    "numero": 48,
    "mot_original": "אֲבִירָם",
    "translitteration": "ʾăḇîrām",
    "prononciation": "ʾăḇîrām",
    "definition": "Abiram, « mon père est exalté » ou « le père (divin) est exalté ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 16:1",
      "1 Rois 16:34"
    ],
    "type": "nom propre",
    "occurrences": 11,
    "recherche": "h48 אֲבִירָם ʾăḇîrām abiram, « mon père est exalté » ou « le père (divin) est exalté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200043,
    "strong": "H49",
    "langue": "hebreu",
    "numero": 49,
    "mot_original": "אֲבִישַׁג",
    "translitteration": "ʾăḇîšaḡ",
    "prononciation": "ʾăḇîšaḡ",
    "definition": "Abishag, « mon père est errance » ou signification incertaine.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 1:3"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h49 אֲבִישַׁג ʾăḇîšaḡ abishag, « mon père est errance » ou signification incertaine. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200044,
    "strong": "H50",
    "langue": "hebreu",
    "numero": 50,
    "mot_original": "אֲבִישׁוּעַ",
    "translitteration": "ʾăḇîšûaʿ",
    "prononciation": "ʾăḇîšûaʿ",
    "definition": "Abishua, « mon père est salut » ou « père du salut ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 5:30"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h50 אֲבִישׁוּעַ ʾăḇîšûaʿ abishua, « mon père est salut » ou « père du salut ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200045,
    "strong": "H51",
    "langue": "hebreu",
    "numero": 51,
    "mot_original": "אֲבִישׁוּר",
    "translitteration": "ʾăḇîšûr",
    "prononciation": "ʾăḇîšûr",
    "definition": "Abishur, « mon père est muraille » ou « père de la muraille ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 2:28"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h51 אֲבִישׁוּר ʾăḇîšûr abishur, « mon père est muraille » ou « père de la muraille ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200046,
    "strong": "H52",
    "langue": "hebreu",
    "numero": 52,
    "mot_original": "אֲבִישַׁי",
    "translitteration": "ʾăḇîšay",
    "prononciation": "ʾăḇîšay",
    "definition": "Abishaï, « mon père est présent » ou « père du don ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 26:8"
    ],
    "type": "nom propre",
    "occurrences": 25,
    "recherche": "h52 אֲבִישַׁי ʾăḇîšay abishaï, « mon père est présent » ou « père du don ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200047,
    "strong": "H53",
    "langue": "hebreu",
    "numero": 53,
    "mot_original": "אֲבִישָׁלוֹם",
    "translitteration": "ʾăḇîšālôm",
    "prononciation": "ʾăḇîšālôm",
    "definition": "Abishalom, « mon père est paix » ou « père de la paix ». Variante de Absalom.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 15:2"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h53 אֲבִישָׁלוֹם ʾăḇîšālôm abishalom, « mon père est paix » ou « père de la paix ». variante de absalom. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200048,
    "strong": "H54",
    "langue": "hebreu",
    "numero": 54,
    "mot_original": "אֶבְיָתָר",
    "translitteration": "ʾeḇyāṯār",
    "prononciation": "ʾeḇyāṯār",
    "definition": "Ébyatar, Abiathar, « le père (divin) a pourvu » ou « père de l'abondance ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 22:20"
    ],
    "type": "nom propre",
    "occurrences": 30,
    "recherche": "h54 אֶבְיָתָר ʾeḇyāṯār ébyatar, abiathar, « le père (divin) a pourvu » ou « père de l'abondance ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200049,
    "strong": "H55",
    "langue": "hebreu",
    "numero": 55,
    "mot_original": "אָבַךְ",
    "translitteration": "ʾāḇaḵ",
    "prononciation": "ʾāḇaḵ",
    "definition": "S'enrouler, monter en spirale, tourbillonner (en parlant de fumée ou de poussière).",
    "categorie": "Verbe",
    "references": [
      "Juges 7:13"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h55 אָבַךְ ʾāḇaḵ s'enrouler, monter en spirale, tourbillonner (en parlant de fumée ou de poussière). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200050,
    "strong": "H56",
    "langue": "hebreu",
    "numero": 56,
    "mot_original": "אָבַל",
    "translitteration": "ʾāḇal",
    "prononciation": "ʾāḇal",
    "definition": "Être en deuil, mener le deuil, se lamenter.",
    "categorie": "Verbe",
    "references": [
      "Ésaïe 24:4"
    ],
    "type": "verbe",
    "occurrences": 8,
    "recherche": "h56 אָבַל ʾāḇal être en deuil, mener le deuil, se lamenter. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200051,
    "strong": "H57",
    "langue": "hebreu",
    "numero": 57,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "En deuil, affligé, portant le deuil.",
    "categorie": "Adjectif",
    "references": [
      "Ésaïe 61:3"
    ],
    "type": "adjectif",
    "occurrences": 8,
    "recherche": "h57 אָבֵל ʾāḇēl en deuil, affligé, portant le deuil. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200052,
    "strong": "H58",
    "langue": "hebreu",
    "numero": 58,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "Prairie, pâturage arrosé, cours d'eau.",
    "categorie": "Nom commun",
    "references": [
      "Juges 11:33"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h58 אָבֵל ʾāḇēl prairie, pâturage arrosé, cours d'eau. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200053,
    "strong": "H59",
    "langue": "hebreu",
    "numero": 59,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "Abel, nom de plusieurs localités en Israël et en Transjordanie.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "2 Samuel 20:18"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 7,
    "recherche": "h59 אָבֵל ʾāḇēl abel, nom de plusieurs localités en israël et en transjordanie. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200054,
    "strong": "H60",
    "langue": "hebreu",
    "numero": 60,
    "mot_original": "אֵבֶל",
    "translitteration": "ʾēḇel",
    "prononciation": "ʾēḇel",
    "definition": "Deuil, lamentation funèbre, cérémonie de deuil.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 50:11"
    ],
    "type": "nom commun",
    "occurrences": 24,
    "recherche": "h60 אֵבֶל ʾēḇel deuil, lamentation funèbre, cérémonie de deuil. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200055,
    "strong": "H61",
    "langue": "hebreu",
    "numero": 61,
    "mot_original": "אֲבָל",
    "translitteration": "ʾăḇāl",
    "prononciation": "ʾăḇāl",
    "definition": "Mais, cependant, toutefois, vraiment, certainement.",
    "categorie": "Adverbe / conjonction",
    "references": [
      "Genèse 17:19",
      "2 Samuel 14:5"
    ],
    "type": "adverbe / conjonction",
    "occurrences": 11,
    "recherche": "h61 אֲבָל ʾăḇāl mais, cependant, toutefois, vraiment, certainement. adverbe / conjonction",
    "audio": "",
    "image": null
  },
  {
    "id": 200056,
    "strong": "H62",
    "langue": "hebreu",
    "numero": 62,
    "mot_original": "אָבֵל בֵּית־מַעֲכָה",
    "translitteration": "ʾāḇēl bêṯ-maʿăḵāh",
    "prononciation": "ʾāḇēl bêṯ-maʿăḵāh",
    "definition": "Abel-Beth-Maaka, « prairie de la maison de Maaka », ville fortifiée du nord d'Israël.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "2 Samuel 20:14"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 4,
    "recherche": "h62 אָבֵל בֵּית־מַעֲכָה ʾāḇēl bêṯ-maʿăḵāh abel-beth-maaka, « prairie de la maison de maaka », ville fortifiée du nord d'israël. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200057,
    "strong": "H63",
    "langue": "hebreu",
    "numero": 63,
    "mot_original": "אָבֵל הַשִּׁטִּים",
    "translitteration": "ʾāḇēl haššiṭṭîm",
    "prononciation": "ʾāḇēl haššiṭṭîm",
    "definition": "Abel-Shittim, « prairie des acacias », dernier campement israélite en Transjordanie.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Nombres 33:49"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h63 אָבֵל הַשִּׁטִּים ʾāḇēl haššiṭṭîm abel-shittim, « prairie des acacias », dernier campement israélite en transjordanie. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200058,
    "strong": "H64",
    "langue": "hebreu",
    "numero": 64,
    "mot_original": "אָבֵל כְּרָמִים",
    "translitteration": "ʾāḇēl kərāmîm",
    "prononciation": "ʾāḇēl kərāmîm",
    "definition": "Abel-Keramim, « prairie des vignes », localité ammonite.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Juges 11:33"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h64 אָבֵל כְּרָמִים ʾāḇēl kərāmîm abel-keramim, « prairie des vignes », localité ammonite. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200059,
    "strong": "H65",
    "langue": "hebreu",
    "numero": 65,
    "mot_original": "אָבֵל מְחוֹלָה",
    "translitteration": "ʾāḇēl məḥôlāh",
    "prononciation": "ʾāḇēl məḥôlāh",
    "definition": "Abel-Meholah, « prairie de la danse », ville de la vallée du Jourdain.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "1 Rois 19:16"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 3,
    "recherche": "h65 אָבֵל מְחוֹלָה ʾāḇēl məḥôlāh abel-meholah, « prairie de la danse », ville de la vallée du jourdain. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200060,
    "strong": "H66",
    "langue": "hebreu",
    "numero": 66,
    "mot_original": "אָבֵל מַיִם",
    "translitteration": "ʾāḇēl mayim",
    "prononciation": "ʾāḇēl mayim",
    "definition": "Abel-Maïm, « prairie des eaux », variante de Abel-Beth-Maaka.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "2 Chroniques 16:4"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h66 אָבֵל מַיִם ʾāḇēl mayim abel-maïm, « prairie des eaux », variante de abel-beth-maaka. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200061,
    "strong": "H67",
    "langue": "hebreu",
    "numero": 67,
    "mot_original": "אָבֵל מִצְרַיִם",
    "translitteration": "ʾāḇēl miṣrayim",
    "prononciation": "ʾāḇēl miṣrayim",
    "definition": "Abel-Mitsraïm, « deuil de l'Égypte », nom donné à l'aire d'Atad après la cérémonie funèbre de Jacob.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Genèse 50:11"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h67 אָבֵל מִצְרַיִם ʾāḇēl miṣrayim abel-mitsraïm, « deuil de l'égypte », nom donné à l'aire d'atad après la cérémonie funèbre de jacob. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200062,
    "strong": "H68",
    "langue": "hebreu",
    "numero": 68,
    "mot_original": "אֶבֶן",
    "translitteration": "ʾeḇen",
    "prononciation": "ʾeḇen",
    "definition": "Pierre, roche, bloc de pierre.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 28:18",
      "Exode 31:18"
    ],
    "type": "nom commun",
    "occurrences": 273,
    "recherche": "h68 אֶבֶן ʾeḇen pierre, roche, bloc de pierre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200063,
    "strong": "H69",
    "langue": "hebreu",
    "numero": 69,
    "mot_original": "אֶבֶן",
    "translitteration": "ʾeḇen",
    "prononciation": "ʾeḇen",
    "definition": "Pierre. Correspondance araméenne de l'hébreu אֶבֶן (H0068).",
    "categorie": "Nom commun",
    "references": [
      "Daniel 2:34",
      "Esdras 6:4"
    ],
    "type": "nom commun",
    "occurrences": 8,
    "recherche": "h69 אֶבֶן ʾeḇen pierre. correspondance araméenne de l'hébreu אֶבֶן (h0068). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200064,
    "strong": "H70",
    "langue": "hebreu",
    "numero": 70,
    "mot_original": "אֹבֶן",
    "translitteration": "ʾōḇen",
    "prononciation": "ʾōḇen",
    "definition": "Siège d'accouchement, pierres sur lesquelles la femme s'accroupissait pour accoucher.",
    "categorie": "Nom commun",
    "references": [
      "Exode 1:16",
      "Jérémie 18:3"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h70 אֹבֶן ʾōḇen siège d'accouchement, pierres sur lesquelles la femme s'accroupissait pour accoucher. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200065,
    "strong": "H71",
    "langue": "hebreu",
    "numero": 71,
    "mot_original": "אֲבָנָה",
    "translitteration": "ʾăḇānāh",
    "prononciation": "ʾăḇānāh",
    "definition": "Abana, rivière de Damas mentionnée par Naaman.",
    "categorie": "Nom propre",
    "references": [
      "2 Rois 5:12"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h71 אֲבָנָה ʾăḇānāh abana, rivière de damas mentionnée par naaman. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200066,
    "strong": "H72",
    "langue": "hebreu",
    "numero": 72,
    "mot_original": "אֶבֶן הָעֵזֶר",
    "translitteration": "ʾeḇen hāʿēzer",
    "prononciation": "ʾeḇen hāʿēzer",
    "definition": "Eben-Ezer, « pierre du secours ». Nom commémoratif donné par Samuel à un lieu de victoire contre les Philistins.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "1 Samuel 7:12"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 3,
    "recherche": "h72 אֶבֶן הָעֵזֶר ʾeḇen hāʿēzer eben-ezer, « pierre du secours ». nom commémoratif donné par samuel à un lieu de victoire contre les philistins. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200067,
    "strong": "H73",
    "langue": "hebreu",
    "numero": 73,
    "mot_original": "אַבְנֵט",
    "translitteration": "ʾaḇnēṭ",
    "prononciation": "ʾaḇnēṭ",
    "definition": "Ceinture, écharpe, baudrier sacerdotal.",
    "categorie": "Nom commun",
    "references": [
      "Exode 28:4"
    ],
    "type": "nom commun",
    "occurrences": 9,
    "recherche": "h73 אַבְנֵט ʾaḇnēṭ ceinture, écharpe, baudrier sacerdotal. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200068,
    "strong": "H74",
    "langue": "hebreu",
    "numero": 74,
    "mot_original": "אַבְנֵר",
    "translitteration": "ʾaḇnēr",
    "prononciation": "ʾaḇnēr",
    "definition": "Abner, « mon père est lampe » ou « père de la lumière ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 14:50"
    ],
    "type": "nom propre",
    "occurrences": 62,
    "recherche": "h74 אַבְנֵר ʾaḇnēr abner, « mon père est lampe » ou « père de la lumière ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200069,
    "strong": "H75",
    "langue": "hebreu",
    "numero": 75,
    "mot_original": "אָבַס",
    "translitteration": "ʾāḇas",
    "prononciation": "ʾāḇas",
    "definition": "Engraisser, nourrir abondamment le bétail à l'étable.",
    "categorie": "Verbe",
    "references": [
      "Proverbes 15:17"
    ],
    "type": "verbe",
    "occurrences": 2,
    "recherche": "h75 אָבַס ʾāḇas engraisser, nourrir abondamment le bétail à l'étable. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200070,
    "strong": "H76",
    "langue": "hebreu",
    "numero": 76,
    "mot_original": "אֲבַעְבֻּעָה",
    "translitteration": "ʾăḇaʿbuʿāh",
    "prononciation": "ʾăḇaʿbuʿāh",
    "definition": "Pustule, ampoule, vésicule cutanée (sixième plaie d'Égypte).",
    "categorie": "Nom commun",
    "references": [
      "Exode 9:9"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h76 אֲבַעְבֻּעָה ʾăḇaʿbuʿāh pustule, ampoule, vésicule cutanée (sixième plaie d'égypte). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200071,
    "strong": "H77",
    "langue": "hebreu",
    "numero": 77,
    "mot_original": "אֶבֶץ",
    "translitteration": "ʾeḇeṣ",
    "prononciation": "ʾeḇeṣ",
    "definition": "Ébets, ville de la tribu d'Issachar.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "Josué 19:20"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h77 אֶבֶץ ʾeḇeṣ ébets, ville de la tribu d'issachar. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200072,
    "strong": "H78",
    "langue": "hebreu",
    "numero": 78,
    "mot_original": "אִבְצָן",
    "translitteration": "ʾiḇṣān",
    "prononciation": "ʾiḇṣān",
    "definition": "Ibtsan, juge d'Israël originaire de Bethléem.",
    "categorie": "Nom propre",
    "references": [
      "Juges 12:8"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h78 אִבְצָן ʾiḇṣān ibtsan, juge d'israël originaire de bethléem. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200073,
    "strong": "H79",
    "langue": "hebreu",
    "numero": 79,
    "mot_original": "אַבְשַׁי",
    "translitteration": "ʾaḇšay",
    "prononciation": "ʾaḇšay",
    "definition": "Abshaï, variante abrégée de Abishaï (H0052).",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 11:20"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h79 אַבְשַׁי ʾaḇšay abshaï, variante abrégée de abishaï (h0052). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200074,
    "strong": "H80",
    "langue": "hebreu",
    "numero": 80,
    "mot_original": "אָבָק",
    "translitteration": "ʾāḇāq",
    "prononciation": "ʾāḇāq",
    "definition": "Poussière fine, poudre impalpable.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 28:24",
      "Ésaïe 29:5"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h80 אָבָק ʾāḇāq poussière fine, poudre impalpable. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200075,
    "strong": "H81",
    "langue": "hebreu",
    "numero": 81,
    "mot_original": "אֲבָקָה",
    "translitteration": "ʾăḇāqāh",
    "prononciation": "ʾăḇāqāh",
    "definition": "Poudre aromatique, parfum en poudre.",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h81 אֲבָקָה ʾăḇāqāh poudre aromatique, parfum en poudre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200076,
    "strong": "H82",
    "langue": "hebreu",
    "numero": 82,
    "mot_original": "אָבַר",
    "translitteration": "ʾāḇar",
    "prononciation": "ʾāḇar",
    "definition": "Sens incertain. Possible « planer, voler » ou « être fort, puissant ».",
    "categorie": "Verbe",
    "references": [
      "Job 39:26"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h82 אָבַר ʾāḇar sens incertain. possible « planer, voler » ou « être fort, puissant ». verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200077,
    "strong": "H83",
    "langue": "hebreu",
    "numero": 83,
    "mot_original": "אֵבֶר",
    "translitteration": "ʾēḇer",
    "prononciation": "ʾēḇer",
    "definition": "Aile, penne, rémige (plume de l'aile).",
    "categorie": "Nom commun",
    "references": [
      "Psaume 55:7",
      "Ézéchiel 17:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h83 אֵבֶר ʾēḇer aile, penne, rémige (plume de l'aile). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200078,
    "strong": "H84",
    "langue": "hebreu",
    "numero": 84,
    "mot_original": "אֶבְרָה",
    "translitteration": "ʾeḇrāh",
    "prononciation": "ʾeḇrāh",
    "definition": "Penne, aile, plumage (forme féminine de H0083).",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 32:11",
      "Psaume 91:4"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h84 אֶבְרָה ʾeḇrāh penne, aile, plumage (forme féminine de h0083). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200079,
    "strong": "H85",
    "langue": "hebreu",
    "numero": 85,
    "mot_original": "אַבְרָהָם",
    "translitteration": "ʾaḇrāhām",
    "prononciation": "ʾaḇrāhām",
    "definition": "Abraham, « père d'une multitude » ou « père élevé ». Patriarche fondateur d'Israël.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 17:5"
    ],
    "type": "nom propre",
    "occurrences": 175,
    "recherche": "h85 אַבְרָהָם ʾaḇrāhām abraham, « père d'une multitude » ou « père élevé ». patriarche fondateur d'israël. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200080,
    "strong": "H86",
    "langue": "hebreu",
    "numero": 86,
    "mot_original": "אַבְרֵךְ",
    "translitteration": "ʾaḇrēḵ",
    "prononciation": "ʾaḇrēḵ",
    "definition": "À genoux ! Prosternez-vous ! Cri acclamant la dignité de Joseph comme vizir d'Égypte.",
    "categorie": "Interjection ou titre",
    "references": [
      "Genèse 41:43"
    ],
    "type": "interjection ou titre",
    "occurrences": 1,
    "recherche": "h86 אַבְרֵךְ ʾaḇrēḵ à genoux ! prosternez-vous ! cri acclamant la dignité de joseph comme vizir d'égypte. interjection ou titre",
    "audio": "",
    "image": null
  },
  {
    "id": 200081,
    "strong": "H87",
    "langue": "hebreu",
    "numero": 87,
    "mot_original": "אַבְרָם",
    "translitteration": "ʾaḇrām",
    "prononciation": "ʾaḇrām",
    "definition": "Abram, « le père (divin) est élevé » ou « père élevé ». Nom originel d'Abraham.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 11:27"
    ],
    "type": "nom propre",
    "occurrences": 61,
    "recherche": "h87 אַבְרָם ʾaḇrām abram, « le père (divin) est élevé » ou « père élevé ». nom originel d'abraham. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200082,
    "strong": "H88",
    "langue": "hebreu",
    "numero": 88,
    "mot_original": "אַבְשָׁלוֹם",
    "translitteration": "ʾaḇšālôm",
    "prononciation": "ʾaḇšālôm",
    "definition": "Absalom, « père de la paix » ou « mon père est paix ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 14:25"
    ],
    "type": "nom propre",
    "occurrences": 86,
    "recherche": "h88 אַבְשָׁלוֹם ʾaḇšālôm absalom, « père de la paix » ou « mon père est paix ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200083,
    "strong": "H89",
    "langue": "hebreu",
    "numero": 89,
    "mot_original": "אֲבִישַׁלֹם",
    "translitteration": "ʾăḇîšālōm",
    "prononciation": "ʾăḇîšālōm",
    "definition": "Abishalom, variante pleine de Absalom (H0088). Voir H0053.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 15:2"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h89 אֲבִישַׁלֹם ʾăḇîšālōm abishalom, variante pleine de absalom (h0088). voir h0053. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200084,
    "strong": "H90",
    "langue": "hebreu",
    "numero": 90,
    "mot_original": "אֶבְיָתָר",
    "translitteration": "ʾeḇyāṯār",
    "prononciation": "ʾeḇyāṯār",
    "definition": "Ébyatar. Voir H0054.",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 22:20"
    ],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h90 אֶבְיָתָר ʾeḇyāṯār ébyatar. voir h0054. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200085,
    "strong": "H91",
    "langue": "hebreu",
    "numero": 91,
    "mot_original": "אֲגָגִי",
    "translitteration": "ʾăḡāḡî",
    "prononciation": "ʾăḡāḡî",
    "definition": "Agaguite, descendant ou sujet d'Agag, roi amalécite.",
    "categorie": "Adjectif gentilé / nom propre",
    "references": [
      "Esther 3:1"
    ],
    "type": "adjectif gentilé / nom propre",
    "occurrences": 5,
    "recherche": "h91 אֲגָגִי ʾăḡāḡî agaguite, descendant ou sujet d'agag, roi amalécite. adjectif gentilé / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200086,
    "strong": "H92",
    "langue": "hebreu",
    "numero": 92,
    "mot_original": "אֲגֻדָּה",
    "translitteration": "ʾăḡuddāh",
    "prononciation": "ʾăḡuddāh",
    "definition": "Bande, faisceau, lien, groupe lié.",
    "categorie": "Nom commun",
    "references": [
      "Exode 12:22",
      "Job 38:31"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h92 אֲגֻדָּה ʾăḡuddāh bande, faisceau, lien, groupe lié. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200087,
    "strong": "H93",
    "langue": "hebreu",
    "numero": 93,
    "mot_original": "אֱגוֹז",
    "translitteration": "ʾĕḡôz",
    "prononciation": "ʾĕḡôz",
    "definition": "Noix, fruit du noyer (Juglans regia).",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h93 אֱגוֹז ʾĕḡôz noix, fruit du noyer (juglans regia). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200088,
    "strong": "H94",
    "langue": "hebreu",
    "numero": 94,
    "mot_original": "אָגוּר",
    "translitteration": "ʾāḡûr",
    "prononciation": "ʾāḡûr",
    "definition": "Agur, nom du sage auteur du chapitre 30 des Proverbes.",
    "categorie": "Nom propre",
    "references": [
      "Proverbes 30:1"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h94 אָגוּר ʾāḡûr agur, nom du sage auteur du chapitre 30 des proverbes. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200089,
    "strong": "H95",
    "langue": "hebreu",
    "numero": 95,
    "mot_original": "אֲגוֹרָה",
    "translitteration": "ʾăḡôrāh",
    "prononciation": "ʾăḡôrāh",
    "definition": "Pièce d'argent, petite monnaie, pourboire.",
    "categorie": "Nom commun",
    "references": [
      "1 Samuel 2:36"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h95 אֲגוֹרָה ʾăḡôrāh pièce d'argent, petite monnaie, pourboire. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200090,
    "strong": "H96",
    "langue": "hebreu",
    "numero": 96,
    "mot_original": "אֶגֶל",
    "translitteration": "ʾeḡel",
    "prononciation": "ʾeḡel",
    "definition": "Goutte, réserve d'eau. Variante poétique ou régionale de עֵגֶל (H5695, « veau ») ou mot distinct.",
    "categorie": "Nom commun",
    "references": [
      "Job 38:28"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h96 אֶגֶל ʾeḡel goutte, réserve d'eau. variante poétique ou régionale de עֵגֶל (h5695, « veau ») ou mot distinct. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200091,
    "strong": "H97",
    "langue": "hebreu",
    "numero": 97,
    "mot_original": "אֶגְלַיִם",
    "translitteration": "ʾeḡlayim",
    "prononciation": "ʾeḡlayim",
    "definition": "Églaïm, localité près de la mer Morte.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "Ézéchiel 47:10"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h97 אֶגְלַיִם ʾeḡlayim églaïm, localité près de la mer morte. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200092,
    "strong": "H98",
    "langue": "hebreu",
    "numero": 98,
    "mot_original": "אֲגַם",
    "translitteration": "ʾăḡam",
    "prononciation": "ʾăḡam",
    "definition": "Marais, étang, mare d'eau stagnante.",
    "categorie": "Nom commun",
    "references": [
      "Exode 7:19"
    ],
    "type": "nom commun",
    "occurrences": 9,
    "recherche": "h98 אֲגַם ʾăḡam marais, étang, mare d'eau stagnante. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200093,
    "strong": "H99",
    "langue": "hebreu",
    "numero": 99,
    "mot_original": "אָגֵם",
    "translitteration": "ʾāḡēm",
    "prononciation": "ʾāḡēm",
    "definition": "Triste, affligé, abattu.",
    "categorie": "Adjectif",
    "references": [],
    "type": "adjectif",
    "occurrences": 1,
    "recherche": "h99 אָגֵם ʾāḡēm triste, affligé, abattu. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200094,
    "strong": "H100",
    "langue": "hebreu",
    "numero": 100,
    "mot_original": "אַגְמוֹן",
    "translitteration": "ʾaḡmôn",
    "prononciation": "ʾaḡmôn",
    "definition": "Jonc, roseau ; métaphoriquement : crochet, hameçon.",
    "categorie": "Nom commun",
    "references": [
      "Job 40:26",
      "Ésaïe 58:5"
    ],
    "type": "nom commun",
    "occurrences": 5,
    "recherche": "h100 אַגְמוֹן ʾaḡmôn jonc, roseau ; métaphoriquement : crochet, hameçon. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200095,
    "strong": "H201",
    "langue": "hebreu",
    "numero": 201,
    "mot_original": "אוֹמָר",
    "translitteration": "ʾômār",
    "prononciation": "ʾômār",
    "definition": "Omar, nom d'un chef édomite, descendant d'Ésaü.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 36:11"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h201 אוֹמָר ʾômār omar, nom d'un chef édomite, descendant d'ésaü. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200096,
    "strong": "H202",
    "langue": "hebreu",
    "numero": 202,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "Vigueur, force, puissance virile ; richesse, prospérité.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 49:3",
      "Osée 12:9"
    ],
    "type": "nom commun",
    "occurrences": 12,
    "recherche": "h202 אוֹן ʾôn vigueur, force, puissance virile ; richesse, prospérité. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200097,
    "strong": "H203",
    "langue": "hebreu",
    "numero": 203,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "On, ville égyptienne, Héliopolis, centre du culte solaire.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 41:45"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 3,
    "recherche": "h203 אוֹן ʾôn on, ville égyptienne, héliopolis, centre du culte solaire. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200098,
    "strong": "H204",
    "langue": "hebreu",
    "numero": 204,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "On, nom de lieu. Probablement doublet ou variante de H0203 ou de אָוֶן (H0205).",
    "categorie": "Nom propre",
    "references": [],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h204 אוֹן ʾôn on, nom de lieu. probablement doublet ou variante de h0203 ou de אָוֶן (h0205). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200099,
    "strong": "H205",
    "langue": "hebreu",
    "numero": 205,
    "mot_original": "אָוֶן",
    "translitteration": "ʾāwen",
    "prononciation": "ʾāwen",
    "definition": "Malheur, iniquité, trouble ; vanité, néant ; idole.",
    "categorie": "Nom commun / nom propre",
    "references": [
      "Psaume 90:10",
      "Osée 4:15"
    ],
    "type": "nom commun / nom propre",
    "occurrences": 78,
    "recherche": "h205 אָוֶן ʾāwen malheur, iniquité, trouble ; vanité, néant ; idole. nom commun / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200100,
    "strong": "H206",
    "langue": "hebreu",
    "numero": 206,
    "mot_original": "אָוֶן",
    "translitteration": "ʾāwen",
    "prononciation": "ʾāwen",
    "definition": "Aven, nom de lieu. Doublet toponymique de H0205.",
    "categorie": "Nom propre",
    "references": [
      "Amos 1:5"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 0,
    "recherche": "h206 אָוֶן ʾāwen aven, nom de lieu. doublet toponymique de h0205. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200101,
    "strong": "H207",
    "langue": "hebreu",
    "numero": 207,
    "mot_original": "אוֹנוֹ",
    "translitteration": "ʾônô",
    "prononciation": "ʾônô",
    "definition": "Ono, ville de Benjamin, dans la plaine de Sharon.",
    "categorie": "Nom propre",
    "references": [
      "Néhémie 6:2"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 5,
    "recherche": "h207 אוֹנוֹ ʾônô ono, ville de benjamin, dans la plaine de sharon. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200102,
    "strong": "H208",
    "langue": "hebreu",
    "numero": 208,
    "mot_original": "אוֹנָם",
    "translitteration": "ʾônām",
    "prononciation": "ʾônām",
    "definition": "Onam, nom de deux descendants de Juda et d'Ésaü.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 36:23"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h208 אוֹנָם ʾônām onam, nom de deux descendants de juda et d'ésaü. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200103,
    "strong": "H209",
    "langue": "hebreu",
    "numero": 209,
    "mot_original": "אוֹנָן",
    "translitteration": "ʾônān",
    "prononciation": "ʾônān",
    "definition": "Onan, second fils de Juda et de la fille de Shua.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 38:9"
    ],
    "type": "nom propre",
    "occurrences": 6,
    "recherche": "h209 אוֹנָן ʾônān onan, second fils de juda et de la fille de shua. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200104,
    "strong": "H210",
    "langue": "hebreu",
    "numero": 210,
    "mot_original": "אוּפָז",
    "translitteration": "ʾûp̄āz",
    "prononciation": "ʾûp̄āz",
    "definition": "Ophaz, région productrice d'or, peut-être identique à Ophir.",
    "categorie": "Nom propre",
    "references": [
      "Daniel 10:5"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 2,
    "recherche": "h210 אוּפָז ʾûp̄āz ophaz, région productrice d'or, peut-être identique à ophir. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200105,
    "strong": "H211",
    "langue": "hebreu",
    "numero": 211,
    "mot_original": "אוֹפִיר",
    "translitteration": "ʾôp̄îr",
    "prononciation": "ʾôp̄îr",
    "definition": "Ophir, région légendaire productrice d'or fin, de pierres précieuses et de bois de santal.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 9:28"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 13,
    "recherche": "h211 אוֹפִיר ʾôp̄îr ophir, région légendaire productrice d'or fin, de pierres précieuses et de bois de santal. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200106,
    "strong": "H212",
    "langue": "hebreu",
    "numero": 212,
    "mot_original": "אוֹפָן",
    "translitteration": "ʾôp̄ān",
    "prononciation": "ʾôp̄ān",
    "definition": "Roue, disque, tourbillon.",
    "categorie": "Nom commun",
    "references": [
      "Ézéchiel 1:16"
    ],
    "type": "nom commun",
    "occurrences": 15,
    "recherche": "h212 אוֹפָן ʾôp̄ān roue, disque, tourbillon. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200107,
    "strong": "H213",
    "langue": "hebreu",
    "numero": 213,
    "mot_original": "אוּץ",
    "translitteration": "ʾûṣ",
    "prononciation": "ʾûṣ",
    "definition": "Presser, se hâter, inciter, contraindre.",
    "categorie": "Verbe",
    "references": [
      "Proverbes 19:2"
    ],
    "type": "verbe",
    "occurrences": 10,
    "recherche": "h213 אוּץ ʾûṣ presser, se hâter, inciter, contraindre. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200108,
    "strong": "H214",
    "langue": "hebreu",
    "numero": 214,
    "mot_original": "אוֹצָר",
    "translitteration": "ʾôṣār",
    "prononciation": "ʾôṣār",
    "definition": "Trésor, magasin, entrepôt, réserve.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 28:12"
    ],
    "type": "nom commun",
    "occurrences": 79,
    "recherche": "h214 אוֹצָר ʾôṣār trésor, magasin, entrepôt, réserve. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200109,
    "strong": "H215",
    "langue": "hebreu",
    "numero": 215,
    "mot_original": "אוֹר",
    "translitteration": "ʾôr",
    "prononciation": "ʾôr",
    "definition": "Être lumineux, briller ; éclairer, illuminer.",
    "categorie": "Verbe",
    "references": [
      "Genèse 1:15"
    ],
    "type": "verbe",
    "occurrences": 43,
    "recherche": "h215 אוֹר ʾôr être lumineux, briller ; éclairer, illuminer. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200110,
    "strong": "H216",
    "langue": "hebreu",
    "numero": 216,
    "mot_original": "אוֹר",
    "translitteration": "ʾôr",
    "prononciation": "ʾôr",
    "definition": "Lumière, clarté, rayonnement.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 1:3",
      "Psaume 119:105"
    ],
    "type": "nom commun",
    "occurrences": 123,
    "recherche": "h216 אוֹר ʾôr lumière, clarté, rayonnement. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200111,
    "strong": "H217",
    "langue": "hebreu",
    "numero": 217,
    "mot_original": "אוּר",
    "translitteration": "ʾûr",
    "prononciation": "ʾûr",
    "definition": "Flamme, feu, lumière ardente.",
    "categorie": "Nom commun",
    "references": [
      "Ésaïe 50:11"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h217 אוּר ʾûr flamme, feu, lumière ardente. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200112,
    "strong": "H218",
    "langue": "hebreu",
    "numero": 218,
    "mot_original": "אוּר",
    "translitteration": "ʾûr",
    "prononciation": "ʾûr",
    "definition": "Ur, « Ur des Chaldéens », ville de Mésopotamie, patrie d'Abraham.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 11:31"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 4,
    "recherche": "h218 אוּר ʾûr ur, « ur des chaldéens », ville de mésopotamie, patrie d'abraham. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200113,
    "strong": "H219",
    "langue": "hebreu",
    "numero": 219,
    "mot_original": "אוֹרָה",
    "translitteration": "ʾôrāh",
    "prononciation": "ʾôrāh",
    "definition": "Lumière, clarté, aurore.",
    "categorie": "Nom commun",
    "references": [
      "Psaume 139:12"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h219 אוֹרָה ʾôrāh lumière, clarté, aurore. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200114,
    "strong": "H220",
    "langue": "hebreu",
    "numero": 220,
    "mot_original": "אֲוֵרָה",
    "translitteration": "ʾăwērāh",
    "prononciation": "ʾăwērāh",
    "definition": "Abri, étable, logement pour le bétail.",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h220 אֲוֵרָה ʾăwērāh abri, étable, logement pour le bétail. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200115,
    "strong": "H221",
    "langue": "hebreu",
    "numero": 221,
    "mot_original": "אוּרִי",
    "translitteration": "ʾûrî",
    "prononciation": "ʾûrî",
    "definition": "Ouri, « ma lumière » ou « lumière de YHWH » (forme abrégée de אוריה).",
    "categorie": "Nom propre",
    "references": [
      "Exode 31:2"
    ],
    "type": "nom propre",
    "occurrences": 8,
    "recherche": "h221 אוּרִי ʾûrî ouri, « ma lumière » ou « lumière de yhwh » (forme abrégée de אוריה). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200116,
    "strong": "H222",
    "langue": "hebreu",
    "numero": 222,
    "mot_original": "אוּרִיאֵל",
    "translitteration": "ʾûrîʾēl",
    "prononciation": "ʾûrîʾēl",
    "definition": "Ouriel, « Dieu est ma lumière » ou « lumière de Dieu ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 15:5"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h222 אוּרִיאֵל ʾûrîʾēl ouriel, « dieu est ma lumière » ou « lumière de dieu ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200117,
    "strong": "H223",
    "langue": "hebreu",
    "numero": 223,
    "mot_original": "אוּרִיָּה",
    "translitteration": "ʾûrîyāh",
    "prononciation": "ʾûrîyāh",
    "definition": "Ouriyah (Urie), « YHWH est ma lumière ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 11:3"
    ],
    "type": "nom propre",
    "occurrences": 35,
    "recherche": "h223 אוּרִיָּה ʾûrîyāh ouriyah (urie), « yhwh est ma lumière ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200118,
    "strong": "H224",
    "langue": "hebreu",
    "numero": 224,
    "mot_original": "אוּרִים",
    "translitteration": "ʾûrîm",
    "prononciation": "ʾûrîm",
    "definition": "Ourim, objet divinatoire associé au pectoral du grand-prêtre.",
    "categorie": "Nom commun",
    "references": [
      "Exode 28:30"
    ],
    "type": "nom commun (pluriel lexicalisé)",
    "occurrences": 7,
    "recherche": "h224 אוּרִים ʾûrîm ourim, objet divinatoire associé au pectoral du grand-prêtre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200119,
    "strong": "H225",
    "langue": "hebreu",
    "numero": 225,
    "mot_original": "אוּת",
    "translitteration": "ʾûṯ",
    "prononciation": "ʾûṯ",
    "definition": "Consentir, accepter, être d'accord.",
    "categorie": "Verbe",
    "references": [
      "2 Rois 12:9"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h225 אוּת ʾûṯ consentir, accepter, être d'accord. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200120,
    "strong": "H226",
    "langue": "hebreu",
    "numero": 226,
    "mot_original": "אוֹת",
    "translitteration": "ʾôṯ",
    "prononciation": "ʾôṯ",
    "definition": "Signe, signal, marque, prodige, miracle.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 9:13",
      "Exode 31:13"
    ],
    "type": "nom commun",
    "occurrences": 79,
    "recherche": "h226 אוֹת ʾôṯ signe, signal, marque, prodige, miracle. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200121,
    "strong": "H227",
    "langue": "hebreu",
    "numero": 227,
    "mot_original": "אָז",
    "translitteration": "ʾāz",
    "prononciation": "ʾāz",
    "definition": "Alors, à ce moment-là, en ce temps-là.",
    "categorie": "Adverbe",
    "references": [
      "Exode 15:1",
      "Psaume 126:2"
    ],
    "type": "adverbe",
    "occurrences": 140,
    "recherche": "h227 אָז ʾāz alors, à ce moment-là, en ce temps-là. adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200122,
    "strong": "H228",
    "langue": "hebreu",
    "numero": 228,
    "mot_original": "אֲזָא",
    "translitteration": "ʾăzāʾ",
    "prononciation": "ʾăzāʾ",
    "definition": "Aller, s'en aller (araméen). Doublet probable de H0230.",
    "categorie": "Verbe",
    "references": [],
    "type": "verbe (araméen)",
    "occurrences": 1,
    "recherche": "h228 אֲזָא ʾăzāʾ aller, s'en aller (araméen). doublet probable de h0230. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200123,
    "strong": "H229",
    "langue": "hebreu",
    "numero": 229,
    "mot_original": "אֶזְבַּי",
    "translitteration": "ʾezbay",
    "prononciation": "ʾezbay",
    "definition": "Ezbay, père d'un guerrier de David.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 11:37"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h229 אֶזְבַּי ʾezbay ezbay, père d'un guerrier de david. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200124,
    "strong": "H230",
    "langue": "hebreu",
    "numero": 230,
    "mot_original": "אַזְדָּא",
    "translitteration": "ʾazdāʾ",
    "prononciation": "ʾazdāʾ",
    "definition": "Certain, sûr, décidé ; échapper (sens incertain en araméen).",
    "categorie": "Adjectif / participe",
    "references": [
      "Daniel 2:5"
    ],
    "type": "adjectif / participe (araméen)",
    "occurrences": 2,
    "recherche": "h230 אַזְדָּא ʾazdāʾ certain, sûr, décidé ; échapper (sens incertain en araméen). adjectif / participe",
    "audio": "",
    "image": null
  },
  {
    "id": 200125,
    "strong": "H231",
    "langue": "hebreu",
    "numero": 231,
    "mot_original": "אֵזוֹב",
    "translitteration": "ʾēzôḇ",
    "prononciation": "ʾēzôḇ",
    "definition": "Hysope, plante aromatique utilisée pour l'aspersion rituelle.",
    "categorie": "Nom commun",
    "references": [
      "Exode 12:22",
      "Psaume 51:9"
    ],
    "type": "nom commun",
    "occurrences": 10,
    "recherche": "h231 אֵזוֹב ʾēzôḇ hysope, plante aromatique utilisée pour l'aspersion rituelle. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200126,
    "strong": "H232",
    "langue": "hebreu",
    "numero": 232,
    "mot_original": "אֵזוֹר",
    "translitteration": "ʾēzôr",
    "prononciation": "ʾēzôr",
    "definition": "Ceinture, pagne, écharpe portée autour des reins.",
    "categorie": "Nom commun",
    "references": [
      "Jérémie 13:1"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h232 אֵזוֹר ʾēzôr ceinture, pagne, écharpe portée autour des reins. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200127,
    "strong": "H233",
    "langue": "hebreu",
    "numero": 233,
    "mot_original": "אֲזַי",
    "translitteration": "ʾăzay",
    "prononciation": "ʾăzay",
    "definition": "Alors, à ce moment-là. Variante poétique de אָז (H0227).",
    "categorie": "Adverbe",
    "references": [
      "Psaume 124:3"
    ],
    "type": "adverbe",
    "occurrences": 3,
    "recherche": "h233 אֲזַי ʾăzay alors, à ce moment-là. variante poétique de אָז (h0227). adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200128,
    "strong": "H234",
    "langue": "hebreu",
    "numero": 234,
    "mot_original": "אַזְכָּרָה",
    "translitteration": "ʾazkārāh",
    "prononciation": "ʾazkārāh",
    "definition": "Mémorial, portion commémorative, offrande consumée sur l'autel en souvenir.",
    "categorie": "Nom commun",
    "references": [
      "Lévitique 2:2"
    ],
    "type": "nom commun",
    "occurrences": 7,
    "recherche": "h234 אַזְכָּרָה ʾazkārāh mémorial, portion commémorative, offrande consumée sur l'autel en souvenir. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200129,
    "strong": "H235",
    "langue": "hebreu",
    "numero": 235,
    "mot_original": "אָזַל",
    "translitteration": "ʾāzal",
    "prononciation": "ʾāzal",
    "definition": "Aller, s'en aller, partir, disparaître.",
    "categorie": "Verbe",
    "references": [
      "Deutéronome 32:36"
    ],
    "type": "verbe",
    "occurrences": 6,
    "recherche": "h235 אָזַל ʾāzal aller, s'en aller, partir, disparaître. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200130,
    "strong": "H236",
    "langue": "hebreu",
    "numero": 236,
    "mot_original": "אֲזַל",
    "translitteration": "ʾăzal",
    "prononciation": "ʾăzal",
    "definition": "Aller, s'en aller. Correspondance araméenne de l'hébreu אָזַל (H0235).",
    "categorie": "Verbe",
    "references": [
      "Esdras 5:8"
    ],
    "type": "verbe (araméen)",
    "occurrences": 7,
    "recherche": "h236 אֲזַל ʾăzal aller, s'en aller. correspondance araméenne de l'hébreu אָזַל (h0235). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200131,
    "strong": "H237",
    "langue": "hebreu",
    "numero": 237,
    "mot_original": "אֶזֶל",
    "translitteration": "ʾezel",
    "prononciation": "ʾezel",
    "definition": "Ézel, nom d'une pierre ou d'un lieu près de Guibéa.",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 20:19"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h237 אֶזֶל ʾezel ézel, nom d'une pierre ou d'un lieu près de guibéa. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200132,
    "strong": "H238",
    "langue": "hebreu",
    "numero": 238,
    "mot_original": "אָזַן",
    "translitteration": "ʾāzan",
    "prononciation": "ʾāzan",
    "definition": "Prêter l'oreille, écouter attentivement, être attentif.",
    "categorie": "Verbe",
    "references": [
      "Deutéronome 32:1"
    ],
    "type": "verbe",
    "occurrences": 41,
    "recherche": "h238 אָזַן ʾāzan prêter l'oreille, écouter attentivement, être attentif. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200133,
    "strong": "H239",
    "langue": "hebreu",
    "numero": 239,
    "mot_original": "אָזַן",
    "translitteration": "ʾāzan",
    "prononciation": "ʾāzan",
    "definition": "Peser, équilibrer ; examiner attentivement.",
    "categorie": "Verbe",
    "references": [
      "Ecclésiaste 12:9"
    ],
    "type": "verbe (piel)",
    "occurrences": 1,
    "recherche": "h239 אָזַן ʾāzan peser, équilibrer ; examiner attentivement. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200134,
    "strong": "H240",
    "langue": "hebreu",
    "numero": 240,
    "mot_original": "אָזֵן",
    "translitteration": "ʾāzēn",
    "prononciation": "ʾāzēn",
    "definition": "Outil, instrument, arme ; variante rare de אֹזֶן ou mot distinct.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 23:14"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h240 אָזֵן ʾāzēn outil, instrument, arme ; variante rare de אֹזֶן ou mot distinct. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200135,
    "strong": "H241",
    "langue": "hebreu",
    "numero": 241,
    "mot_original": "אֹזֶן",
    "translitteration": "ʾōzen",
    "prononciation": "ʾōzen",
    "definition": "Oreille, organe de l'ouïe ; anse, poignée.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 29:3",
      "Psaume 40:7"
    ],
    "type": "nom commun",
    "occurrences": 187,
    "recherche": "h241 אֹזֶן ʾōzen oreille, organe de l'ouïe ; anse, poignée. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200136,
    "strong": "H242",
    "langue": "hebreu",
    "numero": 242,
    "mot_original": "אוּזֵן שֶׁאֱרָה",
    "translitteration": "ʾûzēn šeʾĕrāh",
    "prononciation": "ʾûzēn šeʾĕrāh",
    "definition": "Ouzen-Shééra, ville bâtie par Shééra, fille d'Éphraïm.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 7:24"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h242 אוּזֵן שֶׁאֱרָה ʾûzēn šeʾĕrāh ouzen-shééra, ville bâtie par shééra, fille d'éphraïm. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200137,
    "strong": "H243",
    "langue": "hebreu",
    "numero": 243,
    "mot_original": "אַזְנוֹת תָּבוֹר",
    "translitteration": "ʾAznôwth Tâbôwr",
    "prononciation": "ʾAznôwth Tâbôwr",
    "definition": "Aznoth-Tabor, localité frontalière du territoire de Nephtali, près du mont Thabor.",
    "categorie": "Nom propre",
    "references": [
      "Josué 19:34"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h243 אַזְנוֹת תָּבוֹר ʾaznôwth tâbôwr aznoth-tabor, localité frontalière du territoire de nephtali, près du mont thabor. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200138,
    "strong": "H244",
    "langue": "hebreu",
    "numero": 244,
    "mot_original": "אָזְנִי",
    "translitteration": "ʾāznî",
    "prononciation": "ʾāznî",
    "definition": "Ozni, ancêtre éponyme du clan oznite, de la tribu de Gad.",
    "categorie": "Nom propre",
    "references": [
      "Nombres 26:16"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h244 אָזְנִי ʾāznî ozni, ancêtre éponyme du clan oznite, de la tribu de gad. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200139,
    "strong": "H245",
    "langue": "hebreu",
    "numero": 245,
    "mot_original": "אֲזַנְיָה",
    "translitteration": "ʾăzanyāh",
    "prononciation": "ʾăzanyāh",
    "definition": "Azaniah, « YHWH a entendu » ou « YHWH écoute ».",
    "categorie": "Nom propre",
    "references": [
      "Néhémie 10:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h245 אֲזַנְיָה ʾăzanyāh azaniah, « yhwh a entendu » ou « yhwh écoute ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200140,
    "strong": "H246",
    "langue": "hebreu",
    "numero": 246,
    "mot_original": "אֲזִקִּים",
    "translitteration": "ʾăziqqîm",
    "prononciation": "ʾăziqqîm",
    "definition": "Chaînes, menottes, liens.",
    "categorie": "Nom commun",
    "references": [
      "Jérémie 40:1"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h246 אֲזִקִּים ʾăziqqîm chaînes, menottes, liens. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200141,
    "strong": "H247",
    "langue": "hebreu",
    "numero": 247,
    "mot_original": "אָזַר",
    "translitteration": "ʾāzar",
    "prononciation": "ʾāzar",
    "definition": "Ceindre, entourer, revêtir (spécialement d'une ceinture ou de force).",
    "categorie": "Verbe",
    "references": [
      "Jérémie 1:17",
      "Psaume 93:1"
    ],
    "type": "verbe",
    "occurrences": 16,
    "recherche": "h247 אָזַר ʾāzar ceindre, entourer, revêtir (spécialement d'une ceinture ou de force). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200142,
    "strong": "H248",
    "langue": "hebreu",
    "numero": 248,
    "mot_original": "אֶזְרוֹעַ",
    "translitteration": "ʾezrôaʿ",
    "prononciation": "ʾezrôaʿ",
    "definition": "Bras, avant-bras. Variante poétique de זְרוֹעַ (H2220).",
    "categorie": "Nom commun",
    "references": [
      "Jérémie 32:21"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h248 אֶזְרוֹעַ ʾezrôaʿ bras, avant-bras. variante poétique de זְרוֹעַ (h2220). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200143,
    "strong": "H249",
    "langue": "hebreu",
    "numero": 249,
    "mot_original": "אֶזְרָח",
    "translitteration": "ʾezrāḥ",
    "prononciation": "ʾezrāḥ",
    "definition": "Autochtone, indigène, citoyen de naissance.",
    "categorie": "Nom commun / adjectif",
    "references": [
      "Lévitique 19:34"
    ],
    "type": "nom commun / adjectif",
    "occurrences": 18,
    "recherche": "h249 אֶזְרָח ʾezrāḥ autochtone, indigène, citoyen de naissance. nom commun / adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200144,
    "strong": "H250",
    "langue": "hebreu",
    "numero": 250,
    "mot_original": "אֶזְרָחִי",
    "translitteration": "ʾezrāḥî",
    "prononciation": "ʾezrāḥî",
    "definition": "Ezrahite, membre du clan d'Ézer ou de Zérah.",
    "categorie": "Nom propre / adjectif gentilé",
    "references": [
      "1 Rois 5:11"
    ],
    "type": "nom propre / adjectif gentilé",
    "occurrences": 3,
    "recherche": "h250 אֶזְרָחִי ʾezrāḥî ezrahite, membre du clan d'ézer ou de zérah. nom propre / adjectif gentilé",
    "audio": "",
    "image": null
  },
  {
    "id": 200145,
    "strong": "H251",
    "langue": "hebreu",
    "numero": 251,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Frère, parent, compatriote, prochain.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 4:9",
      "Lévitique 19:17"
    ],
    "type": "nom commun",
    "occurrences": 629,
    "recherche": "h251 אָח ʾāḥ frère, parent, compatriote, prochain. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200146,
    "strong": "H252",
    "langue": "hebreu",
    "numero": 252,
    "mot_original": "אַח",
    "translitteration": "ʾaḥ",
    "prononciation": "ʾaḥ",
    "definition": "Frère. Correspondance araméenne de l'hébreu אָח (H0251).",
    "categorie": "Nom commun",
    "references": [
      "Esdras 7:18"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 1,
    "recherche": "h252 אַח ʾaḥ frère. correspondance araméenne de l'hébreu אָח (h0251). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200147,
    "strong": "H253",
    "langue": "hebreu",
    "numero": 253,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Interjection",
    "references": [
      "Ézéchiel 6:11"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h253 אָח ʾāḥ ah ! hélas ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null
  },
  {
    "id": 200148,
    "strong": "H254",
    "langue": "hebreu",
    "numero": 254,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Brasero, foyer, réchaud.",
    "categorie": "Nom commun",
    "references": [
      "Jérémie 36:22"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h254 אָח ʾāḥ brasero, foyer, réchaud. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200149,
    "strong": "H255",
    "langue": "hebreu",
    "numero": 255,
    "mot_original": "אֹחַ",
    "translitteration": "ʾōaḥ",
    "prononciation": "ʾōaḥ",
    "definition": "Hibou, chat-huant, animal des ruines.",
    "categorie": "Nom commun",
    "references": [
      "Ésaïe 13:21"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h255 אֹחַ ʾōaḥ hibou, chat-huant, animal des ruines. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200150,
    "strong": "H256",
    "langue": "hebreu",
    "numero": 256,
    "mot_original": "אַחְאָב",
    "translitteration": "ʾaḥʾāḇ",
    "prononciation": "ʾaḥʾāḇ",
    "definition": "Achab, « frère du père » ou « oncle paternel ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 16:30"
    ],
    "type": "nom propre",
    "occurrences": 93,
    "recherche": "h256 אַחְאָב ʾaḥʾāḇ achab, « frère du père » ou « oncle paternel ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200151,
    "strong": "H257",
    "langue": "hebreu",
    "numero": 257,
    "mot_original": "אַחְבָּן",
    "translitteration": "ʾaḥbān",
    "prononciation": "ʾaḥbān",
    "definition": "Ahban, descendant de Juda par Yerakhméel.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 2:29"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h257 אַחְבָּן ʾaḥbān ahban, descendant de juda par yerakhméel. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200152,
    "strong": "H258",
    "langue": "hebreu",
    "numero": 258,
    "mot_original": "אָחַד",
    "translitteration": "ʾāḥaḏ",
    "prononciation": "ʾāḥaḏ",
    "definition": "S'unir, être uni, ne faire qu'un.",
    "categorie": "Verbe",
    "references": [
      "Genèse 49:6"
    ],
    "type": "verbe",
    "occurrences": 3,
    "recherche": "h258 אָחַד ʾāḥaḏ s'unir, être uni, ne faire qu'un. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200153,
    "strong": "H259",
    "langue": "hebreu",
    "numero": 259,
    "mot_original": "אֶחָד",
    "translitteration": "ʾeḥāḏ",
    "prononciation": "ʾeḥāḏ",
    "definition": "Un, unique, premier, seul.",
    "categorie": "Adjectif numéral",
    "references": [
      "Deutéronome 6:4",
      "Genèse 2:24"
    ],
    "type": "adjectif numéral",
    "occurrences": 962,
    "recherche": "h259 אֶחָד ʾeḥāḏ un, unique, premier, seul. adjectif numéral",
    "audio": "",
    "image": null
  },
  {
    "id": 200154,
    "strong": "H260",
    "langue": "hebreu",
    "numero": 260,
    "mot_original": "אָחוּ",
    "translitteration": "ʾāḥû",
    "prononciation": "ʾāḥû",
    "definition": "Jonc, roseau, papyrus ; pâturage marécageux.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 41:2"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h260 אָחוּ ʾāḥû jonc, roseau, papyrus ; pâturage marécageux. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200155,
    "strong": "H261",
    "langue": "hebreu",
    "numero": 261,
    "mot_original": "אֵחוּד",
    "translitteration": "ʾēḥûḏ",
    "prononciation": "ʾēḥûḏ",
    "definition": "Éhoud, chef benjaminite. Variante orthographique de אֵהוּד (H0164).",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:6"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h261 אֵחוּד ʾēḥûḏ éhoud, chef benjaminite. variante orthographique de אֵהוּד (h0164). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200156,
    "strong": "H262",
    "langue": "hebreu",
    "numero": 262,
    "mot_original": "אַחְוָה",
    "translitteration": "ʾaḥwāh",
    "prononciation": "ʾaḥwāh",
    "definition": "Déclaration, parole, annonce.",
    "categorie": "Nom commun",
    "references": [
      "Psaume 19:3",
      "Zacharie 11:7"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h262 אַחְוָה ʾaḥwāh déclaration, parole, annonce. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200157,
    "strong": "H263",
    "langue": "hebreu",
    "numero": 263,
    "mot_original": "אַחְוָה",
    "translitteration": "ʾaḥwāh",
    "prononciation": "ʾaḥwāh",
    "definition": "Déclaration, explication, interprétation.",
    "categorie": "Nom commun",
    "references": [
      "Daniel 5:12"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 1,
    "recherche": "h263 אַחְוָה ʾaḥwāh déclaration, explication, interprétation. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200158,
    "strong": "H264",
    "langue": "hebreu",
    "numero": 264,
    "mot_original": "אַחֲוָה",
    "translitteration": "ʾaḥăwāh",
    "prononciation": "ʾaḥăwāh",
    "definition": "Fraternité, union fraternelle. Variante orthographique de H0262.",
    "categorie": "Nom commun",
    "references": [
      "Zacharie 11:14"
    ],
    "type": "nom commun",
    "occurrences": 0,
    "recherche": "h264 אַחֲוָה ʾaḥăwāh fraternité, union fraternelle. variante orthographique de h0262. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200159,
    "strong": "H265",
    "langue": "hebreu",
    "numero": 265,
    "mot_original": "אֲחוֹחַ",
    "translitteration": "ʾăḥôaḥ",
    "prononciation": "ʾăḥôaḥ",
    "definition": "Ahoah, descendant de Benjamin, ancêtre du clan ahoahite.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h265 אֲחוֹחַ ʾăḥôaḥ ahoah, descendant de benjamin, ancêtre du clan ahoahite. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200160,
    "strong": "H266",
    "langue": "hebreu",
    "numero": 266,
    "mot_original": "אֲחוֹחִי",
    "translitteration": "ʾăḥôḥî",
    "prononciation": "ʾăḥôḥî",
    "definition": "Ahoahite, membre du clan d'Ahoah.",
    "categorie": "Adjectif gentilé",
    "references": [
      "2 Samuel 23:9"
    ],
    "type": "adjectif gentilé",
    "occurrences": 4,
    "recherche": "h266 אֲחוֹחִי ʾăḥôḥî ahoahite, membre du clan d'ahoah. adjectif gentilé",
    "audio": "",
    "image": null
  },
  {
    "id": 200161,
    "strong": "H267",
    "langue": "hebreu",
    "numero": 267,
    "mot_original": "אֲחוּמַי",
    "translitteration": "ʾăḥûmay",
    "prononciation": "ʾăḥûmay",
    "definition": "Ahoumaï, descendant de Juda par Shobal.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 4:2"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h267 אֲחוּמַי ʾăḥûmay ahoumaï, descendant de juda par shobal. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200162,
    "strong": "H268",
    "langue": "hebreu",
    "numero": 268,
    "mot_original": "אָחוֹר",
    "translitteration": "ʾāḥôr",
    "prononciation": "ʾāḥôr",
    "definition": "Arrière, dos, partie postérieure ; en arrière.",
    "categorie": "Nom commun / adverbe",
    "references": [
      "Genèse 49:17",
      "Jérémie 7:24"
    ],
    "type": "nom commun / adverbe",
    "occurrences": 41,
    "recherche": "h268 אָחוֹר ʾāḥôr arrière, dos, partie postérieure ; en arrière. nom commun / adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200163,
    "strong": "H269",
    "langue": "hebreu",
    "numero": 269,
    "mot_original": "אָחוֹת",
    "translitteration": "ʾāḥôṯ",
    "prononciation": "ʾāḥôṯ",
    "definition": "Sœur, parente, compagne.",
    "categorie": "Nom commun",
    "references": [
      "Ézéchiel 16:45"
    ],
    "type": "nom commun",
    "occurrences": 114,
    "recherche": "h269 אָחוֹת ʾāḥôṯ sœur, parente, compagne. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200164,
    "strong": "H270",
    "langue": "hebreu",
    "numero": 270,
    "mot_original": "אָחַז",
    "translitteration": "ʾāḥaz",
    "prononciation": "ʾāḥaz",
    "definition": "Saisir, prendre, tenir, posséder.",
    "categorie": "Verbe",
    "references": [
      "Genèse 25:26",
      "Exode 15:14"
    ],
    "type": "verbe",
    "occurrences": 69,
    "recherche": "h270 אָחַז ʾāḥaz saisir, prendre, tenir, posséder. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200165,
    "strong": "H271",
    "langue": "hebreu",
    "numero": 271,
    "mot_original": "אָחָז",
    "translitteration": "ʾāḥāz",
    "prononciation": "ʾāḥāz",
    "definition": "Achaz, « il a saisi », roi de Juda, fils de Yotam, père d'Ézéchias.",
    "categorie": "Nom propre",
    "references": [
      "2 Rois 16:1"
    ],
    "type": "nom propre",
    "occurrences": 41,
    "recherche": "h271 אָחָז ʾāḥāz achaz, « il a saisi », roi de juda, fils de yotam, père d'ézéchias. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200166,
    "strong": "H272",
    "langue": "hebreu",
    "numero": 272,
    "mot_original": "אֲחֻזָּה",
    "translitteration": "ʾăḥuzzāh",
    "prononciation": "ʾăḥuzzāh",
    "definition": "Propriété foncière, possession, domaine héréditaire.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 23:4",
      "Lévitique 25:24"
    ],
    "type": "nom commun",
    "occurrences": 66,
    "recherche": "h272 אֲחֻזָּה ʾăḥuzzāh propriété foncière, possession, domaine héréditaire. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200167,
    "strong": "H273",
    "langue": "hebreu",
    "numero": 273,
    "mot_original": "אַחְזַי",
    "translitteration": "ʾaḥzay",
    "prononciation": "ʾaḥzay",
    "definition": "Ahzaï, prêtre du temps de Néhémie.",
    "categorie": "Nom propre",
    "references": [
      "Néhémie 11:13"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h273 אַחְזַי ʾaḥzay ahzaï, prêtre du temps de néhémie. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200168,
    "strong": "H274",
    "langue": "hebreu",
    "numero": 274,
    "mot_original": "אֲחַזְיָה",
    "translitteration": "ʾăḥazyāh",
    "prononciation": "ʾăḥazyāh",
    "definition": "Achaziah, « YHWH a saisi ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 22:52"
    ],
    "type": "nom propre",
    "occurrences": 37,
    "recherche": "h274 אֲחַזְיָה ʾăḥazyāh achaziah, « yhwh a saisi ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200169,
    "strong": "H275",
    "langue": "hebreu",
    "numero": 275,
    "mot_original": "אֲחֻזָּם",
    "translitteration": "ʾăḥuzzām",
    "prononciation": "ʾăḥuzzām",
    "definition": "Ahuzzam, descendant de Juda.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 4:6"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h275 אֲחֻזָּם ʾăḥuzzām ahuzzam, descendant de juda. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200170,
    "strong": "H276",
    "langue": "hebreu",
    "numero": 276,
    "mot_original": "אֲחֻזַּת",
    "translitteration": "ʾăḥuzzaṯ",
    "prononciation": "ʾăḥuzzaṯ",
    "definition": "Ahuzzath, conseiller d'Abimélek, roi philistin de Guérar.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 26:26"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h276 אֲחֻזַּת ʾăḥuzzaṯ ahuzzath, conseiller d'abimélek, roi philistin de guérar. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200171,
    "strong": "H277",
    "langue": "hebreu",
    "numero": 277,
    "mot_original": "אֲחִי",
    "translitteration": "ʾăḥî",
    "prononciation": "ʾăḥî",
    "definition": "Ahi, « mon frère ». Nom de deux personnages.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 5:15"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h277 אֲחִי ʾăḥî ahi, « mon frère ». nom de deux personnages. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200172,
    "strong": "H278",
    "langue": "hebreu",
    "numero": 278,
    "mot_original": "אֵחִי",
    "translitteration": "ʾēḥî",
    "prononciation": "ʾēḥî",
    "definition": "Éhi, fils de Benjamin.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 46:21"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h278 אֵחִי ʾēḥî éhi, fils de benjamin. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200173,
    "strong": "H279",
    "langue": "hebreu",
    "numero": 279,
    "mot_original": "אֲחִיאָם",
    "translitteration": "ʾăḥîʾām",
    "prononciation": "ʾăḥîʾām",
    "definition": "Ahiam, « frère de la mère » ou « frère du peuple ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 23:33"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h279 אֲחִיאָם ʾăḥîʾām ahiam, « frère de la mère » ou « frère du peuple ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200174,
    "strong": "H280",
    "langue": "hebreu",
    "numero": 280,
    "mot_original": "אֲחִידָה",
    "translitteration": "ʾăḥîḏāh",
    "prononciation": "ʾăḥîḏāh",
    "definition": "Énigme, question difficile, problème à résoudre.",
    "categorie": "Nom commun",
    "references": [
      "Daniel 5:12"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 2,
    "recherche": "h280 אֲחִידָה ʾăḥîḏāh énigme, question difficile, problème à résoudre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200175,
    "strong": "H281",
    "langue": "hebreu",
    "numero": 281,
    "mot_original": "אֲחִיָּה",
    "translitteration": "ʾăḥîyāh",
    "prononciation": "ʾăḥîyāh",
    "definition": "Ahiyah, « frère de YHWH » ou « YHWH est mon frère ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 11:29"
    ],
    "type": "nom propre",
    "occurrences": 24,
    "recherche": "h281 אֲחִיָּה ʾăḥîyāh ahiyah, « frère de yhwh » ou « yhwh est mon frère ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200176,
    "strong": "H282",
    "langue": "hebreu",
    "numero": 282,
    "mot_original": "אֲחִיהוּד",
    "translitteration": "ʾăḥîhûḏ",
    "prononciation": "ʾăḥîhûḏ",
    "definition": "Ahihoud, « frère de majesté » ou « frère est majesté ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 34:27"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h282 אֲחִיהוּד ʾăḥîhûḏ ahihoud, « frère de majesté » ou « frère est majesté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200177,
    "strong": "H283",
    "langue": "hebreu",
    "numero": 283,
    "mot_original": "אַחְיוֹ",
    "translitteration": "ʾaḥyô",
    "prononciation": "ʾaḥyô",
    "definition": "Ahyo, « son frère » ou « fraternel ». Nom d'un conducteur de l'arche.",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 6:3"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h283 אַחְיוֹ ʾaḥyô ahyo, « son frère » ou « fraternel ». nom d'un conducteur de l'arche. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200178,
    "strong": "H284",
    "langue": "hebreu",
    "numero": 284,
    "mot_original": "אֲחִיחֻד",
    "translitteration": "ʾăḥîḥuḏ",
    "prononciation": "ʾăḥîḥuḏ",
    "definition": "Ahihoud, variante orthographique de H0282.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:7"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h284 אֲחִיחֻד ʾăḥîḥuḏ ahihoud, variante orthographique de h0282. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200179,
    "strong": "H285",
    "langue": "hebreu",
    "numero": 285,
    "mot_original": "אֲחִיטוּב",
    "translitteration": "ʾăḥîṭûḇ",
    "prononciation": "ʾăḥîṭûḇ",
    "definition": "Ahitub, « mon frère est bonté » ou « frère de bonté ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 14:3"
    ],
    "type": "nom propre",
    "occurrences": 16,
    "recherche": "h285 אֲחִיטוּב ʾăḥîṭûḇ ahitub, « mon frère est bonté » ou « frère de bonté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200180,
    "strong": "H286",
    "langue": "hebreu",
    "numero": 286,
    "mot_original": "אֲחִילוּד",
    "translitteration": "ʾăḥîlûḏ",
    "prononciation": "ʾăḥîlûḏ",
    "definition": "Ahiloud, « frère d'enfantement » ou « frère est né ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 8:16"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h286 אֲחִילוּד ʾăḥîlûḏ ahiloud, « frère d'enfantement » ou « frère est né ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200181,
    "strong": "H287",
    "langue": "hebreu",
    "numero": 287,
    "mot_original": "אֲחִימוֹת",
    "translitteration": "ʾăḥîmôṯ",
    "prononciation": "ʾăḥîmôṯ",
    "definition": "Ahimoth, « mon frère est mort » ou « frère de la mort ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 6:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h287 אֲחִימוֹת ʾăḥîmôṯ ahimoth, « mon frère est mort » ou « frère de la mort ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200182,
    "strong": "H288",
    "langue": "hebreu",
    "numero": 288,
    "mot_original": "אֲחִימֶלֶךְ",
    "translitteration": "ʾăḥîmeleḵ",
    "prononciation": "ʾăḥîmeleḵ",
    "definition": "Ahimélek, « mon frère est roi » ou « frère du roi ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 21:2"
    ],
    "type": "nom propre",
    "occurrences": 17,
    "recherche": "h288 אֲחִימֶלֶךְ ʾăḥîmeleḵ ahimélek, « mon frère est roi » ou « frère du roi ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200183,
    "strong": "H289",
    "langue": "hebreu",
    "numero": 289,
    "mot_original": "אֲחִימַן",
    "translitteration": "ʾăḥîman",
    "prononciation": "ʾăḥîman",
    "definition": "Ahiman, « mon frère est un don » ou signification incertaine.",
    "categorie": "Nom propre",
    "references": [
      "Nombres 13:22"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h289 אֲחִימַן ʾăḥîman ahiman, « mon frère est un don » ou signification incertaine. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200184,
    "strong": "H290",
    "langue": "hebreu",
    "numero": 290,
    "mot_original": "אֲחִימַעַץ",
    "translitteration": "ʾăḥîmaʿaṣ",
    "prononciation": "ʾăḥîmaʿaṣ",
    "definition": "Ahimaats, « mon frère est colère » ou signification incertaine.",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 18:19"
    ],
    "type": "nom propre",
    "occurrences": 15,
    "recherche": "h290 אֲחִימַעַץ ʾăḥîmaʿaṣ ahimaats, « mon frère est colère » ou signification incertaine. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200185,
    "strong": "H291",
    "langue": "hebreu",
    "numero": 291,
    "mot_original": "אַחְיָן",
    "translitteration": "ʾaḥyān",
    "prononciation": "ʾaḥyān",
    "definition": "Ahyan, descendant de Manassé.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 7:19"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h291 אַחְיָן ʾaḥyān ahyan, descendant de manassé. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200186,
    "strong": "H292",
    "langue": "hebreu",
    "numero": 292,
    "mot_original": "אֲחִינָדָב",
    "translitteration": "ʾăḥînāḏāḇ",
    "prononciation": "ʾăḥînāḏāḇ",
    "definition": "Ahinadab, « mon frère est noble » ou « frère de noblesse ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 4:14"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h292 אֲחִינָדָב ʾăḥînāḏāḇ ahinadab, « mon frère est noble » ou « frère de noblesse ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200187,
    "strong": "H293",
    "langue": "hebreu",
    "numero": 293,
    "mot_original": "אֲחִינֹעַם",
    "translitteration": "ʾăḥînōʿam",
    "prononciation": "ʾăḥînōʿam",
    "definition": "Ahinoam, « mon frère est plaisir » ou « frère de douceur ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 25:43"
    ],
    "type": "nom propre",
    "occurrences": 7,
    "recherche": "h293 אֲחִינֹעַם ʾăḥînōʿam ahinoam, « mon frère est plaisir » ou « frère de douceur ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200188,
    "strong": "H294",
    "langue": "hebreu",
    "numero": 294,
    "mot_original": "אֲחִיסָמָךְ",
    "translitteration": "ʾăḥîsāmāḵ",
    "prononciation": "ʾăḥîsāmāḵ",
    "definition": "Ahisamak, « mon frère soutient » ou « frère de soutien ».",
    "categorie": "Nom propre",
    "references": [
      "Exode 31:6"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h294 אֲחִיסָמָךְ ʾăḥîsāmāḵ ahisamak, « mon frère soutient » ou « frère de soutien ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200189,
    "strong": "H295",
    "langue": "hebreu",
    "numero": 295,
    "mot_original": "אֲחִיעֶזֶר",
    "translitteration": "ʾăḥîʿezer",
    "prononciation": "ʾăḥîʿezer",
    "definition": "Ahiézer, « mon frère est secours » ou « frère de secours ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 1:12"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h295 אֲחִיעֶזֶר ʾăḥîʿezer ahiézer, « mon frère est secours » ou « frère de secours ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200190,
    "strong": "H296",
    "langue": "hebreu",
    "numero": 296,
    "mot_original": "אֲחִיקָם",
    "translitteration": "ʾăḥîqām",
    "prononciation": "ʾăḥîqām",
    "definition": "Ahiqam, « mon frère s'est levé » ou « frère de relèvement ».",
    "categorie": "Nom propre",
    "references": [
      "Jérémie 26:24"
    ],
    "type": "nom propre",
    "occurrences": 20,
    "recherche": "h296 אֲחִיקָם ʾăḥîqām ahiqam, « mon frère s'est levé » ou « frère de relèvement ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200191,
    "strong": "H297",
    "langue": "hebreu",
    "numero": 297,
    "mot_original": "אֲחִירָם",
    "translitteration": "ʾăḥîrām",
    "prononciation": "ʾăḥîrām",
    "definition": "Ahiram, « mon frère est élevé » ou « frère du Très-Haut ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 26:38"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h297 אֲחִירָם ʾăḥîrām ahiram, « mon frère est élevé » ou « frère du très-haut ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200192,
    "strong": "H298",
    "langue": "hebreu",
    "numero": 298,
    "mot_original": "אֲחִירָמִי",
    "translitteration": "ʾăḥîrāmî",
    "prononciation": "ʾăḥîrāmî",
    "definition": "Ahiramite, membre du clan d'Ahiram.",
    "categorie": "Adjectif gentilé",
    "references": [
      "Nombres 26:38"
    ],
    "type": "adjectif gentilé",
    "occurrences": 1,
    "recherche": "h298 אֲחִירָמִי ʾăḥîrāmî ahiramite, membre du clan d'ahiram. adjectif gentilé",
    "audio": "",
    "image": null
  },
  {
    "id": 200193,
    "strong": "H299",
    "langue": "hebreu",
    "numero": 299,
    "mot_original": "אֲחִירַע",
    "translitteration": "ʾăḥîraʿ",
    "prononciation": "ʾăḥîraʿ",
    "definition": "Ahira, « mon frère est mauvais » ou « frère du mal ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 1:15"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h299 אֲחִירַע ʾăḥîraʿ ahira, « mon frère est mauvais » ou « frère du mal ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200194,
    "strong": "H300",
    "langue": "hebreu",
    "numero": 300,
    "mot_original": "אֲחִישַׁחַר",
    "translitteration": "ʾăḥîšaḥar",
    "prononciation": "ʾăḥîšaḥar",
    "definition": "Ahishahar, « mon frère est aurore » ou « frère de l'aube ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 7:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h300 אֲחִישַׁחַר ʾăḥîšaḥar ahishahar, « mon frère est aurore » ou « frère de l'aube ». nom propre",
    "audio": "",
    "image": null
  }
];
