import { StrongEntry } from '../types';

// Fiches lexicographiques compilées manuellement par l'auteur de l'app
// (morphologie, étymologie, occurrences, exemples bibliques sourcés BDB/HALOT/
// Gesenius). Complété au fur et à mesure, par lots reçus dans un ordre quelconque
// (fusion dédupliquée par numéro Strong).
// Couverture actuelle : H0006-H0100, H0101-H0400 (continu), H0348.
export const compiledLexicon: StrongEntry[] = [
  {
    "id": 200000,
    "strong": "H6",
    "langue": "hebreu",
    "numero": 6,
    "mot_original": "אָבַד",
    "translitteration": "ʾāḇaḏ",
    "prononciation": "ʾāḇaḏ",
    "definition": "Périr, être détruit, disparaître, s'égarer.",
    "categorie": "Verbe",
    "references": [
      "Nombres 21:29",
      "Psaume 2:12"
    ],
    "type": "verbe",
    "occurrences": 184,
    "recherche": "h6 אָבַד ʾāḇaḏ périr, être détruit, disparaître, s'égarer. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200001,
    "strong": "H7",
    "langue": "hebreu",
    "numero": 7,
    "mot_original": "אֲבַד",
    "translitteration": "ʾăḇaḏ",
    "prononciation": "ʾăḇaḏ",
    "definition": "Périr, détruire. Correspondance araméenne de l'hébreu אָבַד (H0006).",
    "categorie": "Verbe",
    "references": [
      "Jérémie 10:11",
      "Daniel 7:11"
    ],
    "type": "verbe",
    "occurrences": 7,
    "recherche": "h7 אֲבַד ʾăḇaḏ périr, détruire. correspondance araméenne de l'hébreu אָבַד (h0006). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200002,
    "strong": "H8",
    "langue": "hebreu",
    "numero": 8,
    "mot_original": "אֹבֵד",
    "translitteration": "ʾōḇēḏ",
    "prononciation": "ʾōḇēḏ",
    "definition": "Destruction, ruine ; ce qui est sur le point de périr.",
    "categorie": "Nom commun (substantif dérivé du participe",
    "references": [
      "Proverbes 31:6"
    ],
    "type": "nom commun (substantif dérivé du participe",
    "occurrences": 2,
    "recherche": "h8 אֹבֵד ʾōḇēḏ destruction, ruine ; ce qui est sur le point de périr. nom commun (substantif dérivé du participe",
    "audio": "",
    "image": null
  },
  {
    "id": 200003,
    "strong": "H9",
    "langue": "hebreu",
    "numero": 9,
    "mot_original": "אֲבֵדָה",
    "translitteration": "ʾăḇēḏāh",
    "prononciation": "ʾăḇēḏāh",
    "definition": "Chose perdue, objet égaré.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 22:3"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h9 אֲבֵדָה ʾăḇēḏāh chose perdue, objet égaré. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200004,
    "strong": "H10",
    "langue": "hebreu",
    "numero": 10,
    "mot_original": "אֲבַדֹּה",
    "translitteration": "ʾăḇaddōh",
    "prononciation": "ʾăḇaddōh",
    "definition": "Ruine, destruction, lieu de perdition.",
    "categorie": "Nom commun",
    "references": [
      "Proverbes 27:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h10 אֲבַדֹּה ʾăḇaddōh ruine, destruction, lieu de perdition. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200005,
    "strong": "H11",
    "langue": "hebreu",
    "numero": 11,
    "mot_original": "אֲבַדּוֹן",
    "translitteration": "ʾăḇaddōn",
    "prononciation": "ʾăḇaddōn",
    "definition": "Abaddon. Lieu de destruction ; personnification du monde souterrain.",
    "categorie": "Nom commun / nom propre",
    "references": [
      "Job 26:6",
      "Proverbes 15:11"
    ],
    "type": "nom commun / nom propre",
    "occurrences": 5,
    "recherche": "h11 אֲבַדּוֹן ʾăḇaddōn abaddon. lieu de destruction ; personnification du monde souterrain. nom commun / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200006,
    "strong": "H12",
    "langue": "hebreu",
    "numero": 12,
    "mot_original": "אַבְדָן",
    "translitteration": "ʾaḇdān",
    "prononciation": "ʾaḇdān",
    "definition": "Destruction, anéantissement.",
    "categorie": "Nom commun",
    "references": [
      "Esther 9:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h12 אַבְדָן ʾaḇdān destruction, anéantissement. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200007,
    "strong": "H13",
    "langue": "hebreu",
    "numero": 13,
    "mot_original": "אָבְדַן",
    "translitteration": "ʾoḇdan",
    "prononciation": "ʾoḇdan",
    "definition": "Destruction. Correspondance araméenne de l'hébreu אַבְדָן (H0012).",
    "categorie": "Nom commun",
    "references": [
      "Daniel 2:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h13 אָבְדַן ʾoḇdan destruction. correspondance araméenne de l'hébreu אַבְדָן (h0012). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200008,
    "strong": "H14",
    "langue": "hebreu",
    "numero": 14,
    "mot_original": "אָבָה",
    "translitteration": "ʾāḇāh",
    "prononciation": "ʾāḇāh",
    "definition": "Consentir, vouloir, être disposé à, accepter.",
    "categorie": "Verbe",
    "references": [
      "Deutéronome 25:7",
      "Ésaïe 1:19"
    ],
    "type": "verbe",
    "occurrences": 54,
    "recherche": "h14 אָבָה ʾāḇāh consentir, vouloir, être disposé à, accepter. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200009,
    "strong": "H15",
    "langue": "hebreu",
    "numero": 15,
    "mot_original": "אָבֶה",
    "translitteration": "ʾāḇeh",
    "prononciation": "ʾāḇeh",
    "definition": "Souhait, désir, volonté.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 23:6"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h15 אָבֶה ʾāḇeh souhait, désir, volonté. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200010,
    "strong": "H16",
    "langue": "hebreu",
    "numero": 16,
    "mot_original": "אֵבֶה",
    "translitteration": "ʾēḇeh",
    "prononciation": "ʾēḇeh",
    "definition": "Roseau, papyrus, plante aquatique.",
    "categorie": "Nom commun",
    "references": [
      "Job 9:26"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h16 אֵבֶה ʾēḇeh roseau, papyrus, plante aquatique. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200011,
    "strong": "H17",
    "langue": "hebreu",
    "numero": 17,
    "mot_original": "אֲבוֹי",
    "translitteration": "ʾăḇôy",
    "prononciation": "ʾăḇôy",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Interjection",
    "references": [
      "Proverbes 23:29"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h17 אֲבוֹי ʾăḇôy ah ! hélas ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null
  },
  {
    "id": 200012,
    "strong": "H18",
    "langue": "hebreu",
    "numero": 18,
    "mot_original": "אֵבוּס",
    "translitteration": "ʾēḇûs",
    "prononciation": "ʾēḇûs",
    "definition": "Mangeoire, crèche pour le bétail.",
    "categorie": "Nom commun",
    "references": [
      "Ésaïe 1:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h18 אֵבוּס ʾēḇûs mangeoire, crèche pour le bétail. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200013,
    "strong": "H19",
    "langue": "hebreu",
    "numero": 19,
    "mot_original": "אִבְחָה",
    "translitteration": "ʾiḇḥāh",
    "prononciation": "ʾiḇḥāh",
    "definition": "Épée, lame, pointe. Plus probablement : frayeur, terreur soudaine.",
    "categorie": "Nom commun",
    "references": [
      "Ézéchiel 21:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h19 אִבְחָה ʾiḇḥāh épée, lame, pointe. plus probablement : frayeur, terreur soudaine. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200014,
    "strong": "H20",
    "langue": "hebreu",
    "numero": 20,
    "mot_original": "אֲבַטִּיחַ",
    "translitteration": "ʾăḇaṭṭîaḥ",
    "prononciation": "ʾăḇaṭṭîaḥ",
    "definition": "Pastèque, melon d'eau (Citrullus lanatus).",
    "categorie": "Nom commun",
    "references": [
      "Nombres 11:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h20 אֲבַטִּיחַ ʾăḇaṭṭîaḥ pastèque, melon d'eau (citrullus lanatus). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200015,
    "strong": "H21",
    "langue": "hebreu",
    "numero": 21,
    "mot_original": "אֲבִי",
    "translitteration": "ʾăḇî",
    "prononciation": "ʾăḇî",
    "definition": "Abi, nom propre féminin. Mère du roi Ézéchias.",
    "categorie": "Nom propre",
    "references": [
      "2 Rois 18:2"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h21 אֲבִי ʾăḇî abi, nom propre féminin. mère du roi ézéchias. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200016,
    "strong": "H22",
    "langue": "hebreu",
    "numero": 22,
    "mot_original": "אֲבִיאֵל",
    "translitteration": "ʾăḇîʾēl",
    "prononciation": "ʾăḇîʾēl",
    "definition": "Abiel, « Dieu est mon père » ou « mon père est Dieu ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 9:1"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h22 אֲבִיאֵל ʾăḇîʾēl abiel, « dieu est mon père » ou « mon père est dieu ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200017,
    "strong": "H23",
    "langue": "hebreu",
    "numero": 23,
    "mot_original": "אֲבִיאָסָף",
    "translitteration": "ʾăḇîʾāsāp̄",
    "prononciation": "ʾăḇîʾāsāp̄",
    "definition": "Abiasaph, « mon père a rassemblé » ou « le père du rassemblement ».",
    "categorie": "Nom propre",
    "references": [
      "Exode 6:24"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h23 אֲבִיאָסָף ʾăḇîʾāsāp̄ abiasaph, « mon père a rassemblé » ou « le père du rassemblement ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200018,
    "strong": "H24",
    "langue": "hebreu",
    "numero": 24,
    "mot_original": "אָבִיב",
    "translitteration": "ʾāḇîḇ",
    "prononciation": "ʾāḇîḇ",
    "definition": "Épi mûr, épi tendre ; mois des épis (printemps).",
    "categorie": "Nom commun",
    "references": [
      "Exode 13:4"
    ],
    "type": "nom commun",
    "occurrences": 8,
    "recherche": "h24 אָבִיב ʾāḇîḇ épi mûr, épi tendre ; mois des épis (printemps). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200019,
    "strong": "H25",
    "langue": "hebreu",
    "numero": 25,
    "mot_original": "אֲבִי גִבְעוֹן",
    "translitteration": "ʾăḇî ḡiḇʿôn",
    "prononciation": "ʾăḇî ḡiḇʿôn",
    "definition": "Abi-Gibeon, « père de Gibeon ». Nom ou titre d'un personnage benjaminite.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:29"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h25 אֲבִי גִבְעוֹן ʾăḇî ḡiḇʿôn abi-gibeon, « père de gibeon ». nom ou titre d'un personnage benjaminite. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200020,
    "strong": "H26",
    "langue": "hebreu",
    "numero": 26,
    "mot_original": "אֲבִיגַיִל",
    "translitteration": "ʾăḇîḡayil",
    "prononciation": "ʾăḇîḡayil",
    "definition": "Abigaïl, « mon père est joie » ou « père de l'exultation ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 25:3"
    ],
    "type": "nom propre",
    "occurrences": 17,
    "recherche": "h26 אֲבִיגַיִל ʾăḇîḡayil abigaïl, « mon père est joie » ou « père de l'exultation ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200021,
    "strong": "H27",
    "langue": "hebreu",
    "numero": 27,
    "mot_original": "אֲבִידָן",
    "translitteration": "ʾăḇîḏān",
    "prononciation": "ʾăḇîḏān",
    "definition": "Abidan, « mon père a jugé » ou « père du jugement ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 1:11"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h27 אֲבִידָן ʾăḇîḏān abidan, « mon père a jugé » ou « père du jugement ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200022,
    "strong": "H28",
    "langue": "hebreu",
    "numero": 28,
    "mot_original": "אֲבִידָע",
    "translitteration": "ʾăḇîḏāʿ",
    "prononciation": "ʾăḇîḏāʿ",
    "definition": "Abida, « mon père a connu » ou « père de la connaissance ».",
    "categorie": "Nom propre",
    "references": [
      "Genèse 25:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h28 אֲבִידָע ʾăḇîḏāʿ abida, « mon père a connu » ou « père de la connaissance ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200023,
    "strong": "H29",
    "langue": "hebreu",
    "numero": 29,
    "mot_original": "אֲבִיָּה",
    "translitteration": "ʾăḇîyāh",
    "prononciation": "ʾăḇîyāh",
    "definition": "Abiya, Abiyahu, « YHWH est mon père ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 14:1"
    ],
    "type": "nom propre",
    "occurrences": 25,
    "recherche": "h29 אֲבִיָּה ʾăḇîyāh abiya, abiyahu, « yhwh est mon père ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200024,
    "strong": "H30",
    "langue": "hebreu",
    "numero": 30,
    "mot_original": "אֲבִיהוּא",
    "translitteration": "ʾăḇîhûʾ",
    "prononciation": "ʾăḇîhûʾ",
    "definition": "Abihu, « lui (YHWH) est mon père ».",
    "categorie": "Nom propre",
    "references": [
      "Lévitique 10:1"
    ],
    "type": "nom propre",
    "occurrences": 12,
    "recherche": "h30 אֲבִיהוּא ʾăḇîhûʾ abihu, « lui (yhwh) est mon père ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200025,
    "strong": "H31",
    "langue": "hebreu",
    "numero": 31,
    "mot_original": "אֲבִיהוּד",
    "translitteration": "ʾăḇîhûḏ",
    "prononciation": "ʾăḇîhûḏ",
    "definition": "Abihud, « mon père est majesté » ou « père de gloire ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:3"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h31 אֲבִיהוּד ʾăḇîhûḏ abihud, « mon père est majesté » ou « père de gloire ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200026,
    "strong": "H32",
    "langue": "hebreu",
    "numero": 32,
    "mot_original": "אֲבִיהַיִל",
    "translitteration": "ʾăḇîhayil",
    "prononciation": "ʾăḇîhayil",
    "definition": "Abihail, « mon père est force » ou « père de la force ».",
    "categorie": "Nom propre",
    "references": [
      "Esther 2:15"
    ],
    "type": "nom propre",
    "occurrences": 6,
    "recherche": "h32 אֲבִיהַיִל ʾăḇîhayil abihail, « mon père est force » ou « père de la force ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200027,
    "strong": "H33",
    "langue": "hebreu",
    "numero": 33,
    "mot_original": "אֲבִי הָעֶזְרִי",
    "translitteration": "ʾăḇî hāʿezrî",
    "prononciation": "ʾăḇî hāʿezrî",
    "definition": "Abiézerite, membre du clan d'Abiézer, de la tribu de Manassé.",
    "categorie": "Nom propre (gentilé)",
    "references": [
      "Juges 6:11"
    ],
    "type": "nom propre (gentilé)",
    "occurrences": 3,
    "recherche": "h33 אֲבִי הָעֶזְרִי ʾăḇî hāʿezrî abiézerite, membre du clan d'abiézer, de la tribu de manassé. nom propre (gentilé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200028,
    "strong": "H34",
    "langue": "hebreu",
    "numero": 34,
    "mot_original": "אֶבְיוֹן",
    "translitteration": "ʾeḇyôn",
    "prononciation": "ʾeḇyôn",
    "definition": "Pauvre, indigent, nécessiteux, celui qui manque de ressources.",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Exode 23:11",
      "Deutéronome 15:7"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 61,
    "recherche": "h34 אֶבְיוֹן ʾeḇyôn pauvre, indigent, nécessiteux, celui qui manque de ressources. adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200029,
    "strong": "H35",
    "langue": "hebreu",
    "numero": 35,
    "mot_original": "אֲבִיּוֹנָה",
    "translitteration": "ʾăḇîyônāh",
    "prononciation": "ʾăḇîyônāh",
    "definition": "Câpre, fruit du câprier (Capparis spinosa).",
    "categorie": "Nom commun",
    "references": [
      "Ecclésiaste 12:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h35 אֲבִיּוֹנָה ʾăḇîyônāh câpre, fruit du câprier (capparis spinosa). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200030,
    "strong": "H36",
    "langue": "hebreu",
    "numero": 36,
    "mot_original": "אֲבִיטוּב",
    "translitteration": "ʾăḇîṭûḇ",
    "prononciation": "ʾăḇîṭûḇ",
    "definition": "Abitub, « mon père est bonté » ou « père de la bonté ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:11"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h36 אֲבִיטוּב ʾăḇîṭûḇ abitub, « mon père est bonté » ou « père de la bonté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200031,
    "strong": "H37",
    "langue": "hebreu",
    "numero": 37,
    "mot_original": "אֲבִיטָל",
    "translitteration": "ʾăḇîṭāl",
    "prononciation": "ʾăḇîṭāl",
    "definition": "Abital, « mon père est rosée » ou « père de la rosée ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 3:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h37 אֲבִיטָל ʾăḇîṭāl abital, « mon père est rosée » ou « père de la rosée ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200032,
    "strong": "H38",
    "langue": "hebreu",
    "numero": 38,
    "mot_original": "אֲבִיָּם",
    "translitteration": "ʾăḇîyām",
    "prononciation": "ʾăḇîyām",
    "definition": "Abiyam, \"mon père est Yām (Mer)\" ou forme alternative de Abiya. Roi de Juda, fils de Roboam.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 14:31"
    ],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h38 אֲבִיָּם ʾăḇîyām abiyam, \"mon père est yām (mer)\" ou forme alternative de abiya. roi de juda, fils de roboam. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200033,
    "strong": "H39",
    "langue": "hebreu",
    "numero": 39,
    "mot_original": "אֲבִימָאֵל",
    "translitteration": "ʾăḇîmāʾēl",
    "prononciation": "ʾăḇîmāʾēl",
    "definition": "Abimaël, \"mon père est vraiment Dieu\" ou \"le père est de Dieu\". Descendant de Sem.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 10:28"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h39 אֲבִימָאֵל ʾăḇîmāʾēl abimaël, \"mon père est vraiment dieu\" ou \"le père est de dieu\". descendant de sem. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200034,
    "strong": "H40",
    "langue": "hebreu",
    "numero": 40,
    "mot_original": "אֲבִימֶלֶךְ",
    "translitteration": "ʾăḇîmeleḵ",
    "prononciation": "ʾăḇîmeleḵ",
    "definition": "Abimélek, \"mon père est roi\" ou \"le père (divin) est roi\".",
    "categorie": "Nom propre",
    "references": [
      "Genèse 20:2"
    ],
    "type": "nom propre",
    "occurrences": 67,
    "recherche": "h40 אֲבִימֶלֶךְ ʾăḇîmeleḵ abimélek, \"mon père est roi\" ou \"le père (divin) est roi\". nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200035,
    "strong": "H41",
    "langue": "hebreu",
    "numero": 41,
    "mot_original": "אֲבִינָדָב",
    "translitteration": "ʾăḇînāḏāḇ",
    "prononciation": "ʾăḇînāḏāḇ",
    "definition": "Abinadab, « mon père est noble » ou « père de la noblesse ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 7:1"
    ],
    "type": "nom propre",
    "occurrences": 12,
    "recherche": "h41 אֲבִינָדָב ʾăḇînāḏāḇ abinadab, « mon père est noble » ou « père de la noblesse ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200036,
    "strong": "H42",
    "langue": "hebreu",
    "numero": 42,
    "mot_original": "אֲבִינֹעַם",
    "translitteration": "ʾăḇînōʿam",
    "prononciation": "ʾăḇînōʿam",
    "definition": "Abinoam, « mon père est plaisir » ou « père de la douceur ».",
    "categorie": "Nom propre",
    "references": [
      "Juges 4:6"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h42 אֲבִינֹעַם ʾăḇînōʿam abinoam, « mon père est plaisir » ou « père de la douceur ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200037,
    "strong": "H43",
    "langue": "hebreu",
    "numero": 43,
    "mot_original": "אֶבְיָסָף",
    "translitteration": "ʾeḇyāsāp̄",
    "prononciation": "ʾeḇyāsāp̄",
    "definition": "Ebyasaph, variante orthographique de Abiasaph (H0023).",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 6:8"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h43 אֶבְיָסָף ʾeḇyāsāp̄ ebyasaph, variante orthographique de abiasaph (h0023). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200038,
    "strong": "H44",
    "langue": "hebreu",
    "numero": 44,
    "mot_original": "אֲבִיעֶזֶר",
    "translitteration": "ʾăḇîʿezer",
    "prononciation": "ʾăḇîʿezer",
    "definition": "Abiézer, « mon père est secours » ou « père du secours ».",
    "categorie": "Nom propre",
    "references": [
      "Juges 6:34"
    ],
    "type": "nom propre",
    "occurrences": 7,
    "recherche": "h44 אֲבִיעֶזֶר ʾăḇîʿezer abiézer, « mon père est secours » ou « père du secours ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200039,
    "strong": "H45",
    "langue": "hebreu",
    "numero": 45,
    "mot_original": "אֲבִי־עַלְבוֹן",
    "translitteration": "ʾăḇî-ʿalḇôn",
    "prononciation": "ʾăḇî-ʿalḇôn",
    "definition": "Abi-Albon, « père de force » ou nom composé incluant עַלְבוֹן.",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 23:31"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h45 אֲבִי־עַלְבוֹן ʾăḇî-ʿalḇôn abi-albon, « père de force » ou nom composé incluant עַלְבוֹן. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200040,
    "strong": "H46",
    "langue": "hebreu",
    "numero": 46,
    "mot_original": "אָבִיר",
    "translitteration": "ʾāḇîr",
    "prononciation": "ʾāḇîr",
    "definition": "Fort, puissant, taureau (métaphore de puissance).",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Genèse 49:24",
      "Ésaïe 1:24"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 6,
    "recherche": "h46 אָבִיר ʾāḇîr fort, puissant, taureau (métaphore de puissance). adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200041,
    "strong": "H47",
    "langue": "hebreu",
    "numero": 47,
    "mot_original": "אַבִּיר",
    "translitteration": "ʾabbîr",
    "prononciation": "ʾabbîr",
    "definition": "Puissant, fort, taureau ; coursier, destrier.",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Juges 5:22",
      "Psaume 22:13"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 17,
    "recherche": "h47 אַבִּיר ʾabbîr puissant, fort, taureau ; coursier, destrier. adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200042,
    "strong": "H48",
    "langue": "hebreu",
    "numero": 48,
    "mot_original": "אֲבִירָם",
    "translitteration": "ʾăḇîrām",
    "prononciation": "ʾăḇîrām",
    "definition": "Abiram, « mon père est exalté » ou « le père (divin) est exalté ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 16:1",
      "1 Rois 16:34"
    ],
    "type": "nom propre",
    "occurrences": 11,
    "recherche": "h48 אֲבִירָם ʾăḇîrām abiram, « mon père est exalté » ou « le père (divin) est exalté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200043,
    "strong": "H49",
    "langue": "hebreu",
    "numero": 49,
    "mot_original": "אֲבִישַׁג",
    "translitteration": "ʾăḇîšaḡ",
    "prononciation": "ʾăḇîšaḡ",
    "definition": "Abishag, « mon père est errance » ou signification incertaine.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 1:3"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h49 אֲבִישַׁג ʾăḇîšaḡ abishag, « mon père est errance » ou signification incertaine. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200044,
    "strong": "H50",
    "langue": "hebreu",
    "numero": 50,
    "mot_original": "אֲבִישׁוּעַ",
    "translitteration": "ʾăḇîšûaʿ",
    "prononciation": "ʾăḇîšûaʿ",
    "definition": "Abishua, « mon père est salut » ou « père du salut ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 5:30"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h50 אֲבִישׁוּעַ ʾăḇîšûaʿ abishua, « mon père est salut » ou « père du salut ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200045,
    "strong": "H51",
    "langue": "hebreu",
    "numero": 51,
    "mot_original": "אֲבִישׁוּר",
    "translitteration": "ʾăḇîšûr",
    "prononciation": "ʾăḇîšûr",
    "definition": "Abishur, « mon père est muraille » ou « père de la muraille ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 2:28"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h51 אֲבִישׁוּר ʾăḇîšûr abishur, « mon père est muraille » ou « père de la muraille ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200046,
    "strong": "H52",
    "langue": "hebreu",
    "numero": 52,
    "mot_original": "אֲבִישַׁי",
    "translitteration": "ʾăḇîšay",
    "prononciation": "ʾăḇîšay",
    "definition": "Abishaï, « mon père est présent » ou « père du don ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 26:8"
    ],
    "type": "nom propre",
    "occurrences": 25,
    "recherche": "h52 אֲבִישַׁי ʾăḇîšay abishaï, « mon père est présent » ou « père du don ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200047,
    "strong": "H53",
    "langue": "hebreu",
    "numero": 53,
    "mot_original": "אֲבִישָׁלוֹם",
    "translitteration": "ʾăḇîšālôm",
    "prononciation": "ʾăḇîšālôm",
    "definition": "Abishalom, « mon père est paix » ou « père de la paix ». Variante de Absalom.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 15:2"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h53 אֲבִישָׁלוֹם ʾăḇîšālôm abishalom, « mon père est paix » ou « père de la paix ». variante de absalom. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200048,
    "strong": "H54",
    "langue": "hebreu",
    "numero": 54,
    "mot_original": "אֶבְיָתָר",
    "translitteration": "ʾeḇyāṯār",
    "prononciation": "ʾeḇyāṯār",
    "definition": "Ébyatar, Abiathar, « le père (divin) a pourvu » ou « père de l'abondance ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 22:20"
    ],
    "type": "nom propre",
    "occurrences": 30,
    "recherche": "h54 אֶבְיָתָר ʾeḇyāṯār ébyatar, abiathar, « le père (divin) a pourvu » ou « père de l'abondance ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200049,
    "strong": "H55",
    "langue": "hebreu",
    "numero": 55,
    "mot_original": "אָבַךְ",
    "translitteration": "ʾāḇaḵ",
    "prononciation": "ʾāḇaḵ",
    "definition": "S'enrouler, monter en spirale, tourbillonner (en parlant de fumée ou de poussière).",
    "categorie": "Verbe",
    "references": [
      "Juges 7:13"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h55 אָבַךְ ʾāḇaḵ s'enrouler, monter en spirale, tourbillonner (en parlant de fumée ou de poussière). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200050,
    "strong": "H56",
    "langue": "hebreu",
    "numero": 56,
    "mot_original": "אָבַל",
    "translitteration": "ʾāḇal",
    "prononciation": "ʾāḇal",
    "definition": "Être en deuil, mener le deuil, se lamenter.",
    "categorie": "Verbe",
    "references": [
      "Ésaïe 24:4"
    ],
    "type": "verbe",
    "occurrences": 8,
    "recherche": "h56 אָבַל ʾāḇal être en deuil, mener le deuil, se lamenter. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200051,
    "strong": "H57",
    "langue": "hebreu",
    "numero": 57,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "En deuil, affligé, portant le deuil.",
    "categorie": "Adjectif",
    "references": [
      "Ésaïe 61:3"
    ],
    "type": "adjectif",
    "occurrences": 8,
    "recherche": "h57 אָבֵל ʾāḇēl en deuil, affligé, portant le deuil. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200052,
    "strong": "H58",
    "langue": "hebreu",
    "numero": 58,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "Prairie, pâturage arrosé, cours d'eau.",
    "categorie": "Nom commun",
    "references": [
      "Juges 11:33"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h58 אָבֵל ʾāḇēl prairie, pâturage arrosé, cours d'eau. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200053,
    "strong": "H59",
    "langue": "hebreu",
    "numero": 59,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "Abel, nom de plusieurs localités en Israël et en Transjordanie.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "2 Samuel 20:18"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 7,
    "recherche": "h59 אָבֵל ʾāḇēl abel, nom de plusieurs localités en israël et en transjordanie. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200054,
    "strong": "H60",
    "langue": "hebreu",
    "numero": 60,
    "mot_original": "אֵבֶל",
    "translitteration": "ʾēḇel",
    "prononciation": "ʾēḇel",
    "definition": "Deuil, lamentation funèbre, cérémonie de deuil.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 50:11"
    ],
    "type": "nom commun",
    "occurrences": 24,
    "recherche": "h60 אֵבֶל ʾēḇel deuil, lamentation funèbre, cérémonie de deuil. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200055,
    "strong": "H61",
    "langue": "hebreu",
    "numero": 61,
    "mot_original": "אֲבָל",
    "translitteration": "ʾăḇāl",
    "prononciation": "ʾăḇāl",
    "definition": "Mais, cependant, toutefois, vraiment, certainement.",
    "categorie": "Adverbe / conjonction",
    "references": [
      "Genèse 17:19",
      "2 Samuel 14:5"
    ],
    "type": "adverbe / conjonction",
    "occurrences": 11,
    "recherche": "h61 אֲבָל ʾăḇāl mais, cependant, toutefois, vraiment, certainement. adverbe / conjonction",
    "audio": "",
    "image": null
  },
  {
    "id": 200056,
    "strong": "H62",
    "langue": "hebreu",
    "numero": 62,
    "mot_original": "אָבֵל בֵּית־מַעֲכָה",
    "translitteration": "ʾāḇēl bêṯ-maʿăḵāh",
    "prononciation": "ʾāḇēl bêṯ-maʿăḵāh",
    "definition": "Abel-Beth-Maaka, « prairie de la maison de Maaka », ville fortifiée du nord d'Israël.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "2 Samuel 20:14"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 4,
    "recherche": "h62 אָבֵל בֵּית־מַעֲכָה ʾāḇēl bêṯ-maʿăḵāh abel-beth-maaka, « prairie de la maison de maaka », ville fortifiée du nord d'israël. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200057,
    "strong": "H63",
    "langue": "hebreu",
    "numero": 63,
    "mot_original": "אָבֵל הַשִּׁטִּים",
    "translitteration": "ʾāḇēl haššiṭṭîm",
    "prononciation": "ʾāḇēl haššiṭṭîm",
    "definition": "Abel-Shittim, « prairie des acacias », dernier campement israélite en Transjordanie.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Nombres 33:49"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h63 אָבֵל הַשִּׁטִּים ʾāḇēl haššiṭṭîm abel-shittim, « prairie des acacias », dernier campement israélite en transjordanie. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200058,
    "strong": "H64",
    "langue": "hebreu",
    "numero": 64,
    "mot_original": "אָבֵל כְּרָמִים",
    "translitteration": "ʾāḇēl kərāmîm",
    "prononciation": "ʾāḇēl kərāmîm",
    "definition": "Abel-Keramim, « prairie des vignes », localité ammonite.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Juges 11:33"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h64 אָבֵל כְּרָמִים ʾāḇēl kərāmîm abel-keramim, « prairie des vignes », localité ammonite. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200059,
    "strong": "H65",
    "langue": "hebreu",
    "numero": 65,
    "mot_original": "אָבֵל מְחוֹלָה",
    "translitteration": "ʾāḇēl məḥôlāh",
    "prononciation": "ʾāḇēl məḥôlāh",
    "definition": "Abel-Meholah, « prairie de la danse », ville de la vallée du Jourdain.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "1 Rois 19:16"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 3,
    "recherche": "h65 אָבֵל מְחוֹלָה ʾāḇēl məḥôlāh abel-meholah, « prairie de la danse », ville de la vallée du jourdain. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200060,
    "strong": "H66",
    "langue": "hebreu",
    "numero": 66,
    "mot_original": "אָבֵל מַיִם",
    "translitteration": "ʾāḇēl mayim",
    "prononciation": "ʾāḇēl mayim",
    "definition": "Abel-Maïm, « prairie des eaux », variante de Abel-Beth-Maaka.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "2 Chroniques 16:4"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h66 אָבֵל מַיִם ʾāḇēl mayim abel-maïm, « prairie des eaux », variante de abel-beth-maaka. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200061,
    "strong": "H67",
    "langue": "hebreu",
    "numero": 67,
    "mot_original": "אָבֵל מִצְרַיִם",
    "translitteration": "ʾāḇēl miṣrayim",
    "prononciation": "ʾāḇēl miṣrayim",
    "definition": "Abel-Mitsraïm, « deuil de l'Égypte », nom donné à l'aire d'Atad après la cérémonie funèbre de Jacob.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Genèse 50:11"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h67 אָבֵל מִצְרַיִם ʾāḇēl miṣrayim abel-mitsraïm, « deuil de l'égypte », nom donné à l'aire d'atad après la cérémonie funèbre de jacob. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200062,
    "strong": "H68",
    "langue": "hebreu",
    "numero": 68,
    "mot_original": "אֶבֶן",
    "translitteration": "ʾeḇen",
    "prononciation": "ʾeḇen",
    "definition": "Pierre, roche, bloc de pierre.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 28:18",
      "Exode 31:18"
    ],
    "type": "nom commun",
    "occurrences": 273,
    "recherche": "h68 אֶבֶן ʾeḇen pierre, roche, bloc de pierre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200063,
    "strong": "H69",
    "langue": "hebreu",
    "numero": 69,
    "mot_original": "אֶבֶן",
    "translitteration": "ʾeḇen",
    "prononciation": "ʾeḇen",
    "definition": "Pierre. Correspondance araméenne de l'hébreu אֶבֶן (H0068).",
    "categorie": "Nom commun",
    "references": [
      "Daniel 2:34",
      "Esdras 6:4"
    ],
    "type": "nom commun",
    "occurrences": 8,
    "recherche": "h69 אֶבֶן ʾeḇen pierre. correspondance araméenne de l'hébreu אֶבֶן (h0068). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200064,
    "strong": "H70",
    "langue": "hebreu",
    "numero": 70,
    "mot_original": "אֹבֶן",
    "translitteration": "ʾōḇen",
    "prononciation": "ʾōḇen",
    "definition": "Siège d'accouchement, pierres sur lesquelles la femme s'accroupissait pour accoucher.",
    "categorie": "Nom commun",
    "references": [
      "Exode 1:16",
      "Jérémie 18:3"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h70 אֹבֶן ʾōḇen siège d'accouchement, pierres sur lesquelles la femme s'accroupissait pour accoucher. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200065,
    "strong": "H71",
    "langue": "hebreu",
    "numero": 71,
    "mot_original": "אֲבָנָה",
    "translitteration": "ʾăḇānāh",
    "prononciation": "ʾăḇānāh",
    "definition": "Abana, rivière de Damas mentionnée par Naaman.",
    "categorie": "Nom propre",
    "references": [
      "2 Rois 5:12"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h71 אֲבָנָה ʾăḇānāh abana, rivière de damas mentionnée par naaman. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200066,
    "strong": "H72",
    "langue": "hebreu",
    "numero": 72,
    "mot_original": "אֶבֶן הָעֵזֶר",
    "translitteration": "ʾeḇen hāʿēzer",
    "prononciation": "ʾeḇen hāʿēzer",
    "definition": "Eben-Ezer, « pierre du secours ». Nom commémoratif donné par Samuel à un lieu de victoire contre les Philistins.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "1 Samuel 7:12"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 3,
    "recherche": "h72 אֶבֶן הָעֵזֶר ʾeḇen hāʿēzer eben-ezer, « pierre du secours ». nom commémoratif donné par samuel à un lieu de victoire contre les philistins. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200067,
    "strong": "H73",
    "langue": "hebreu",
    "numero": 73,
    "mot_original": "אַבְנֵט",
    "translitteration": "ʾaḇnēṭ",
    "prononciation": "ʾaḇnēṭ",
    "definition": "Ceinture, écharpe, baudrier sacerdotal.",
    "categorie": "Nom commun",
    "references": [
      "Exode 28:4"
    ],
    "type": "nom commun",
    "occurrences": 9,
    "recherche": "h73 אַבְנֵט ʾaḇnēṭ ceinture, écharpe, baudrier sacerdotal. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200068,
    "strong": "H74",
    "langue": "hebreu",
    "numero": 74,
    "mot_original": "אַבְנֵר",
    "translitteration": "ʾaḇnēr",
    "prononciation": "ʾaḇnēr",
    "definition": "Abner, « mon père est lampe » ou « père de la lumière ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 14:50"
    ],
    "type": "nom propre",
    "occurrences": 62,
    "recherche": "h74 אַבְנֵר ʾaḇnēr abner, « mon père est lampe » ou « père de la lumière ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200069,
    "strong": "H75",
    "langue": "hebreu",
    "numero": 75,
    "mot_original": "אָבַס",
    "translitteration": "ʾāḇas",
    "prononciation": "ʾāḇas",
    "definition": "Engraisser, nourrir abondamment le bétail à l'étable.",
    "categorie": "Verbe",
    "references": [
      "Proverbes 15:17"
    ],
    "type": "verbe",
    "occurrences": 2,
    "recherche": "h75 אָבַס ʾāḇas engraisser, nourrir abondamment le bétail à l'étable. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200070,
    "strong": "H76",
    "langue": "hebreu",
    "numero": 76,
    "mot_original": "אֲבַעְבֻּעָה",
    "translitteration": "ʾăḇaʿbuʿāh",
    "prononciation": "ʾăḇaʿbuʿāh",
    "definition": "Pustule, ampoule, vésicule cutanée (sixième plaie d'Égypte).",
    "categorie": "Nom commun",
    "references": [
      "Exode 9:9"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h76 אֲבַעְבֻּעָה ʾăḇaʿbuʿāh pustule, ampoule, vésicule cutanée (sixième plaie d'égypte). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200071,
    "strong": "H77",
    "langue": "hebreu",
    "numero": 77,
    "mot_original": "אֶבֶץ",
    "translitteration": "ʾeḇeṣ",
    "prononciation": "ʾeḇeṣ",
    "definition": "Ébets, ville de la tribu d'Issachar.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "Josué 19:20"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h77 אֶבֶץ ʾeḇeṣ ébets, ville de la tribu d'issachar. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200072,
    "strong": "H78",
    "langue": "hebreu",
    "numero": 78,
    "mot_original": "אִבְצָן",
    "translitteration": "ʾiḇṣān",
    "prononciation": "ʾiḇṣān",
    "definition": "Ibtsan, juge d'Israël originaire de Bethléem.",
    "categorie": "Nom propre",
    "references": [
      "Juges 12:8"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h78 אִבְצָן ʾiḇṣān ibtsan, juge d'israël originaire de bethléem. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200073,
    "strong": "H79",
    "langue": "hebreu",
    "numero": 79,
    "mot_original": "אַבְשַׁי",
    "translitteration": "ʾaḇšay",
    "prononciation": "ʾaḇšay",
    "definition": "Abshaï, variante abrégée de Abishaï (H0052).",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 11:20"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h79 אַבְשַׁי ʾaḇšay abshaï, variante abrégée de abishaï (h0052). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200074,
    "strong": "H80",
    "langue": "hebreu",
    "numero": 80,
    "mot_original": "אָבָק",
    "translitteration": "ʾāḇāq",
    "prononciation": "ʾāḇāq",
    "definition": "Poussière fine, poudre impalpable.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 28:24",
      "Ésaïe 29:5"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h80 אָבָק ʾāḇāq poussière fine, poudre impalpable. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200075,
    "strong": "H81",
    "langue": "hebreu",
    "numero": 81,
    "mot_original": "אֲבָקָה",
    "translitteration": "ʾăḇāqāh",
    "prononciation": "ʾăḇāqāh",
    "definition": "Poudre aromatique, parfum en poudre.",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h81 אֲבָקָה ʾăḇāqāh poudre aromatique, parfum en poudre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200076,
    "strong": "H82",
    "langue": "hebreu",
    "numero": 82,
    "mot_original": "אָבַר",
    "translitteration": "ʾāḇar",
    "prononciation": "ʾāḇar",
    "definition": "Sens incertain. Possible « planer, voler » ou « être fort, puissant ».",
    "categorie": "Verbe",
    "references": [
      "Job 39:26"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h82 אָבַר ʾāḇar sens incertain. possible « planer, voler » ou « être fort, puissant ». verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200077,
    "strong": "H83",
    "langue": "hebreu",
    "numero": 83,
    "mot_original": "אֵבֶר",
    "translitteration": "ʾēḇer",
    "prononciation": "ʾēḇer",
    "definition": "Aile, penne, rémige (plume de l'aile).",
    "categorie": "Nom commun",
    "references": [
      "Psaume 55:7",
      "Ézéchiel 17:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h83 אֵבֶר ʾēḇer aile, penne, rémige (plume de l'aile). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200078,
    "strong": "H84",
    "langue": "hebreu",
    "numero": 84,
    "mot_original": "אֶבְרָה",
    "translitteration": "ʾeḇrāh",
    "prononciation": "ʾeḇrāh",
    "definition": "Penne, aile, plumage (forme féminine de H0083).",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 32:11",
      "Psaume 91:4"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h84 אֶבְרָה ʾeḇrāh penne, aile, plumage (forme féminine de h0083). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200079,
    "strong": "H85",
    "langue": "hebreu",
    "numero": 85,
    "mot_original": "אַבְרָהָם",
    "translitteration": "ʾaḇrāhām",
    "prononciation": "ʾaḇrāhām",
    "definition": "Abraham, « père d'une multitude » ou « père élevé ». Patriarche fondateur d'Israël.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 17:5"
    ],
    "type": "nom propre",
    "occurrences": 175,
    "recherche": "h85 אַבְרָהָם ʾaḇrāhām abraham, « père d'une multitude » ou « père élevé ». patriarche fondateur d'israël. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200080,
    "strong": "H86",
    "langue": "hebreu",
    "numero": 86,
    "mot_original": "אַבְרֵךְ",
    "translitteration": "ʾaḇrēḵ",
    "prononciation": "ʾaḇrēḵ",
    "definition": "À genoux ! Prosternez-vous ! Cri acclamant la dignité de Joseph comme vizir d'Égypte.",
    "categorie": "Interjection ou titre",
    "references": [
      "Genèse 41:43"
    ],
    "type": "interjection ou titre",
    "occurrences": 1,
    "recherche": "h86 אַבְרֵךְ ʾaḇrēḵ à genoux ! prosternez-vous ! cri acclamant la dignité de joseph comme vizir d'égypte. interjection ou titre",
    "audio": "",
    "image": null
  },
  {
    "id": 200081,
    "strong": "H87",
    "langue": "hebreu",
    "numero": 87,
    "mot_original": "אַבְרָם",
    "translitteration": "ʾaḇrām",
    "prononciation": "ʾaḇrām",
    "definition": "Abram, « le père (divin) est élevé » ou « père élevé ». Nom originel d'Abraham.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 11:27"
    ],
    "type": "nom propre",
    "occurrences": 61,
    "recherche": "h87 אַבְרָם ʾaḇrām abram, « le père (divin) est élevé » ou « père élevé ». nom originel d'abraham. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200082,
    "strong": "H88",
    "langue": "hebreu",
    "numero": 88,
    "mot_original": "אַבְשָׁלוֹם",
    "translitteration": "ʾaḇšālôm",
    "prononciation": "ʾaḇšālôm",
    "definition": "Absalom, « père de la paix » ou « mon père est paix ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 14:25"
    ],
    "type": "nom propre",
    "occurrences": 86,
    "recherche": "h88 אַבְשָׁלוֹם ʾaḇšālôm absalom, « père de la paix » ou « mon père est paix ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200083,
    "strong": "H89",
    "langue": "hebreu",
    "numero": 89,
    "mot_original": "אֲבִישַׁלֹם",
    "translitteration": "ʾăḇîšālōm",
    "prononciation": "ʾăḇîšālōm",
    "definition": "Abishalom, variante pleine de Absalom (H0088). Voir H0053.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 15:2"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h89 אֲבִישַׁלֹם ʾăḇîšālōm abishalom, variante pleine de absalom (h0088). voir h0053. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200084,
    "strong": "H90",
    "langue": "hebreu",
    "numero": 90,
    "mot_original": "אֶבְיָתָר",
    "translitteration": "ʾeḇyāṯār",
    "prononciation": "ʾeḇyāṯār",
    "definition": "Ébyatar. Voir H0054.",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 22:20"
    ],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h90 אֶבְיָתָר ʾeḇyāṯār ébyatar. voir h0054. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200085,
    "strong": "H91",
    "langue": "hebreu",
    "numero": 91,
    "mot_original": "אֲגָגִי",
    "translitteration": "ʾăḡāḡî",
    "prononciation": "ʾăḡāḡî",
    "definition": "Agaguite, descendant ou sujet d'Agag, roi amalécite.",
    "categorie": "Adjectif gentilé / nom propre",
    "references": [
      "Esther 3:1"
    ],
    "type": "adjectif gentilé / nom propre",
    "occurrences": 5,
    "recherche": "h91 אֲגָגִי ʾăḡāḡî agaguite, descendant ou sujet d'agag, roi amalécite. adjectif gentilé / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200086,
    "strong": "H92",
    "langue": "hebreu",
    "numero": 92,
    "mot_original": "אֲגֻדָּה",
    "translitteration": "ʾăḡuddāh",
    "prononciation": "ʾăḡuddāh",
    "definition": "Bande, faisceau, lien, groupe lié.",
    "categorie": "Nom commun",
    "references": [
      "Exode 12:22",
      "Job 38:31"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h92 אֲגֻדָּה ʾăḡuddāh bande, faisceau, lien, groupe lié. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200087,
    "strong": "H93",
    "langue": "hebreu",
    "numero": 93,
    "mot_original": "אֱגוֹז",
    "translitteration": "ʾĕḡôz",
    "prononciation": "ʾĕḡôz",
    "definition": "Noix, fruit du noyer (Juglans regia).",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h93 אֱגוֹז ʾĕḡôz noix, fruit du noyer (juglans regia). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200088,
    "strong": "H94",
    "langue": "hebreu",
    "numero": 94,
    "mot_original": "אָגוּר",
    "translitteration": "ʾāḡûr",
    "prononciation": "ʾāḡûr",
    "definition": "Agur, nom du sage auteur du chapitre 30 des Proverbes.",
    "categorie": "Nom propre",
    "references": [
      "Proverbes 30:1"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h94 אָגוּר ʾāḡûr agur, nom du sage auteur du chapitre 30 des proverbes. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200089,
    "strong": "H95",
    "langue": "hebreu",
    "numero": 95,
    "mot_original": "אֲגוֹרָה",
    "translitteration": "ʾăḡôrāh",
    "prononciation": "ʾăḡôrāh",
    "definition": "Pièce d'argent, petite monnaie, pourboire.",
    "categorie": "Nom commun",
    "references": [
      "1 Samuel 2:36"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h95 אֲגוֹרָה ʾăḡôrāh pièce d'argent, petite monnaie, pourboire. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200090,
    "strong": "H96",
    "langue": "hebreu",
    "numero": 96,
    "mot_original": "אֶגֶל",
    "translitteration": "ʾeḡel",
    "prononciation": "ʾeḡel",
    "definition": "Goutte, réserve d'eau. Variante poétique ou régionale de עֵגֶל (H5695, « veau ») ou mot distinct.",
    "categorie": "Nom commun",
    "references": [
      "Job 38:28"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h96 אֶגֶל ʾeḡel goutte, réserve d'eau. variante poétique ou régionale de עֵגֶל (h5695, « veau ») ou mot distinct. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200091,
    "strong": "H97",
    "langue": "hebreu",
    "numero": 97,
    "mot_original": "אֶגְלַיִם",
    "translitteration": "ʾeḡlayim",
    "prononciation": "ʾeḡlayim",
    "definition": "Églaïm, localité près de la mer Morte.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "Ézéchiel 47:10"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h97 אֶגְלַיִם ʾeḡlayim églaïm, localité près de la mer morte. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200092,
    "strong": "H98",
    "langue": "hebreu",
    "numero": 98,
    "mot_original": "אֲגַם",
    "translitteration": "ʾăḡam",
    "prononciation": "ʾăḡam",
    "definition": "Marais, étang, mare d'eau stagnante.",
    "categorie": "Nom commun",
    "references": [
      "Exode 7:19"
    ],
    "type": "nom commun",
    "occurrences": 9,
    "recherche": "h98 אֲגַם ʾăḡam marais, étang, mare d'eau stagnante. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200093,
    "strong": "H99",
    "langue": "hebreu",
    "numero": 99,
    "mot_original": "אָגֵם",
    "translitteration": "ʾāḡēm",
    "prononciation": "ʾāḡēm",
    "definition": "Triste, affligé, abattu.",
    "categorie": "Adjectif",
    "references": [],
    "type": "adjectif",
    "occurrences": 1,
    "recherche": "h99 אָגֵם ʾāḡēm triste, affligé, abattu. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200094,
    "strong": "H100",
    "langue": "hebreu",
    "numero": 100,
    "mot_original": "אַגְמוֹן",
    "translitteration": "ʾaḡmôn",
    "prononciation": "ʾaḡmôn",
    "definition": "Jonc, roseau ; métaphoriquement : crochet, hameçon.",
    "categorie": "Nom commun",
    "references": [
      "Job 40:26",
      "Ésaïe 58:5"
    ],
    "type": "nom commun",
    "occurrences": 5,
    "recherche": "h100 אַגְמוֹן ʾaḡmôn jonc, roseau ; métaphoriquement : crochet, hameçon. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200285,
    "strong": "H101",
    "langue": "hebreu",
    "numero": 101,
    "mot_original": "אַגָּן",
    "translitteration": "ʾaggān",
    "prononciation": "ʾaggān",
    "definition": "Coupe, bassin, bol à libation.",
    "categorie": "Non classé",
    "references": [
      "Exode 24:6",
      "Cantique des Cantiques 7:2"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h101 אַגָּן ʾaggān coupe, bassin, bol à libation.",
    "audio": "",
    "image": null
  },
  {
    "id": 200286,
    "strong": "H102",
    "langue": "hebreu",
    "numero": 102,
    "mot_original": "אֲגַף",
    "translitteration": "ʾăḡap̄",
    "prononciation": "ʾăḡap̄",
    "definition": "Aile, flanc ; corps de troupes, bande armée.",
    "categorie": "Non classé",
    "references": [
      "Ézéchiel 12:14"
    ],
    "type": "",
    "occurrences": 7,
    "recherche": "h102 אֲגַף ʾăḡap̄ aile, flanc ; corps de troupes, bande armée.",
    "audio": "",
    "image": null
  },
  {
    "id": 200287,
    "strong": "H103",
    "langue": "hebreu",
    "numero": 103,
    "mot_original": "אָגַר",
    "translitteration": "ʾāḡar",
    "prononciation": "ʾāḡar",
    "definition": "Amasser, collecter, engranger.",
    "categorie": "Non classé",
    "references": [
      "Proverbes 6:8"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h103 אָגַר ʾāḡar amasser, collecter, engranger.",
    "audio": "",
    "image": null
  },
  {
    "id": 200288,
    "strong": "H104",
    "langue": "hebreu",
    "numero": 104,
    "mot_original": "אִגֶּרֶת",
    "translitteration": "ʾiggereṯ",
    "prononciation": "ʾiggereṯ",
    "definition": "Lettre, missive, document écrit.",
    "categorie": "Non classé",
    "references": [
      "Néhémie 2:8"
    ],
    "type": "",
    "occurrences": 10,
    "recherche": "h104 אִגֶּרֶת ʾiggereṯ lettre, missive, document écrit.",
    "audio": "",
    "image": null
  },
  {
    "id": 200289,
    "strong": "H105",
    "langue": "hebreu",
    "numero": 105,
    "mot_original": "אַגַרְטָל",
    "translitteration": "ʾăḡarṭāl",
    "prononciation": "ʾăḡarṭāl",
    "definition": "Bassin, cuvette, plat cultuel.",
    "categorie": "Non classé",
    "references": [
      "Esdras 1:9"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h105 אַגַרְטָל ʾăḡarṭāl bassin, cuvette, plat cultuel.",
    "audio": "",
    "image": null
  },
  {
    "id": 200290,
    "strong": "H106",
    "langue": "hebreu",
    "numero": 106,
    "mot_original": "אֶגְרֹף",
    "translitteration": "ʾeḡrōp̄",
    "prononciation": "ʾeḡrōp̄",
    "definition": "Poing fermé, main fermée.",
    "categorie": "Non classé",
    "references": [
      "Exode 21:18",
      "Ésaïe 58:4"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h106 אֶגְרֹף ʾeḡrōp̄ poing fermé, main fermée.",
    "audio": "",
    "image": null
  },
  {
    "id": 200291,
    "strong": "H107",
    "langue": "hebreu",
    "numero": 107,
    "mot_original": "אִגֶּרֶת",
    "translitteration": "ʾiggereṯ",
    "prononciation": "ʾiggereṯ",
    "definition": "Lettre, missive. Doublet de H0104.",
    "categorie": "Non classé",
    "references": [],
    "type": "",
    "occurrences": 0,
    "recherche": "h107 אִגֶּרֶת ʾiggereṯ lettre, missive. doublet de h0104.",
    "audio": "",
    "image": null
  },
  {
    "id": 200292,
    "strong": "H108",
    "langue": "hebreu",
    "numero": 108,
    "mot_original": "אֵד",
    "translitteration": "ʾēḏ",
    "prononciation": "ʾēḏ",
    "definition": "Vapeur, brume, nuage de pluie.",
    "categorie": "Non classé",
    "references": [
      "Genèse 2:6",
      "Job 36:27"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h108 אֵד ʾēḏ vapeur, brume, nuage de pluie.",
    "audio": "",
    "image": null
  },
  {
    "id": 200293,
    "strong": "H109",
    "langue": "hebreu",
    "numero": 109,
    "mot_original": "אָדַב",
    "translitteration": "ʾāḏaḇ",
    "prononciation": "ʾāḏaḇ",
    "definition": "Languir, dépérir, être affligé.",
    "categorie": "Non classé",
    "references": [
      "1 Samuel 2:33"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h109 אָדַב ʾāḏaḇ languir, dépérir, être affligé.",
    "audio": "",
    "image": null
  },
  {
    "id": 200294,
    "strong": "H110",
    "langue": "hebreu",
    "numero": 110,
    "mot_original": "אַדְבְּאֵל",
    "translitteration": "ʾaḏbəʾēl",
    "prononciation": "ʾaḏbəʾēl",
    "definition": "Adbéel, fils d'Ismaël.",
    "categorie": "Non classé",
    "references": [
      "Genèse 25:13"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h110 אַדְבְּאֵל ʾaḏbəʾēl adbéel, fils d'ismaël.",
    "audio": "",
    "image": null
  },
  {
    "id": 200295,
    "strong": "H111",
    "langue": "hebreu",
    "numero": 111,
    "mot_original": "אֲדַד",
    "translitteration": "ʾăḏaḏ",
    "prononciation": "ʾăḏaḏ",
    "definition": "Hadad, divinité cananéenne de l'orage et rois édomites.",
    "categorie": "Non classé",
    "references": [
      "Genèse 36:35"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h111 אֲדַד ʾăḏaḏ hadad, divinité cananéenne de l'orage et rois édomites.",
    "audio": "",
    "image": null
  },
  {
    "id": 200296,
    "strong": "H112",
    "langue": "hebreu",
    "numero": 112,
    "mot_original": "אִדּוֹ",
    "translitteration": "ʾiddô",
    "prononciation": "ʾiddô",
    "definition": "Iddo, plusieurs personnages bibliques.",
    "categorie": "Non classé",
    "references": [
      "2 Chroniques 12:15"
    ],
    "type": "",
    "occurrences": 0,
    "recherche": "h112 אִדּוֹ ʾiddô iddo, plusieurs personnages bibliques.",
    "audio": "",
    "image": null
  },
  {
    "id": 200297,
    "strong": "H113",
    "langue": "hebreu",
    "numero": 113,
    "mot_original": "אָדוֹן",
    "translitteration": "ʾāḏôn",
    "prononciation": "ʾāḏôn",
    "definition": "Seigneur, maître, propriétaire, souverain.",
    "categorie": "Non classé",
    "references": [
      "Genèse 45:8",
      "Psaume 110:1"
    ],
    "type": "",
    "occurrences": 335,
    "recherche": "h113 אָדוֹן ʾāḏôn seigneur, maître, propriétaire, souverain.",
    "audio": "",
    "image": null
  },
  {
    "id": 200298,
    "strong": "H114",
    "langue": "hebreu",
    "numero": 114,
    "mot_original": "אַדּוֹן",
    "translitteration": "ʾaddôn",
    "prononciation": "ʾaddôn",
    "definition": "Addôn, localité babylonienne.",
    "categorie": "Non classé",
    "references": [
      "Néhémie 7:61"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h114 אַדּוֹן ʾaddôn addôn, localité babylonienne.",
    "audio": "",
    "image": null
  },
  {
    "id": 200299,
    "strong": "H115",
    "langue": "hebreu",
    "numero": 115,
    "mot_original": "אֲדוֹרַיִם",
    "translitteration": "ʾăḏôrayim",
    "prononciation": "ʾăḏôrayim",
    "definition": "Adoraïm, ville fortifiée de Juda.",
    "categorie": "Non classé",
    "references": [
      "2 Chroniques 11:9"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h115 אֲדוֹרַיִם ʾăḏôrayim adoraïm, ville fortifiée de juda.",
    "audio": "",
    "image": null
  },
  {
    "id": 200300,
    "strong": "H116",
    "langue": "hebreu",
    "numero": 116,
    "mot_original": "אֱדַיִן",
    "translitteration": "ʾĕḏayin",
    "prononciation": "ʾĕḏayin",
    "definition": "Alors, ensuite, à ce moment-là.",
    "categorie": "Non classé",
    "references": [
      "Daniel 2:15"
    ],
    "type": "",
    "occurrences": 57,
    "recherche": "h116 אֱדַיִן ʾĕḏayin alors, ensuite, à ce moment-là.",
    "audio": "",
    "image": null
  },
  {
    "id": 200301,
    "strong": "H117",
    "langue": "hebreu",
    "numero": 117,
    "mot_original": "אַדִּיר",
    "translitteration": "ʾaddîr",
    "prononciation": "ʾaddîr",
    "definition": "Puissant, magnifique, majestueux, noble.",
    "categorie": "Non classé",
    "references": [
      "Exode 15:11",
      "Psaume 8:2"
    ],
    "type": "",
    "occurrences": 27,
    "recherche": "h117 אַדִּיר ʾaddîr puissant, magnifique, majestueux, noble.",
    "audio": "",
    "image": null
  },
  {
    "id": 200302,
    "strong": "H118",
    "langue": "hebreu",
    "numero": 118,
    "mot_original": "אֲדַלְיָא",
    "translitteration": "ʾăḏalyāʾ",
    "prononciation": "ʾăḏalyāʾ",
    "definition": "Adalia, fils d'Haman.",
    "categorie": "Non classé",
    "references": [
      "Esther 9:8"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h118 אֲדַלְיָא ʾăḏalyāʾ adalia, fils d'haman.",
    "audio": "",
    "image": null
  },
  {
    "id": 200303,
    "strong": "H119",
    "langue": "hebreu",
    "numero": 119,
    "mot_original": "אָדַם",
    "translitteration": "ʾāḏam",
    "prononciation": "ʾāḏam",
    "definition": "Être rouge, devenir rouge, rougir.",
    "categorie": "Non classé",
    "references": [
      "Lamentations 4:7"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h119 אָדַם ʾāḏam être rouge, devenir rouge, rougir.",
    "audio": "",
    "image": null
  },
  {
    "id": 200304,
    "strong": "H120",
    "langue": "hebreu",
    "numero": 120,
    "mot_original": "אָדָם",
    "translitteration": "ʾāḏām",
    "prononciation": "ʾāḏām",
    "definition": "Homme, être humain, humanité ; Adam.",
    "categorie": "Non classé",
    "references": [
      "Genèse 1:27",
      "Genèse 2:7",
      "Psaume 8:5"
    ],
    "type": "",
    "occurrences": 543,
    "recherche": "h120 אָדָם ʾāḏām homme, être humain, humanité ; adam.",
    "audio": "",
    "image": null
  },
  {
    "id": 200305,
    "strong": "H121",
    "langue": "hebreu",
    "numero": 121,
    "mot_original": "אָדָם",
    "translitteration": "ʾāḏām",
    "prononciation": "ʾāḏām",
    "definition": "Adam, nom du premier homme.",
    "categorie": "Non classé",
    "references": [
      "Genèse 5:1"
    ],
    "type": "",
    "occurrences": 34,
    "recherche": "h121 אָדָם ʾāḏām adam, nom du premier homme.",
    "audio": "",
    "image": null
  },
  {
    "id": 200306,
    "strong": "H122",
    "langue": "hebreu",
    "numero": 122,
    "mot_original": "אָדֹם",
    "translitteration": "ʾāḏōm",
    "prononciation": "ʾāḏōm",
    "definition": "Rouge, roux, vermeil.",
    "categorie": "Non classé",
    "references": [
      "Genèse 25:25",
      "Nombres 19:2"
    ],
    "type": "",
    "occurrences": 9,
    "recherche": "h122 אָדֹם ʾāḏōm rouge, roux, vermeil.",
    "audio": "",
    "image": null
  },
  {
    "id": 200307,
    "strong": "H123",
    "langue": "hebreu",
    "numero": 123,
    "mot_original": "אֱדוֹם",
    "translitteration": "ʾĕḏôm",
    "prononciation": "ʾĕḏôm",
    "definition": "Édom, peuple et territoire d'Ésaü.",
    "categorie": "Non classé",
    "references": [
      "Genèse 25:30"
    ],
    "type": "",
    "occurrences": 100,
    "recherche": "h123 אֱדוֹם ʾĕḏôm édom, peuple et territoire d'ésaü.",
    "audio": "",
    "image": null
  },
  {
    "id": 200308,
    "strong": "H124",
    "langue": "hebreu",
    "numero": 124,
    "mot_original": "אֹדֶם",
    "translitteration": "ʾōḏem",
    "prononciation": "ʾōḏem",
    "definition": "Rubis, escarboucle, pierre précieuse rouge.",
    "categorie": "Non classé",
    "references": [
      "Exode 28:17"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h124 אֹדֶם ʾōḏem rubis, escarboucle, pierre précieuse rouge.",
    "audio": "",
    "image": null
  },
  {
    "id": 200309,
    "strong": "H125",
    "langue": "hebreu",
    "numero": 125,
    "mot_original": "אֲדַמְדָּם",
    "translitteration": "ʾăḏamḏām",
    "prononciation": "ʾăḏamḏām",
    "definition": "Rougeâtre, tirant sur le rouge.",
    "categorie": "Non classé",
    "references": [
      "Lévitique 13:19"
    ],
    "type": "",
    "occurrences": 6,
    "recherche": "h125 אֲדַמְדָּם ʾăḏamḏām rougeâtre, tirant sur le rouge.",
    "audio": "",
    "image": null
  },
  {
    "id": 200310,
    "strong": "H126",
    "langue": "hebreu",
    "numero": 126,
    "mot_original": "אַדְמָה",
    "translitteration": "ʾaḏmāh",
    "prononciation": "ʾaḏmāh",
    "definition": "Adma, ville de la plaine détruite avec Sodome.",
    "categorie": "Non classé",
    "references": [
      "Genèse 14:2"
    ],
    "type": "",
    "occurrences": 4,
    "recherche": "h126 אַדְמָה ʾaḏmāh adma, ville de la plaine détruite avec sodome.",
    "audio": "",
    "image": null
  },
  {
    "id": 200311,
    "strong": "H127",
    "langue": "hebreu",
    "numero": 127,
    "mot_original": "אֲדָמָה",
    "translitteration": "ʾăḏāmāh",
    "prononciation": "ʾăḏāmāh",
    "definition": "Sol, terre arable, terre cultivable, territoire.",
    "categorie": "Non classé",
    "references": [
      "Genèse 2:7",
      "Deutéronome 11:17"
    ],
    "type": "",
    "occurrences": 225,
    "recherche": "h127 אֲדָמָה ʾăḏāmāh sol, terre arable, terre cultivable, territoire.",
    "audio": "",
    "image": null
  },
  {
    "id": 200312,
    "strong": "H128",
    "langue": "hebreu",
    "numero": 128,
    "mot_original": "אֲדָמָה",
    "translitteration": "ʾăḏāmāh",
    "prononciation": "ʾăḏāmāh",
    "definition": "Adama, ville de Nephtali.",
    "categorie": "Non classé",
    "references": [
      "Josué 19:36"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h128 אֲדָמָה ʾăḏāmāh adama, ville de nephtali.",
    "audio": "",
    "image": null
  },
  {
    "id": 200313,
    "strong": "H129",
    "langue": "hebreu",
    "numero": 129,
    "mot_original": "אֲדָמִי",
    "translitteration": "ʾăḏāmî",
    "prononciation": "ʾăḏāmî",
    "definition": "Adami, toponyme Adami-Hanneqev, Nephtali.",
    "categorie": "Non classé",
    "references": [
      "Josué 19:33"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h129 אֲדָמִי ʾăḏāmî adami, toponyme adami-hanneqev, nephtali.",
    "audio": "",
    "image": null
  },
  {
    "id": 200314,
    "strong": "H130",
    "langue": "hebreu",
    "numero": 130,
    "mot_original": "אֱדֹמִי",
    "translitteration": "ʾĕḏōmî",
    "prononciation": "ʾĕḏōmî",
    "definition": "Édomite, habitant ou descendant d'Édom.",
    "categorie": "Non classé",
    "references": [
      "Deutéronome 23:8",
      "1 Samuel 21:8"
    ],
    "type": "",
    "occurrences": 10,
    "recherche": "h130 אֱדֹמִי ʾĕḏōmî édomite, habitant ou descendant d'édom.",
    "audio": "",
    "image": null
  },
  {
    "id": 200315,
    "strong": "H131",
    "langue": "hebreu",
    "numero": 131,
    "mot_original": "אֲדֻמִּים",
    "translitteration": "ʾăḏummîm",
    "prononciation": "ʾăḏummîm",
    "definition": "Adummim, col montagneux vers Jéricho.",
    "categorie": "Non classé",
    "references": [
      "Josué 15:7"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h131 אֲדֻמִּים ʾăḏummîm adummim, col montagneux vers jéricho.",
    "audio": "",
    "image": null
  },
  {
    "id": 200316,
    "strong": "H132",
    "langue": "hebreu",
    "numero": 132,
    "mot_original": "אַדְמֹנִי",
    "translitteration": "ʾaḏmōnî",
    "prononciation": "ʾaḏmōnî",
    "definition": "Roux, rouquin.",
    "categorie": "Non classé",
    "references": [
      "1 Samuel 16:12"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h132 אַדְמֹנִי ʾaḏmōnî roux, rouquin.",
    "audio": "",
    "image": null
  },
  {
    "id": 200317,
    "strong": "H133",
    "langue": "hebreu",
    "numero": 133,
    "mot_original": "אַדְמָתָא",
    "translitteration": "ʾaḏmāṯāʾ",
    "prononciation": "ʾaḏmāṯāʾ",
    "definition": "Admatha, conseiller du roi Assuérus.",
    "categorie": "Non classé",
    "references": [
      "Esther 1:14"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h133 אַדְמָתָא ʾaḏmāṯāʾ admatha, conseiller du roi assuérus.",
    "audio": "",
    "image": null
  },
  {
    "id": 200318,
    "strong": "H134",
    "langue": "hebreu",
    "numero": 134,
    "mot_original": "אֶדֶן",
    "translitteration": "ʾeḏen",
    "prononciation": "ʾeḏen",
    "definition": "Socle, base, support, piédestal.",
    "categorie": "Non classé",
    "references": [
      "Exode 26:19",
      "Cantique des Cantiques 5:15"
    ],
    "type": "",
    "occurrences": 57,
    "recherche": "h134 אֶדֶן ʾeḏen socle, base, support, piédestal.",
    "audio": "",
    "image": null
  },
  {
    "id": 200319,
    "strong": "H135",
    "langue": "hebreu",
    "numero": 135,
    "mot_original": "אֶדֶן",
    "translitteration": "ʾeḏen",
    "prononciation": "ʾeḏen",
    "definition": "Éden, ville ou région (toponyme).",
    "categorie": "Non classé",
    "references": [],
    "type": "",
    "occurrences": 3,
    "recherche": "h135 אֶדֶן ʾeḏen éden, ville ou région (toponyme).",
    "audio": "",
    "image": null
  },
  {
    "id": 200320,
    "strong": "H136",
    "langue": "hebreu",
    "numero": 136,
    "mot_original": "אֲדֹנָי",
    "translitteration": "ʾăḏōnāy",
    "prononciation": "ʾăḏōnāy",
    "definition": "Seigneur, titre divin appliqué exclusivement à YHWH.",
    "categorie": "Non classé",
    "references": [
      "Genèse 15:2",
      "Psaume 110:1"
    ],
    "type": "",
    "occurrences": 434,
    "recherche": "h136 אֲדֹנָי ʾăḏōnāy seigneur, titre divin appliqué exclusivement à yhwh.",
    "audio": "",
    "image": null
  },
  {
    "id": 200321,
    "strong": "H137",
    "langue": "hebreu",
    "numero": 137,
    "mot_original": "אֲדֹנִי־בֶזֶק",
    "translitteration": "ʾăḏōnî-ḇezeq",
    "prononciation": "ʾăḏōnî-ḇezeq",
    "definition": "Adoni-Bézek, roi cananéen vaincu par Juda et Siméon.",
    "categorie": "Non classé",
    "references": [
      "Juges 1:7"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h137 אֲדֹנִי־בֶזֶק ʾăḏōnî-ḇezeq adoni-bézek, roi cananéen vaincu par juda et siméon.",
    "audio": "",
    "image": null
  },
  {
    "id": 200322,
    "strong": "H138",
    "langue": "hebreu",
    "numero": 138,
    "mot_original": "אֲדֹנִיָּה",
    "translitteration": "ʾăḏōnîyāh",
    "prononciation": "ʾăḏōnîyāh",
    "definition": "Adonija, YHWH est mon Seigneur.",
    "categorie": "Non classé",
    "references": [
      "1 Rois 1:5"
    ],
    "type": "",
    "occurrences": 26,
    "recherche": "h138 אֲדֹנִיָּה ʾăḏōnîyāh adonija, yhwh est mon seigneur.",
    "audio": "",
    "image": null
  },
  {
    "id": 200323,
    "strong": "H139",
    "langue": "hebreu",
    "numero": 139,
    "mot_original": "אֲדֹנִי־צֶדֶק",
    "translitteration": "ʾĂḏōnî-Ṣeḏeq",
    "prononciation": "ʾĂḏōnî-Ṣeḏeq",
    "definition": "Adoni-Tsédeq, roi cananéen de Jérusalem, chef d'une coalition de cinq rois vaincue par Josué.",
    "categorie": "Non classé",
    "references": [
      "Josué 10:1",
      "Josué 10:3"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h139 אֲדֹנִי־צֶדֶק ʾăḏōnî-ṣeḏeq adoni-tsédeq, roi cananéen de jérusalem, chef d'une coalition de cinq rois vaincue par josué.",
    "audio": "",
    "image": null
  },
  {
    "id": 200324,
    "strong": "H140",
    "langue": "hebreu",
    "numero": 140,
    "mot_original": "אֲדֹנִיקָם",
    "translitteration": "ʾăḏōnîqām",
    "prononciation": "ʾăḏōnîqām",
    "definition": "Adoniqam, mon seigneur s'est levé.",
    "categorie": "Non classé",
    "references": [
      "Esdras 2:13"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h140 אֲדֹנִיקָם ʾăḏōnîqām adoniqam, mon seigneur s'est levé.",
    "audio": "",
    "image": null
  },
  {
    "id": 200325,
    "strong": "H141",
    "langue": "hebreu",
    "numero": 141,
    "mot_original": "אֲדֹנִירָם",
    "translitteration": "ʾăḏōnîrām",
    "prononciation": "ʾăḏōnîrām",
    "definition": "Adoniram, mon seigneur est élevé.",
    "categorie": "Non classé",
    "references": [
      "1 Rois 4:6"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h141 אֲדֹנִירָם ʾăḏōnîrām adoniram, mon seigneur est élevé.",
    "audio": "",
    "image": null
  },
  {
    "id": 200326,
    "strong": "H142",
    "langue": "hebreu",
    "numero": 142,
    "mot_original": "אָדַר",
    "translitteration": "ʾāḏar",
    "prononciation": "ʾāḏar",
    "definition": "Être grand, magnifique, glorieux.",
    "categorie": "Non classé",
    "references": [
      "Exode 15:11"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h142 אָדַר ʾāḏar être grand, magnifique, glorieux.",
    "audio": "",
    "image": null
  },
  {
    "id": 200327,
    "strong": "H143",
    "langue": "hebreu",
    "numero": 143,
    "mot_original": "אֲדָר",
    "translitteration": "ʾăḏār",
    "prononciation": "ʾăḏār",
    "definition": "Adar, douzième mois du calendrier.",
    "categorie": "Non classé",
    "references": [
      "Esther 3:7"
    ],
    "type": "",
    "occurrences": 8,
    "recherche": "h143 אֲדָר ʾăḏār adar, douzième mois du calendrier.",
    "audio": "",
    "image": null
  },
  {
    "id": 200328,
    "strong": "H144",
    "langue": "hebreu",
    "numero": 144,
    "mot_original": "אֲדָר",
    "translitteration": "ʾăḏār",
    "prononciation": "ʾăḏār",
    "definition": "Adar, nom du mois en araméen. Doublet de H0143.",
    "categorie": "Non classé",
    "references": [
      "Esdras 6:15"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h144 אֲדָר ʾăḏār adar, nom du mois en araméen. doublet de h0143.",
    "audio": "",
    "image": null
  },
  {
    "id": 200329,
    "strong": "H145",
    "langue": "hebreu",
    "numero": 145,
    "mot_original": "אֶדֶר",
    "translitteration": "ʾeḏer",
    "prononciation": "ʾeḏer",
    "definition": "Manteau, cape, vêtement ample.",
    "categorie": "Non classé",
    "references": [
      "Genèse 25:25",
      "Zacharie 13:4"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h145 אֶדֶר ʾeḏer manteau, cape, vêtement ample.",
    "audio": "",
    "image": null
  },
  {
    "id": 200330,
    "strong": "H146",
    "langue": "hebreu",
    "numero": 146,
    "mot_original": "אַדָּר",
    "translitteration": "ʾaddār",
    "prononciation": "ʾaddār",
    "definition": "Addar, descendant de Benjamin.",
    "categorie": "Non classé",
    "references": [
      "1 Chroniques 8:3"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h146 אַדָּר ʾaddār addar, descendant de benjamin.",
    "audio": "",
    "image": null
  },
  {
    "id": 200331,
    "strong": "H147",
    "langue": "hebreu",
    "numero": 147,
    "mot_original": "אִדַּר",
    "translitteration": "ʾiddar",
    "prononciation": "ʾiddar",
    "definition": "Sens incertain. Possiblement aire de battage, grange.",
    "categorie": "Non classé",
    "references": [],
    "type": "",
    "occurrences": 1,
    "recherche": "h147 אִדַּר ʾiddar sens incertain. possiblement aire de battage, grange.",
    "audio": "",
    "image": null
  },
  {
    "id": 200332,
    "strong": "H148",
    "langue": "hebreu",
    "numero": 148,
    "mot_original": "אַדְרַגָּזֵר",
    "translitteration": "ʾaḏargāzēr",
    "prononciation": "ʾaḏargāzēr",
    "definition": "Conseiller, juge, haut fonctionnaire babylonien.",
    "categorie": "Non classé",
    "references": [
      "Daniel 3:2"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h148 אַדְרַגָּזֵר ʾaḏargāzēr conseiller, juge, haut fonctionnaire babylonien.",
    "audio": "",
    "image": null
  },
  {
    "id": 200333,
    "strong": "H149",
    "langue": "hebreu",
    "numero": 149,
    "mot_original": "אַדְרַזְדָּא",
    "translitteration": "ʾaḏrazdāʾ",
    "prononciation": "ʾaḏrazdāʾ",
    "definition": "Avec soin, diligemment, exactement.",
    "categorie": "Non classé",
    "references": [
      "Esdras 7:23"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h149 אַדְרַזְדָּא ʾaḏrazdāʾ avec soin, diligemment, exactement.",
    "audio": "",
    "image": null
  },
  {
    "id": 200334,
    "strong": "H150",
    "langue": "hebreu",
    "numero": 150,
    "mot_original": "אֲדַרְכּוֹן",
    "translitteration": "ʾăḏarkōn",
    "prononciation": "ʾăḏarkōn",
    "definition": "Darique, pièce d'or perse.",
    "categorie": "Non classé",
    "references": [
      "Esdras 8:27"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h150 אֲדַרְכּוֹן ʾăḏarkōn darique, pièce d'or perse.",
    "audio": "",
    "image": null
  },
  {
    "id": 200335,
    "strong": "H151",
    "langue": "hebreu",
    "numero": 151,
    "mot_original": "אֲדֹרָם",
    "translitteration": "ʾăḏōrām",
    "prononciation": "ʾăḏōrām",
    "definition": "Adoram, forme abrégée de Adoniram.",
    "categorie": "Non classé",
    "references": [
      "1 Rois 12:18"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h151 אֲדֹרָם ʾăḏōrām adoram, forme abrégée de adoniram.",
    "audio": "",
    "image": null
  },
  {
    "id": 200336,
    "strong": "H152",
    "langue": "hebreu",
    "numero": 152,
    "mot_original": "אַדְרַמֶּלֶךְ",
    "translitteration": "ʾaḏrammeleḵ",
    "prononciation": "ʾaḏrammeleḵ",
    "definition": "Adrammélek, le roi est magnifique.",
    "categorie": "Non classé",
    "references": [
      "2 Rois 19:37"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h152 אַדְרַמֶּלֶךְ ʾaḏrammeleḵ adrammélek, le roi est magnifique.",
    "audio": "",
    "image": null
  },
  {
    "id": 200337,
    "strong": "H153",
    "langue": "hebreu",
    "numero": 153,
    "mot_original": "אֶדְרָע",
    "translitteration": "ʾeḏrāʿ",
    "prononciation": "ʾeḏrāʿ",
    "definition": "Bras, avant-bras, force.",
    "categorie": "Non classé",
    "references": [
      "Daniel 2:32"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h153 אֶדְרָע ʾeḏrāʿ bras, avant-bras, force.",
    "audio": "",
    "image": null
  },
  {
    "id": 200338,
    "strong": "H154",
    "langue": "hebreu",
    "numero": 154,
    "mot_original": "אֶדְרֶעִי",
    "translitteration": "ʾeḏreʿî",
    "prononciation": "ʾeḏreʿî",
    "definition": "Édréï, deux villes bibliques.",
    "categorie": "Non classé",
    "references": [
      "Nombres 21:33"
    ],
    "type": "",
    "occurrences": 7,
    "recherche": "h154 אֶדְרֶעִי ʾeḏreʿî édréï, deux villes bibliques.",
    "audio": "",
    "image": null
  },
  {
    "id": 200339,
    "strong": "H155",
    "langue": "hebreu",
    "numero": 155,
    "mot_original": "אַדֶּרֶת",
    "translitteration": "ʾaddereṯ",
    "prononciation": "ʾaddereṯ",
    "definition": "Manteau, cape, vêtement ample et luxueux.",
    "categorie": "Non classé",
    "references": [
      "1 Rois 19:19"
    ],
    "type": "",
    "occurrences": 0,
    "recherche": "h155 אַדֶּרֶת ʾaddereṯ manteau, cape, vêtement ample et luxueux.",
    "audio": "",
    "image": null
  },
  {
    "id": 200340,
    "strong": "H156",
    "langue": "hebreu",
    "numero": 156,
    "mot_original": "אָדַשׁ",
    "translitteration": "ʾāḏaš",
    "prononciation": "ʾāḏaš",
    "definition": "Fouler, battre le grain, dépiquer.",
    "categorie": "Non classé",
    "references": [],
    "type": "",
    "occurrences": 1,
    "recherche": "h156 אָדַשׁ ʾāḏaš fouler, battre le grain, dépiquer.",
    "audio": "",
    "image": null
  },
  {
    "id": 200341,
    "strong": "H157",
    "langue": "hebreu",
    "numero": 157,
    "mot_original": "אָהַב",
    "translitteration": "ʾāhaḇ",
    "prononciation": "ʾāhaḇ",
    "definition": "Aimer, avoir de l'affection pour, désirer.",
    "categorie": "Non classé",
    "references": [
      "Deutéronome 6:5",
      "Lévitique 19:18",
      "1 Samuel 18:1"
    ],
    "type": "",
    "occurrences": 208,
    "recherche": "h157 אָהַב ʾāhaḇ aimer, avoir de l'affection pour, désirer.",
    "audio": "",
    "image": null
  },
  {
    "id": 200342,
    "strong": "H158",
    "langue": "hebreu",
    "numero": 158,
    "mot_original": "אַהַב",
    "translitteration": "ʾahaḇ",
    "prononciation": "ʾahaḇ",
    "definition": "Amour, affection, désir.",
    "categorie": "Non classé",
    "references": [
      "Osée 2:7"
    ],
    "type": "",
    "occurrences": 7,
    "recherche": "h158 אַהַב ʾahaḇ amour, affection, désir.",
    "audio": "",
    "image": null
  },
  {
    "id": 200343,
    "strong": "H159",
    "langue": "hebreu",
    "numero": 159,
    "mot_original": "אֹהַב",
    "translitteration": "ʾōhaḇ",
    "prononciation": "ʾōhaḇ",
    "definition": "Amour, objet d'amour.",
    "categorie": "Non classé",
    "references": [
      "Osée 9:10"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h159 אֹהַב ʾōhaḇ amour, objet d'amour.",
    "audio": "",
    "image": null
  },
  {
    "id": 200344,
    "strong": "H160",
    "langue": "hebreu",
    "numero": 160,
    "mot_original": "אַהֲבָה",
    "translitteration": "ʾahăḇāh",
    "prononciation": "ʾahăḇāh",
    "definition": "Amour, affection, bienveillance.",
    "categorie": "Non classé",
    "references": [
      "Cantique des Cantiques 8:7",
      "Deutéronome 7:8"
    ],
    "type": "",
    "occurrences": 37,
    "recherche": "h160 אַהֲבָה ʾahăḇāh amour, affection, bienveillance.",
    "audio": "",
    "image": null
  },
  {
    "id": 200345,
    "strong": "H161",
    "langue": "hebreu",
    "numero": 161,
    "mot_original": "אֹהַד",
    "translitteration": "ʾōhaḏ",
    "prononciation": "ʾōhaḏ",
    "definition": "Ohad, fils de Siméon.",
    "categorie": "Non classé",
    "references": [
      "Genèse 46:10"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h161 אֹהַד ʾōhaḏ ohad, fils de siméon.",
    "audio": "",
    "image": null
  },
  {
    "id": 200346,
    "strong": "H162",
    "langue": "hebreu",
    "numero": 162,
    "mot_original": "אֲהָהּ",
    "translitteration": "ʾăhāh",
    "prononciation": "ʾăhāh",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Non classé",
    "references": [
      "Josué 7:7",
      "Jérémie 1:6"
    ],
    "type": "",
    "occurrences": 15,
    "recherche": "h162 אֲהָהּ ʾăhāh ah ! hélas ! exclamation de lamentation.",
    "audio": "",
    "image": null
  },
  {
    "id": 200347,
    "strong": "H163",
    "langue": "hebreu",
    "numero": 163,
    "mot_original": "אַהֲוָא",
    "translitteration": "ʾahăwāʾ",
    "prononciation": "ʾahăwāʾ",
    "definition": "Ahava, localité de Babylonie.",
    "categorie": "Non classé",
    "references": [
      "Esdras 8:15"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h163 אַהֲוָא ʾahăwāʾ ahava, localité de babylonie.",
    "audio": "",
    "image": null
  },
  {
    "id": 200348,
    "strong": "H164",
    "langue": "hebreu",
    "numero": 164,
    "mot_original": "אֵהוּד",
    "translitteration": "ʾēhûḏ",
    "prononciation": "ʾēhûḏ",
    "definition": "Éhoud, second juge d'Israël.",
    "categorie": "Non classé",
    "references": [
      "Juges 3:15"
    ],
    "type": "",
    "occurrences": 9,
    "recherche": "h164 אֵהוּד ʾēhûḏ éhoud, second juge d'israël.",
    "audio": "",
    "image": null
  },
  {
    "id": 200349,
    "strong": "H165",
    "langue": "hebreu",
    "numero": 165,
    "mot_original": "אֱהִי",
    "translitteration": "ʾĕhî",
    "prononciation": "ʾĕhî",
    "definition": "Où ? Où donc ? particule interrogative.",
    "categorie": "Non classé",
    "references": [
      "Osée 13:10"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h165 אֱהִי ʾĕhî où ? où donc ? particule interrogative.",
    "audio": "",
    "image": null
  },
  {
    "id": 200350,
    "strong": "H166",
    "langue": "hebreu",
    "numero": 166,
    "mot_original": "אָהַל",
    "translitteration": "ʾāhal",
    "prononciation": "ʾāhal",
    "definition": "Dresser la tente, camper.",
    "categorie": "Non classé",
    "references": [
      "Genèse 13:12"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h166 אָהַל ʾāhal dresser la tente, camper.",
    "audio": "",
    "image": null
  },
  {
    "id": 200351,
    "strong": "H167",
    "langue": "hebreu",
    "numero": 167,
    "mot_original": "אֹהֶל",
    "translitteration": "ʾōhel",
    "prononciation": "ʾōhel",
    "definition": "Dresser la tente. Doublet de H0166.",
    "categorie": "Non classé",
    "references": [],
    "type": "",
    "occurrences": 0,
    "recherche": "h167 אֹהֶל ʾōhel dresser la tente. doublet de h0166.",
    "audio": "",
    "image": null
  },
  {
    "id": 200352,
    "strong": "H168",
    "langue": "hebreu",
    "numero": 168,
    "mot_original": "אֹהֶל",
    "translitteration": "ʾōhel",
    "prononciation": "ʾōhel",
    "definition": "Tente, habitation temporaire, demeure.",
    "categorie": "Non classé",
    "references": [
      "Genèse 12:8",
      "Exode 33:7",
      "Psaume 27:5"
    ],
    "type": "",
    "occurrences": 345,
    "recherche": "h168 אֹהֶל ʾōhel tente, habitation temporaire, demeure.",
    "audio": "",
    "image": null
  },
  {
    "id": 200353,
    "strong": "H169",
    "langue": "hebreu",
    "numero": 169,
    "mot_original": "אֹהֶל",
    "translitteration": "ʾōhel",
    "prononciation": "ʾōhel",
    "definition": "Ohel, descendant de Juda par Zorobabel.",
    "categorie": "Non classé",
    "references": [
      "1 Chroniques 3:20"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h169 אֹהֶל ʾōhel ohel, descendant de juda par zorobabel.",
    "audio": "",
    "image": null
  },
  {
    "id": 200354,
    "strong": "H170",
    "langue": "hebreu",
    "numero": 170,
    "mot_original": "אָהֳלָה",
    "translitteration": "ʾāholāh",
    "prononciation": "ʾāholāh",
    "definition": "Ohola, nom allégorique de Samarie.",
    "categorie": "Non classé",
    "references": [
      "Ézéchiel 23:4"
    ],
    "type": "",
    "occurrences": 5,
    "recherche": "h170 אָהֳלָה ʾāholāh ohola, nom allégorique de samarie.",
    "audio": "",
    "image": null
  },
  {
    "id": 200355,
    "strong": "H171",
    "langue": "hebreu",
    "numero": 171,
    "mot_original": "אָהֳלִיאָב",
    "translitteration": "ʾāholîʾāḇ",
    "prononciation": "ʾāholîʾāḇ",
    "definition": "Oholiab, artisan assistant de Betsaléel.",
    "categorie": "Non classé",
    "references": [
      "Exode 31:6"
    ],
    "type": "",
    "occurrences": 5,
    "recherche": "h171 אָהֳלִיאָב ʾāholîʾāḇ oholiab, artisan assistant de betsaléel.",
    "audio": "",
    "image": null
  },
  {
    "id": 200356,
    "strong": "H172",
    "langue": "hebreu",
    "numero": 172,
    "mot_original": "אָהֳלִיבָה",
    "translitteration": "ʾāholîḇāh",
    "prononciation": "ʾāholîḇāh",
    "definition": "Oholiba, nom allégorique de Jérusalem.",
    "categorie": "Non classé",
    "references": [
      "Ézéchiel 23:4"
    ],
    "type": "",
    "occurrences": 6,
    "recherche": "h172 אָהֳלִיבָה ʾāholîḇāh oholiba, nom allégorique de jérusalem.",
    "audio": "",
    "image": null
  },
  {
    "id": 200357,
    "strong": "H173",
    "langue": "hebreu",
    "numero": 173,
    "mot_original": "אָהֳלִיבָמָה",
    "translitteration": "ʾāholîḇāmāh",
    "prononciation": "ʾāholîḇāmāh",
    "definition": "Oholibama, épouse d'Ésaü.",
    "categorie": "Non classé",
    "references": [
      "Genèse 36:2"
    ],
    "type": "",
    "occurrences": 8,
    "recherche": "h173 אָהֳלִיבָמָה ʾāholîḇāmāh oholibama, épouse d'ésaü.",
    "audio": "",
    "image": null
  },
  {
    "id": 200358,
    "strong": "H174",
    "langue": "hebreu",
    "numero": 174,
    "mot_original": "אֲהָלִים",
    "translitteration": "ʾăhālîm",
    "prononciation": "ʾăhālîm",
    "definition": "Aloès, bois d'aloès aromatique.",
    "categorie": "Non classé",
    "references": [
      "Psaume 45:9"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h174 אֲהָלִים ʾăhālîm aloès, bois d'aloès aromatique.",
    "audio": "",
    "image": null
  },
  {
    "id": 200359,
    "strong": "H175",
    "langue": "hebreu",
    "numero": 175,
    "mot_original": "אַהֲרוֹן",
    "translitteration": "ʾAhărôn",
    "prononciation": "ʾAhărôn",
    "definition": "Aaron, frère aîné de Moïse, premier grand-prêtre d'Israël, ancêtre de la lignée sacerdotale lévitique.",
    "categorie": "Non classé",
    "references": [
      "Exode 4:14",
      "Exode 28:1"
    ],
    "type": "",
    "occurrences": 0,
    "recherche": "h175 אַהֲרוֹן ʾahărôn aaron, frère aîné de moïse, premier grand-prêtre d'israël, ancêtre de la lignée sacerdotale lévitique.",
    "audio": "",
    "image": null
  },
  {
    "id": 200360,
    "strong": "H176",
    "langue": "hebreu",
    "numero": 176,
    "mot_original": "אוֹ",
    "translitteration": "ʾô",
    "prononciation": "ʾô",
    "definition": "Ou, ou bien, soit.",
    "categorie": "Non classé",
    "references": [
      "Genèse 24:55"
    ],
    "type": "",
    "occurrences": 320,
    "recherche": "h176 אוֹ ʾô ou, ou bien, soit.",
    "audio": "",
    "image": null
  },
  {
    "id": 200361,
    "strong": "H177",
    "langue": "hebreu",
    "numero": 177,
    "mot_original": "אוּאֵל",
    "translitteration": "ʾûʾēl",
    "prononciation": "ʾûʾēl",
    "definition": "Uel, Israélite listé par Esdras.",
    "categorie": "Non classé",
    "references": [
      "Esdras 10:34"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h177 אוּאֵל ʾûʾēl uel, israélite listé par esdras.",
    "audio": "",
    "image": null
  },
  {
    "id": 200362,
    "strong": "H178",
    "langue": "hebreu",
    "numero": 178,
    "mot_original": "אוֹב",
    "translitteration": "ʾôḇ",
    "prononciation": "ʾôḇ",
    "definition": "Nécromancien, esprit des morts.",
    "categorie": "Non classé",
    "references": [
      "1 Samuel 28:7",
      "Lévitique 20:27"
    ],
    "type": "",
    "occurrences": 17,
    "recherche": "h178 אוֹב ʾôḇ nécromancien, esprit des morts.",
    "audio": "",
    "image": null
  },
  {
    "id": 200363,
    "strong": "H179",
    "langue": "hebreu",
    "numero": 179,
    "mot_original": "אוֹבִיל",
    "translitteration": "ʾôḇîl",
    "prononciation": "ʾôḇîl",
    "definition": "Obil, intendant des chameaux de David.",
    "categorie": "Non classé",
    "references": [
      "1 Chroniques 27:30"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h179 אוֹבִיל ʾôḇîl obil, intendant des chameaux de david.",
    "audio": "",
    "image": null
  },
  {
    "id": 200364,
    "strong": "H180",
    "langue": "hebreu",
    "numero": 180,
    "mot_original": "אוֹבָל",
    "translitteration": "ʾôḇāl",
    "prononciation": "ʾôḇāl",
    "definition": "Obal, fils de Yoqtan.",
    "categorie": "Non classé",
    "references": [
      "Genèse 10:28"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h180 אוֹבָל ʾôḇāl obal, fils de yoqtan.",
    "audio": "",
    "image": null
  },
  {
    "id": 200365,
    "strong": "H181",
    "langue": "hebreu",
    "numero": 181,
    "mot_original": "אוּד",
    "translitteration": "ʾûḏ",
    "prononciation": "ʾûḏ",
    "definition": "Tison, brandon, bois à demi brûlé.",
    "categorie": "Non classé",
    "references": [
      "Amos 4:11",
      "Zacharie 3:2"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h181 אוּד ʾûḏ tison, brandon, bois à demi brûlé.",
    "audio": "",
    "image": null
  },
  {
    "id": 200366,
    "strong": "H182",
    "langue": "hebreu",
    "numero": 182,
    "mot_original": "אוֹדוֹת",
    "translitteration": "ʾôḏôṯ",
    "prononciation": "ʾôḏôṯ",
    "definition": "Cause, raison, circonstance, concernant.",
    "categorie": "Non classé",
    "references": [
      "Genèse 21:11"
    ],
    "type": "",
    "occurrences": 11,
    "recherche": "h182 אוֹדוֹת ʾôḏôṯ cause, raison, circonstance, concernant.",
    "audio": "",
    "image": null
  },
  {
    "id": 200367,
    "strong": "H183",
    "langue": "hebreu",
    "numero": 183,
    "mot_original": "אָוָה",
    "translitteration": "ʾāwāh",
    "prononciation": "ʾāwāh",
    "definition": "Désirer ardemment, convoiter.",
    "categorie": "Non classé",
    "references": [
      "Deutéronome 5:18",
      "Psaume 106:14"
    ],
    "type": "",
    "occurrences": 26,
    "recherche": "h183 אָוָה ʾāwāh désirer ardemment, convoiter.",
    "audio": "",
    "image": null
  },
  {
    "id": 200368,
    "strong": "H184",
    "langue": "hebreu",
    "numero": 184,
    "mot_original": "אָוָה",
    "translitteration": "ʾāwāh",
    "prononciation": "ʾāwāh",
    "definition": "Marquer, tracer, délimiter.",
    "categorie": "Non classé",
    "references": [
      "Nombres 34:10"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h184 אָוָה ʾāwāh marquer, tracer, délimiter.",
    "audio": "",
    "image": null
  },
  {
    "id": 200369,
    "strong": "H185",
    "langue": "hebreu",
    "numero": 185,
    "mot_original": "אַוָּה",
    "translitteration": "ʾawwāh",
    "prononciation": "ʾawwāh",
    "definition": "Désir, souhait, volonté, convoitise.",
    "categorie": "Non classé",
    "references": [
      "Deutéronome 12:20"
    ],
    "type": "",
    "occurrences": 7,
    "recherche": "h185 אַוָּה ʾawwāh désir, souhait, volonté, convoitise.",
    "audio": "",
    "image": null
  },
  {
    "id": 200370,
    "strong": "H186",
    "langue": "hebreu",
    "numero": 186,
    "mot_original": "אוּזַי",
    "translitteration": "ʾûzay",
    "prononciation": "ʾûzay",
    "definition": "Uzaï, bâtisseur de la muraille de Jérusalem.",
    "categorie": "Non classé",
    "references": [
      "Néhémie 3:25"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h186 אוּזַי ʾûzay uzaï, bâtisseur de la muraille de jérusalem.",
    "audio": "",
    "image": null
  },
  {
    "id": 200371,
    "strong": "H187",
    "langue": "hebreu",
    "numero": 187,
    "mot_original": "אוּזָל",
    "translitteration": "ʾûzāl",
    "prononciation": "ʾûzāl",
    "definition": "Uzal, descendant de Yoqtan, région d'Arabie.",
    "categorie": "Non classé",
    "references": [
      "Genèse 10:27"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h187 אוּזָל ʾûzāl uzal, descendant de yoqtan, région d'arabie.",
    "audio": "",
    "image": null
  },
  {
    "id": 200372,
    "strong": "H188",
    "langue": "hebreu",
    "numero": 188,
    "mot_original": "אוֹי",
    "translitteration": "ʾôy",
    "prononciation": "ʾôy",
    "definition": "Malheur ! Hélas ! Cri de lamentation.",
    "categorie": "Non classé",
    "references": [
      "Ésaïe 6:5",
      "Nombres 21:29"
    ],
    "type": "",
    "occurrences": 23,
    "recherche": "h188 אוֹי ʾôy malheur ! hélas ! cri de lamentation.",
    "audio": "",
    "image": null
  },
  {
    "id": 200373,
    "strong": "H189",
    "langue": "hebreu",
    "numero": 189,
    "mot_original": "אֱוִי",
    "translitteration": "ʾĕwî",
    "prononciation": "ʾĕwî",
    "definition": "Évi, prince madianite tué par Israël.",
    "categorie": "Non classé",
    "references": [
      "Nombres 31:8"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h189 אֱוִי ʾĕwî évi, prince madianite tué par israël.",
    "audio": "",
    "image": null
  },
  {
    "id": 200374,
    "strong": "H190",
    "langue": "hebreu",
    "numero": 190,
    "mot_original": "אוֹיָה",
    "translitteration": "ʾôyāh",
    "prononciation": "ʾôyāh",
    "definition": "Malheur à moi ! Hélas !",
    "categorie": "Non classé",
    "references": [
      "Psaume 120:5"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h190 אוֹיָה ʾôyāh malheur à moi ! hélas !",
    "audio": "",
    "image": null
  },
  {
    "id": 200375,
    "strong": "H191",
    "langue": "hebreu",
    "numero": 191,
    "mot_original": "אֱוִיל",
    "translitteration": "ʾĕwîl",
    "prononciation": "ʾĕwîl",
    "definition": "Insensé, sot, stupide.",
    "categorie": "Non classé",
    "references": [
      "Proverbes 1:7",
      "Proverbes 12:15"
    ],
    "type": "",
    "occurrences": 26,
    "recherche": "h191 אֱוִיל ʾĕwîl insensé, sot, stupide.",
    "audio": "",
    "image": null
  },
  {
    "id": 200376,
    "strong": "H192",
    "langue": "hebreu",
    "numero": 192,
    "mot_original": "אֱוִיל מְרֹדַךְ",
    "translitteration": "ʾĕwîl mərōḏaḵ",
    "prononciation": "ʾĕwîl mərōḏaḵ",
    "definition": "Évil-Merodak, roi de Babylone.",
    "categorie": "Non classé",
    "references": [
      "2 Rois 25:27"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h192 אֱוִיל מְרֹדַךְ ʾĕwîl mərōḏaḵ évil-merodak, roi de babylone.",
    "audio": "",
    "image": null
  },
  {
    "id": 200377,
    "strong": "H193",
    "langue": "hebreu",
    "numero": 193,
    "mot_original": "אוּל",
    "translitteration": "ʾûl",
    "prononciation": "ʾûl",
    "definition": "Ventre, corps, puissance corporelle.",
    "categorie": "Non classé",
    "references": [
      "Job 40:16"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h193 אוּל ʾûl ventre, corps, puissance corporelle.",
    "audio": "",
    "image": null
  },
  {
    "id": 200378,
    "strong": "H194",
    "langue": "hebreu",
    "numero": 194,
    "mot_original": "אוּלַי",
    "translitteration": "ʾûlay",
    "prononciation": "ʾûlay",
    "definition": "Peut-être, il se peut que.",
    "categorie": "Non classé",
    "references": [
      "Genèse 18:24",
      "Sophonie 2:3"
    ],
    "type": "",
    "occurrences": 42,
    "recherche": "h194 אוּלַי ʾûlay peut-être, il se peut que.",
    "audio": "",
    "image": null
  },
  {
    "id": 200379,
    "strong": "H195",
    "langue": "hebreu",
    "numero": 195,
    "mot_original": "אוּלַי",
    "translitteration": "ʾûlay",
    "prononciation": "ʾûlay",
    "definition": "Oulaï, fleuve d'Élam.",
    "categorie": "Non classé",
    "references": [
      "Daniel 8:2"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h195 אוּלַי ʾûlay oulaï, fleuve d'élam.",
    "audio": "",
    "image": null
  },
  {
    "id": 200380,
    "strong": "H196",
    "langue": "hebreu",
    "numero": 196,
    "mot_original": "אֱוִלִי",
    "translitteration": "ʾĕwilî",
    "prononciation": "ʾĕwilî",
    "definition": "Insensé, stupide. Variante de H0191.",
    "categorie": "Non classé",
    "references": [
      "Zacharie 11:15"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h196 אֱוִלִי ʾĕwilî insensé, stupide. variante de h0191.",
    "audio": "",
    "image": null
  },
  {
    "id": 200381,
    "strong": "H197",
    "langue": "hebreu",
    "numero": 197,
    "mot_original": "אוּלָם",
    "translitteration": "ʾûlām",
    "prononciation": "ʾûlām",
    "definition": "Vestibule, portique, salle d'entrée.",
    "categorie": "Non classé",
    "references": [
      "1 Rois 6:3"
    ],
    "type": "",
    "occurrences": 34,
    "recherche": "h197 אוּלָם ʾûlām vestibule, portique, salle d'entrée.",
    "audio": "",
    "image": null
  },
  {
    "id": 200382,
    "strong": "H198",
    "langue": "hebreu",
    "numero": 198,
    "mot_original": "אוּלָם",
    "translitteration": "ʾûlām",
    "prononciation": "ʾûlām",
    "definition": "Oulam, descendants de Manassé et Benjamin.",
    "categorie": "Non classé",
    "references": [
      "1 Chroniques 8:39"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h198 אוּלָם ʾûlām oulam, descendants de manassé et benjamin.",
    "audio": "",
    "image": null
  },
  {
    "id": 200383,
    "strong": "H199",
    "langue": "hebreu",
    "numero": 199,
    "mot_original": "אוּלָם",
    "translitteration": "ʾûlām",
    "prononciation": "ʾûlām",
    "definition": "Mais, cependant, toutefois.",
    "categorie": "Non classé",
    "references": [
      "Job 1:11"
    ],
    "type": "",
    "occurrences": 12,
    "recherche": "h199 אוּלָם ʾûlām mais, cependant, toutefois.",
    "audio": "",
    "image": null
  },
  {
    "id": 200384,
    "strong": "H200",
    "langue": "hebreu",
    "numero": 200,
    "mot_original": "אִוֶּלֶת",
    "translitteration": "ʾiwweleṯ",
    "prononciation": "ʾiwweleṯ",
    "definition": "Folie, sottise, stupidité morale.",
    "categorie": "Non classé",
    "references": [
      "Proverbes 9:13",
      "Proverbes 14:29"
    ],
    "type": "",
    "occurrences": 25,
    "recherche": "h200 אִוֶּלֶת ʾiwweleṯ folie, sottise, stupidité morale.",
    "audio": "",
    "image": null
  },
  {
    "id": 200095,
    "strong": "H201",
    "langue": "hebreu",
    "numero": 201,
    "mot_original": "אוֹמָר",
    "translitteration": "ʾômār",
    "prononciation": "ʾômār",
    "definition": "Omar, nom d'un chef édomite, descendant d'Ésaü.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 36:11"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h201 אוֹמָר ʾômār omar, nom d'un chef édomite, descendant d'ésaü. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200096,
    "strong": "H202",
    "langue": "hebreu",
    "numero": 202,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "Vigueur, force, puissance virile ; richesse, prospérité.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 49:3",
      "Osée 12:9"
    ],
    "type": "nom commun",
    "occurrences": 12,
    "recherche": "h202 אוֹן ʾôn vigueur, force, puissance virile ; richesse, prospérité. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200097,
    "strong": "H203",
    "langue": "hebreu",
    "numero": 203,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "On, ville égyptienne, Héliopolis, centre du culte solaire.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 41:45"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 3,
    "recherche": "h203 אוֹן ʾôn on, ville égyptienne, héliopolis, centre du culte solaire. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200098,
    "strong": "H204",
    "langue": "hebreu",
    "numero": 204,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "On, nom de lieu. Probablement doublet ou variante de H0203 ou de אָוֶן (H0205).",
    "categorie": "Nom propre",
    "references": [],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h204 אוֹן ʾôn on, nom de lieu. probablement doublet ou variante de h0203 ou de אָוֶן (h0205). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200099,
    "strong": "H205",
    "langue": "hebreu",
    "numero": 205,
    "mot_original": "אָוֶן",
    "translitteration": "ʾāwen",
    "prononciation": "ʾāwen",
    "definition": "Malheur, iniquité, trouble ; vanité, néant ; idole.",
    "categorie": "Nom commun / nom propre",
    "references": [
      "Psaume 90:10",
      "Osée 4:15"
    ],
    "type": "nom commun / nom propre",
    "occurrences": 78,
    "recherche": "h205 אָוֶן ʾāwen malheur, iniquité, trouble ; vanité, néant ; idole. nom commun / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200100,
    "strong": "H206",
    "langue": "hebreu",
    "numero": 206,
    "mot_original": "אָוֶן",
    "translitteration": "ʾāwen",
    "prononciation": "ʾāwen",
    "definition": "Aven, nom de lieu. Doublet toponymique de H0205.",
    "categorie": "Nom propre",
    "references": [
      "Amos 1:5"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 0,
    "recherche": "h206 אָוֶן ʾāwen aven, nom de lieu. doublet toponymique de h0205. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200101,
    "strong": "H207",
    "langue": "hebreu",
    "numero": 207,
    "mot_original": "אוֹנוֹ",
    "translitteration": "ʾônô",
    "prononciation": "ʾônô",
    "definition": "Ono, ville de Benjamin, dans la plaine de Sharon.",
    "categorie": "Nom propre",
    "references": [
      "Néhémie 6:2"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 5,
    "recherche": "h207 אוֹנוֹ ʾônô ono, ville de benjamin, dans la plaine de sharon. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200102,
    "strong": "H208",
    "langue": "hebreu",
    "numero": 208,
    "mot_original": "אוֹנָם",
    "translitteration": "ʾônām",
    "prononciation": "ʾônām",
    "definition": "Onam, nom de deux descendants de Juda et d'Ésaü.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 36:23"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h208 אוֹנָם ʾônām onam, nom de deux descendants de juda et d'ésaü. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200103,
    "strong": "H209",
    "langue": "hebreu",
    "numero": 209,
    "mot_original": "אוֹנָן",
    "translitteration": "ʾônān",
    "prononciation": "ʾônān",
    "definition": "Onan, second fils de Juda et de la fille de Shua.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 38:9"
    ],
    "type": "nom propre",
    "occurrences": 6,
    "recherche": "h209 אוֹנָן ʾônān onan, second fils de juda et de la fille de shua. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200104,
    "strong": "H210",
    "langue": "hebreu",
    "numero": 210,
    "mot_original": "אוּפָז",
    "translitteration": "ʾûp̄āz",
    "prononciation": "ʾûp̄āz",
    "definition": "Ophaz, région productrice d'or, peut-être identique à Ophir.",
    "categorie": "Nom propre",
    "references": [
      "Daniel 10:5"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 2,
    "recherche": "h210 אוּפָז ʾûp̄āz ophaz, région productrice d'or, peut-être identique à ophir. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200105,
    "strong": "H211",
    "langue": "hebreu",
    "numero": 211,
    "mot_original": "אוֹפִיר",
    "translitteration": "ʾôp̄îr",
    "prononciation": "ʾôp̄îr",
    "definition": "Ophir, région légendaire productrice d'or fin, de pierres précieuses et de bois de santal.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 9:28"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 13,
    "recherche": "h211 אוֹפִיר ʾôp̄îr ophir, région légendaire productrice d'or fin, de pierres précieuses et de bois de santal. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200106,
    "strong": "H212",
    "langue": "hebreu",
    "numero": 212,
    "mot_original": "אוֹפָן",
    "translitteration": "ʾôp̄ān",
    "prononciation": "ʾôp̄ān",
    "definition": "Roue, disque, tourbillon.",
    "categorie": "Nom commun",
    "references": [
      "Ézéchiel 1:16"
    ],
    "type": "nom commun",
    "occurrences": 15,
    "recherche": "h212 אוֹפָן ʾôp̄ān roue, disque, tourbillon. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200107,
    "strong": "H213",
    "langue": "hebreu",
    "numero": 213,
    "mot_original": "אוּץ",
    "translitteration": "ʾûṣ",
    "prononciation": "ʾûṣ",
    "definition": "Presser, se hâter, inciter, contraindre.",
    "categorie": "Verbe",
    "references": [
      "Proverbes 19:2"
    ],
    "type": "verbe",
    "occurrences": 10,
    "recherche": "h213 אוּץ ʾûṣ presser, se hâter, inciter, contraindre. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200108,
    "strong": "H214",
    "langue": "hebreu",
    "numero": 214,
    "mot_original": "אוֹצָר",
    "translitteration": "ʾôṣār",
    "prononciation": "ʾôṣār",
    "definition": "Trésor, magasin, entrepôt, réserve.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 28:12"
    ],
    "type": "nom commun",
    "occurrences": 79,
    "recherche": "h214 אוֹצָר ʾôṣār trésor, magasin, entrepôt, réserve. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200109,
    "strong": "H215",
    "langue": "hebreu",
    "numero": 215,
    "mot_original": "אוֹר",
    "translitteration": "ʾôr",
    "prononciation": "ʾôr",
    "definition": "Être lumineux, briller ; éclairer, illuminer.",
    "categorie": "Verbe",
    "references": [
      "Genèse 1:15"
    ],
    "type": "verbe",
    "occurrences": 43,
    "recherche": "h215 אוֹר ʾôr être lumineux, briller ; éclairer, illuminer. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200110,
    "strong": "H216",
    "langue": "hebreu",
    "numero": 216,
    "mot_original": "אוֹר",
    "translitteration": "ʾôr",
    "prononciation": "ʾôr",
    "definition": "Lumière, clarté, rayonnement.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 1:3",
      "Psaume 119:105"
    ],
    "type": "nom commun",
    "occurrences": 123,
    "recherche": "h216 אוֹר ʾôr lumière, clarté, rayonnement. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200111,
    "strong": "H217",
    "langue": "hebreu",
    "numero": 217,
    "mot_original": "אוּר",
    "translitteration": "ʾûr",
    "prononciation": "ʾûr",
    "definition": "Flamme, feu, lumière ardente.",
    "categorie": "Nom commun",
    "references": [
      "Ésaïe 50:11"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h217 אוּר ʾûr flamme, feu, lumière ardente. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200112,
    "strong": "H218",
    "langue": "hebreu",
    "numero": 218,
    "mot_original": "אוּר",
    "translitteration": "ʾûr",
    "prononciation": "ʾûr",
    "definition": "Ur, « Ur des Chaldéens », ville de Mésopotamie, patrie d'Abraham.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 11:31"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 4,
    "recherche": "h218 אוּר ʾûr ur, « ur des chaldéens », ville de mésopotamie, patrie d'abraham. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200113,
    "strong": "H219",
    "langue": "hebreu",
    "numero": 219,
    "mot_original": "אוֹרָה",
    "translitteration": "ʾôrāh",
    "prononciation": "ʾôrāh",
    "definition": "Lumière, clarté, aurore.",
    "categorie": "Nom commun",
    "references": [
      "Psaume 139:12"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h219 אוֹרָה ʾôrāh lumière, clarté, aurore. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200114,
    "strong": "H220",
    "langue": "hebreu",
    "numero": 220,
    "mot_original": "אֲוֵרָה",
    "translitteration": "ʾăwērāh",
    "prononciation": "ʾăwērāh",
    "definition": "Abri, étable, logement pour le bétail.",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h220 אֲוֵרָה ʾăwērāh abri, étable, logement pour le bétail. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200115,
    "strong": "H221",
    "langue": "hebreu",
    "numero": 221,
    "mot_original": "אוּרִי",
    "translitteration": "ʾûrî",
    "prononciation": "ʾûrî",
    "definition": "Ouri, « ma lumière » ou « lumière de YHWH » (forme abrégée de אוריה).",
    "categorie": "Nom propre",
    "references": [
      "Exode 31:2"
    ],
    "type": "nom propre",
    "occurrences": 8,
    "recherche": "h221 אוּרִי ʾûrî ouri, « ma lumière » ou « lumière de yhwh » (forme abrégée de אוריה). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200116,
    "strong": "H222",
    "langue": "hebreu",
    "numero": 222,
    "mot_original": "אוּרִיאֵל",
    "translitteration": "ʾûrîʾēl",
    "prononciation": "ʾûrîʾēl",
    "definition": "Ouriel, « Dieu est ma lumière » ou « lumière de Dieu ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 15:5"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h222 אוּרִיאֵל ʾûrîʾēl ouriel, « dieu est ma lumière » ou « lumière de dieu ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200117,
    "strong": "H223",
    "langue": "hebreu",
    "numero": 223,
    "mot_original": "אוּרִיָּה",
    "translitteration": "ʾûrîyāh",
    "prononciation": "ʾûrîyāh",
    "definition": "Ouriyah (Urie), « YHWH est ma lumière ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 11:3"
    ],
    "type": "nom propre",
    "occurrences": 35,
    "recherche": "h223 אוּרִיָּה ʾûrîyāh ouriyah (urie), « yhwh est ma lumière ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200118,
    "strong": "H224",
    "langue": "hebreu",
    "numero": 224,
    "mot_original": "אוּרִים",
    "translitteration": "ʾûrîm",
    "prononciation": "ʾûrîm",
    "definition": "Ourim, objet divinatoire associé au pectoral du grand-prêtre.",
    "categorie": "Nom commun",
    "references": [
      "Exode 28:30"
    ],
    "type": "nom commun (pluriel lexicalisé)",
    "occurrences": 7,
    "recherche": "h224 אוּרִים ʾûrîm ourim, objet divinatoire associé au pectoral du grand-prêtre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200119,
    "strong": "H225",
    "langue": "hebreu",
    "numero": 225,
    "mot_original": "אוּת",
    "translitteration": "ʾûṯ",
    "prononciation": "ʾûṯ",
    "definition": "Consentir, accepter, être d'accord.",
    "categorie": "Verbe",
    "references": [
      "2 Rois 12:9"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h225 אוּת ʾûṯ consentir, accepter, être d'accord. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200120,
    "strong": "H226",
    "langue": "hebreu",
    "numero": 226,
    "mot_original": "אוֹת",
    "translitteration": "ʾôṯ",
    "prononciation": "ʾôṯ",
    "definition": "Signe, signal, marque, prodige, miracle.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 9:13",
      "Exode 31:13"
    ],
    "type": "nom commun",
    "occurrences": 79,
    "recherche": "h226 אוֹת ʾôṯ signe, signal, marque, prodige, miracle. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200121,
    "strong": "H227",
    "langue": "hebreu",
    "numero": 227,
    "mot_original": "אָז",
    "translitteration": "ʾāz",
    "prononciation": "ʾāz",
    "definition": "Alors, à ce moment-là, en ce temps-là.",
    "categorie": "Adverbe",
    "references": [
      "Exode 15:1",
      "Psaume 126:2"
    ],
    "type": "adverbe",
    "occurrences": 140,
    "recherche": "h227 אָז ʾāz alors, à ce moment-là, en ce temps-là. adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200122,
    "strong": "H228",
    "langue": "hebreu",
    "numero": 228,
    "mot_original": "אֲזָא",
    "translitteration": "ʾăzāʾ",
    "prononciation": "ʾăzāʾ",
    "definition": "Aller, s'en aller (araméen). Doublet probable de H0230.",
    "categorie": "Verbe",
    "references": [],
    "type": "verbe (araméen)",
    "occurrences": 1,
    "recherche": "h228 אֲזָא ʾăzāʾ aller, s'en aller (araméen). doublet probable de h0230. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200123,
    "strong": "H229",
    "langue": "hebreu",
    "numero": 229,
    "mot_original": "אֶזְבַּי",
    "translitteration": "ʾezbay",
    "prononciation": "ʾezbay",
    "definition": "Ezbay, père d'un guerrier de David.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 11:37"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h229 אֶזְבַּי ʾezbay ezbay, père d'un guerrier de david. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200124,
    "strong": "H230",
    "langue": "hebreu",
    "numero": 230,
    "mot_original": "אַזְדָּא",
    "translitteration": "ʾazdāʾ",
    "prononciation": "ʾazdāʾ",
    "definition": "Certain, sûr, décidé ; échapper (sens incertain en araméen).",
    "categorie": "Adjectif / participe",
    "references": [
      "Daniel 2:5"
    ],
    "type": "adjectif / participe (araméen)",
    "occurrences": 2,
    "recherche": "h230 אַזְדָּא ʾazdāʾ certain, sûr, décidé ; échapper (sens incertain en araméen). adjectif / participe",
    "audio": "",
    "image": null
  },
  {
    "id": 200125,
    "strong": "H231",
    "langue": "hebreu",
    "numero": 231,
    "mot_original": "אֵזוֹב",
    "translitteration": "ʾēzôḇ",
    "prononciation": "ʾēzôḇ",
    "definition": "Hysope, plante aromatique utilisée pour l'aspersion rituelle.",
    "categorie": "Nom commun",
    "references": [
      "Exode 12:22",
      "Psaume 51:9"
    ],
    "type": "nom commun",
    "occurrences": 10,
    "recherche": "h231 אֵזוֹב ʾēzôḇ hysope, plante aromatique utilisée pour l'aspersion rituelle. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200126,
    "strong": "H232",
    "langue": "hebreu",
    "numero": 232,
    "mot_original": "אֵזוֹר",
    "translitteration": "ʾēzôr",
    "prononciation": "ʾēzôr",
    "definition": "Ceinture, pagne, écharpe portée autour des reins.",
    "categorie": "Nom commun",
    "references": [
      "Jérémie 13:1"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h232 אֵזוֹר ʾēzôr ceinture, pagne, écharpe portée autour des reins. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200127,
    "strong": "H233",
    "langue": "hebreu",
    "numero": 233,
    "mot_original": "אֲזַי",
    "translitteration": "ʾăzay",
    "prononciation": "ʾăzay",
    "definition": "Alors, à ce moment-là. Variante poétique de אָז (H0227).",
    "categorie": "Adverbe",
    "references": [
      "Psaume 124:3"
    ],
    "type": "adverbe",
    "occurrences": 3,
    "recherche": "h233 אֲזַי ʾăzay alors, à ce moment-là. variante poétique de אָז (h0227). adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200128,
    "strong": "H234",
    "langue": "hebreu",
    "numero": 234,
    "mot_original": "אַזְכָּרָה",
    "translitteration": "ʾazkārāh",
    "prononciation": "ʾazkārāh",
    "definition": "Mémorial, portion commémorative, offrande consumée sur l'autel en souvenir.",
    "categorie": "Nom commun",
    "references": [
      "Lévitique 2:2"
    ],
    "type": "nom commun",
    "occurrences": 7,
    "recherche": "h234 אַזְכָּרָה ʾazkārāh mémorial, portion commémorative, offrande consumée sur l'autel en souvenir. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200129,
    "strong": "H235",
    "langue": "hebreu",
    "numero": 235,
    "mot_original": "אָזַל",
    "translitteration": "ʾāzal",
    "prononciation": "ʾāzal",
    "definition": "Aller, s'en aller, partir, disparaître.",
    "categorie": "Verbe",
    "references": [
      "Deutéronome 32:36"
    ],
    "type": "verbe",
    "occurrences": 6,
    "recherche": "h235 אָזַל ʾāzal aller, s'en aller, partir, disparaître. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200130,
    "strong": "H236",
    "langue": "hebreu",
    "numero": 236,
    "mot_original": "אֲזַל",
    "translitteration": "ʾăzal",
    "prononciation": "ʾăzal",
    "definition": "Aller, s'en aller. Correspondance araméenne de l'hébreu אָזַל (H0235).",
    "categorie": "Verbe",
    "references": [
      "Esdras 5:8"
    ],
    "type": "verbe (araméen)",
    "occurrences": 7,
    "recherche": "h236 אֲזַל ʾăzal aller, s'en aller. correspondance araméenne de l'hébreu אָזַל (h0235). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200131,
    "strong": "H237",
    "langue": "hebreu",
    "numero": 237,
    "mot_original": "אֶזֶל",
    "translitteration": "ʾezel",
    "prononciation": "ʾezel",
    "definition": "Ézel, nom d'une pierre ou d'un lieu près de Guibéa.",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 20:19"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h237 אֶזֶל ʾezel ézel, nom d'une pierre ou d'un lieu près de guibéa. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200132,
    "strong": "H238",
    "langue": "hebreu",
    "numero": 238,
    "mot_original": "אָזַן",
    "translitteration": "ʾāzan",
    "prononciation": "ʾāzan",
    "definition": "Prêter l'oreille, écouter attentivement, être attentif.",
    "categorie": "Verbe",
    "references": [
      "Deutéronome 32:1"
    ],
    "type": "verbe",
    "occurrences": 41,
    "recherche": "h238 אָזַן ʾāzan prêter l'oreille, écouter attentivement, être attentif. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200133,
    "strong": "H239",
    "langue": "hebreu",
    "numero": 239,
    "mot_original": "אָזַן",
    "translitteration": "ʾāzan",
    "prononciation": "ʾāzan",
    "definition": "Peser, équilibrer ; examiner attentivement.",
    "categorie": "Verbe",
    "references": [
      "Ecclésiaste 12:9"
    ],
    "type": "verbe (piel)",
    "occurrences": 1,
    "recherche": "h239 אָזַן ʾāzan peser, équilibrer ; examiner attentivement. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200134,
    "strong": "H240",
    "langue": "hebreu",
    "numero": 240,
    "mot_original": "אָזֵן",
    "translitteration": "ʾāzēn",
    "prononciation": "ʾāzēn",
    "definition": "Outil, instrument, arme ; variante rare de אֹזֶן ou mot distinct.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 23:14"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h240 אָזֵן ʾāzēn outil, instrument, arme ; variante rare de אֹזֶן ou mot distinct. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200135,
    "strong": "H241",
    "langue": "hebreu",
    "numero": 241,
    "mot_original": "אֹזֶן",
    "translitteration": "ʾōzen",
    "prononciation": "ʾōzen",
    "definition": "Oreille, organe de l'ouïe ; anse, poignée.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 29:3",
      "Psaume 40:7"
    ],
    "type": "nom commun",
    "occurrences": 187,
    "recherche": "h241 אֹזֶן ʾōzen oreille, organe de l'ouïe ; anse, poignée. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200136,
    "strong": "H242",
    "langue": "hebreu",
    "numero": 242,
    "mot_original": "אוּזֵן שֶׁאֱרָה",
    "translitteration": "ʾûzēn šeʾĕrāh",
    "prononciation": "ʾûzēn šeʾĕrāh",
    "definition": "Ouzen-Shééra, ville bâtie par Shééra, fille d'Éphraïm.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 7:24"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h242 אוּזֵן שֶׁאֱרָה ʾûzēn šeʾĕrāh ouzen-shééra, ville bâtie par shééra, fille d'éphraïm. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200137,
    "strong": "H243",
    "langue": "hebreu",
    "numero": 243,
    "mot_original": "אַזְנוֹת תָּבוֹר",
    "translitteration": "ʾAznôwth Tâbôwr",
    "prononciation": "ʾAznôwth Tâbôwr",
    "definition": "Aznoth-Tabor, localité frontalière du territoire de Nephtali, près du mont Thabor.",
    "categorie": "Nom propre",
    "references": [
      "Josué 19:34"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h243 אַזְנוֹת תָּבוֹר ʾaznôwth tâbôwr aznoth-tabor, localité frontalière du territoire de nephtali, près du mont thabor. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200138,
    "strong": "H244",
    "langue": "hebreu",
    "numero": 244,
    "mot_original": "אָזְנִי",
    "translitteration": "ʾāznî",
    "prononciation": "ʾāznî",
    "definition": "Ozni, ancêtre éponyme du clan oznite, de la tribu de Gad.",
    "categorie": "Nom propre",
    "references": [
      "Nombres 26:16"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h244 אָזְנִי ʾāznî ozni, ancêtre éponyme du clan oznite, de la tribu de gad. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200139,
    "strong": "H245",
    "langue": "hebreu",
    "numero": 245,
    "mot_original": "אֲזַנְיָה",
    "translitteration": "ʾăzanyāh",
    "prononciation": "ʾăzanyāh",
    "definition": "Azaniah, « YHWH a entendu » ou « YHWH écoute ».",
    "categorie": "Nom propre",
    "references": [
      "Néhémie 10:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h245 אֲזַנְיָה ʾăzanyāh azaniah, « yhwh a entendu » ou « yhwh écoute ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200140,
    "strong": "H246",
    "langue": "hebreu",
    "numero": 246,
    "mot_original": "אֲזִקִּים",
    "translitteration": "ʾăziqqîm",
    "prononciation": "ʾăziqqîm",
    "definition": "Chaînes, menottes, liens.",
    "categorie": "Nom commun",
    "references": [
      "Jérémie 40:1"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h246 אֲזִקִּים ʾăziqqîm chaînes, menottes, liens. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200141,
    "strong": "H247",
    "langue": "hebreu",
    "numero": 247,
    "mot_original": "אָזַר",
    "translitteration": "ʾāzar",
    "prononciation": "ʾāzar",
    "definition": "Ceindre, entourer, revêtir (spécialement d'une ceinture ou de force).",
    "categorie": "Verbe",
    "references": [
      "Jérémie 1:17",
      "Psaume 93:1"
    ],
    "type": "verbe",
    "occurrences": 16,
    "recherche": "h247 אָזַר ʾāzar ceindre, entourer, revêtir (spécialement d'une ceinture ou de force). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200142,
    "strong": "H248",
    "langue": "hebreu",
    "numero": 248,
    "mot_original": "אֶזְרוֹעַ",
    "translitteration": "ʾezrôaʿ",
    "prononciation": "ʾezrôaʿ",
    "definition": "Bras, avant-bras. Variante poétique de זְרוֹעַ (H2220).",
    "categorie": "Nom commun",
    "references": [
      "Jérémie 32:21"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h248 אֶזְרוֹעַ ʾezrôaʿ bras, avant-bras. variante poétique de זְרוֹעַ (h2220). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200143,
    "strong": "H249",
    "langue": "hebreu",
    "numero": 249,
    "mot_original": "אֶזְרָח",
    "translitteration": "ʾezrāḥ",
    "prononciation": "ʾezrāḥ",
    "definition": "Autochtone, indigène, citoyen de naissance.",
    "categorie": "Nom commun / adjectif",
    "references": [
      "Lévitique 19:34"
    ],
    "type": "nom commun / adjectif",
    "occurrences": 18,
    "recherche": "h249 אֶזְרָח ʾezrāḥ autochtone, indigène, citoyen de naissance. nom commun / adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200144,
    "strong": "H250",
    "langue": "hebreu",
    "numero": 250,
    "mot_original": "אֶזְרָחִי",
    "translitteration": "ʾezrāḥî",
    "prononciation": "ʾezrāḥî",
    "definition": "Ezrahite, membre du clan d'Ézer ou de Zérah.",
    "categorie": "Nom propre / adjectif gentilé",
    "references": [
      "1 Rois 5:11"
    ],
    "type": "nom propre / adjectif gentilé",
    "occurrences": 3,
    "recherche": "h250 אֶזְרָחִי ʾezrāḥî ezrahite, membre du clan d'ézer ou de zérah. nom propre / adjectif gentilé",
    "audio": "",
    "image": null
  },
  {
    "id": 200145,
    "strong": "H251",
    "langue": "hebreu",
    "numero": 251,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Frère, parent, compatriote, prochain.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 4:9",
      "Lévitique 19:17"
    ],
    "type": "nom commun",
    "occurrences": 629,
    "recherche": "h251 אָח ʾāḥ frère, parent, compatriote, prochain. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200146,
    "strong": "H252",
    "langue": "hebreu",
    "numero": 252,
    "mot_original": "אַח",
    "translitteration": "ʾaḥ",
    "prononciation": "ʾaḥ",
    "definition": "Frère. Correspondance araméenne de l'hébreu אָח (H0251).",
    "categorie": "Nom commun",
    "references": [
      "Esdras 7:18"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 1,
    "recherche": "h252 אַח ʾaḥ frère. correspondance araméenne de l'hébreu אָח (h0251). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200147,
    "strong": "H253",
    "langue": "hebreu",
    "numero": 253,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Interjection",
    "references": [
      "Ézéchiel 6:11"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h253 אָח ʾāḥ ah ! hélas ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null
  },
  {
    "id": 200148,
    "strong": "H254",
    "langue": "hebreu",
    "numero": 254,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Brasero, foyer, réchaud.",
    "categorie": "Nom commun",
    "references": [
      "Jérémie 36:22"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h254 אָח ʾāḥ brasero, foyer, réchaud. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200149,
    "strong": "H255",
    "langue": "hebreu",
    "numero": 255,
    "mot_original": "אֹחַ",
    "translitteration": "ʾōaḥ",
    "prononciation": "ʾōaḥ",
    "definition": "Hibou, chat-huant, animal des ruines.",
    "categorie": "Nom commun",
    "references": [
      "Ésaïe 13:21"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h255 אֹחַ ʾōaḥ hibou, chat-huant, animal des ruines. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200150,
    "strong": "H256",
    "langue": "hebreu",
    "numero": 256,
    "mot_original": "אַחְאָב",
    "translitteration": "ʾaḥʾāḇ",
    "prononciation": "ʾaḥʾāḇ",
    "definition": "Achab, « frère du père » ou « oncle paternel ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 16:30"
    ],
    "type": "nom propre",
    "occurrences": 93,
    "recherche": "h256 אַחְאָב ʾaḥʾāḇ achab, « frère du père » ou « oncle paternel ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200151,
    "strong": "H257",
    "langue": "hebreu",
    "numero": 257,
    "mot_original": "אַחְבָּן",
    "translitteration": "ʾaḥbān",
    "prononciation": "ʾaḥbān",
    "definition": "Ahban, descendant de Juda par Yerakhméel.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 2:29"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h257 אַחְבָּן ʾaḥbān ahban, descendant de juda par yerakhméel. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200152,
    "strong": "H258",
    "langue": "hebreu",
    "numero": 258,
    "mot_original": "אָחַד",
    "translitteration": "ʾāḥaḏ",
    "prononciation": "ʾāḥaḏ",
    "definition": "S'unir, être uni, ne faire qu'un.",
    "categorie": "Verbe",
    "references": [
      "Genèse 49:6"
    ],
    "type": "verbe",
    "occurrences": 3,
    "recherche": "h258 אָחַד ʾāḥaḏ s'unir, être uni, ne faire qu'un. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200153,
    "strong": "H259",
    "langue": "hebreu",
    "numero": 259,
    "mot_original": "אֶחָד",
    "translitteration": "ʾeḥāḏ",
    "prononciation": "ʾeḥāḏ",
    "definition": "Un, unique, premier, seul.",
    "categorie": "Adjectif numéral",
    "references": [
      "Deutéronome 6:4",
      "Genèse 2:24"
    ],
    "type": "adjectif numéral",
    "occurrences": 962,
    "recherche": "h259 אֶחָד ʾeḥāḏ un, unique, premier, seul. adjectif numéral",
    "audio": "",
    "image": null
  },
  {
    "id": 200154,
    "strong": "H260",
    "langue": "hebreu",
    "numero": 260,
    "mot_original": "אָחוּ",
    "translitteration": "ʾāḥû",
    "prononciation": "ʾāḥû",
    "definition": "Jonc, roseau, papyrus ; pâturage marécageux.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 41:2"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h260 אָחוּ ʾāḥû jonc, roseau, papyrus ; pâturage marécageux. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200155,
    "strong": "H261",
    "langue": "hebreu",
    "numero": 261,
    "mot_original": "אֵחוּד",
    "translitteration": "ʾēḥûḏ",
    "prononciation": "ʾēḥûḏ",
    "definition": "Éhoud, chef benjaminite. Variante orthographique de אֵהוּד (H0164).",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:6"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h261 אֵחוּד ʾēḥûḏ éhoud, chef benjaminite. variante orthographique de אֵהוּד (h0164). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200156,
    "strong": "H262",
    "langue": "hebreu",
    "numero": 262,
    "mot_original": "אַחְוָה",
    "translitteration": "ʾaḥwāh",
    "prononciation": "ʾaḥwāh",
    "definition": "Déclaration, parole, annonce.",
    "categorie": "Nom commun",
    "references": [
      "Psaume 19:3",
      "Zacharie 11:7"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h262 אַחְוָה ʾaḥwāh déclaration, parole, annonce. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200157,
    "strong": "H263",
    "langue": "hebreu",
    "numero": 263,
    "mot_original": "אַחְוָה",
    "translitteration": "ʾaḥwāh",
    "prononciation": "ʾaḥwāh",
    "definition": "Déclaration, explication, interprétation.",
    "categorie": "Nom commun",
    "references": [
      "Daniel 5:12"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 1,
    "recherche": "h263 אַחְוָה ʾaḥwāh déclaration, explication, interprétation. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200158,
    "strong": "H264",
    "langue": "hebreu",
    "numero": 264,
    "mot_original": "אַחֲוָה",
    "translitteration": "ʾaḥăwāh",
    "prononciation": "ʾaḥăwāh",
    "definition": "Fraternité, union fraternelle. Variante orthographique de H0262.",
    "categorie": "Nom commun",
    "references": [
      "Zacharie 11:14"
    ],
    "type": "nom commun",
    "occurrences": 0,
    "recherche": "h264 אַחֲוָה ʾaḥăwāh fraternité, union fraternelle. variante orthographique de h0262. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200159,
    "strong": "H265",
    "langue": "hebreu",
    "numero": 265,
    "mot_original": "אֲחוֹחַ",
    "translitteration": "ʾăḥôaḥ",
    "prononciation": "ʾăḥôaḥ",
    "definition": "Ahoah, descendant de Benjamin, ancêtre du clan ahoahite.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h265 אֲחוֹחַ ʾăḥôaḥ ahoah, descendant de benjamin, ancêtre du clan ahoahite. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200160,
    "strong": "H266",
    "langue": "hebreu",
    "numero": 266,
    "mot_original": "אֲחוֹחִי",
    "translitteration": "ʾăḥôḥî",
    "prononciation": "ʾăḥôḥî",
    "definition": "Ahoahite, membre du clan d'Ahoah.",
    "categorie": "Adjectif gentilé",
    "references": [
      "2 Samuel 23:9"
    ],
    "type": "adjectif gentilé",
    "occurrences": 4,
    "recherche": "h266 אֲחוֹחִי ʾăḥôḥî ahoahite, membre du clan d'ahoah. adjectif gentilé",
    "audio": "",
    "image": null
  },
  {
    "id": 200161,
    "strong": "H267",
    "langue": "hebreu",
    "numero": 267,
    "mot_original": "אֲחוּמַי",
    "translitteration": "ʾăḥûmay",
    "prononciation": "ʾăḥûmay",
    "definition": "Ahoumaï, descendant de Juda par Shobal.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 4:2"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h267 אֲחוּמַי ʾăḥûmay ahoumaï, descendant de juda par shobal. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200162,
    "strong": "H268",
    "langue": "hebreu",
    "numero": 268,
    "mot_original": "אָחוֹר",
    "translitteration": "ʾāḥôr",
    "prononciation": "ʾāḥôr",
    "definition": "Arrière, dos, partie postérieure ; en arrière.",
    "categorie": "Nom commun / adverbe",
    "references": [
      "Genèse 49:17",
      "Jérémie 7:24"
    ],
    "type": "nom commun / adverbe",
    "occurrences": 41,
    "recherche": "h268 אָחוֹר ʾāḥôr arrière, dos, partie postérieure ; en arrière. nom commun / adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200163,
    "strong": "H269",
    "langue": "hebreu",
    "numero": 269,
    "mot_original": "אָחוֹת",
    "translitteration": "ʾāḥôṯ",
    "prononciation": "ʾāḥôṯ",
    "definition": "Sœur, parente, compagne.",
    "categorie": "Nom commun",
    "references": [
      "Ézéchiel 16:45"
    ],
    "type": "nom commun",
    "occurrences": 114,
    "recherche": "h269 אָחוֹת ʾāḥôṯ sœur, parente, compagne. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200164,
    "strong": "H270",
    "langue": "hebreu",
    "numero": 270,
    "mot_original": "אָחַז",
    "translitteration": "ʾāḥaz",
    "prononciation": "ʾāḥaz",
    "definition": "Saisir, prendre, tenir, posséder.",
    "categorie": "Verbe",
    "references": [
      "Genèse 25:26",
      "Exode 15:14"
    ],
    "type": "verbe",
    "occurrences": 69,
    "recherche": "h270 אָחַז ʾāḥaz saisir, prendre, tenir, posséder. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200165,
    "strong": "H271",
    "langue": "hebreu",
    "numero": 271,
    "mot_original": "אָחָז",
    "translitteration": "ʾāḥāz",
    "prononciation": "ʾāḥāz",
    "definition": "Achaz, « il a saisi », roi de Juda, fils de Yotam, père d'Ézéchias.",
    "categorie": "Nom propre",
    "references": [
      "2 Rois 16:1"
    ],
    "type": "nom propre",
    "occurrences": 41,
    "recherche": "h271 אָחָז ʾāḥāz achaz, « il a saisi », roi de juda, fils de yotam, père d'ézéchias. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200166,
    "strong": "H272",
    "langue": "hebreu",
    "numero": 272,
    "mot_original": "אֲחֻזָּה",
    "translitteration": "ʾăḥuzzāh",
    "prononciation": "ʾăḥuzzāh",
    "definition": "Propriété foncière, possession, domaine héréditaire.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 23:4",
      "Lévitique 25:24"
    ],
    "type": "nom commun",
    "occurrences": 66,
    "recherche": "h272 אֲחֻזָּה ʾăḥuzzāh propriété foncière, possession, domaine héréditaire. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200167,
    "strong": "H273",
    "langue": "hebreu",
    "numero": 273,
    "mot_original": "אַחְזַי",
    "translitteration": "ʾaḥzay",
    "prononciation": "ʾaḥzay",
    "definition": "Ahzaï, prêtre du temps de Néhémie.",
    "categorie": "Nom propre",
    "references": [
      "Néhémie 11:13"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h273 אַחְזַי ʾaḥzay ahzaï, prêtre du temps de néhémie. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200168,
    "strong": "H274",
    "langue": "hebreu",
    "numero": 274,
    "mot_original": "אֲחַזְיָה",
    "translitteration": "ʾăḥazyāh",
    "prononciation": "ʾăḥazyāh",
    "definition": "Achaziah, « YHWH a saisi ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 22:52"
    ],
    "type": "nom propre",
    "occurrences": 37,
    "recherche": "h274 אֲחַזְיָה ʾăḥazyāh achaziah, « yhwh a saisi ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200169,
    "strong": "H275",
    "langue": "hebreu",
    "numero": 275,
    "mot_original": "אֲחֻזָּם",
    "translitteration": "ʾăḥuzzām",
    "prononciation": "ʾăḥuzzām",
    "definition": "Ahuzzam, descendant de Juda.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 4:6"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h275 אֲחֻזָּם ʾăḥuzzām ahuzzam, descendant de juda. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200170,
    "strong": "H276",
    "langue": "hebreu",
    "numero": 276,
    "mot_original": "אֲחֻזַּת",
    "translitteration": "ʾăḥuzzaṯ",
    "prononciation": "ʾăḥuzzaṯ",
    "definition": "Ahuzzath, conseiller d'Abimélek, roi philistin de Guérar.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 26:26"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h276 אֲחֻזַּת ʾăḥuzzaṯ ahuzzath, conseiller d'abimélek, roi philistin de guérar. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200171,
    "strong": "H277",
    "langue": "hebreu",
    "numero": 277,
    "mot_original": "אֲחִי",
    "translitteration": "ʾăḥî",
    "prononciation": "ʾăḥî",
    "definition": "Ahi, « mon frère ». Nom de deux personnages.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 5:15"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h277 אֲחִי ʾăḥî ahi, « mon frère ». nom de deux personnages. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200172,
    "strong": "H278",
    "langue": "hebreu",
    "numero": 278,
    "mot_original": "אֵחִי",
    "translitteration": "ʾēḥî",
    "prononciation": "ʾēḥî",
    "definition": "Éhi, fils de Benjamin.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 46:21"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h278 אֵחִי ʾēḥî éhi, fils de benjamin. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200173,
    "strong": "H279",
    "langue": "hebreu",
    "numero": 279,
    "mot_original": "אֲחִיאָם",
    "translitteration": "ʾăḥîʾām",
    "prononciation": "ʾăḥîʾām",
    "definition": "Ahiam, « frère de la mère » ou « frère du peuple ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 23:33"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h279 אֲחִיאָם ʾăḥîʾām ahiam, « frère de la mère » ou « frère du peuple ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200174,
    "strong": "H280",
    "langue": "hebreu",
    "numero": 280,
    "mot_original": "אֲחִידָה",
    "translitteration": "ʾăḥîḏāh",
    "prononciation": "ʾăḥîḏāh",
    "definition": "Énigme, question difficile, problème à résoudre.",
    "categorie": "Nom commun",
    "references": [
      "Daniel 5:12"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 2,
    "recherche": "h280 אֲחִידָה ʾăḥîḏāh énigme, question difficile, problème à résoudre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200175,
    "strong": "H281",
    "langue": "hebreu",
    "numero": 281,
    "mot_original": "אֲחִיָּה",
    "translitteration": "ʾăḥîyāh",
    "prononciation": "ʾăḥîyāh",
    "definition": "Ahiyah, « frère de YHWH » ou « YHWH est mon frère ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 11:29"
    ],
    "type": "nom propre",
    "occurrences": 24,
    "recherche": "h281 אֲחִיָּה ʾăḥîyāh ahiyah, « frère de yhwh » ou « yhwh est mon frère ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200176,
    "strong": "H282",
    "langue": "hebreu",
    "numero": 282,
    "mot_original": "אֲחִיהוּד",
    "translitteration": "ʾăḥîhûḏ",
    "prononciation": "ʾăḥîhûḏ",
    "definition": "Ahihoud, « frère de majesté » ou « frère est majesté ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 34:27"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h282 אֲחִיהוּד ʾăḥîhûḏ ahihoud, « frère de majesté » ou « frère est majesté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200177,
    "strong": "H283",
    "langue": "hebreu",
    "numero": 283,
    "mot_original": "אַחְיוֹ",
    "translitteration": "ʾaḥyô",
    "prononciation": "ʾaḥyô",
    "definition": "Ahyo, « son frère » ou « fraternel ». Nom d'un conducteur de l'arche.",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 6:3"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h283 אַחְיוֹ ʾaḥyô ahyo, « son frère » ou « fraternel ». nom d'un conducteur de l'arche. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200178,
    "strong": "H284",
    "langue": "hebreu",
    "numero": 284,
    "mot_original": "אֲחִיחֻד",
    "translitteration": "ʾăḥîḥuḏ",
    "prononciation": "ʾăḥîḥuḏ",
    "definition": "Ahihoud, variante orthographique de H0282.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:7"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h284 אֲחִיחֻד ʾăḥîḥuḏ ahihoud, variante orthographique de h0282. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200179,
    "strong": "H285",
    "langue": "hebreu",
    "numero": 285,
    "mot_original": "אֲחִיטוּב",
    "translitteration": "ʾăḥîṭûḇ",
    "prononciation": "ʾăḥîṭûḇ",
    "definition": "Ahitub, « mon frère est bonté » ou « frère de bonté ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 14:3"
    ],
    "type": "nom propre",
    "occurrences": 16,
    "recherche": "h285 אֲחִיטוּב ʾăḥîṭûḇ ahitub, « mon frère est bonté » ou « frère de bonté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200180,
    "strong": "H286",
    "langue": "hebreu",
    "numero": 286,
    "mot_original": "אֲחִילוּד",
    "translitteration": "ʾăḥîlûḏ",
    "prononciation": "ʾăḥîlûḏ",
    "definition": "Ahiloud, « frère d'enfantement » ou « frère est né ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 8:16"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h286 אֲחִילוּד ʾăḥîlûḏ ahiloud, « frère d'enfantement » ou « frère est né ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200181,
    "strong": "H287",
    "langue": "hebreu",
    "numero": 287,
    "mot_original": "אֲחִימוֹת",
    "translitteration": "ʾăḥîmôṯ",
    "prononciation": "ʾăḥîmôṯ",
    "definition": "Ahimoth, « mon frère est mort » ou « frère de la mort ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 6:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h287 אֲחִימוֹת ʾăḥîmôṯ ahimoth, « mon frère est mort » ou « frère de la mort ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200182,
    "strong": "H288",
    "langue": "hebreu",
    "numero": 288,
    "mot_original": "אֲחִימֶלֶךְ",
    "translitteration": "ʾăḥîmeleḵ",
    "prononciation": "ʾăḥîmeleḵ",
    "definition": "Ahimélek, « mon frère est roi » ou « frère du roi ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 21:2"
    ],
    "type": "nom propre",
    "occurrences": 17,
    "recherche": "h288 אֲחִימֶלֶךְ ʾăḥîmeleḵ ahimélek, « mon frère est roi » ou « frère du roi ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200183,
    "strong": "H289",
    "langue": "hebreu",
    "numero": 289,
    "mot_original": "אֲחִימַן",
    "translitteration": "ʾăḥîman",
    "prononciation": "ʾăḥîman",
    "definition": "Ahiman, « mon frère est un don » ou signification incertaine.",
    "categorie": "Nom propre",
    "references": [
      "Nombres 13:22"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h289 אֲחִימַן ʾăḥîman ahiman, « mon frère est un don » ou signification incertaine. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200184,
    "strong": "H290",
    "langue": "hebreu",
    "numero": 290,
    "mot_original": "אֲחִימַעַץ",
    "translitteration": "ʾăḥîmaʿaṣ",
    "prononciation": "ʾăḥîmaʿaṣ",
    "definition": "Ahimaats, « mon frère est colère » ou signification incertaine.",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 18:19"
    ],
    "type": "nom propre",
    "occurrences": 15,
    "recherche": "h290 אֲחִימַעַץ ʾăḥîmaʿaṣ ahimaats, « mon frère est colère » ou signification incertaine. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200185,
    "strong": "H291",
    "langue": "hebreu",
    "numero": 291,
    "mot_original": "אַחְיָן",
    "translitteration": "ʾaḥyān",
    "prononciation": "ʾaḥyān",
    "definition": "Ahyan, descendant de Manassé.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 7:19"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h291 אַחְיָן ʾaḥyān ahyan, descendant de manassé. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200186,
    "strong": "H292",
    "langue": "hebreu",
    "numero": 292,
    "mot_original": "אֲחִינָדָב",
    "translitteration": "ʾăḥînāḏāḇ",
    "prononciation": "ʾăḥînāḏāḇ",
    "definition": "Ahinadab, « mon frère est noble » ou « frère de noblesse ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 4:14"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h292 אֲחִינָדָב ʾăḥînāḏāḇ ahinadab, « mon frère est noble » ou « frère de noblesse ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200187,
    "strong": "H293",
    "langue": "hebreu",
    "numero": 293,
    "mot_original": "אֲחִינֹעַם",
    "translitteration": "ʾăḥînōʿam",
    "prononciation": "ʾăḥînōʿam",
    "definition": "Ahinoam, « mon frère est plaisir » ou « frère de douceur ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 25:43"
    ],
    "type": "nom propre",
    "occurrences": 7,
    "recherche": "h293 אֲחִינֹעַם ʾăḥînōʿam ahinoam, « mon frère est plaisir » ou « frère de douceur ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200188,
    "strong": "H294",
    "langue": "hebreu",
    "numero": 294,
    "mot_original": "אֲחִיסָמָךְ",
    "translitteration": "ʾăḥîsāmāḵ",
    "prononciation": "ʾăḥîsāmāḵ",
    "definition": "Ahisamak, « mon frère soutient » ou « frère de soutien ».",
    "categorie": "Nom propre",
    "references": [
      "Exode 31:6"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h294 אֲחִיסָמָךְ ʾăḥîsāmāḵ ahisamak, « mon frère soutient » ou « frère de soutien ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200189,
    "strong": "H295",
    "langue": "hebreu",
    "numero": 295,
    "mot_original": "אֲחִיעֶזֶר",
    "translitteration": "ʾăḥîʿezer",
    "prononciation": "ʾăḥîʿezer",
    "definition": "Ahiézer, « mon frère est secours » ou « frère de secours ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 1:12"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h295 אֲחִיעֶזֶר ʾăḥîʿezer ahiézer, « mon frère est secours » ou « frère de secours ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200190,
    "strong": "H296",
    "langue": "hebreu",
    "numero": 296,
    "mot_original": "אֲחִיקָם",
    "translitteration": "ʾăḥîqām",
    "prononciation": "ʾăḥîqām",
    "definition": "Ahiqam, « mon frère s'est levé » ou « frère de relèvement ».",
    "categorie": "Nom propre",
    "references": [
      "Jérémie 26:24"
    ],
    "type": "nom propre",
    "occurrences": 20,
    "recherche": "h296 אֲחִיקָם ʾăḥîqām ahiqam, « mon frère s'est levé » ou « frère de relèvement ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200191,
    "strong": "H297",
    "langue": "hebreu",
    "numero": 297,
    "mot_original": "אֲחִירָם",
    "translitteration": "ʾăḥîrām",
    "prononciation": "ʾăḥîrām",
    "definition": "Ahiram, « mon frère est élevé » ou « frère du Très-Haut ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 26:38"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h297 אֲחִירָם ʾăḥîrām ahiram, « mon frère est élevé » ou « frère du très-haut ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200192,
    "strong": "H298",
    "langue": "hebreu",
    "numero": 298,
    "mot_original": "אֲחִירָמִי",
    "translitteration": "ʾăḥîrāmî",
    "prononciation": "ʾăḥîrāmî",
    "definition": "Ahiramite, membre du clan d'Ahiram.",
    "categorie": "Adjectif gentilé",
    "references": [
      "Nombres 26:38"
    ],
    "type": "adjectif gentilé",
    "occurrences": 1,
    "recherche": "h298 אֲחִירָמִי ʾăḥîrāmî ahiramite, membre du clan d'ahiram. adjectif gentilé",
    "audio": "",
    "image": null
  },
  {
    "id": 200193,
    "strong": "H299",
    "langue": "hebreu",
    "numero": 299,
    "mot_original": "אֲחִירַע",
    "translitteration": "ʾăḥîraʿ",
    "prononciation": "ʾăḥîraʿ",
    "definition": "Ahira, « mon frère est mauvais » ou « frère du mal ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 1:15"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h299 אֲחִירַע ʾăḥîraʿ ahira, « mon frère est mauvais » ou « frère du mal ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200194,
    "strong": "H300",
    "langue": "hebreu",
    "numero": 300,
    "mot_original": "אֲחִישַׁחַר",
    "translitteration": "ʾăḥîšaḥar",
    "prononciation": "ʾăḥîšaḥar",
    "definition": "Ahishahar, « mon frère est aurore » ou « frère de l'aube ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 7:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h300 אֲחִישַׁחַר ʾăḥîšaḥar ahishahar, « mon frère est aurore » ou « frère de l'aube ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200195,
    "strong": "H311",
    "langue": "hebreu",
    "numero": 311,
    "mot_original": "אַחֲרֵי",
    "translitteration": "ʾaḥărê",
    "prononciation": "akh-ar-ay'",
    "definition": "Après, derrière, à la suite de.",
    "categorie": "Préposition / conjonction",
    "references": [
      "Genèse 5:4",
      "Exode 14:4",
      "Deutéronome 4:3",
      "1 Rois 1:6",
      "Jérémie 2:2"
    ],
    "type": "préposition / conjonction",
    "occurrences": 769,
    "recherche": "h311 אַחֲרֵי ʾaḥărê après, derrière, à la suite de. préposition / conjonction",
    "audio": "",
    "image": null
  },
  {
    "id": 200196,
    "strong": "H312",
    "langue": "hebreu",
    "numero": 312,
    "mot_original": "אַחֵר",
    "translitteration": "ʾaḥēr",
    "prononciation": "akh-air'",
    "definition": "Autre, différent, second.",
    "categorie": "Adjectif",
    "references": [
      "Genèse 4:25",
      "Exode 20:3",
      "Lévitique 13:5",
      "Deutéronome 5:7",
      "Psaume 109:8"
    ],
    "type": "adjectif",
    "occurrences": 166,
    "recherche": "h312 אַחֵר ʾaḥēr autre, différent, second. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200197,
    "strong": "H313",
    "langue": "hebreu",
    "numero": 313,
    "mot_original": "אַחֵר",
    "translitteration": "ʾaḥēr",
    "prononciation": "akh-air'",
    "definition": "Aher, nom d'un descendant de Benjamin.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 7:12"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h313 אַחֵר ʾaḥēr aher, nom d'un descendant de benjamin. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200198,
    "strong": "H314",
    "langue": "hebreu",
    "numero": 314,
    "mot_original": "אַחֲרוֹן",
    "translitteration": "ʾaḥărôn",
    "prononciation": "akh-ar-one'",
    "definition": "Dernier, ultérieur, final.",
    "categorie": "Adjectif",
    "references": [
      "Genèse 33:2",
      "Deutéronome 17:7",
      "Ésaïe 44:6",
      "Ésaïe 48:12",
      "Daniel 8:3"
    ],
    "type": "adjectif",
    "occurrences": 51,
    "recherche": "h314 אַחֲרוֹן ʾaḥărôn dernier, ultérieur, final. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200199,
    "strong": "H315",
    "langue": "hebreu",
    "numero": 315,
    "mot_original": "אַחְרַח",
    "translitteration": "ʾaḥraḥ",
    "prononciation": "akh-rakh'",
    "definition": "Ahrah, descendant de Juda.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 2:25"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h315 אַחְרַח ʾaḥraḥ ahrah, descendant de juda. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200200,
    "strong": "H316",
    "langue": "hebreu",
    "numero": 316,
    "mot_original": "אֲחַרְחֵל",
    "translitteration": "ʾăḥarḥēl",
    "prononciation": "akh-ar-khale'",
    "definition": "Aharhel, descendant de Juda.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 4:8"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h316 אֲחַרְחֵל ʾăḥarḥēl aharhel, descendant de juda. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200201,
    "strong": "H317",
    "langue": "hebreu",
    "numero": 317,
    "mot_original": "אׇחֳרִי",
    "translitteration": "ʾoḥŏrî",
    "prononciation": "okh-or-ee'",
    "definition": "Autre, différent. Correspondance araméenne de l'hébreu אַחֵר (H0312).",
    "categorie": "Adjectif",
    "references": [
      "Daniel 2:11",
      "Daniel 2:39",
      "Daniel 7:5"
    ],
    "type": "adjectif (araméen)",
    "occurrences": 5,
    "recherche": "h317 אׇחֳרִי ʾoḥŏrî autre, différent. correspondance araméenne de l'hébreu אַחֵר (h0312). adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200202,
    "strong": "H318",
    "langue": "hebreu",
    "numero": 318,
    "mot_original": "אׇחֳרֵין",
    "translitteration": "ʾoḥŏrên",
    "prononciation": "okh-or-ane'",
    "definition": "Enfin, finalement, à la fin.",
    "categorie": "Adverbe",
    "references": [
      "Daniel 2:31"
    ],
    "type": "adverbe (araméen)",
    "occurrences": 1,
    "recherche": "h318 אׇחֳרֵין ʾoḥŏrên enfin, finalement, à la fin. adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200203,
    "strong": "H319",
    "langue": "hebreu",
    "numero": 319,
    "mot_original": "אַחֲרִית",
    "translitteration": "ʾaḥărîṯ",
    "prononciation": "akh-ar-eeth'",
    "definition": "Fin, issue, avenir, postérité, reste.",
    "categorie": "Nom commun",
    "references": [
      "Nombres 23:10",
      "Deutéronome 4:30",
      "Proverbes 14:12",
      "Ésaïe 46:10",
      "Daniel 12:8"
    ],
    "type": "nom commun",
    "occurrences": 61,
    "recherche": "h319 אַחֲרִית ʾaḥărîṯ fin, issue, avenir, postérité, reste. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200204,
    "strong": "H320",
    "langue": "hebreu",
    "numero": 320,
    "mot_original": "אַחֲרִית",
    "translitteration": "ʾaḥărîṯ",
    "prononciation": "akh-ar-eeth'",
    "definition": "Fin, avenir. Correspondance araméenne de l'hébreu אַחֲרִית (H0319).",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun (araméen)",
    "occurrences": 0,
    "recherche": "h320 אַחֲרִית ʾaḥărîṯ fin, avenir. correspondance araméenne de l'hébreu אַחֲרִית (h0319). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200205,
    "strong": "H321",
    "langue": "hebreu",
    "numero": 321,
    "mot_original": "אָחֳרָן",
    "translitteration": "ʾoḥŏrān",
    "prononciation": "okh-or-awn'",
    "definition": "Autre, différent. Variante araméenne de אָחֳרִי (H0317).",
    "categorie": "Adjectif",
    "references": [
      "Daniel 2:11",
      "Daniel 3:29",
      "Daniel 6:16"
    ],
    "type": "adjectif (araméen)",
    "occurrences": 5,
    "recherche": "h321 אָחֳרָן ʾoḥŏrān autre, différent. variante araméenne de אָחֳרִי (h0317). adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200206,
    "strong": "H322",
    "langue": "hebreu",
    "numero": 322,
    "mot_original": "אֲחֹרַנִּית",
    "translitteration": "ʾăḥōrannîṯ",
    "prononciation": "akh-o-ran-neeth'",
    "definition": "En arrière, à reculons, vers l'arrière.",
    "categorie": "Adverbe",
    "references": [
      "Genèse 9:23",
      "1 Samuel 4:18",
      "2 Rois 20:10",
      "Ésaïe 38:8"
    ],
    "type": "adverbe",
    "occurrences": 7,
    "recherche": "h322 אֲחֹרַנִּית ʾăḥōrannîṯ en arrière, à reculons, vers l'arrière. adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200207,
    "strong": "H323",
    "langue": "hebreu",
    "numero": 323,
    "mot_original": "אֲחַשְׁדַּרְפָּן",
    "translitteration": "ʾăḥašdarpan",
    "prononciation": "akh-ash-dar-pawn'",
    "definition": "Satrape, gouverneur d'une province de l'Empire perse.",
    "categorie": "Nom commun",
    "references": [
      "Esther 3:12",
      "Esther 8:9",
      "Daniel 3:2",
      "Daniel 6:2"
    ],
    "type": "nom commun",
    "occurrences": 13,
    "recherche": "h323 אֲחַשְׁדַּרְפָּן ʾăḥašdarpan satrape, gouverneur d'une province de l'empire perse. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200208,
    "strong": "H324",
    "langue": "hebreu",
    "numero": 324,
    "mot_original": "אֲחַשְׁדַּרְפָּן",
    "translitteration": "ʾăḥašdarpan",
    "prononciation": "akh-ash-dar-pawn'",
    "definition": "Satrape. Correspondance araméenne de H0323.",
    "categorie": "Nom commun",
    "references": [
      "Daniel 3:2",
      "Daniel 6:2"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 9,
    "recherche": "h324 אֲחַשְׁדַּרְפָּן ʾăḥašdarpan satrape. correspondance araméenne de h0323. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200209,
    "strong": "H325",
    "langue": "hebreu",
    "numero": 325,
    "mot_original": "אֲחַשְׁוֵרוֹשׁ",
    "translitteration": "ʾăḥašwērôš",
    "prononciation": "akh-ash-vay-rosh'",
    "definition": "Assuérus, nom de plusieurs rois perses dans la Bible. Identifié à Xerxès Ier (486-465 avant l'ère courante) dans le livre d'Esther.",
    "categorie": "Nom propre",
    "references": [
      "Esther 1:1",
      "Esther 2:16",
      "Esdras 4:6",
      "Daniel 9:1"
    ],
    "type": "nom propre",
    "occurrences": 31,
    "recherche": "h325 אֲחַשְׁוֵרוֹשׁ ʾăḥašwērôš assuérus, nom de plusieurs rois perses dans la bible. identifié à xerxès ier (486-465 avant l'ère courante) dans le livre d'esther. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200210,
    "strong": "H326",
    "langue": "hebreu",
    "numero": 326,
    "mot_original": "אֲחַשְׁתָּרִי",
    "translitteration": "ʾăḥaštārî",
    "prononciation": "akh-ash-taw-ree'",
    "definition": "Ahashtari, descendant de Juda.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 4:6"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h326 אֲחַשְׁתָּרִי ʾăḥaštārî ahashtari, descendant de juda. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200211,
    "strong": "H327",
    "langue": "hebreu",
    "numero": 327,
    "mot_original": "אֲחַשְׁתָּרָן",
    "translitteration": "ʾăḥaštārān",
    "prononciation": "akh-ash-taw-rawn'",
    "definition": "Coursier, cheval rapide, monture royale.",
    "categorie": "Nom commun",
    "references": [
      "Esther 8:10",
      "Esther 8:14"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h327 אֲחַשְׁתָּרָן ʾăḥaštārān coursier, cheval rapide, monture royale. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200212,
    "strong": "H328",
    "langue": "hebreu",
    "numero": 328,
    "mot_original": "אַט",
    "translitteration": "ʾaṭ",
    "prononciation": "at",
    "definition": "Lentement, doucement, à pas lents.",
    "categorie": "Adverbe",
    "references": [
      "Genèse 33:14",
      "2 Samuel 18:5",
      "1 Rois 21:27",
      "Ésaïe 8:6",
      "Job 15:11"
    ],
    "type": "adverbe",
    "occurrences": 6,
    "recherche": "h328 אַט ʾaṭ lentement, doucement, à pas lents. adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200213,
    "strong": "H329",
    "langue": "hebreu",
    "numero": 329,
    "mot_original": "אָטָד",
    "translitteration": "ʾāṭāḏ",
    "prononciation": "aw-tawd'",
    "definition": "Jujubier, épine, buisson épineux.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 50:10",
      "Juges 9:14",
      "Psaume 58:10"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h329 אָטָד ʾāṭāḏ jujubier, épine, buisson épineux. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200214,
    "strong": "H330",
    "langue": "hebreu",
    "numero": 330,
    "mot_original": "אֵטוּן",
    "translitteration": "ʾēṭûn",
    "prononciation": "ay-toon'",
    "definition": "Lin fin, étoffe précieuse, tissu d'Égypte.",
    "categorie": "Nom commun",
    "references": [
      "Proverbes 7:16"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h330 אֵטוּן ʾēṭûn lin fin, étoffe précieuse, tissu d'égypte. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200215,
    "strong": "H331",
    "langue": "hebreu",
    "numero": 331,
    "mot_original": "אָטַם",
    "translitteration": "ʾāṭam",
    "prononciation": "aw-tam'",
    "definition": "Boucher, fermer, obstruer (spécialement les oreilles).",
    "categorie": "Verbe",
    "references": [
      "1 Rois 6:4",
      "Psaume 58:5",
      "Proverbes 21:13",
      "Ésaïe 33:15"
    ],
    "type": "verbe",
    "occurrences": 8,
    "recherche": "h331 אָטַם ʾāṭam boucher, fermer, obstruer (spécialement les oreilles). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200216,
    "strong": "H332",
    "langue": "hebreu",
    "numero": 332,
    "mot_original": "אָטַר",
    "translitteration": "ʾāṭar",
    "prononciation": "aw-tar'",
    "definition": "Fermer, boucher, retenir.",
    "categorie": "Verbe",
    "references": [
      "Genèse 20:18",
      "Psaume 69:16"
    ],
    "type": "verbe",
    "occurrences": 2,
    "recherche": "h332 אָטַר ʾāṭar fermer, boucher, retenir. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200217,
    "strong": "H333",
    "langue": "hebreu",
    "numero": 333,
    "mot_original": "אָטֵר",
    "translitteration": "ʾāṭēr",
    "prononciation": "aw-tare'",
    "definition": "Ater, « borgne » ou « fermé ». Ancêtre d'une famille de rapatriés de l'exil.",
    "categorie": "Nom propre",
    "references": [
      "Esdras 2:16",
      "Esdras 2:42",
      "Néhémie 7:21",
      "Néhémie 10:18"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h333 אָטֵר ʾāṭēr ater, « borgne » ou « fermé ». ancêtre d'une famille de rapatriés de l'exil. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200218,
    "strong": "H334",
    "langue": "hebreu",
    "numero": 334,
    "mot_original": "אִטֵּר",
    "translitteration": "ʾiṭṭēr",
    "prononciation": "it-tare'",
    "definition": "Gaucher, empêché de la main droite.",
    "categorie": "Adjectif",
    "references": [
      "Juges 3:15",
      "Juges 20:16"
    ],
    "type": "adjectif",
    "occurrences": 2,
    "recherche": "h334 אִטֵּר ʾiṭṭēr gaucher, empêché de la main droite. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200219,
    "strong": "H335",
    "langue": "hebreu",
    "numero": 335,
    "mot_original": "אַי",
    "translitteration": "ʾay",
    "prononciation": "ah'ee",
    "definition": "Où ? Où donc ?",
    "categorie": "Adverbe interrogatif",
    "references": [
      "Genèse 4:9",
      "Deutéronome 32:37",
      "Psaume 42:4",
      "Psaume 115:2"
    ],
    "type": "adverbe interrogatif",
    "occurrences": 0,
    "recherche": "h335 אַי ʾay où ? où donc ? adverbe interrogatif",
    "audio": "",
    "image": null
  },
  {
    "id": 200220,
    "strong": "H336",
    "langue": "hebreu",
    "numero": 336,
    "mot_original": "אִי",
    "translitteration": "ʾî",
    "prononciation": "ee",
    "definition": "Non, pas, il n'y a pas. Particule de négation.",
    "categorie": "Adverbe",
    "references": [
      "Job 22:30"
    ],
    "type": "adverbe",
    "occurrences": 1,
    "recherche": "h336 אִי ʾî non, pas, il n'y a pas. particule de négation. adverbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200221,
    "strong": "H337",
    "langue": "hebreu",
    "numero": 337,
    "mot_original": "אִי",
    "translitteration": "ʾî",
    "prononciation": "ee",
    "definition": "Hélas ! Malheur ! Exclamation de lamentation.",
    "categorie": "Interjection",
    "references": [
      "Ecclésiaste 4:10"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h337 אִי ʾî hélas ! malheur ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null
  },
  {
    "id": 200222,
    "strong": "H338",
    "langue": "hebreu",
    "numero": 338,
    "mot_original": "אִי",
    "translitteration": "ʾî",
    "prononciation": "ee",
    "definition": "Chacal, animal hurlant des ruines.",
    "categorie": "Nom commun",
    "references": [
      "Ésaïe 13:22",
      "Ésaïe 34:14",
      "Jérémie 50:39"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h338 אִי ʾî chacal, animal hurlant des ruines. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200223,
    "strong": "H339",
    "langue": "hebreu",
    "numero": 339,
    "mot_original": "אִי",
    "translitteration": "ʾî",
    "prononciation": "ee",
    "definition": "Île, région côtière, terre lointaine accessible par mer.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 10:5",
      "Ésaïe 41:1",
      "Ésaïe 42:4",
      "Psaume 97:1"
    ],
    "type": "nom commun",
    "occurrences": 36,
    "recherche": "h339 אִי ʾî île, région côtière, terre lointaine accessible par mer. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200224,
    "strong": "H340",
    "langue": "hebreu",
    "numero": 340,
    "mot_original": "אָיַב",
    "translitteration": "ʾāyaḇ",
    "prononciation": "aw-yab'",
    "definition": "Être hostile, être ennemi, haïr.",
    "categorie": "Verbe",
    "references": [
      "Exode 23:22",
      "Deutéronome 30:7",
      "Psaume 83:3"
    ],
    "type": "verbe",
    "occurrences": 0,
    "recherche": "h340 אָיַב ʾāyaḇ être hostile, être ennemi, haïr. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200225,
    "strong": "H341",
    "langue": "hebreu",
    "numero": 341,
    "mot_original": "אֹיֵב",
    "translitteration": "ʾōyēḇ",
    "prononciation": "o-yabe'",
    "definition": "Ennemi, adversaire.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 22:17",
      "Exode 15:6",
      "Psaume 8:3",
      "Psaume 110:1",
      "Ésaïe 1:24"
    ],
    "type": "nom commun (participe substantivé)",
    "occurrences": 282,
    "recherche": "h341 אֹיֵב ʾōyēḇ ennemi, adversaire. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200226,
    "strong": "H342",
    "langue": "hebreu",
    "numero": 342,
    "mot_original": "אֵיבָה",
    "translitteration": "ʾēḇāh",
    "prononciation": "ay-baw'",
    "definition": "Inimitié, hostilité, haine.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 3:15",
      "Nombres 35:21",
      "Ézéchiel 25:15",
      "Ézéchiel 35:5"
    ],
    "type": "nom commun",
    "occurrences": 5,
    "recherche": "h342 אֵיבָה ʾēḇāh inimitié, hostilité, haine. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200227,
    "strong": "H343",
    "langue": "hebreu",
    "numero": 343,
    "mot_original": "אֵיד",
    "translitteration": "ʾêḏ",
    "prononciation": "ade",
    "definition": "Calamité, détresse, ruine, malheur soudain.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 32:35",
      "Job 18:12",
      "Proverbes 1:26",
      "Ésaïe 47:11"
    ],
    "type": "nom commun",
    "occurrences": 24,
    "recherche": "h343 אֵיד ʾêḏ calamité, détresse, ruine, malheur soudain. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200228,
    "strong": "H344",
    "langue": "hebreu",
    "numero": 344,
    "mot_original": "אַיָּה",
    "translitteration": "ʾayyāh",
    "prononciation": "ah-yaw'",
    "definition": "Faucon, busard, oiseau de proie.",
    "categorie": "Nom commun",
    "references": [
      "Lévitique 11:14",
      "Deutéronome 14:13",
      "Job 28:7"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h344 אַיָּה ʾayyāh faucon, busard, oiseau de proie. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200229,
    "strong": "H345",
    "langue": "hebreu",
    "numero": 345,
    "mot_original": "אַיָּה",
    "translitteration": "ʾayyāh",
    "prononciation": "ah-yaw'",
    "definition": "Aya, « faucon ». Nom de deux personnages bibliques.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 36:24",
      "2 Samuel 3:7",
      "2 Samuel 21:8"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h345 אַיָּה ʾayyāh aya, « faucon ». nom de deux personnages bibliques. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200230,
    "strong": "H346",
    "langue": "hebreu",
    "numero": 346,
    "mot_original": "אַיֵּה",
    "translitteration": "ʾayyēh",
    "prononciation": "ah-yay'",
    "definition": "Où ? Où donc ?",
    "categorie": "Adverbe interrogatif",
    "references": [
      "Genèse 18:9",
      "Genèse 22:7",
      "2 Rois 2:14",
      "Psaume 42:4"
    ],
    "type": "adverbe interrogatif",
    "occurrences": 45,
    "recherche": "h346 אַיֵּה ʾayyēh où ? où donc ? adverbe interrogatif",
    "audio": "",
    "image": null
  },
  {
    "id": 200231,
    "strong": "H347",
    "langue": "hebreu",
    "numero": 347,
    "mot_original": "אִיּוֹב",
    "translitteration": "ʾîyôḇ",
    "prononciation": "ee-yobe'",
    "definition": "Job, « l'assailli », « l'hostilisé » ou « où est le père ? ». Patriarche juste et patient.",
    "categorie": "Nom propre",
    "references": [
      "Job 1:1",
      "Job 42:10",
      "Ézéchiel 14:14"
    ],
    "type": "nom propre",
    "occurrences": 58,
    "recherche": "h347 אִיּוֹב ʾîyôḇ job, « l'assailli », « l'hostilisé » ou « où est le père ? ». patriarche juste et patient. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200232,
    "strong": "H348",
    "langue": "hebreu",
    "numero": 348,
    "mot_original": "אִיזָבֶל",
    "translitteration": "ʾîzāḇel",
    "prononciation": "ee-zeh'-bel",
    "definition": "Jézabel, reine d'Israël, épouse d'Achab, fille du roi de Sidon.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 16:31",
      "1 Rois 18:4",
      "1 Rois 21:5",
      "2 Rois 9:30"
    ],
    "type": "nom propre",
    "occurrences": 22,
    "recherche": "h348 אִיזָבֶל ʾîzāḇel jézabel, reine d'israël, épouse d'achab, fille du roi de sidon. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200233,
    "strong": "H349",
    "langue": "hebreu",
    "numero": 349,
    "mot_original": "אֵיךְ",
    "translitteration": "ʾêyk",
    "prononciation": "ake",
    "definition": "Comment ? de quelle manière ? (parfois aussi : où ?).",
    "categorie": "Adverbe interrogatif",
    "references": [],
    "type": "adverbe interrogatif",
    "occurrences": 0,
    "recherche": "h349 אֵיךְ ʾêyk comment ? de quelle manière ? (parfois aussi : où ?). adverbe interrogatif",
    "audio": "",
    "image": null
  },
  {
    "id": 200234,
    "strong": "H350",
    "langue": "hebreu",
    "numero": 350,
    "mot_original": "אִי־כָבוֹד",
    "translitteration": "ʾî-ḵāḇôḏ",
    "prononciation": "ee-kaw-bode'",
    "definition": "I-Kabod, « pas de gloire » ou « où est la gloire ? ». Fils de Phinéas, né après la capture de l'arche.",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 4:21"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h350 אִי־כָבוֹד ʾî-ḵāḇôḏ i-kabod, « pas de gloire » ou « où est la gloire ? ». fils de phinéas, né après la capture de l'arche. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200235,
    "strong": "H351",
    "langue": "hebreu",
    "numero": 351,
    "mot_original": "אֵיכֹה",
    "translitteration": "ʾêḵōh",
    "prononciation": "ay-ko'",
    "definition": "Où ? Vers où ? Comment ?",
    "categorie": "Adverbe interrogatif",
    "references": [
      "2 Rois 6:13",
      "Cantiques 1:7"
    ],
    "type": "adverbe interrogatif",
    "occurrences": 3,
    "recherche": "h351 אֵיכֹה ʾêḵōh où ? vers où ? comment ? adverbe interrogatif",
    "audio": "",
    "image": null
  },
  {
    "id": 200236,
    "strong": "H352",
    "langue": "hebreu",
    "numero": 352,
    "mot_original": "אַיִל",
    "translitteration": "ʾayil",
    "prononciation": "ah'-yil",
    "definition": "Bélier, mâle de l'ovin.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 15:9",
      "Genèse 22:13",
      "Exode 29:15",
      "Lévitique 8:18"
    ],
    "type": "nom commun",
    "occurrences": 185,
    "recherche": "h352 אַיִל ʾayil bélier, mâle de l'ovin. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200237,
    "strong": "H353",
    "langue": "hebreu",
    "numero": 353,
    "mot_original": "אֱיָל",
    "translitteration": "ʾĕyāl",
    "prononciation": "eh-yawl'",
    "definition": "Force, vigueur, puissance.",
    "categorie": "Nom commun",
    "references": [
      "Psaume 22:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h353 אֱיָל ʾĕyāl force, vigueur, puissance. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200238,
    "strong": "H354",
    "langue": "hebreu",
    "numero": 354,
    "mot_original": "אַיָּל",
    "translitteration": "ʾayyāl",
    "prononciation": "ah-yawl'",
    "definition": "Cerf, daim, chevreuil.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 12:15",
      "Deutéronome 12:22",
      "1 Rois 5:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h354 אַיָּל ʾayyāl cerf, daim, chevreuil. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200239,
    "strong": "H355",
    "langue": "hebreu",
    "numero": 355,
    "mot_original": "אַיָּלָה",
    "translitteration": "ʾayyālāh",
    "prononciation": "ah-yaw-law'",
    "definition": "Biche, femelle du cerf.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 49:21",
      "Psaume 18:34",
      "Psaume 42:2",
      "Cantiques 2:7",
      "Habacuc 3:19"
    ],
    "type": "nom commun",
    "occurrences": 7,
    "recherche": "h355 אַיָּלָה ʾayyālāh biche, femelle du cerf. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200240,
    "strong": "H356",
    "langue": "hebreu",
    "numero": 356,
    "mot_original": "אֵילוֹן",
    "translitteration": "ʾêlôn",
    "prononciation": "ay-lone'",
    "definition": "Élon, « grand arbre, chêne, térébinthe ». Nom de trois personnages et d'un lieu.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 26:34",
      "Juges 12:11",
      "Genèse 46:14",
      "Josué 19:43"
    ],
    "type": "nom propre (toponyme / anthroponyme)",
    "occurrences": 10,
    "recherche": "h356 אֵילוֹן ʾêlôn élon, « grand arbre, chêne, térébinthe ». nom de trois personnages et d'un lieu. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200241,
    "strong": "H357",
    "langue": "hebreu",
    "numero": 357,
    "mot_original": "אַיָּלוֹן",
    "translitteration": "ʾayyālôn",
    "prononciation": "ah-yaw-lone'",
    "definition": "Ayyalôn, « lieu des cerfs » ou « grande biche ». Nom de plusieurs localités.",
    "categorie": "Nom propre",
    "references": [
      "Josué 10:12",
      "Josué 19:42",
      "Juges 1:35",
      "2 Chroniques 11:10"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 10,
    "recherche": "h357 אַיָּלוֹן ʾayyālôn ayyalôn, « lieu des cerfs » ou « grande biche ». nom de plusieurs localités. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200242,
    "strong": "H358",
    "langue": "hebreu",
    "numero": 358,
    "mot_original": "אֵילוֹן בֵּית חָנָן",
    "translitteration": "ʾêlôn bêṯ ḥānān",
    "prononciation": "ay-lone' bayth khaw-nawn'",
    "definition": "Élon-Beth-Hanan, « grand arbre de la maison de grâce ». Localité du district de Salomon.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 4:9"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h358 אֵילוֹן בֵּית חָנָן ʾêlôn bêṯ ḥānān élon-beth-hanan, « grand arbre de la maison de grâce ». localité du district de salomon. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200243,
    "strong": "H359",
    "langue": "hebreu",
    "numero": 359,
    "mot_original": "אֵילַת",
    "translitteration": "ʾêlaṯ",
    "prononciation": "ay-lawth'",
    "definition": "Élath, port sur la mer Rouge (golfe d'Aqaba).",
    "categorie": "Nom propre",
    "references": [
      "Deutéronome 2:8",
      "1 Rois 9:26",
      "2 Rois 14:22"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 3,
    "recherche": "h359 אֵילַת ʾêlaṯ élath, port sur la mer rouge (golfe d'aqaba). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200244,
    "strong": "H360",
    "langue": "hebreu",
    "numero": 360,
    "mot_original": "אֵילוֹת",
    "translitteration": "ʾêlôṯ",
    "prononciation": "ay-loth'",
    "definition": "Éloth, variante orthographique de Élath (H0359).",
    "categorie": "Nom propre",
    "references": [],
    "type": "nom propre (toponyme)",
    "occurrences": 3,
    "recherche": "h360 אֵילוֹת ʾêlôṯ éloth, variante orthographique de élath (h0359). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200245,
    "strong": "H361",
    "langue": "hebreu",
    "numero": 361,
    "mot_original": "אֵילָם",
    "translitteration": "ʾêlām",
    "prononciation": "ay-lawm'",
    "definition": "Vestibule, portique, galerie à colonnes.",
    "categorie": "Nom commun",
    "references": [
      "Ézéchiel 40:16",
      "Ézéchiel 41:15"
    ],
    "type": "nom commun",
    "occurrences": 15,
    "recherche": "h361 אֵילָם ʾêlām vestibule, portique, galerie à colonnes. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200246,
    "strong": "H362",
    "langue": "hebreu",
    "numero": 362,
    "mot_original": "אֵילִם",
    "translitteration": "ʾêlim",
    "prononciation": "ay-leem'",
    "definition": "Élim, « grands arbres, térébinthes ». Oasis dans le désert après le passage de la mer.",
    "categorie": "Nom propre",
    "references": [
      "Exode 15:27",
      "Exode 16:1",
      "Nombres 33:9"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 6,
    "recherche": "h362 אֵילִם ʾêlim élim, « grands arbres, térébinthes ». oasis dans le désert après le passage de la mer. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200247,
    "strong": "H363",
    "langue": "hebreu",
    "numero": 363,
    "mot_original": "אִילָן",
    "translitteration": "ʾîlān",
    "prononciation": "ee-lawn'",
    "definition": "Arbre. Correspondance araméenne de l'hébreu אֵיל (arbre).",
    "categorie": "Nom commun",
    "references": [
      "Daniel 4:7",
      "Daniel 4:17"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 6,
    "recherche": "h363 אִילָן ʾîlān arbre. correspondance araméenne de l'hébreu אֵיל (arbre). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200248,
    "strong": "H364",
    "langue": "hebreu",
    "numero": 364,
    "mot_original": "אֵיל פָּארָן",
    "translitteration": "ʾêl pāʾrān",
    "prononciation": "ale paw-rawn'",
    "definition": "Él-Paran, « grand arbre de Paran » ou « térébinthe de Paran ». Localité du désert.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 14:6"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h364 אֵיל פָּארָן ʾêl pāʾrān él-paran, « grand arbre de paran » ou « térébinthe de paran ». localité du désert. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200249,
    "strong": "H365",
    "langue": "hebreu",
    "numero": 365,
    "mot_original": "אַיֶּלֶת",
    "translitteration": "ʾayyeleṯ",
    "prononciation": "ah-yeh´-leth",
    "definition": "Biche, forme apparentée à H0355 utilisée notamment dans un titre de psaume (« Biche de l'aurore »).",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun (forme construite)",
    "occurrences": 0,
    "recherche": "h365 אַיֶּלֶת ʾayyeleṯ biche, forme apparentée à h0355 utilisée notamment dans un titre de psaume (« biche de l'aurore »). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200250,
    "strong": "H366",
    "langue": "hebreu",
    "numero": 366,
    "mot_original": "אָיֹם",
    "translitteration": "ʾāyōm",
    "prononciation": "aw-yome'",
    "definition": "Terrible, redoutable, imposant.",
    "categorie": "Adjectif",
    "references": [
      "Cantiques 6:4",
      "Cantiques 6:10",
      "Habacuc 1:7"
    ],
    "type": "adjectif",
    "occurrences": 3,
    "recherche": "h366 אָיֹם ʾāyōm terrible, redoutable, imposant. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200251,
    "strong": "H367",
    "langue": "hebreu",
    "numero": 367,
    "mot_original": "אֵימָה",
    "translitteration": "ʾêmāh",
    "prononciation": "ay-maw'",
    "definition": "Terreur, effroi, épouvante.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 15:12",
      "Exode 15:16",
      "Exode 23:27",
      "Job 9:34"
    ],
    "type": "nom commun",
    "occurrences": 17,
    "recherche": "h367 אֵימָה ʾêmāh terreur, effroi, épouvante. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200252,
    "strong": "H368",
    "langue": "hebreu",
    "numero": 368,
    "mot_original": "אֵימִים",
    "translitteration": "ʾêmîm",
    "prononciation": "ay-meem'",
    "definition": "Émim, « les terribles ». Peuple légendaire de Transjordanie, identifié aux Rephaïm.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 14:5",
      "Deutéronome 2:10"
    ],
    "type": "nom propre (ethnonyme)",
    "occurrences": 3,
    "recherche": "h368 אֵימִים ʾêmîm émim, « les terribles ». peuple légendaire de transjordanie, identifié aux rephaïm. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200253,
    "strong": "H369",
    "langue": "hebreu",
    "numero": 369,
    "mot_original": "אַיִן",
    "translitteration": "ʾayin",
    "prononciation": "ah'-yin",
    "definition": "Il n'y a pas, rien, néant, non-existence.",
    "categorie": "Adverbe / nom commun",
    "references": [
      "Genèse 2:5",
      "Exode 5:11",
      "Deutéronome 4:35",
      "Psaume 14:1",
      "Ésaïe 45:5"
    ],
    "type": "adverbe / nom commun",
    "occurrences": 790,
    "recherche": "h369 אַיִן ʾayin il n'y a pas, rien, néant, non-existence. adverbe / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200254,
    "strong": "H370",
    "langue": "hebreu",
    "numero": 370,
    "mot_original": "אַיִן",
    "translitteration": "ʾayin",
    "prononciation": "ah'-yin",
    "definition": "Où ? D'où ?",
    "categorie": "Adverbe interrogatif",
    "references": [
      "Genèse 16:8",
      "Job 1:7",
      "Job 28:12",
      "Jonas 1:8"
    ],
    "type": "adverbe interrogatif (homographe de h0369)",
    "occurrences": 0,
    "recherche": "h370 אַיִן ʾayin où ? d'où ? adverbe interrogatif",
    "audio": "",
    "image": null
  },
  {
    "id": 200255,
    "strong": "H371",
    "langue": "hebreu",
    "numero": 371,
    "mot_original": "אִין",
    "translitteration": "ʾîn",
    "prononciation": "een",
    "definition": "Est-ce qu'il n'y a pas ? N'y a-t-il pas ? Particule interrogative négative.",
    "categorie": "Adverbe interrogatif / particule",
    "references": [
      "1 Samuel 21:9"
    ],
    "type": "adverbe interrogatif / particule",
    "occurrences": 1,
    "recherche": "h371 אִין ʾîn est-ce qu'il n'y a pas ? n'y a-t-il pas ? particule interrogative négative. adverbe interrogatif / particule",
    "audio": "",
    "image": null
  },
  {
    "id": 200256,
    "strong": "H372",
    "langue": "hebreu",
    "numero": 372,
    "mot_original": "אִיעֶזֶר",
    "translitteration": "ʾîʿezer",
    "prononciation": "ee-eh'-zer",
    "definition": "Iézer, forme abrégée de Abiézer (H0044). Nom d'un guerrier de David.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 27:12"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h372 אִיעֶזֶר ʾîʿezer iézer, forme abrégée de abiézer (h0044). nom d'un guerrier de david. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200257,
    "strong": "H373",
    "langue": "hebreu",
    "numero": 373,
    "mot_original": "אִיעֶזְרִי",
    "translitteration": "ʾîʿezrî",
    "prononciation": "ee-ez-ree'",
    "definition": "Iézrite, membre du clan d'Iézer.",
    "categorie": "Adjectif gentilé",
    "references": [
      "Nombres 26:30"
    ],
    "type": "adjectif gentilé",
    "occurrences": 1,
    "recherche": "h373 אִיעֶזְרִי ʾîʿezrî iézrite, membre du clan d'iézer. adjectif gentilé",
    "audio": "",
    "image": null
  },
  {
    "id": 200258,
    "strong": "H374",
    "langue": "hebreu",
    "numero": 374,
    "mot_original": "אֵיפָה",
    "translitteration": "ʾêp̄āh",
    "prononciation": "ay-faw'",
    "definition": "Épha, unité de mesure de capacité pour les matières sèches (environ 22 litres).",
    "categorie": "Nom commun",
    "references": [
      "Exode 16:36",
      "Lévitique 19:36",
      "Deutéronome 25:14",
      "Zacharie 5:6"
    ],
    "type": "nom commun",
    "occurrences": 35,
    "recherche": "h374 אֵיפָה ʾêp̄āh épha, unité de mesure de capacité pour les matières sèches (environ 22 litres). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200259,
    "strong": "H375",
    "langue": "hebreu",
    "numero": 375,
    "mot_original": "אֵיפֹה",
    "translitteration": "ʾêp̄ōh",
    "prononciation": "ay-fo'",
    "definition": "Où donc ? Où ?",
    "categorie": "Adverbe interrogatif",
    "references": [
      "Genèse 37:16",
      "Job 38:4",
      "Ésaïe 49:21"
    ],
    "type": "adverbe interrogatif",
    "occurrences": 10,
    "recherche": "h375 אֵיפֹה ʾêp̄ōh où donc ? où ? adverbe interrogatif",
    "audio": "",
    "image": null
  },
  {
    "id": 200260,
    "strong": "H376",
    "langue": "hebreu",
    "numero": 376,
    "mot_original": "אִישׁ",
    "translitteration": "ʾîš",
    "prononciation": "eesh",
    "definition": "Homme, être humain mâle, mari, chacun.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 2:23",
      "Genèse 6:9",
      "Deutéronome 22:22",
      "Psaume 1:1",
      "Ésaïe 2:9"
    ],
    "type": "nom commun",
    "occurrences": 2183,
    "recherche": "h376 אִישׁ ʾîš homme, être humain mâle, mari, chacun. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200261,
    "strong": "H377",
    "langue": "hebreu",
    "numero": 377,
    "mot_original": "אִישׁ",
    "translitteration": "ʾîš",
    "prononciation": "eesh",
    "definition": "Agir en homme, se comporter virilement. Sens hypothétique.",
    "categorie": "Verbe",
    "references": [],
    "type": "verbe (dénominal)",
    "occurrences": 0,
    "recherche": "h377 אִישׁ ʾîš agir en homme, se comporter virilement. sens hypothétique. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200262,
    "strong": "H378",
    "langue": "hebreu",
    "numero": 378,
    "mot_original": "אִישׁ־בֹּשֶׁת",
    "translitteration": "ʾîš-bōšeṯ",
    "prononciation": "eesh-bo'-sheth",
    "definition": "Ish-Bosheth, « homme de honte ». Fils de Saül, éphémère roi d'Israël.",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 2:8",
      "2 Samuel 3:7",
      "2 Samuel 4:5"
    ],
    "type": "nom propre",
    "occurrences": 11,
    "recherche": "h378 אִישׁ־בֹּשֶׁת ʾîš-bōšeṯ ish-bosheth, « homme de honte ». fils de saül, éphémère roi d'israël. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200263,
    "strong": "H379",
    "langue": "hebreu",
    "numero": 379,
    "mot_original": "אִישְׁהוֹד",
    "translitteration": "ʾÎysh-hôwd",
    "prononciation": "eesh-hode´",
    "definition": "Ishehod, un Israélite de la tribu de Manassé.",
    "categorie": "Nom propre",
    "references": [],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h379 אִישְׁהוֹד ʾîysh-hôwd ishehod, un israélite de la tribu de manassé. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200264,
    "strong": "H380",
    "langue": "hebreu",
    "numero": 380,
    "mot_original": "אִישׁוֹן",
    "translitteration": "ʾîšôn",
    "prononciation": "ee-shone'",
    "definition": "Prunelle, pupille de l'œil ; partie centrale, milieu.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 32:10",
      "Psaume 17:8",
      "Proverbes 7:2"
    ],
    "type": "nom commun",
    "occurrences": 5,
    "recherche": "h380 אִישׁוֹן ʾîšôn prunelle, pupille de l'œil ; partie centrale, milieu. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200265,
    "strong": "H381",
    "langue": "hebreu",
    "numero": 381,
    "mot_original": "אִישׁ־חַיִל",
    "translitteration": "ʾîš-ḥayil",
    "prononciation": "eesh-khah'-yil",
    "definition": "Homme de valeur, guerrier vaillant, homme de bien.",
    "categorie": "Nom commun",
    "references": [
      "Ruth 2:1",
      "Juges 6:12",
      "1 Samuel 9:1",
      "1 Samuel 16:18"
    ],
    "type": "nom commun (expression composée)",
    "occurrences": 0,
    "recherche": "h381 אִישׁ־חַיִל ʾîš-ḥayil homme de valeur, guerrier vaillant, homme de bien. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200266,
    "strong": "H382",
    "langue": "hebreu",
    "numero": 382,
    "mot_original": "אִישׁ־טוֹב",
    "translitteration": "ʾîš-ṭôḇ",
    "prononciation": "eesh-tobe'",
    "definition": "Ish-Tob, « homme de Tob » ou « homme bon ». Région de Transjordanie.",
    "categorie": "Nom propre",
    "references": [
      "Juges 11:3",
      "2 Samuel 10:6"
    ],
    "type": "nom propre (toponyme) / expression composée",
    "occurrences": 4,
    "recherche": "h382 אִישׁ־טוֹב ʾîš-ṭôḇ ish-tob, « homme de tob » ou « homme bon ». région de transjordanie. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200267,
    "strong": "H383",
    "langue": "hebreu",
    "numero": 383,
    "mot_original": "אִיתַי",
    "translitteration": "ʾîṯay",
    "prononciation": "ee-thah'ee",
    "definition": "Il y a, il existe. Correspondance araméenne de l'hébreu יֵשׁ (H3426).",
    "categorie": "Adverbe / particule d'existence",
    "references": [
      "Esdras 4:16",
      "Daniel 2:10",
      "Daniel 3:14"
    ],
    "type": "adverbe / particule d'existence (araméen)",
    "occurrences": 17,
    "recherche": "h383 אִיתַי ʾîṯay il y a, il existe. correspondance araméenne de l'hébreu יֵשׁ (h3426). adverbe / particule d'existence",
    "audio": "",
    "image": null
  },
  {
    "id": 200268,
    "strong": "H384",
    "langue": "hebreu",
    "numero": 384,
    "mot_original": "אִיתִיאֵל",
    "translitteration": "ʾîṯîʾēl",
    "prononciation": "eeth-ee-ale'",
    "definition": "Ithiel, « Dieu est avec moi » ou « Dieu existe ».",
    "categorie": "Nom propre",
    "references": [
      "Proverbes 30:1",
      "Néhémie 11:7"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h384 אִיתִיאֵל ʾîṯîʾēl ithiel, « dieu est avec moi » ou « dieu existe ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200269,
    "strong": "H385",
    "langue": "hebreu",
    "numero": 385,
    "mot_original": "אִיתָמָר",
    "translitteration": "ʾîṯāmār",
    "prononciation": "eeth-aw-mawr'",
    "definition": "Ithamar, « île de palmier » ou « père du palmier ». Quatrième fils d'Aaron, ancêtre d'une lignée sacerdotale.",
    "categorie": "Nom propre",
    "references": [
      "Exode 6:23",
      "Exode 28:1",
      "Lévitique 10:6",
      "1 Chroniques 24:1"
    ],
    "type": "nom propre",
    "occurrences": 21,
    "recherche": "h385 אִיתָמָר ʾîṯāmār ithamar, « île de palmier » ou « père du palmier ». quatrième fils d'aaron, ancêtre d'une lignée sacerdotale. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200270,
    "strong": "H386",
    "langue": "hebreu",
    "numero": 386,
    "mot_original": "אֵיתָן",
    "translitteration": "ʾêṯān",
    "prononciation": "ay-thawn'",
    "definition": "Permanent, durable, constant ; puissant, fort.",
    "categorie": "Adjectif / nom propre",
    "references": [
      "Genèse 49:24",
      "Amos 5:24",
      "Michée 6:2",
      "Psaume 74:15"
    ],
    "type": "adjectif / nom propre",
    "occurrences": 13,
    "recherche": "h386 אֵיתָן ʾêṯān permanent, durable, constant ; puissant, fort. adjectif / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200271,
    "strong": "H387",
    "langue": "hebreu",
    "numero": 387,
    "mot_original": "אֵיתָן",
    "translitteration": "ʾêṯān",
    "prononciation": "ay-thawn'",
    "definition": "Éthan, « permanent, durable ». Nom de plusieurs personnages.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 5:11",
      "Psaume 89:1",
      "1 Chroniques 6:27"
    ],
    "type": "nom propre",
    "occurrences": 8,
    "recherche": "h387 אֵיתָן ʾêṯān éthan, « permanent, durable ». nom de plusieurs personnages. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200272,
    "strong": "H388",
    "langue": "hebreu",
    "numero": 388,
    "mot_original": "אֵיתָנִים",
    "translitteration": "ʾêṯānîm",
    "prononciation": "ay-thaw-neem'",
    "definition": "Éthanim, « les [mois] permanents » ou « les [cours d'eau] permanents ». Septième mois du calendrier cananéen, correspondant à Tishri.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 8:2"
    ],
    "type": "nom propre (mois du calendrier)",
    "occurrences": 1,
    "recherche": "h388 אֵיתָנִים ʾêṯānîm éthanim, « les [mois] permanents » ou « les [cours d'eau] permanents ». septième mois du calendrier cananéen, correspondant à tishri. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200273,
    "strong": "H389",
    "langue": "hebreu",
    "numero": 389,
    "mot_original": "אַךְ",
    "translitteration": "ʾaḵ",
    "prononciation": "ak",
    "definition": "Seulement, cependant, certes, vraiment, mais.",
    "categorie": "Adverbe / conjonction",
    "references": [
      "Genèse 7:23",
      "Genèse 9:4",
      "Psaume 73:1",
      "Ésaïe 14:15"
    ],
    "type": "adverbe / conjonction",
    "occurrences": 155,
    "recherche": "h389 אַךְ ʾaḵ seulement, cependant, certes, vraiment, mais. adverbe / conjonction",
    "audio": "",
    "image": null
  },
  {
    "id": 200274,
    "strong": "H390",
    "langue": "hebreu",
    "numero": 390,
    "mot_original": "אַכַּד",
    "translitteration": "ʾakkaḏ",
    "prononciation": "ak-kad'",
    "definition": "Akkad, ville de Mésopotamie, capitale de l'Empire akkadien fondé par Sargon.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 10:10"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h390 אַכַּד ʾakkaḏ akkad, ville de mésopotamie, capitale de l'empire akkadien fondé par sargon. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200275,
    "strong": "H391",
    "langue": "hebreu",
    "numero": 391,
    "mot_original": "אַכְזָב",
    "translitteration": "ʾaḵzāḇ",
    "prononciation": "ak-zawb'",
    "definition": "Trompeur, décevant, tarissant ; comme un ruisseau qui se dessèche.",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Jérémie 15:18",
      "Michée 1:14"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 2,
    "recherche": "h391 אַכְזָב ʾaḵzāḇ trompeur, décevant, tarissant ; comme un ruisseau qui se dessèche. adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200276,
    "strong": "H392",
    "langue": "hebreu",
    "numero": 392,
    "mot_original": "אַכְזִיב",
    "translitteration": "ʾaḵzîḇ",
    "prononciation": "ak-zeeb'",
    "definition": "Akzib, « trompeur, tarissant ». Nom de deux villes.",
    "categorie": "Nom propre",
    "references": [
      "Josué 15:44",
      "Juges 1:31",
      "Michée 1:14"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 4,
    "recherche": "h392 אַכְזִיב ʾaḵzîḇ akzib, « trompeur, tarissant ». nom de deux villes. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200277,
    "strong": "H393",
    "langue": "hebreu",
    "numero": 393,
    "mot_original": "אַכְזָר",
    "translitteration": "ʾaḵzār",
    "prononciation": "ak-zawr'",
    "definition": "Cruel, féroce, impitoyable.",
    "categorie": "Adjectif",
    "references": [
      "Deutéronome 32:33",
      "Job 30:21",
      "Proverbes 12:10",
      "Jérémie 30:14"
    ],
    "type": "adjectif",
    "occurrences": 6,
    "recherche": "h393 אַכְזָר ʾaḵzār cruel, féroce, impitoyable. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200278,
    "strong": "H394",
    "langue": "hebreu",
    "numero": 394,
    "mot_original": "אַכְזָרִי",
    "translitteration": "ʾaḵzārî",
    "prononciation": "ak-zaw-ree'",
    "definition": "Cruel, féroce. Variante adjectivale de H0393.",
    "categorie": "Adjectif",
    "references": [
      "Ésaïe 13:9",
      "Jérémie 30:14",
      "Jérémie 50:42"
    ],
    "type": "adjectif",
    "occurrences": 5,
    "recherche": "h394 אַכְזָרִי ʾaḵzārî cruel, féroce. variante adjectivale de h0393. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200279,
    "strong": "H395",
    "langue": "hebreu",
    "numero": 395,
    "mot_original": "אַכְזְרִיּוּת",
    "translitteration": "ʾaḵzərîyûṯ",
    "prononciation": "ak-ze-ree-ooth'",
    "definition": "Cruauté, férocité.",
    "categorie": "Nom commun",
    "references": [
      "Proverbes 27:4"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h395 אַכְזְרִיּוּת ʾaḵzərîyûṯ cruauté, férocité. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200280,
    "strong": "H396",
    "langue": "hebreu",
    "numero": 396,
    "mot_original": "אַכִּילָה",
    "translitteration": "ʾakkîlāh",
    "prononciation": "ak-ee-law'",
    "definition": "Nourriture, aliment, repas.",
    "categorie": "Nom commun",
    "references": [
      "1 Rois 19:8"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h396 אַכִּילָה ʾakkîlāh nourriture, aliment, repas. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200281,
    "strong": "H397",
    "langue": "hebreu",
    "numero": 397,
    "mot_original": "אָכִישׁ",
    "translitteration": "ʾāḵîš",
    "prononciation": "aw-keesh'",
    "definition": "Akish, roi philistin de Gath, contemporain de David.",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 21:11",
      "1 Samuel 27:1",
      "1 Samuel 28:1",
      "1 Samuel 29:1"
    ],
    "type": "nom propre",
    "occurrences": 21,
    "recherche": "h397 אָכִישׁ ʾāḵîš akish, roi philistin de gath, contemporain de david. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200282,
    "strong": "H398",
    "langue": "hebreu",
    "numero": 398,
    "mot_original": "אָכַל",
    "translitteration": "ʾāḵal",
    "prononciation": "aw-kal'",
    "definition": "Manger, consommer, dévorer.",
    "categorie": "Verbe",
    "references": [
      "Genèse 2:16",
      "Genèse 3:6",
      "Exode 12:15",
      "Deutéronome 4:24"
    ],
    "type": "verbe",
    "occurrences": 810,
    "recherche": "h398 אָכַל ʾāḵal manger, consommer, dévorer. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200283,
    "strong": "H399",
    "langue": "hebreu",
    "numero": 399,
    "mot_original": "אֲכַל",
    "translitteration": "ʾăḵal",
    "prononciation": "ak-al'",
    "definition": "Manger, dévorer. Correspondance araméenne de l'hébreu אָכַל (H0398).",
    "categorie": "Verbe",
    "references": [
      "Daniel 3:8",
      "Daniel 7:5"
    ],
    "type": "verbe (araméen)",
    "occurrences": 7,
    "recherche": "h399 אֲכַל ʾăḵal manger, dévorer. correspondance araméenne de l'hébreu אָכַל (h0398). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200284,
    "strong": "H400",
    "langue": "hebreu",
    "numero": 400,
    "mot_original": "אֹכֶל",
    "translitteration": "ʾōḵel",
    "prononciation": "o'-khel",
    "definition": "Nourriture, aliment, vivres.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 2:9",
      "Genèse 3:6",
      "Psaume 104:21",
      "Psaume 145:15"
    ],
    "type": "nom commun",
    "occurrences": 44,
    "recherche": "h400 אֹכֶל ʾōḵel nourriture, aliment, vivres. nom commun",
    "audio": "",
    "image": null
  }
];
