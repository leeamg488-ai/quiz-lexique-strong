import { StrongEntry } from '../types';

// Fiches lexicographiques compilées manuellement par l'auteur de l'app
// (morphologie, étymologie, occurrences, exemples bibliques sourcés BDB/HALOT/
// Gesenius). Fusion dédupliquée par numéro Strong.
// Couverture : H0006-H0400 (continu) + H0348.
// Champs enrichis additionnels (dialecte, racine, categorie_grammaticale,
// sens_principal, etymologie, formes_derivees, synonymes, premiere_occurrence,
// niveau, difficulte, tags, notes) présents pour H0006-H0100, H0201-H0300,
// H0311-H0400 (sourcés depuis les docx détaillés) ; absents pour H0101-H0200
// et H0348 (source plus sommaire, en attente d'un lot ultérieur).
// Ces champs sont volontairement nommés différemment des champs de base
// (langue/categorie) déjà utilisés par l'app, pour éviter toute collision.
export const compiledLexicon: StrongEntry[] = [
  {
    "id": 200000,
    "strong": "H6",
    "langue": "hebreu",
    "numero": 6,
    "mot_original": "אָבַד",
    "translitteration": "ʾāḇaḏ",
    "prononciation": "ʾāḇaḏ",
    "definition": "Périr, être détruit, disparaître, s'égarer.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Nombres 21:29",
      "Psaume 2:12"
    ],
    "type": "verbe",
    "occurrences": 184,
    "recherche": "h6 אָבַד ʾāḇaḏ périr, être détruit, disparaître, s'égarer. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Périr",
    "etymologie": "Racine sémitique commune ʾBD. Akkadien : abātu (détruire, anéantir) Araméen : אֲבַד (H0007) Syriaque : ܐܒܕ (ʾeḇaḏ) Arabe : ʾabada (périr, disparaître) Ougaritique : ảbd",
    "formes_derivees": [
      "H7",
      "H8",
      "H12"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 21:29",
      "texte": "Malheur à toi, Moab ! Tu as péri, peuple de Kemosh."
    },
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe אָבַד et ses dérivés nominaux (H0008 H0012) couvrent le champ sémantique de la disparition et de l'anéantissement. La législation deutéronomique menace de « périr » rapidement (Deutéronome 4:26) en cas d'infraction à l'alliance, inscrivant le terme dans le cadre des sanctions juridiques collectives. Le Piel et le Hifil…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200001,
    "strong": "H7",
    "langue": "hebreu",
    "numero": 7,
    "mot_original": "אֲבַד",
    "translitteration": "ʾăḇaḏ",
    "prononciation": "ʾăḇaḏ",
    "definition": "Périr, détruire. Correspondance araméenne de l'hébreu אָבַד (H0006).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Jérémie 10:11",
      "Daniel 7:11"
    ],
    "type": "verbe",
    "occurrences": 7,
    "recherche": "h7 אֲבַד ʾăḇaḏ périr, détruire. correspondance araméenne de l'hébreu אָבַד (h0006). verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Périr",
    "etymologie": "Racine araméenne ʾBD, correspondance exacte de l'hébreu H0006.",
    "formes_derivees": [
      "H6"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Jérémie 10:11",
      "texte": "Les dieux qui n\\'ont pas fait les cieux et la terre, ceux-ci > périront de la terre."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "verbe"
    ],
    "notes": "Le verset de Jérémie 10:11 constitue le seul passage en araméen du livre, adressé aux exilés judéens en Babylonie. La formulation fonctionne comme une confession polémique opposée aux cultes astraux babyloniens. Le verbe proclame l'extinction programmée des divinités astrales, placées sous le jugement de YHWH. En Daniel, le verbe apparaît…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200002,
    "strong": "H8",
    "langue": "hebreu",
    "numero": 8,
    "mot_original": "אֹבֵד",
    "translitteration": "ʾōḇēḏ",
    "prononciation": "ʾōḇēḏ",
    "definition": "Destruction, ruine ; ce qui est sur le point de périr.",
    "categorie": "Onction",
    "references": [
      "Proverbes 31:6"
    ],
    "type": "nom commun (substantif dérivé du participe",
    "occurrences": 2,
    "recherche": "h8 אֹבֵד ʾōḇēḏ destruction, ruine ; ce qui est sur le point de périr. nom commun (substantif dérivé du participe",
    "audio": "",
    "image": null,
    "racine": "H6",
    "sens_principal": "Destruction",
    "etymologie": "Dérivé nominal de la racine verbale אָבַד (H0006).",
    "formes_derivees": [
      "H6"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Proverbes 31:6",
      "texte": "Donnez de la boisson forte à celui qui périt, et du vin à ceux qui > ont l\\'amertume dans l\\'âme."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Ce substantif, dérivé du participe actif verbal, désigne la personne en état de détresse extrême. Le conseil d'administrer des boissons alcoolisées à « celui qui périt » reflète une pratique attestée dans le Proche Orient ancien : l'usage de substances psychotropes (alcool, opium) comme analgésiques ou anxiolytiques. La recommandation s'inscrit…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200003,
    "strong": "H9",
    "langue": "hebreu",
    "numero": 9,
    "mot_original": "אֲבֵדָה",
    "translitteration": "ʾăḇēḏāh",
    "prononciation": "ʾăḇēḏāh",
    "definition": "Chose perdue, objet égaré.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 22:3"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h9 אֲבֵדָה ʾăḇēḏāh chose perdue, objet égaré. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Chose perdue",
    "etymologie": "Dérivé féminin de la racine אָבַד (H0006).",
    "formes_derivees": [
      "H6"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 22:3",
      "texte": "Tu feras de même pour son âne, de même pour son vêtement, de même > pour toute chose perdue par ton frère, qu\\'il aurait égarée et que tu > aurais trouvée."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme est un technicisme juridique relevant du droit casuistique. La législation impose l'obligation de restitution : trouver un objet perdu et ne pas le rendre constitue une faute. Le code de l'alliance (Exode 22), le code de sainteté (Lévitique 5) et le code deutéronomique (Deutéronome 22) traitent tous du…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200004,
    "strong": "H10",
    "langue": "hebreu",
    "numero": 10,
    "mot_original": "אֲבַדֹּה",
    "translitteration": "ʾăḇaddōh",
    "prononciation": "ʾăḇaddōh",
    "definition": "Ruine, destruction, lieu de perdition.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Proverbes 27:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h10 אֲבַדֹּה ʾăḇaddōh ruine, destruction, lieu de perdition. nom commun",
    "audio": "",
    "image": null,
    "racine": "H6",
    "sens_principal": "Ruine",
    "etymologie": "Forme dérivée de la racine אָבַד (H0006) avec redoublement de la deuxième radicale, exprimant l'intensité ou l'abstraction.",
    "formes_derivees": [
      "H6",
      "H11"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Proverbes 27:20",
      "texte": "Le Shéol et la Perdition ne sont jamais rassasiés ; de même les > yeux de l\\'homme ne sont jamais rassasiés."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le parallélisme poétique entre Shéol et Abaddoh en Proverbes 27:20 identifie les deux termes comme désignant le monde souterrain. Dans la cosmologie de l'Ancien Testament, le Shéol est le séjour des morts, conçu comme un espace souterrain où les défunts mènent une existence amoindrie. L'image du Shéol et de la…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200005,
    "strong": "H11",
    "langue": "hebreu",
    "numero": 11,
    "mot_original": "אֲבַדּוֹן",
    "translitteration": "ʾăḇaddōn",
    "prononciation": "ʾăḇaddōn",
    "definition": "Abaddon. Lieu de destruction ; personnification du monde souterrain.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Job 26:6",
      "Proverbes 15:11"
    ],
    "type": "nom commun / nom propre",
    "occurrences": 5,
    "recherche": "h11 אֲבַדּוֹן ʾăḇaddōn abaddon. lieu de destruction ; personnification du monde souterrain. nom commun / nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abaddon",
    "etymologie": "Dérivé intensif de la racine אָבַד (H0006) avec suffixe ôn.",
    "formes_derivees": [
      "H6"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Job 26:6",
      "texte": "Le Shéol est nu devant lui, et Abaddon n\\'a point de voile."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abaddon dans la Bible hébraïque n'est pas encore une figure angélique distincte, mais une réalité cosmique personnifiée : le royaume de la destruction totale. La notion de l'omniscience divine pénétrant jusqu'au Shéol et Abaddon (Job 26:6 ; Proverbes 15:11) affirme l'universalité de la juridiction divine, incluant le domaine de la…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200006,
    "strong": "H12",
    "langue": "hebreu",
    "numero": 12,
    "mot_original": "אַבְדָן",
    "translitteration": "ʾaḇdān",
    "prononciation": "ʾaḇdān",
    "definition": "Destruction, anéantissement.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esther 9:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h12 אַבְדָן ʾaḇdān destruction, anéantissement. nom commun",
    "audio": "",
    "image": null,
    "racine": "H6",
    "sens_principal": "Destruction",
    "etymologie": "Autre dérivé nominal de la racine אָבַד (H0006).",
    "formes_derivees": [
      "H6"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Esther 9:5",
      "texte": "Les Juifs frappèrent tous leurs ennemis à coups d\\'épée, les tuant > et les faisant périr."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme apparaît dans le récit du massacre défensif des Juifs dans l'Empire perse. Le triplet « épée, massacre, destruction » (חֶרֶב וְהֶרֶג וְאַבְדָן) constitue une formule rhétorique décrivant l'anéantissement militaire complet. Le livre d'Esther relate le renversement du décret génocidaire promulgué par Haman. Le terme אַבְדָן fait écho au…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200007,
    "strong": "H13",
    "langue": "hebreu",
    "numero": 13,
    "mot_original": "אָבְדַן",
    "translitteration": "ʾoḇdan",
    "prononciation": "ʾoḇdan",
    "definition": "Destruction. Correspondance araméenne de l'hébreu אַבְדָן (H0012).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 2:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h13 אָבְדַן ʾoḇdan destruction. correspondance araméenne de l'hébreu אַבְדָן (h0012). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Destruction",
    "etymologie": "Dérivé araméen de la racine אֲבַד (H0007).",
    "formes_derivees": [
      "H7",
      "H12"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Daniel 2:5",
      "texte": "Le roi répondit aux Chaldéens : La parole m\\'a échappé. Si vous ne > me faites pas connaître le songe et son interprétation, vous serez mis > en pièces, et vos maisons seront réduites en un tas de ruines."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "La menace royale proférée en Daniel 2:5 illustre l'absolutisme judiciaire du monarque néo babylonien. La sanction comporte deux volets : la mutilation corporelle (הַדָּמִין, « mis en pièces ») et la destruction de l'habitation familiale (נְוָלִי, « tas de ruines »). La destruction de la maison comme châtiment pénal est…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200008,
    "strong": "H14",
    "langue": "hebreu",
    "numero": 14,
    "mot_original": "אָבָה",
    "translitteration": "ʾāḇāh",
    "prononciation": "ʾāḇāh",
    "definition": "Consentir, vouloir, être disposé à, accepter.",
    "categorie": "Loi et commandement",
    "references": [
      "Deutéronome 25:7",
      "Ésaïe 1:19"
    ],
    "type": "verbe",
    "occurrences": 54,
    "recherche": "h14 אָבָה ʾāḇāh consentir, vouloir, être disposé à, accepter. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Consentir",
    "etymologie": "Racine sémitique ʾBY. Arabe : ʾabā (refuser, avec glissement sémantique)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 25:7",
      "texte": "Et si l\\'homme ne consent pas à prendre sa belle-sœur."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe אָבָה exprime l'acte de la volonté dans sa dimension d'acquiescement ou de refus. La construction syntaxique majoritaire est l'emploi avec une négation (לֹא אָבָה), dénotant un refus catégorique. Le refus d'obéir à YHWH constitue une accusation récurrente de la littérature prophétique et deutéronomique. En Deutéronome 25:7, le verbe…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200009,
    "strong": "H15",
    "langue": "hebreu",
    "numero": 15,
    "mot_original": "אָבֶה",
    "translitteration": "ʾāḇeh",
    "prononciation": "ʾāḇeh",
    "definition": "Souhait, désir, volonté.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 23:6"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h15 אָבֶה ʾāḇeh souhait, désir, volonté. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Souhait",
    "etymologie": "Dérivé nominal du verbe אָבָה (H0014).",
    "formes_derivees": [
      "H14"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 23:6",
      "texte": "Mais YHWH ton Dieu n\\'a pas voulu écouter Balaam."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Ce substantif, hapax legomenon, apparaît dans le contexte de l'interdiction faite aux Ammonites et Moabites d'entrer dans l'assemblée de YHWH. Le motif juridique invoqué est double : le refus d'hospitalité lors de la sortie d'Égypte et le recours au prophète Balaam pour maudire Israël. Le terme אָבֶה désigne ici la…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200010,
    "strong": "H16",
    "langue": "hebreu",
    "numero": 16,
    "mot_original": "אֵבֶה",
    "translitteration": "ʾēḇeh",
    "prononciation": "ʾēḇeh",
    "definition": "Roseau, papyrus, plante aquatique.",
    "categorie": "Eau et baptême",
    "references": [
      "Job 9:26"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h16 אֵבֶה ʾēḇeh roseau, papyrus, plante aquatique. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Roseau",
    "etymologie": "D'origine incertaine.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Job 9:26",
      "texte": "Ils passent comme les barques de jonc."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme apparaît dans une comparaison poétique de Job : les jours de l'homme passent aussi rapidement que les barques de jonc sur le Nil. L'image présuppose la connaissance des embarcations légères fabriquées en faisceaux de papyrus, typiques de la navigation fluviale égyptienne. Ces barques de papyrus sont documentées archéologiquement…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200011,
    "strong": "H17",
    "langue": "hebreu",
    "numero": 17,
    "mot_original": "אֲבוֹי",
    "translitteration": "ʾăḇôy",
    "prononciation": "ʾăḇôy",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Proverbes 23:29"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h17 אֲבוֹי ʾăḇôy ah ! hélas ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ah ! Hélas ! Exclamation de",
    "etymologie": "Onomatopée expressive commune.",
    "formes_derivees": [
      "H188"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Proverbes 23:29",
      "texte": "À qui les ah ? à qui les hélas ? à qui les querelles ? à qui les > plaintes ?"
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "interjection"
    ],
    "notes": "L'interjection apparaît dans un poème sapientiel sur l'ivrognerie. Le sage dresse le portrait de l'ivrogne en énumérant les conséquences de l'abus de vin. Le parallélisme synonymique entre אוֹי et אֲבוֹי constitue un procédé rhétorique d'intensification émotionnelle. Les interjections de lamentation sont un trait commun des littératures du Proche Orient ancien,…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Interjection"
  },
  {
    "id": 200012,
    "strong": "H18",
    "langue": "hebreu",
    "numero": 18,
    "mot_original": "אֵבוּס",
    "translitteration": "ʾēḇûs",
    "prononciation": "ʾēḇûs",
    "definition": "Mangeoire, crèche pour le bétail.",
    "categorie": "Ange et messager",
    "references": [
      "Ésaïe 1:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h18 אֵבוּס ʾēḇûs mangeoire, crèche pour le bétail. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Mangeoire",
    "etymologie": "Dérivé de la racine אבס (ʾBS), « engraisser, nourrir à la crèche ».",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ésaïe 1:3",
      "texte": "Le bœuf connaît son possesseur, et l\\'âne la crèche de son maître. >"
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La mangeoire est un équipement domestique standard dans les sociétés agro pastorales du Levant. Les auges étaient généralement taillées dans la pierre ou façonnées en argile. Leur présence dans les étables et les cours des maisons rurales en fait un élément familier de l'économie domestique. En Ésaïe 1:3, l'argument prophétique…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200013,
    "strong": "H19",
    "langue": "hebreu",
    "numero": 19,
    "mot_original": "אִבְחָה",
    "translitteration": "ʾiḇḥāh",
    "prononciation": "ʾiḇḥāh",
    "definition": "Épée, lame, pointe. Plus probablement : frayeur, terreur soudaine.",
    "categorie": "Onction",
    "references": [
      "Ézéchiel 21:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h19 אִבְחָה ʾiḇḥāh épée, lame, pointe. plus probablement : frayeur, terreur soudaine. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Épée",
    "etymologie": "Origine incertaine.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ézéchiel 21:20",
      "texte": "Afin que le cœur défaille, et que les occasions de chute soient > multipliées, c\\'est contre toutes leurs portes que j\\'ai placé le > tranchant de l\\'épée."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'incertitude sémantique de ce hapax legomenon illustre la difficulté d'établir le sens de termes rares sans parallèles bibliques. Le contexte d'Ézéchiel 21, oracle du jugement par l'épée contre Jérusalem, suggère un vocabulaire militaire. Les traductions anciennes divergent déjà : la Septante traduit par σφαγή (« massacre »), la Vulgate par…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200014,
    "strong": "H20",
    "langue": "hebreu",
    "numero": 20,
    "mot_original": "אֲבַטִּיחַ",
    "translitteration": "ʾăḇaṭṭîaḥ",
    "prononciation": "ʾăḇaṭṭîaḥ",
    "definition": "Pastèque, melon d'eau (Citrullus lanatus).",
    "categorie": "Eau et baptême",
    "references": [
      "Nombres 11:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h20 אֲבַטִּיחַ ʾăḇaṭṭîaḥ pastèque, melon d'eau (citrullus lanatus). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Pastèque",
    "etymologie": "Nom d'origine égyptienne.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 11:5",
      "texte": "Nous nous souvenons du poisson que nous mangions gratuitement en > Égypte, des concombres, des pastèques."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La pastèque est mentionnée dans le récit des récriminations des Israélites au désert. Les Hébreux regrettent les produits agricoles égyptiens, énumérant une liste de plantes potagères caractéristiques du régime alimentaire de la vallée du Nil. La culture de la pastèque en Égypte est documentée archéologiquement depuis le Nouvel Empire (des…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200015,
    "strong": "H21",
    "langue": "hebreu",
    "numero": 21,
    "mot_original": "אֲבִי",
    "translitteration": "ʾăḇî",
    "prononciation": "ʾăḇî",
    "definition": "Abi, nom propre féminin. Mère du roi Ézéchias.",
    "categorie": "Royaume",
    "references": [
      "2 Rois 18:2"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h21 אֲבִי ʾăḇî abi, nom propre féminin. mère du roi ézéchias. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abi",
    "etymologie": "Forme abrégée d'un nom théophore, probablement אֲבִיָּה (Abiyah, « YHWH est mon père ») ou אֲבִיאֵל (« Dieu est mon père »).",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Rois 18:2",
      "texte": "Il avait vingt-cinq ans à son avènement, et il régna vingt-neuf ans > à Jérusalem. Le nom de sa mère était Abi, fille de Zekaryah."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "La mention du nom de la mère du roi est une pratique annalistique régulière dans les livres des Rois pour les souverains de Juda, alors qu'elle est absente pour les rois d'Israël. Cette différence reflète probablement le rôle institutionnel de la reine mère (gebîrāh) à la cour de Jérusalem, fonction…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200016,
    "strong": "H22",
    "langue": "hebreu",
    "numero": 22,
    "mot_original": "אֲבִיאֵל",
    "translitteration": "ʾăḇîʾēl",
    "prononciation": "ʾăḇîʾēl",
    "definition": "Abiel, « Dieu est mon père » ou « mon père est Dieu ».",
    "categorie": "Noms de Dieu",
    "references": [
      "1 Samuel 9:1"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h22 אֲבִיאֵל ʾăḇîʾēl abiel, « dieu est mon père » ou « mon père est dieu ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abiel",
    "etymologie": "Nom théophore composé de אָב (H0001, « père ») + אֵל (H0410, « Dieu ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H410"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 9:1",
      "texte": "Il y avait un homme de Benjamin, nommé Qish, fils d\\'Abiel."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Le nom Abiel est un théophore yahwiste à élément El, divinité principale du panthéon cananéen dont le nom est utilisé dans la Bible comme titre du Dieu d'Israël. La formule « Dieu est mon père » exprime une relation de protection et d'appartenance. L'Abiel de 1 Samuel est un notable…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200017,
    "strong": "H23",
    "langue": "hebreu",
    "numero": 23,
    "mot_original": "אֲבִיאָסָף",
    "translitteration": "ʾăḇîʾāsāp̄",
    "prononciation": "ʾăḇîʾāsāp̄",
    "definition": "Abiasaph, « mon père a rassemblé » ou « le père du rassemblement ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Exode 6:24"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h23 אֲבִיאָסָף ʾăḇîʾāsāp̄ abiasaph, « mon père a rassemblé » ou « le père du rassemblement ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abiasaph",
    "etymologie": "Composé de אָב (H0001, « père ») + אָסַף (H0622, « rassembler »).",
    "formes_derivees": [
      "H1",
      "H622"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 6:24",
      "texte": "Les fils de Qorah : Assir, Elqana et Abiasaph."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abiasaph est répertorié dans la généalogie des Qorahites, lignée lévitique associée au service du sanctuaire. La famille de Qorah a une histoire complexe : si Qorah périt lors de la révolte de Nombres 16, ses fils survivent et leur descendance est intégrée au personnel cultuel. Les Qorahites sont crédités de…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200018,
    "strong": "H24",
    "langue": "hebreu",
    "numero": 24,
    "mot_original": "אָבִיב",
    "translitteration": "ʾāḇîḇ",
    "prononciation": "ʾāḇîḇ",
    "definition": "Épi mûr, épi tendre ; mois des épis (printemps).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 13:4"
    ],
    "type": "nom commun",
    "occurrences": 8,
    "recherche": "h24 אָבִיב ʾāḇîḇ épi mûr, épi tendre ; mois des épis (printemps). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Épi mûr",
    "etymologie": "Racine sémitique ʾBB signifiant « être vert, tendre, pousser ». Arabe : ʾabba (herbe fraîche) Akkadien : abābu (pousser, verdir)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 13:4",
      "texte": "Vous sortez aujourd\\'hui, dans le mois des épis."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le mois de l'Abib correspond à mars avril dans le calendrier moderne, période de maturation de l'orge en Palestine. C'est le premier mois du calendrier cultuel israélite selon la prescription de l'Exode, le mois de la Pâque et de la sortie d'Égypte. Le terme appartient au vocabulaire calendaire cananéen. Après…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200019,
    "strong": "H25",
    "langue": "hebreu",
    "numero": 25,
    "mot_original": "אֲבִי גִבְעוֹן",
    "translitteration": "ʾăḇî ḡiḇʿôn",
    "prononciation": "ʾăḇî ḡiḇʿôn",
    "definition": "Abi-Gibeon, « père de Gibeon ». Nom ou titre d'un personnage benjaminite.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 8:29"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h25 אֲבִי גִבְעוֹן ʾăḇî ḡiḇʿôn abi-gibeon, « père de gibeon ». nom ou titre d'un personnage benjaminite. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abi Gibeon",
    "etymologie": "Composé de אָב (H0001, « père ») au construit + גִּבְעוֹן (H1391, « Gibeon », toponyme).",
    "formes_derivees": [
      "H1",
      "H1391"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 8:29",
      "texte": "À Gibeon habitaient : le père de Gibeon."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "La formule אֲבִי suivi d'un toponyme est une construction généalogique et administrative désignant le fondateur ou chef éponyme d'une localité. Gibeon était une ville cananéenne notable, située à environ 9 km au nord ouest de Jérusalem, dont la population fut intégrée à Israël par traité selon Josué 9. Les listes…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200020,
    "strong": "H26",
    "langue": "hebreu",
    "numero": 26,
    "mot_original": "אֲבִיגַיִל",
    "translitteration": "ʾăḇîḡayil",
    "prononciation": "ʾăḇîḡayil",
    "definition": "Abigaïl, « mon père est joie » ou « père de l'exultation ».",
    "categorie": "Joie",
    "references": [
      "1 Samuel 25:3"
    ],
    "type": "nom propre",
    "occurrences": 17,
    "recherche": "h26 אֲבִיגַיִל ʾăḇîḡayil abigaïl, « mon père est joie » ou « père de l'exultation ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abigaïl",
    "etymologie": "Composé de אָב (H0001, « père ») + גִּיל (H1524, « joie, exultation ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H1524"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 25:3",
      "texte": "Le nom de l\\'homme était Nabal, et le nom de sa femme Abigaïl. La > femme était de bon sens et belle d\\'apparence."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "L'Abigaïl de 1 Samuel 25 est présentée comme une femme de discernement (ṭôḇaṯ śeḵel) dont l'intervention diplomatique empêche David de commettre un massacre contre la maisonnée de Nabal. Son discours persuade David de renoncer à la vengeance personnelle, invoquant le principe de rétribution divine. Le mariage subséquent de David avec…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200021,
    "strong": "H27",
    "langue": "hebreu",
    "numero": 27,
    "mot_original": "אֲבִידָן",
    "translitteration": "ʾăḇîḏān",
    "prononciation": "ʾăḇîḏān",
    "definition": "Abidan, « mon père a jugé » ou « père du jugement ».",
    "categorie": "Justice et jugement",
    "references": [
      "Nombres 1:11"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h27 אֲבִידָן ʾăḇîḏān abidan, « mon père a jugé » ou « père du jugement ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abidan",
    "etymologie": "Composé de אָב (H0001, « père ») + דִּין (H1777, « juger ») avec suffixe pronominal 1ère personne probable.",
    "formes_derivees": [
      "H1",
      "H1777"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 1:11",
      "texte": "Pour Benjamin : Abidan, fils de Guideoni."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abidan fait partie des douze chefs tribaux nommés en Nombres 1 pour assister Moïse et Aaron lors du recensement des Israélites dans le désert du Sinaï. Chaque chef (nāśîʾ) représentait sa tribu dans l'organisation militaire et administrative du camp. La liste des Nombres reflète une structuration tribale idéalisée de l'Israël…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200022,
    "strong": "H28",
    "langue": "hebreu",
    "numero": 28,
    "mot_original": "אֲבִידָע",
    "translitteration": "ʾăḇîḏāʿ",
    "prononciation": "ʾăḇîḏāʿ",
    "definition": "Abida, « mon père a connu » ou « père de la connaissance ».",
    "categorie": "Sagesse et connaissance",
    "references": [
      "Genèse 25:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h28 אֲבִידָע ʾăḇîḏāʿ abida, « mon père a connu » ou « père de la connaissance ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abida",
    "etymologie": "Composé de אָב (H0001, « père ») + יָדַע (H3045, « connaître ») avec suffixe pronominal 1ère personne probable.",
    "formes_derivees": [
      "H1",
      "H3045"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 25:4",
      "texte": "Les fils de Madian : Épha, Épher, Hénok, Abida et Eldaa."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abida est répertorié parmi les descendants d'Abraham par sa concubine Qetura (Genèse 25:1 4). Ces généalogies rattachent les peuples de la péninsule arabique et du nord ouest de l'Arabie à la lignée abrahamique. Les Madianites, peuple auquel appartient Abida, sont attestés dans les sources extrabibliques (inscriptions égyptiennes, assyriennes) comme une…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200023,
    "strong": "H29",
    "langue": "hebreu",
    "numero": 29,
    "mot_original": "אֲבִיָּה",
    "translitteration": "ʾăḇîyāh",
    "prononciation": "ʾăḇîyāh",
    "definition": "Abiya, Abiyahu, « YHWH est mon père ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 14:1"
    ],
    "type": "nom propre",
    "occurrences": 25,
    "recherche": "h29 אֲבִיָּה ʾăḇîyāh abiya, abiyahu, « yhwh est mon père ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abiya",
    "etymologie": "Nom théophore composé de אָב (H0001, « père ») + יָהּ (H3050, abréviation de YHWH) avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H21",
      "H3050"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 14:1",
      "texte": "En ce temps-là, Abiya, fils de Jéroboam, tomba malade."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Le nom Abiya est l'un des noms théophores yahwistes les plus attestés dans l'onomastique biblique. L'élément « YHWH est mon père » exprime la relation de protection divine conceptualisée en termes de parenté. La répartition chronologique des porteurs du nom s'étend de la période des Juges (fils de Samuel) à…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200024,
    "strong": "H30",
    "langue": "hebreu",
    "numero": 30,
    "mot_original": "אֲבִיהוּא",
    "translitteration": "ʾăḇîhûʾ",
    "prononciation": "ʾăḇîhûʾ",
    "definition": "Abihu, « lui (YHWH) est mon père ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Lévitique 10:1"
    ],
    "type": "nom propre",
    "occurrences": 12,
    "recherche": "h30 אֲבִיהוּא ʾăḇîhûʾ abihu, « lui (yhwh) est mon père ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abihu",
    "etymologie": "Composé de אָב (H0001, « père ») + הוּא (H1931, pronom 3ms, ici substitut du nom divin).",
    "formes_derivees": [
      "H1",
      "H1931"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Lévitique 10:1",
      "texte": "Les fils d\\'Aaron, Nadab et Abihu, prirent chacun leur encensoir. >"
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abihu et son frère aîné Nadab sont frappés de mort pour avoir offert un « feu étranger » (ʾēš zārāh) devant YHWH (Lévitique 10:1 2). Le récit, inséré dans le code de sainteté, fonctionne comme un précédent juridique sur les limites de l'improvisation rituelle dans le culte d'Israël. Le châtiment…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200025,
    "strong": "H31",
    "langue": "hebreu",
    "numero": 31,
    "mot_original": "אֲבִיהוּד",
    "translitteration": "ʾăḇîhûḏ",
    "prononciation": "ʾăḇîhûḏ",
    "definition": "Abihud, « mon père est majesté » ou « père de gloire ».",
    "categorie": "Loi et commandement",
    "references": [
      "1 Chroniques 8:3"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h31 אֲבִיהוּד ʾăḇîhûḏ abihud, « mon père est majesté » ou « père de gloire ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abihud",
    "etymologie": "Composé de אָב (H0001, « père ») + הוֹד (H1935, « majesté, splendeur ») avec suffixe pronominal 1ère personne probable.",
    "formes_derivees": [
      "H1",
      "H1935"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 8:3",
      "texte": "Les fils de Béla furent : Addar, Géra, Abihud."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abihud est répertorié dans la généalogie de la tribu de Benjamin en 1 Chroniques 8. Ce chapitre fournit la liste la plus détaillée des descendants benjaminites, incluant la lignée de Saül et les ancêtres des familles réinstallées à Jérusalem après l'exil. L'élément onomastique הוֹד (« majesté, splendeur ») est utilisé…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200026,
    "strong": "H32",
    "langue": "hebreu",
    "numero": 32,
    "mot_original": "אֲבִיהַיִל",
    "translitteration": "ʾăḇîhayil",
    "prononciation": "ʾăḇîhayil",
    "definition": "Abihail, « mon père est force » ou « père de la force ».",
    "categorie": "Puissance et autorité",
    "references": [
      "Esther 2:15"
    ],
    "type": "nom propre",
    "occurrences": 6,
    "recherche": "h32 אֲבִיהַיִל ʾăḇîhayil abihail, « mon père est force » ou « père de la force ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abihail",
    "etymologie": "Composé de אָב (H0001, « père ») + חַיִל (H2428, « force, puissance, richesse ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H2428"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Esther 2:15",
      "texte": "Lorsque vint le tour d\\'Esther, fille d\\'Abihail, oncle de > Mardochée."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Le nom Abihail est porté par des personnages de sexe masculin et féminin. L'usage d'un même nom théophore pour les deux sexes est un phénomène onomastique attesté, reflétant la neutralité de genre des formules de confession divine. L'Abihail du livre d'Esther est le père biologique d'Esther et l'oncle de Mardochée.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200027,
    "strong": "H33",
    "langue": "hebreu",
    "numero": 33,
    "mot_original": "אֲבִי הָעֶזְרִי",
    "translitteration": "ʾăḇî hāʿezrî",
    "prononciation": "ʾăḇî hāʿezrî",
    "definition": "Abiézerite, membre du clan d'Abiézer, de la tribu de Manassé.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Juges 6:11"
    ],
    "type": "nom propre (gentilé)",
    "occurrences": 3,
    "recherche": "h33 אֲבִי הָעֶזְרִי ʾăḇî hāʿezrî abiézerite, membre du clan d'abiézer, de la tribu de manassé. nom propre (gentilé)",
    "audio": "",
    "image": null,
    "racine": "H44",
    "sens_principal": "Abiézerite",
    "etymologie": "Gentilé dérivé de אֲבִיעֶזֶר (H0044, Abiézer) avec suffixe adjectival î.",
    "formes_derivees": [
      "H44"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Juges 6:11",
      "texte": "L\\'ange de YHWH vint et s\\'assit sous le térébinthe d\\'Ophra, qui > appartenait à Joas, l\\'Abiézérite."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Les Abiézerites constituent un clan de la tribu de Manassé établi dans la région d'Ophra, localité de la montagne cisjordanienne. Le clan est connu par la geste de Gédéon, membre de cette famille, qui conduit la résistance contre les incursions madianites (Juges 6 8). La mention des Abiézerites dans les…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200028,
    "strong": "H34",
    "langue": "hebreu",
    "numero": 34,
    "mot_original": "אֶבְיוֹן",
    "translitteration": "ʾeḇyôn",
    "prononciation": "ʾeḇyôn",
    "definition": "Pauvre, indigent, nécessiteux, celui qui manque de ressources.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 23:11",
      "Deutéronome 15:7"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 61,
    "recherche": "h34 אֶבְיוֹן ʾeḇyôn pauvre, indigent, nécessiteux, celui qui manque de ressources. adjectif / nom commun",
    "audio": "",
    "image": null,
    "racine": "H14",
    "sens_principal": "Pauvre",
    "etymologie": "Dérivé de la racine אָבָה (H0014, « vouloir, désirer ») avec suffixe adjectival ôn.",
    "formes_derivees": [
      "H14"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 23:11",
      "texte": "La septième année, tu la laisseras en jachère et tu > l\\'abandonneras, et les pauvres de ton peuple en mangeront."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme אֶבְיוֹן désigne une catégorie socio économique spécifique dans la société israélite : la personne sans terre ou sans ressources, dépendante de l'assistance familiale ou communautaire. La législation du Pentateuque contient des dispositions protectrices envers l'eḇyôn : glanage (Lévitique 19:10), prêt sans intérêt (Exode 22:24), jachère de la septième…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200029,
    "strong": "H35",
    "langue": "hebreu",
    "numero": 35,
    "mot_original": "אֲבִיּוֹנָה",
    "translitteration": "ʾăḇîyônāh",
    "prononciation": "ʾăḇîyônāh",
    "definition": "Câpre, fruit du câprier (Capparis spinosa).",
    "categorie": "Prière et adoration",
    "references": [
      "Ecclésiaste 12:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h35 אֲבִיּוֹנָה ʾăḇîyônāh câpre, fruit du câprier (capparis spinosa). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Câpre",
    "etymologie": "Nom de plante d'origine sémitique. Arabe : ʾabiyyun Syriaque : ܐܒܝܘܢܐ (ʾaḇyônāʾ)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ecclésiaste 12:5",
      "texte": "Et la câpre n\\'a plus d\\'effet."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La câpre est mentionnée dans le poème allégorique sur la vieillesse qui conclut l'Ecclésiaste (12:1 7). Le texte décrit le déclin des facultés physiques à travers une série de métaphores. La câpre, réputée dans la pharmacopée antique pour ses propriétés stimulantes et aphrodisiaques, perd son efficacité, symbolisant l'extinction du désir…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200030,
    "strong": "H36",
    "langue": "hebreu",
    "numero": 36,
    "mot_original": "אֲבִיטוּב",
    "translitteration": "ʾăḇîṭûḇ",
    "prononciation": "ʾăḇîṭûḇ",
    "definition": "Abitub, « mon père est bonté » ou « père de la bonté ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 8:11"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h36 אֲבִיטוּב ʾăḇîṭûḇ abitub, « mon père est bonté » ou « père de la bonté ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abitub",
    "etymologie": "Composé de אָב (H0001, « père ») + טוּב (H2898, « bonté, bien ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H2898"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 8:11",
      "texte": "De Hushim, il engendra Abitub."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abitub est mentionné dans une généalogie benjaminite complexe de 1 Chroniques 8, qui énumère les descendants de Shaharaïm nés dans les champs de Moab après une rupture familiale. Cette généalogie documente les liens entre les Benjaminites et les territoires transjordaniens. L'élément onomastique טוּב (« bonté, prospérité ») est rare dans…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200031,
    "strong": "H37",
    "langue": "hebreu",
    "numero": 37,
    "mot_original": "אֲבִיטָל",
    "translitteration": "ʾăḇîṭāl",
    "prononciation": "ʾăḇîṭāl",
    "definition": "Abital, « mon père est rosée » ou « père de la rosée ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "2 Samuel 3:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h37 אֲבִיטָל ʾăḇîṭāl abital, « mon père est rosée » ou « père de la rosée ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abital",
    "etymologie": "Composé de אָב (H0001, « père ») + טַל (H2919, « rosée ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H2919"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 3:4",
      "texte": "Le quatrième, Adonija, fils de Haggith ; le cinquième, Shephatiah, > fils d\\'Abital."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abital est une des épouses de David à Hébron, période où le roi constitue un harem pour sceller des alliances politiques avec les clans judéens. Chaque mariage de David documenté en 2 Samuel 3 correspond à une stratégie d'intégration des factions locales. La rosée (ṭal) est une image poétique majeure…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200032,
    "strong": "H38",
    "langue": "hebreu",
    "numero": 38,
    "mot_original": "אֲבִיָּם",
    "translitteration": "ʾăḇîyām",
    "prononciation": "ʾăḇîyām",
    "definition": "Abiyam, \"mon père est Yām (Mer)\" ou forme alternative de Abiya. Roi de Juda, fils de Roboam.",
    "categorie": "Royaume",
    "references": [
      "1 Rois 14:31"
    ],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h38 אֲבִיָּם ʾăḇîyām abiyam, \"mon père est yām (mer)\" ou forme alternative de abiya. roi de juda, fils de roboam. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abiyam",
    "etymologie": "Composé de אָב (H0001, \"père\") + יָם (H3220, \"mer\").",
    "formes_derivees": [
      "H1",
      "H29",
      "H3220"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Le roi Abiyam régna sur Juda pendant trois ans (environ 913 911 avant l'ère courante selon la chronologie conventionnelle). Le livre des Rois le présente de manière défavorable, lui reprochant de marcher dans les péchés de son père Roboam. Les Chroniques (2 Chroniques 13) donnent un portrait plus développé incluant…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200033,
    "strong": "H39",
    "langue": "hebreu",
    "numero": 39,
    "mot_original": "אֲבִימָאֵל",
    "translitteration": "ʾăḇîmāʾēl",
    "prononciation": "ʾăḇîmāʾēl",
    "definition": "Abimaël, \"mon père est vraiment Dieu\" ou \"le père est de Dieu\". Descendant de Sem.",
    "categorie": "Noms de Dieu",
    "references": [
      "Genèse 10:28"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h39 אֲבִימָאֵל ʾăḇîmāʾēl abimaël, \"mon père est vraiment dieu\" ou \"le père est de dieu\". descendant de sem. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abimaël",
    "etymologie": "Composé de אָב (H0001, \"père\") + מָאֵל, où מָא est une particule emphatique (\"vraiment\") + אֵל (H0410, \"Dieu\").",
    "formes_derivees": [
      "H1",
      "H410"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abimaël est répertorié parmi les descendants de Yoqtan, dans la branche sémitique de la Table des Nations (Genèse 10). La liste des fils de Yoqtan (Genèse 10:26 29) énumère treize noms correspondant à des tribus ou localités de la péninsule arabique. Les Yoqtanides sont généralement identifiés aux populations du sud…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200034,
    "strong": "H40",
    "langue": "hebreu",
    "numero": 40,
    "mot_original": "אֲבִימֶלֶךְ",
    "translitteration": "ʾăḇîmeleḵ",
    "prononciation": "ʾăḇîmeleḵ",
    "definition": "Abimélek, \"mon père est roi\" ou \"le père (divin) est roi\".",
    "categorie": "Noms de Dieu",
    "references": [
      "Genèse 20:2"
    ],
    "type": "nom propre",
    "occurrences": 67,
    "recherche": "h40 אֲבִימֶלֶךְ ʾăḇîmeleḵ abimélek, \"mon père est roi\" ou \"le père (divin) est roi\". nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abimélek",
    "etymologie": "Composé de אָב (H0001, \"père\") + מֶלֶךְ (H4428, \"roi\") avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H4428"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Le nom Abimélek est porté par des personnages distincts dans des contextes narratifs différents. Le roi philistin de Guérar apparaît dans les récits patriarcaux comme interlocuteur d'Abraham puis d'Isaac. Les récits de Genèse 20 et 26 présentent des motifs similaires (mariage sororal dissimulé, conflit sur les puits, alliance à Beer…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200035,
    "strong": "H41",
    "langue": "hebreu",
    "numero": 41,
    "mot_original": "אֲבִינָדָב",
    "translitteration": "ʾăḇînāḏāḇ",
    "prononciation": "ʾăḇînāḏāḇ",
    "definition": "Abinadab, « mon père est noble » ou « père de la noblesse ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Samuel 7:1"
    ],
    "type": "nom propre",
    "occurrences": 12,
    "recherche": "h41 אֲבִינָדָב ʾăḇînāḏāḇ abinadab, « mon père est noble » ou « père de la noblesse ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abinadab",
    "etymologie": "Composé de אָב (H0001, « père ») + נָדִיב (H5081, « noble, généreux, prince ») avec suffixe pronominal 1ère personne probable.",
    "formes_derivees": [
      "H1",
      "H5081"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 7:1",
      "texte": "Les hommes de Qiryat-Yéarim vinrent, firent monter l\\'arche de YHWH > et l\\'amenèrent dans la maison d\\'Abinadab, sur la colline."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Le nom Abinadab est porté par trois personnages distincts de l'époque pré monarchique et du début de la royauté. L'Abinadab de Qiryat Yéarim reçoit l'arche d'alliance après son retour du territoire philistin (1 Samuel 7:1). Sa maison devient le sanctuaire temporaire du symbole cultuel central d'Israël pendant vingt ans, jusqu'au…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200036,
    "strong": "H42",
    "langue": "hebreu",
    "numero": 42,
    "mot_original": "אֲבִינֹעַם",
    "translitteration": "ʾăḇînōʿam",
    "prononciation": "ʾăḇînōʿam",
    "definition": "Abinoam, « mon père est plaisir » ou « père de la douceur ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Juges 4:6"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h42 אֲבִינֹעַם ʾăḇînōʿam abinoam, « mon père est plaisir » ou « père de la douceur ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abinoam",
    "etymologie": "Composé de אָב (H0001, « père ») + נֹעַם (H5278, « plaisir, douceur, agrément ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H5278"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Juges 4:6",
      "texte": "Elle envoya appeler Baraq, fils d\\'Abinoam, de Qédesh en Nephtali. >"
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abinoam n'est connu que comme père de Baraq. Son nom est systématiquement mentionné dans le patronyme complet « Baraq ben Abinoam », selon la formule d'identification tribale et familiale standard de l'historiographie biblique. Baraq, originaire de Qédesh en Nephtali, est mobilisé par la prophétesse Débora pour conduire la coalition des…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200037,
    "strong": "H43",
    "langue": "hebreu",
    "numero": 43,
    "mot_original": "אֶבְיָסָף",
    "translitteration": "ʾeḇyāsāp̄",
    "prononciation": "ʾeḇyāsāp̄",
    "definition": "Ebyasaph, variante orthographique de Abiasaph (H0023).",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 6:8"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h43 אֶבְיָסָף ʾeḇyāsāp̄ ebyasaph, variante orthographique de abiasaph (h0023). nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ebyasaph",
    "etymologie": "Variante de אֲבִיאָסָף (H0023). Composé des mêmes éléments avec métathèse ou altération vocalique.",
    "formes_derivees": [
      "H23"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 6:8",
      "texte": "Fils de Qehath : Amminadab, son fils ; Qorah, son fils ; Assir, son > fils ; Ebyasaph, son fils."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ebyasaph est une variante textuelle de Abiasaph (H0023), apparaissant dans la généalogie lévitique de 1 Chroniques 6. Les listes généalogiques des Chroniques présentent fréquemment des variations orthographiques pour les mêmes noms, phénomène caractéristique de la transmission textuelle des listes sacerdotales. La généalogie qorahite de 1 Chroniques 6 rattache les chantres…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200038,
    "strong": "H44",
    "langue": "hebreu",
    "numero": 44,
    "mot_original": "אֲבִיעֶזֶר",
    "translitteration": "ʾăḇîʿezer",
    "prononciation": "ʾăḇîʿezer",
    "definition": "Abiézer, « mon père est secours » ou « père du secours ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Juges 6:34"
    ],
    "type": "nom propre",
    "occurrences": 7,
    "recherche": "h44 אֲבִיעֶזֶר ʾăḇîʿezer abiézer, « mon père est secours » ou « père du secours ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abiézer",
    "etymologie": "Composé de אָב (H0001, « père ») + עֵזֶר (H5828, « secours, aide ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H33",
      "H5828"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Juges 6:34",
      "texte": "L\\'esprit de YHWH revêtit Gédéon ; il sonna du shofar, et le clan > d\\'Abiézer se rassembla derrière lui."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abiézer est l'ancêtre éponyme d'un clan de la tribu de Manassé, les Abiézerites (H0033), auquel appartient Gédéon. Le clan est mentionné dans les ostraca de Samarie (VIIIe siècle avant l'ère courante), qui documentent les livraisons fiscales de domaines claniques manassites. Cette attestation épigraphique confirme l'existence historique du clan et son…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200039,
    "strong": "H45",
    "langue": "hebreu",
    "numero": 45,
    "mot_original": "אֲבִי־עַלְבוֹן",
    "translitteration": "ʾăḇî-ʿalḇôn",
    "prononciation": "ʾăḇî-ʿalḇôn",
    "definition": "Abi-Albon, « père de force » ou nom composé incluant עַלְבוֹן.",
    "categorie": "Puissance et autorité",
    "references": [
      "2 Samuel 23:31"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h45 אֲבִי־עַלְבוֹן ʾăḇî-ʿalḇôn abi-albon, « père de force » ou nom composé incluant עַלְבוֹן. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abi Albon",
    "etymologie": "Composé de אָב (H0001, « père ») + עַלְבוֹן, nom propre ou substantif d'origine incertaine.",
    "formes_derivees": [
      "H1"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 23:31",
      "texte": "Abi-Albon, l\\'Arbatite."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abi Albon est répertorié dans la liste des Trente guerriers de David (2 Samuel 23:24 39), document administratif ou militaire préservant les noms des combattants d'élite de la période davidique. La liste présente des variantes entre Samuel et Chroniques, attribuables aux aléas de la transmission textuelle. Le guerrier est identifié…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200040,
    "strong": "H46",
    "langue": "hebreu",
    "numero": 46,
    "mot_original": "אָבִיר",
    "translitteration": "ʾāḇîr",
    "prononciation": "ʾāḇîr",
    "definition": "Fort, puissant, taureau (métaphore de puissance).",
    "categorie": "Puissance et autorité",
    "references": [
      "Genèse 49:24",
      "Ésaïe 1:24"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 6,
    "recherche": "h46 אָבִיר ʾāḇîr fort, puissant, taureau (métaphore de puissance). adjectif / nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Fort",
    "etymologie": "Dérivé de la racine אבר (ʾBR), « être fort, puissant ». Arabe : ʾabara (être fort) Ougaritique : ảibr (taureau, puissant)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 49:24",
      "texte": "De là, le Berger, la Pierre d\\'Israël, par les mains du Puissant de > Jacob."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le titre « Puissant de Jacob/Israël » est une épithète divine archaïque, cantonnée à la poésie biblique. L'équivalent ougaritique ảibr désigne le taureau comme symbole de force et de fertilité, appliqué au dieu El. L'hébreu biblique conserve l'acception métaphorique (« puissant ») sans expliciter la référence taurine, probablement par aniconisme.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200041,
    "strong": "H47",
    "langue": "hebreu",
    "numero": 47,
    "mot_original": "אַבִּיר",
    "translitteration": "ʾabbîr",
    "prononciation": "ʾabbîr",
    "definition": "Puissant, fort, taureau ; coursier, destrier.",
    "categorie": "Eau et baptême",
    "references": [
      "Juges 5:22",
      "Psaume 22:13"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 17,
    "recherche": "h47 אַבִּיר ʾabbîr puissant, fort, taureau ; coursier, destrier. adjectif / nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Puissant",
    "etymologie": "Même racine אבר (ʾBR) que אָבִיר (H0046), avec redoublement de la seconde radicale exprimant l'intensité.",
    "formes_derivees": [
      "H46"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Juges 5:22",
      "texte": "Alors les sabots des chevaux martelèrent le sol, au galop, au galop > de leurs destriers."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme אַבִּיר couvre un spectre sémantique allant de l'animal (taureau) au cheval de guerre, puis métaphoriquement à l'homme puissant. Le redoublement de la seconde radicale (forme qattîl) indique une intensification par rapport à la forme simple אָבִיר. L'usage pour désigner les taureaux de Bashan (Psaume 22:13) reflète la réputation…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200042,
    "strong": "H48",
    "langue": "hebreu",
    "numero": 48,
    "mot_original": "אֲבִירָם",
    "translitteration": "ʾăḇîrām",
    "prononciation": "ʾăḇîrām",
    "definition": "Abiram, « mon père est exalté » ou « le père (divin) est exalté ».",
    "categorie": "Noms de Dieu",
    "references": [
      "Nombres 16:1",
      "1 Rois 16:34"
    ],
    "type": "nom propre",
    "occurrences": 11,
    "recherche": "h48 אֲבִירָם ʾăḇîrām abiram, « mon père est exalté » ou « le père (divin) est exalté ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abiram",
    "etymologie": "Composé de אָב (H0001, « père ») + רוּם (H7311, « être haut, exalté ») avec suffixe pronominal 1ère personne ou sans suffixe.",
    "formes_derivees": [
      "H1",
      "H7311"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 16:1",
      "texte": "Qorah prit\\... Dathan et Abiram, fils d\\'Éliab."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "L'Abiram rubénite est l'un des protagonistes de la révolte contre l'autorité de Moïse et Aaron en Nombres 16. Avec son frère Dathan, il conteste la légitimité de la direction mosaïque, invoquant la promesse non tenue d'entrer dans une terre fertile. Le châtiment par engloutissement dans la terre (Nombres 16:31 33)…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200043,
    "strong": "H49",
    "langue": "hebreu",
    "numero": 49,
    "mot_original": "אֲבִישַׁג",
    "translitteration": "ʾăḇîšaḡ",
    "prononciation": "ʾăḇîšaḡ",
    "definition": "Abishag, « mon père est errance » ou signification incertaine.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 1:3"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h49 אֲבִישַׁג ʾăḇîšaḡ abishag, « mon père est errance » ou signification incertaine. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abishag",
    "etymologie": "Composé de אָב (H0001, « père ») + élément שַׁג d'origine incertaine.",
    "formes_derivees": [
      "H1"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 1:3",
      "texte": "On chercha une jeune fille belle dans tout le territoire d\\'Israël > ; on trouva Abishag la Sunamite."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abishag est une jeune femme de Sunem (localité de la vallée de Jezréel) choisie pour sa beauté afin de prendre soin du roi David vieillissant. Sa fonction officielle est de réchauffer le roi en partageant sa couche, pratique thérapeutique attestée dans la médecine antique (Grecs, Romains) pour les personnes âgées…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200044,
    "strong": "H50",
    "langue": "hebreu",
    "numero": 50,
    "mot_original": "אֲבִישׁוּעַ",
    "translitteration": "ʾăḇîšûaʿ",
    "prononciation": "ʾăḇîšûaʿ",
    "definition": "Abishua, « mon père est salut » ou « père du salut ».",
    "categorie": "Rédemption et salut",
    "references": [
      "1 Chroniques 5:30"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h50 אֲבִישׁוּעַ ʾăḇîšûaʿ abishua, « mon père est salut » ou « père du salut ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abishua",
    "etymologie": "Composé de אָב (H0001, « père ») + יָשַׁע (H3467, « sauver, secourir ») avec suffixe pronominal 1ère personne probable.",
    "formes_derivees": [
      "H1",
      "H3467"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 5:30",
      "texte": "Phinéas engendra Abishua ; Abishua engendra Buqqi."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abishua le grand prêtre appartient à la généalogie sacerdotale aaronide. Il est le quatrième grand prêtre selon la succession : Aaron → Éléazar → Phinéas → Abishua → Buqqi → Uzzi. La liste généalogique de 1 Chroniques 5:27 41 (numérotation hébraïque) établit la continuité de la lignée sacerdotale légitime jusqu'à…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200045,
    "strong": "H51",
    "langue": "hebreu",
    "numero": 51,
    "mot_original": "אֲבִישׁוּר",
    "translitteration": "ʾăḇîšûr",
    "prononciation": "ʾăḇîšûr",
    "definition": "Abishur, « mon père est muraille » ou « père de la muraille ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 2:28"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h51 אֲבִישׁוּר ʾăḇîšûr abishur, « mon père est muraille » ou « père de la muraille ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abishur",
    "etymologie": "Composé de אָב (H0001, « père ») + שׁוּר (H7791, « muraille, rempart ») avec suffixe pronominal 1ère personne probable.",
    "formes_derivees": [
      "H1",
      "H7791"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 2:28",
      "texte": "Les fils de Shammaï furent Abdon et Abishur."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abishur est mentionné dans la généalogie de la tribu de Juda en 1 Chroniques 2. Il épouse Abihaïl et engendre Ahban et Molid. La notice inclut des informations familiales (nom de l'épouse, noms des fils) inhabituelles dans une liste généalogique, suggérant que cette famille conservait une mémoire historique particulière. L'élément…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200046,
    "strong": "H52",
    "langue": "hebreu",
    "numero": 52,
    "mot_original": "אֲבִישַׁי",
    "translitteration": "ʾăḇîšay",
    "prononciation": "ʾăḇîšay",
    "definition": "Abishaï, « mon père est présent » ou « père du don ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Samuel 26:8"
    ],
    "type": "nom propre",
    "occurrences": 25,
    "recherche": "h52 אֲבִישַׁי ʾăḇîšay abishaï, « mon père est présent » ou « père du don ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abishaï",
    "etymologie": "Composé de אָב (H0001, « père ») + élément שַׁי, abréviation probable de שַׁי (H7862, « don, présent ») ou de יֵשׁ (H3426, « être, exister »).",
    "formes_derivees": [
      "H1",
      "H79",
      "H3426",
      "H7862"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 26:8",
      "texte": "Abishaï dit à David : Dieu livre aujourd\\'hui ton ennemi entre tes > mains."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abishaï est un chef militaire majeur de l'entourage de David, appartenant au cercle restreint des fils de Tserouyah (avec Joab et Asaël). Sa carrière militaire comprend : l'infiltration nocturne du camp de Saül (1 Samuel 26), le meurtre de l'assassin d'Abner (2 Samuel 3:30), le commandement d'un contingent contre les…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200047,
    "strong": "H53",
    "langue": "hebreu",
    "numero": 53,
    "mot_original": "אֲבִישָׁלוֹם",
    "translitteration": "ʾăḇîšālôm",
    "prononciation": "ʾăḇîšālôm",
    "definition": "Abishalom, « mon père est paix » ou « père de la paix ». Variante de Absalom.",
    "categorie": "Paix",
    "references": [
      "1 Rois 15:2"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h53 אֲבִישָׁלוֹם ʾăḇîšālôm abishalom, « mon père est paix » ou « père de la paix ». variante de absalom. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abishalom",
    "etymologie": "Composé de אָב (H0001, « père ») + שָׁלוֹם (H7965, « paix ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H88",
      "H7965"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 15:2",
      "texte": "Il régna trois ans à Jérusalem. Le nom de sa mère était Maaka, > fille d\\'Abishalom."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abishalom est mentionné comme ancêtre maternel de la dynastie judéenne. Sa fille (ou petite fille) Maaka devient l'épouse de Roboam et la mère du roi Abiyam. Elle conserve le titre influent de reine mère (gebîrāh) sous le règne de son petit fils Asa, jusqu'à ce que celui ci la destitue…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200048,
    "strong": "H54",
    "langue": "hebreu",
    "numero": 54,
    "mot_original": "אֶבְיָתָר",
    "translitteration": "ʾeḇyāṯār",
    "prononciation": "ʾeḇyāṯār",
    "definition": "Ébyatar, Abiathar, « le père (divin) a pourvu » ou « père de l'abondance ».",
    "categorie": "Noms de Dieu",
    "references": [
      "1 Samuel 22:20"
    ],
    "type": "nom propre",
    "occurrences": 30,
    "recherche": "h54 אֶבְיָתָר ʾeḇyāṯār ébyatar, abiathar, « le père (divin) a pourvu » ou « père de l'abondance ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ébyatar",
    "etymologie": "Composé de אָב (H0001, « père ») + יָתַר (H3498, « rester, être de reste, abonder »).",
    "formes_derivees": [
      "H1",
      "H3498"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 22:20",
      "texte": "Un fils d\\'Ahimélek, fils d\\'Ahitub, s\\'échappa. Son nom était > Ébyatar."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ébyatar est le seul survivant du massacre des prêtres de Nob ordonné par Saül pour avoir secouru David (1 Samuel 22). Il rejoint David avec l'éphod sacerdotal, instrument de consultation oraculaire, devenant le prêtre personnel de David pendant sa vie de fugitif puis son règne. Sous David, Ébyatar partage le…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200049,
    "strong": "H55",
    "langue": "hebreu",
    "numero": 55,
    "mot_original": "אָבַךְ",
    "translitteration": "ʾāḇaḵ",
    "prononciation": "ʾāḇaḵ",
    "definition": "S'enrouler, monter en spirale, tourbillonner (en parlant de fumée ou de poussière).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Juges 7:13"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h55 אָבַךְ ʾāḇaḵ s'enrouler, monter en spirale, tourbillonner (en parlant de fumée ou de poussière). verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "S'enrouler",
    "etymologie": "Racine sémitique ʾBK signifiant « tourner, tordre, enrouler ». Syriaque : ܐܒܟ (ʾeḇaḵ, « enrouler, tordre ») Arabe : ʾabaka (« tresser, enrouler »)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Juges 7:13",
      "texte": "Il dit : Voici, j\\'ai eu un songe : une miche de pain d\\'orge > roulait dans le camp de Madian, elle arriva jusqu\\'à la tente, la > frappa, et elle tomba ; elle la retourna sens dessus dessous, et la > tente s\\'écroula."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Ce verbe rare n'est attesté qu'une fois, et la lecture textuelle est incertaine. La racine אבך décrit un mouvement de rotation, typiquement celui de la fumée, de la poussière ou de la vapeur qui monte en colonne. L'image du tourbillon appartient au vocabulaire des théophanies et des phénomènes atmosphériques.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200050,
    "strong": "H56",
    "langue": "hebreu",
    "numero": 56,
    "mot_original": "אָבַל",
    "translitteration": "ʾāḇal",
    "prononciation": "ʾāḇal",
    "definition": "Être en deuil, mener le deuil, se lamenter.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Ésaïe 24:4"
    ],
    "type": "verbe",
    "occurrences": 8,
    "recherche": "h56 אָבַל ʾāḇal être en deuil, mener le deuil, se lamenter. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Être en deuil",
    "etymologie": "Racine sémitique ʾBL signifiant « être sec, se dessécher ; être en deuil ». Arabe : ʾabala (se dessécher) Syriaque : ܐܒܠ (ʾeḇal, « deuil ») Akkadien : abālu (se dessécher, être sec)",
    "formes_derivees": [
      "H60"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ésaïe 24:4",
      "texte": "La terre est en deuil, elle dépérit."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe אָבַל et ses dérivés (אֵבֶל H0060, « deuil ») décrivent l'ensemble des pratiques sociales et rituelles entourant la mort. Le deuil israélite comprenait : le port du sac, l'aspersion de cendres, le jeûne, les lamentations vocales, les incisions rituelles (interdites en Lévitique 19:28), et l'abstention d'onction d'huile. L'usage…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200051,
    "strong": "H57",
    "langue": "hebreu",
    "numero": 57,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "En deuil, affligé, portant le deuil.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Ésaïe 61:3"
    ],
    "type": "adjectif",
    "occurrences": 8,
    "recherche": "h57 אָבֵל ʾāḇēl en deuil, affligé, portant le deuil. adjectif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "En deuil",
    "etymologie": "Participe actif Qal substantivé du verbe אָבַל (H0056).",
    "formes_derivees": [
      "H56"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ésaïe 61:3",
      "texte": "Pour mettre \\[une coiffure\\] aux endeuillés de Sion."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Le terme désigne spécifiquement la personne qui accomplit les gestes du deuil. Le statut d'« endeuillé » implique une période de séparation sociale, des vêtements spécifiques, et une participation de la communauté aux rites funéraires. La « consolation des endeuillés de Sion » (Ésaïe 61:3) figure parmi les missions du…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200052,
    "strong": "H58",
    "langue": "hebreu",
    "numero": 58,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "Prairie, pâturage arrosé, cours d'eau.",
    "categorie": "Eau et baptême",
    "references": [
      "Juges 11:33"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h58 אָבֵל ʾāḇēl prairie, pâturage arrosé, cours d'eau. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Prairie",
    "etymologie": "Racine ʾBL homonyme de la racine « deuil », signifiant « être humide, arrosé ». Arabe : ʾabala (être humide, arrosé) Akkadien : ablu (prairie, pâturage)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Juges 11:33",
      "texte": "Il les frappa depuis Aroër jusqu\\'à l\\'entrée de Minnith, vingt > villes, et jusqu\\'à Abel-Keramim."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme אָבֵל comme « prairie » apparaît presque exclusivement dans des toponymes composés : Abel Keramim (« prairie des vignes »), Abel Meholah (« prairie de la danse »), Abel Maïm (« prairie des eaux »). Ces toponymes désignent des localités situées dans des zones bien irriguées, typiquement dans…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200053,
    "strong": "H59",
    "langue": "hebreu",
    "numero": 59,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "Abel, nom de plusieurs localités en Israël et en Transjordanie.",
    "categorie": "Noms propres bibliques",
    "references": [
      "2 Samuel 20:18"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 7,
    "recherche": "h59 אָבֵל ʾāḇēl abel, nom de plusieurs localités en israël et en transjordanie. nom propre (toponyme)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abel",
    "etymologie": "Dérivé du nom commun אָבֵל (H0058, « prairie, pâturage arrosé »).",
    "formes_derivees": [
      "H58"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 20:18",
      "texte": "Elle dit : Autrefois on avait coutume de dire : Que l\\'on consulte > Abel ! Et ainsi on terminait l\\'affaire."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Abel Beth Maaka est la plus notable des localités portant ce nom. Située à l'extrémité nord du territoire israélite, près de Dan, elle est assiégée par Joab lors de la poursuite du rebelle Sheba ben Bikri (2 Samuel 20). Une « femme sage » de la ville négocie la reddition…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200054,
    "strong": "H60",
    "langue": "hebreu",
    "numero": 60,
    "mot_original": "אֵבֶל",
    "translitteration": "ʾēḇel",
    "prononciation": "ʾēḇel",
    "definition": "Deuil, lamentation funèbre, cérémonie de deuil.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Genèse 50:11"
    ],
    "type": "nom commun",
    "occurrences": 24,
    "recherche": "h60 אֵבֶל ʾēḇel deuil, lamentation funèbre, cérémonie de deuil. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Deuil",
    "etymologie": "Dérivé nominal du verbe אָבַל (H0056, « être en deuil »).",
    "formes_derivees": [
      "H56"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 50:11",
      "texte": "Les habitants du pays, les Cananéens, virent le deuil dans l\\'aire > d\\'Atad."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le deuil israélite comportait une durée variable selon le statut du défunt : sept jours pour le deuil ordinaire (Genèse 50:10 ; 1 Samuel 31:13), trente jours pour les figures éminentes (Moïse : Deutéronome 34:8 ; Aaron : Nombres 20:29). Les pratiques incluaient le port du sac (שַׂק), l'aspersion de…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200055,
    "strong": "H61",
    "langue": "hebreu",
    "numero": 61,
    "mot_original": "אֲבָל",
    "translitteration": "ʾăḇāl",
    "prononciation": "ʾăḇāl",
    "definition": "Mais, cependant, toutefois, vraiment, certainement.",
    "categorie": "Foi",
    "references": [
      "Genèse 17:19",
      "2 Samuel 14:5"
    ],
    "type": "adverbe / conjonction",
    "occurrences": 11,
    "recherche": "h61 אֲבָל ʾăḇāl mais, cependant, toutefois, vraiment, certainement. adverbe / conjonction",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Mais",
    "etymologie": "Dérivé de la particule présentative אָב (non attestée isolément en hébreu) + suffixe adverbial āl. Araméen : אֲבָל (ʾăḇāl, « mais, cependant ») Syriaque : ܐܒܠ (ʾāḇēl, « mais ») Arabe : bal (« mais, plutôt »)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 17:19",
      "texte": "Dieu dit : Mais Sara, ta femme, t\\'enfantera un fils."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "adverbe"
    ],
    "notes": "La particule אֲבָל fonctionne comme connecteur logique marquant une opposition ou une restriction par rapport à l'énoncé précédent. En contexte narratif, elle introduit une objection, une correction ou une précision. L'usage assertif (« vraiment, certainement ») est moins fréquent et souvent difficile à distinguer de l'usage adversatif. La forme est…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200056,
    "strong": "H62",
    "langue": "hebreu",
    "numero": 62,
    "mot_original": "אָבֵל בֵּית־מַעֲכָה",
    "translitteration": "ʾāḇēl bêṯ-maʿăḵāh",
    "prononciation": "ʾāḇēl bêṯ-maʿăḵāh",
    "definition": "Abel-Beth-Maaka, « prairie de la maison de Maaka », ville fortifiée du nord d'Israël.",
    "categorie": "Noms propres bibliques",
    "references": [
      "2 Samuel 20:14"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 4,
    "recherche": "h62 אָבֵל בֵּית־מַעֲכָה ʾāḇēl bêṯ-maʿăḵāh abel-beth-maaka, « prairie de la maison de maaka », ville fortifiée du nord d'israël. nom propre (toponyme composé)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abel Beth Maaka",
    "etymologie": "Composé de אָבֵל (H0058, « prairie ») + בַּיִת (H1004, « maison ») + מַעֲכָה (H4601, nom de personne ou de région).",
    "formes_derivees": [
      "H58",
      "H59",
      "H1004",
      "H4601"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 20:14",
      "texte": "Sheba parcourut toutes les tribus d\\'Israël jusqu\\'à Abel et > Beth-Maaka."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Voir notes contextuelles de H0059. Abel Beth Maaka est le site le plus documenté des toponymes en Abel. La ville est qualifiée de « ville et mère en Israël » (2 Samuel 20:19), expression désignant une métropole régionale ou une cité mère dont dépendaient des villages satellites. La « femme…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200057,
    "strong": "H63",
    "langue": "hebreu",
    "numero": 63,
    "mot_original": "אָבֵל הַשִּׁטִּים",
    "translitteration": "ʾāḇēl haššiṭṭîm",
    "prononciation": "ʾāḇēl haššiṭṭîm",
    "definition": "Abel-Shittim, « prairie des acacias », dernier campement israélite en Transjordanie.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Nombres 33:49"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h63 אָבֵל הַשִּׁטִּים ʾāḇēl haššiṭṭîm abel-shittim, « prairie des acacias », dernier campement israélite en transjordanie. nom propre (toponyme composé)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abel Shittim",
    "etymologie": "Composé de אָבֵל (H0058, « prairie ») + שִּׁטָּה (H7848, « acacia ») avec article défini au pluriel.",
    "formes_derivees": [
      "H58",
      "H7848"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 33:49",
      "texte": "Ils campèrent près du Jourdain, de Beth-Yeshimoth jusqu\\'à > Abel-Shittim, dans les plaines de Moab."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abel Shittim est le campement de base israélite avant la traversée du Jourdain. C'est à Shittim que se situe l'épisode de l'idolâtrie avec les filles de Moab et l'apostasie de Baal Peor (Nombres 25), ainsi que le second recensement (Nombres 26) et les dernières instructions de Moïse (Nombres 33 36).…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200058,
    "strong": "H64",
    "langue": "hebreu",
    "numero": 64,
    "mot_original": "אָבֵל כְּרָמִים",
    "translitteration": "ʾāḇēl kərāmîm",
    "prononciation": "ʾāḇēl kərāmîm",
    "definition": "Abel-Keramim, « prairie des vignes », localité ammonite.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Juges 11:33"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h64 אָבֵל כְּרָמִים ʾāḇēl kərāmîm abel-keramim, « prairie des vignes », localité ammonite. nom propre (toponyme composé)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abel Keramim",
    "etymologie": "Composé de אָבֵל (H0058, « prairie ») + כֶּרֶם (H3754, « vigne, vignoble ») au pluriel.",
    "formes_derivees": [
      "H58",
      "H3754"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Juges 11:33",
      "texte": "Il les frappa depuis Aroër jusqu\\'à l\\'entrée de Minnith, vingt > villes, et jusqu\\'à Abel-Keramim."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Abel Keramim est mentionnée dans le récit de la campagne de Jephté contre les Ammonites (Juges 11). La localité est située en territoire ammonite, probablement dans la région fertile au nord est de la mer Morte, réputée pour ses vignobles. Le toponyme « prairie des vignes » décrit précisément les…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200059,
    "strong": "H65",
    "langue": "hebreu",
    "numero": 65,
    "mot_original": "אָבֵל מְחוֹלָה",
    "translitteration": "ʾāḇēl məḥôlāh",
    "prononciation": "ʾāḇēl məḥôlāh",
    "definition": "Abel-Meholah, « prairie de la danse », ville de la vallée du Jourdain.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 19:16"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 3,
    "recherche": "h65 אָבֵל מְחוֹלָה ʾāḇēl məḥôlāh abel-meholah, « prairie de la danse », ville de la vallée du jourdain. nom propre (toponyme composé)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abel Meholah",
    "etymologie": "Composé de אָבֵל (H0058, « prairie ») + מְחוֹלָה (H4246, « danse »).",
    "formes_derivees": [
      "H58",
      "H4246"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 19:16",
      "texte": "Tu oindras Élisée, fils de Shaphat, d\\'Abel-Meholah, comme prophète > à ta place."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Abel Meholah est située dans la vallée du Jourdain, probablement au sud de Beth Shéan, dans une zone de terres alluviales fertiles propices à l'agriculture. La ville est mentionnée dans la liste des préfectures de Salomon (1 Rois 4:12), dans le district de Baana. La mention d'Abel Meholah comme patrie…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200060,
    "strong": "H66",
    "langue": "hebreu",
    "numero": 66,
    "mot_original": "אָבֵל מַיִם",
    "translitteration": "ʾāḇēl mayim",
    "prononciation": "ʾāḇēl mayim",
    "definition": "Abel-Maïm, « prairie des eaux », variante de Abel-Beth-Maaka.",
    "categorie": "Eau et baptême",
    "references": [
      "2 Chroniques 16:4"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h66 אָבֵל מַיִם ʾāḇēl mayim abel-maïm, « prairie des eaux », variante de abel-beth-maaka. nom propre (toponyme composé)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abel Maïm",
    "etymologie": "Composé de אָבֵל (H0058, « prairie ») + מַיִם (H4325, « eaux »).",
    "formes_derivees": [
      "H58",
      "H62",
      "H4325"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Chroniques 16:4",
      "texte": "Ben-Hadad écouta le roi Asa ; il envoya les chefs de son armée > contre les villes d\\'Israël, et ils frappèrent Iyyôn, Dan, Abel-Maïm. >"
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abel Maïm est la désignation du Chroniste pour Abel Beth Maaka (H0062). La substitution de « Maïm » (eaux) à « Beth Maaka » pourrait être une clarification géographique soulignant les ressources hydriques du site, ou une adaptation théologique évitant la mention d'une « maison » étrangère. La campagne de…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200061,
    "strong": "H67",
    "langue": "hebreu",
    "numero": 67,
    "mot_original": "אָבֵל מִצְרַיִם",
    "translitteration": "ʾāḇēl miṣrayim",
    "prononciation": "ʾāḇēl miṣrayim",
    "definition": "Abel-Mitsraïm, « deuil de l'Égypte », nom donné à l'aire d'Atad après la cérémonie funèbre de Jacob.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 50:11"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h67 אָבֵל מִצְרַיִם ʾāḇēl miṣrayim abel-mitsraïm, « deuil de l'égypte », nom donné à l'aire d'atad après la cérémonie funèbre de jacob. nom propre (toponyme composé)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abel Mitsraïm",
    "etymologie": "Jeu de mots entre אֵבֶל (H0060, « deuil ») et le toponyme אָבֵל (« prairie ») + מִצְרַיִם (H4714, « Égypte »).",
    "formes_derivees": [
      "H60",
      "H4714"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 50:11",
      "texte": "On appela ce lieu Abel-Mitsraïm, qui est au-delà du Jourdain."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Le toponyme Abel Mitsraïm illustre le procédé biblique de l'étiologie narrative : un événement (le deuil égyptien pour Jacob) donne naissance à un nom de lieu par réinterprétation d'un toponyme préexistant. La localisation « au delà du Jourdain » situe le site en Transjordanie. La cérémonie funèbre de Jacob mobilise…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200062,
    "strong": "H68",
    "langue": "hebreu",
    "numero": 68,
    "mot_original": "אֶבֶן",
    "translitteration": "ʾeḇen",
    "prononciation": "ʾeḇen",
    "definition": "Pierre, roche, bloc de pierre.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 28:18",
      "Exode 31:18"
    ],
    "type": "nom commun",
    "occurrences": 273,
    "recherche": "h68 אֶבֶן ʾeḇen pierre, roche, bloc de pierre. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Pierre",
    "etymologie": "Racine sémitique ʾBN. Akkadien : abnu Ougaritique : ảbn Phénicien : ʾbn Araméen : אֶבֶן (ʾeḇen) Arabe : ʾibn (fils, pierre)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 28:18",
      "texte": "Jacob se leva de bon matin, prit la pierre qu\\'il avait mise sous > sa tête, et la dressa comme stèle."
    },
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La pierre est un élément fondamental de la culture matérielle et symbolique du Proche Orient ancien. La construction en pierre de taille se développe en Israël à partir de la monarchie unifiée (palais de David, temple de Salomon). L'usage de pierres brutes pour les autels est prescrit en Exode 20:25,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200063,
    "strong": "H69",
    "langue": "hebreu",
    "numero": 69,
    "mot_original": "אֶבֶן",
    "translitteration": "ʾeḇen",
    "prononciation": "ʾeḇen",
    "definition": "Pierre. Correspondance araméenne de l'hébreu אֶבֶן (H0068).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 2:34",
      "Esdras 6:4"
    ],
    "type": "nom commun",
    "occurrences": 8,
    "recherche": "h69 אֶבֶן ʾeḇen pierre. correspondance araméenne de l'hébreu אֶבֶן (h0068). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Pierre",
    "etymologie": "Correspondance araméenne exacte de l'hébreu אֶבֶן (H0068). Racine sémitique ʾBN. Syriaque : ܐܒܢܐ (ʾaḇnā) Mandéen : abna",
    "formes_derivees": [
      "H68"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Daniel 2:34",
      "texte": "Tu regardais jusqu\\'à ce qu\\'une pierre se détachât sans l\\'aide > d\\'aucune main."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "L'araméen אֶבֶן est identique à l'hébreu dans sa graphie non vocalisée, seule la vocalisation massorétique distingue les deux formes (segol en hébreu contre patah segol en araméen). En Esdras, le terme apparaît dans des documents administratifs concernant la reconstruction du Temple de Jérusalem, citant le décret de Cyrus autorisant l'usage…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200064,
    "strong": "H70",
    "langue": "hebreu",
    "numero": 70,
    "mot_original": "אֹבֶן",
    "translitteration": "ʾōḇen",
    "prononciation": "ʾōḇen",
    "definition": "Siège d'accouchement, pierres sur lesquelles la femme s'accroupissait pour accoucher.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 1:16",
      "Jérémie 18:3"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h70 אֹבֶן ʾōḇen siège d'accouchement, pierres sur lesquelles la femme s'accroupissait pour accoucher. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Siège d'accouchement",
    "etymologie": "Dérivé duel de אֶבֶן (H0068, « pierre »), littéralement « les deux pierres ».",
    "formes_derivees": [
      "H68"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 1:16",
      "texte": "Quand vous accoucherez les femmes hébraïques, observez les deux > pierres."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme duel אָבְנָיִם désigne deux dispositifs distincts mais structurellement analogues : le siège d'accouchement et le tour de potier. Le trait commun est la présence de deux pierres ou plateformes parallèles. Le siège d'accouchement (Exode 1:16) correspond à une pratique obstétrique attestée dans l'Égypte ancienne : la parturiente s'accroupissait…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200065,
    "strong": "H71",
    "langue": "hebreu",
    "numero": 71,
    "mot_original": "אֲבָנָה",
    "translitteration": "ʾăḇānāh",
    "prononciation": "ʾăḇānāh",
    "definition": "Abana, rivière de Damas mentionnée par Naaman.",
    "categorie": "Noms propres bibliques",
    "references": [
      "2 Rois 5:12"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h71 אֲבָנָה ʾăḇānāh abana, rivière de damas mentionnée par naaman. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abana",
    "etymologie": "Nom de fleuve d'origine araméenne ou syrienne.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Rois 5:12",
      "texte": "L\\'Abana et le Parpar, fleuves de Damas, ne valent-ils pas mieux > que toutes les eaux d\\'Israël ?"
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "araméen",
      "nom propre",
      "personnage"
    ],
    "notes": "L'Abana est traditionnellement identifié au Barada, le principal cours d'eau de Damas. Le Barada descend de l'Anti Liban, traverse Damas en se divisant en canaux d'irrigation, et alimente l'oasis de la Ghouta qui fit la réputation agricole de Damas depuis l'Antiquité. La mention du fleuve par Naaman reflète le chauvinisme…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200066,
    "strong": "H72",
    "langue": "hebreu",
    "numero": 72,
    "mot_original": "אֶבֶן הָעֵזֶר",
    "translitteration": "ʾeḇen hāʿēzer",
    "prononciation": "ʾeḇen hāʿēzer",
    "definition": "Eben-Ezer, « pierre du secours ». Nom commémoratif donné par Samuel à un lieu de victoire contre les Philistins.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Samuel 7:12"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 3,
    "recherche": "h72 אֶבֶן הָעֵזֶר ʾeḇen hāʿēzer eben-ezer, « pierre du secours ». nom commémoratif donné par samuel à un lieu de victoire contre les philistins. nom propre (toponyme composé)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Eben Ezer",
    "etymologie": "Composé de אֶבֶן (H0068, « pierre ») + עֵזֶר (H5828, « secours, aide ») avec article défini.",
    "formes_derivees": [
      "H68",
      "H5828"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 7:12",
      "texte": "Samuel prit une pierre et la plaça entre Mitspa et Shen ; il > l\\'appela Eben-Ezer, disant : Jusqu\\'ici YHWH nous a secourus."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Eben Ezer est le théâtre de deux affrontements majeurs avec les Philistins. La première bataille (1 Samuel 4) se solde par une défaite israélite cuisante et la capture de l'arche d'alliance. La seconde (1 Samuel 7), sous la direction de Samuel, voit la déroute des Philistins et leur refoulement durable.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200067,
    "strong": "H73",
    "langue": "hebreu",
    "numero": 73,
    "mot_original": "אַבְנֵט",
    "translitteration": "ʾaḇnēṭ",
    "prononciation": "ʾaḇnēṭ",
    "definition": "Ceinture, écharpe, baudrier sacerdotal.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 28:4"
    ],
    "type": "nom commun",
    "occurrences": 9,
    "recherche": "h73 אַבְנֵט ʾaḇnēṭ ceinture, écharpe, baudrier sacerdotal. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ceinture",
    "etymologie": "Mot d'origine non sémitique, probablement un emprunt.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 28:4",
      "texte": "Voici les vêtements qu\\'ils feront : pectoral, éphod, robe, tunique > brodée, turban et ceinture."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'abnēṭ est un élément distinctif du costume sacerdotal aaronide. Il s'agit d'une longue bande d'étoffe portée à la taille, probablement enroulée plusieurs fois autour du corps, confectionnée en lin fin retors et brodée de fils de couleur (pourpre violette, pourpre écarlate, cramoisi) selon Exode 39:29. La ceinture maintient la tunique…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200068,
    "strong": "H74",
    "langue": "hebreu",
    "numero": 74,
    "mot_original": "אַבְנֵר",
    "translitteration": "ʾaḇnēr",
    "prononciation": "ʾaḇnēr",
    "definition": "Abner, « mon père est lampe » ou « père de la lumière ».",
    "categorie": "Lumière et ténèbres",
    "references": [
      "1 Samuel 14:50"
    ],
    "type": "nom propre",
    "occurrences": 62,
    "recherche": "h74 אַבְנֵר ʾaḇnēr abner, « mon père est lampe » ou « père de la lumière ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abner",
    "etymologie": "Forme contractée de אֲבִינֵר, composé de אָב (H0001, « père ») + נֵר (H5216, « lampe ») avec suffixe pronominal 1ère personne.",
    "formes_derivees": [
      "H1",
      "H5216"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 14:50",
      "texte": "Le nom de la femme de Saül était Ahinoam, fille d\\'Ahimaats. Le nom > du chef de son armée était Abner, fils de Ner, oncle de Saül."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abner ben Ner est une figure militaire majeure du cycle de Saül et du début du règne de David. Commandant de l'armée de Saül, il est le protecteur de la dynastie saülide après la mort du roi à Guilboa. Il proclame Ish Bosheth, fils survivant de Saül, roi d'Israël à…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200069,
    "strong": "H75",
    "langue": "hebreu",
    "numero": 75,
    "mot_original": "אָבַס",
    "translitteration": "ʾāḇas",
    "prononciation": "ʾāḇas",
    "definition": "Engraisser, nourrir abondamment le bétail à l'étable.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Proverbes 15:17"
    ],
    "type": "verbe",
    "occurrences": 2,
    "recherche": "h75 אָבַס ʾāḇas engraisser, nourrir abondamment le bétail à l'étable. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Engraisser",
    "etymologie": "Racine sémitique ʾBS liée à l'alimentation animale. Akkadien : abāsu (engraisser) Syriaque : ܐܒܣ (ʾeḇas, « engraisser ») Arabe : ʾabasa (rassembler le bétail pour l'engraisser)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Proverbes 15:17",
      "texte": "Mieux vaut un plat de légumes avec de l\\'amour qu\\'un bœuf > engraissé avec de la haine."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe décrit la pratique de l'engraissement du bétail à l'auge, attestée dans les économies agro pastorales du Proche Orient. Le « bœuf engraissé » (שׁוֹר אָבוּס) est un animal de boucherie de qualité supérieure, réservé pour les occasions festives. Le contraste sapientiel entre le bœuf engraissé et le plat…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200070,
    "strong": "H76",
    "langue": "hebreu",
    "numero": 76,
    "mot_original": "אֲבַעְבֻּעָה",
    "translitteration": "ʾăḇaʿbuʿāh",
    "prononciation": "ʾăḇaʿbuʿāh",
    "definition": "Pustule, ampoule, vésicule cutanée (sixième plaie d'Égypte).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 9:9"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h76 אֲבַעְבֻּעָה ʾăḇaʿbuʿāh pustule, ampoule, vésicule cutanée (sixième plaie d'égypte). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Pustule",
    "etymologie": "Dérivé par redoublement de la racine בוע (BWʿ, « bouillonner, jaillir »), précédée du aleph prosthétique.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 9:9",
      "texte": "Elle deviendra une poussière sur tout le pays d\\'Égypte, et elle > produira sur les hommes et sur les bêtes des ulcères bourgeonnant en > pustules."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La sixième plaie d'Égypte consiste en furoncles purulents affectant hommes et bétail. Le récit précise que Moïse jette de la suie de fournaise vers le ciel, et que celle ci se transforme en poussière produisant les pustules. La terminologie אֲבַעְבֻּעֹת, avec son redoublement consonantique, suggère des lésions cutanées gonflées et…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200071,
    "strong": "H77",
    "langue": "hebreu",
    "numero": 77,
    "mot_original": "אֶבֶץ",
    "translitteration": "ʾeḇeṣ",
    "prononciation": "ʾeḇeṣ",
    "definition": "Ébets, ville de la tribu d'Issachar.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Josué 19:20"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h77 אֶבֶץ ʾeḇeṣ ébets, ville de la tribu d'issachar. nom propre (toponyme)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ébets",
    "etymologie": "Nom de lieu d'origine incertaine.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Josué 19:20",
      "texte": "Harabbith, Qishyôn et Ébets."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Ébets figure dans la liste des villes de la tribu d'Issachar (Josué 19:17 23). Le territoire d'Issachar s'étendait dans la vallée de Jezréel et les collines adjacentes, région fertile propice à l'agriculture. La localisation exacte d'Ébets n'est pas identifiée archéologiquement. La liste de Josué 19 appartient au système de géographie…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200072,
    "strong": "H78",
    "langue": "hebreu",
    "numero": 78,
    "mot_original": "אִבְצָן",
    "translitteration": "ʾiḇṣān",
    "prononciation": "ʾiḇṣān",
    "definition": "Ibtsan, juge d'Israël originaire de Bethléem.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Juges 12:8"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h78 אִבְצָן ʾiḇṣān ibtsan, juge d'israël originaire de bethléem. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ibtsan",
    "etymologie": "Nom d'origine incertaine.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Juges 12:8",
      "texte": "Après lui, Ibtsan de Bethléem jugea Israël."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ibtsan est l'un des juges dits « mineurs » dont le livre des Juges ne rapporte que des notices biographiques sommaires. Il succède à Jephté et précède Élôn. La notice indique qu'il eut trente fils et trente filles, marque de prospérité et de statut social. Le Bethléem mentionné est probablement…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200073,
    "strong": "H79",
    "langue": "hebreu",
    "numero": 79,
    "mot_original": "אַבְשַׁי",
    "translitteration": "ʾaḇšay",
    "prononciation": "ʾaḇšay",
    "definition": "Abshaï, variante abrégée de Abishaï (H0052).",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 11:20"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h79 אַבְשַׁי ʾaḇšay abshaï, variante abrégée de abishaï (h0052). nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abshaï",
    "etymologie": "Forme contractée de אֲבִישַׁי (H0052).",
    "formes_derivees": [
      "H52"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 11:20",
      "texte": "Abshaï, frère de Joab, était le chef des Trois."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Voir H0052 pour les notes contextuelles sur Abishaï/Abshaï. La forme abrégée אַבְשַׁי est caractéristique de l'orthographe du Chroniste, qui tend à simplifier certains noms composés. Le phénomène d'abréviation onomastique est bien documenté dans l'épigraphie hébraïque (sceaux, ostraca, inscriptions).",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200074,
    "strong": "H80",
    "langue": "hebreu",
    "numero": 80,
    "mot_original": "אָבָק",
    "translitteration": "ʾāḇāq",
    "prononciation": "ʾāḇāq",
    "definition": "Poussière fine, poudre impalpable.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 28:24",
      "Ésaïe 29:5"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h80 אָבָק ʾāḇāq poussière fine, poudre impalpable. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Poussière fine",
    "etymologie": "Racine sémitique ʾBQ signifiant « être fin, pulvérulent ». Syriaque : ܐܒܩܐ (ʾaḇqā, « poussière ») Arabe : ʾabaqa (être fin, poudreux)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 28:24",
      "texte": "YHWH donnera à ton pays, au lieu de pluie, de la poussière et de la > poudre."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme אָבָק désigne une poussière extrêmement fine, plus subtile que עָפָר (poussière ordinaire, terre sèche). La distinction est marquée en Deutéronome 28:24 où les deux termes sont juxtaposés pour décrire une sécheresse absolue. En Ésaïe 29:5, la poussière fine symbolise la fragilité et l'inconsistance des ennemis face à l'intervention…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200075,
    "strong": "H81",
    "langue": "hebreu",
    "numero": 81,
    "mot_original": "אֲבָקָה",
    "translitteration": "ʾăḇāqāh",
    "prononciation": "ʾăḇāqāh",
    "definition": "Poudre aromatique, parfum en poudre.",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h81 אֲבָקָה ʾăḇāqāh poudre aromatique, parfum en poudre. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Poudre aromatique",
    "etymologie": "Dérivé féminin de אָבָק (H0080, « poussière fine »), spécialisé pour désigner une poudre parfumée.",
    "formes_derivees": [
      "H80"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Cantique des Cantiques 3:6",
      "texte": "Qui est celle qui monte du désert comme des colonnes de fumée, > parfumée de myrrhe et d\\'encens, de toutes les poudres du marchand ? >"
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La poudre aromatique du marchand (אַבְקַת רוֹכֵל) désigne les mélanges parfumés commercialisés par les négociants itinérants. Le commerce des aromates (myrrhe, encens, nard, cannelle) transitait par les routes caravanières de la péninsule arabique (la « route de l'encens ») vers le Levant et la Méditerranée. Dans le Cantique des Cantiques,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200076,
    "strong": "H82",
    "langue": "hebreu",
    "numero": 82,
    "mot_original": "אָבַר",
    "translitteration": "ʾāḇar",
    "prononciation": "ʾāḇar",
    "definition": "Sens incertain. Possible « planer, voler » ou « être fort, puissant ».",
    "categorie": "Vocabulaire courant",
    "references": [
      "Job 39:26"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h82 אָבַר ʾāḇar sens incertain. possible « planer, voler » ou « être fort, puissant ». verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Sens incertain",
    "etymologie": "Racine sémitique ʾBR avec deux acceptions possibles : 1. Voler, planer (arabe : ʾabara, « voler » ; syriaque : ܐܒܪ (ʾeḇar, « aile »)) 2. Être fort (hébreu אַבִּיר H0047, « puissant »)",
    "formes_derivees": [
      "H47"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Job 39:26",
      "texte": "Est-ce par ton intelligence que le faucon prend son essor, qu\\'il > déploie ses ailes vers le sud ?"
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe est d'occurrence trop rare pour établir un contexte d'usage. La racine apparentée en syriaque et en arabe suggère un lien avec le vol et le plumage des oiseaux. Le passage de Job 39 fait partie du discours divin énumérant les phénomènes naturels échappant à la compréhension humaine :…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200077,
    "strong": "H83",
    "langue": "hebreu",
    "numero": 83,
    "mot_original": "אֵבֶר",
    "translitteration": "ʾēḇer",
    "prononciation": "ʾēḇer",
    "definition": "Aile, penne, rémige (plume de l'aile).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Psaume 55:7",
      "Ézéchiel 17:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h83 אֵבֶר ʾēḇer aile, penne, rémige (plume de l'aile). nom commun",
    "audio": "",
    "image": null,
    "racine": "H82",
    "sens_principal": "Aile",
    "etymologie": "Dérivé nominal de la racine אָבַר (H0082, « voler, planer »). Syriaque : ܐܒܪܐ (ʾeḇrā, « aile, plume ») Arabe : ʾibratun (plume)",
    "formes_derivees": [
      "H82"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Psaume 55:7",
      "texte": "Je dis : Qui me donnera les ailes de la colombe ?"
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme אֵבֶר désigne spécifiquement les longues plumes de l'aile (rémiges), par opposition à כָּנָף (aile entière) ou נוֹצָה (plume en général). En Ézéchiel 17:3, l'aigle « aux longues pennes » symbolise Nabuchodonosor, dans une allégorie politique utilisant le bestiaire impérial babylonien. Le souhait du psalmiste d'avoir « les ailes…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200078,
    "strong": "H84",
    "langue": "hebreu",
    "numero": 84,
    "mot_original": "אֶבְרָה",
    "translitteration": "ʾeḇrāh",
    "prononciation": "ʾeḇrāh",
    "definition": "Penne, aile, plumage (forme féminine de H0083).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 32:11",
      "Psaume 91:4"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h84 אֶבְרָה ʾeḇrāh penne, aile, plumage (forme féminine de h0083). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Penne",
    "etymologie": "Forme féminine de אֵבֶר (H0083, « aile, penne »).",
    "formes_derivees": [
      "H83"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 32:11",
      "texte": "Comme un aigle qui éveille sa couvée, plane sur ses petits, déploie > ses ailes, les prend, les porte sur ses pennes."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'image de l'aigle portant ses petits sur ses pennes (Deutéronome 32:11) est une métaphore de la protection divine lors de la sortie d'Égypte. L'observation naturaliste sous jacente (l'aigle encourageant ses aiglons à voler puis les rattrapant) est attestée dans la littérature proche orientale. Le Psaume 91 utilise la même image…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200079,
    "strong": "H85",
    "langue": "hebreu",
    "numero": 85,
    "mot_original": "אַבְרָהָם",
    "translitteration": "ʾaḇrāhām",
    "prononciation": "ʾaḇrāhām",
    "definition": "Abraham, « père d'une multitude » ou « père élevé ». Patriarche fondateur d'Israël.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 17:5"
    ],
    "type": "nom propre",
    "occurrences": 175,
    "recherche": "h85 אַבְרָהָם ʾaḇrāhām abraham, « père d'une multitude » ou « père élevé ». patriarche fondateur d'israël. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abraham",
    "etymologie": "Forme élargie de אַבְרָם (H0087). Le changement de nom est présenté en Genèse 17:5 comme signifiant « père d'une multitude de nations » (אַב־הֲמוֹן גּוֹיִם).",
    "formes_derivees": [
      "H87"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 17:5",
      "texte": "On ne t\\'appellera plus Abram, mais ton nom sera Abraham, car je te > fais père d\\'une multitude de nations."
    },
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abraham est présenté dans la Genèse comme un migrant originaire d'Ur en Mésopotamie, ayant transité par Harran avant de s'établir en Canaan. Les récits patriarcaux le décrivent comme un éleveur semi nomade possédant troupeaux, or et serviteurs, en relation avec les cités États cananéennes (Sichem, Hébron, Guérar) et les puissances…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200080,
    "strong": "H86",
    "langue": "hebreu",
    "numero": 86,
    "mot_original": "אַבְרֵךְ",
    "translitteration": "ʾaḇrēḵ",
    "prononciation": "ʾaḇrēḵ",
    "definition": "À genoux ! Prosternez-vous ! Cri acclamant la dignité de Joseph comme vizir d'Égypte.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 41:43"
    ],
    "type": "interjection ou titre",
    "occurrences": 1,
    "recherche": "h86 אַבְרֵךְ ʾaḇrēḵ à genoux ! prosternez-vous ! cri acclamant la dignité de joseph comme vizir d'égypte. interjection ou titre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "À genoux ! Prosternez vous !",
    "etymologie": "Origine incertaine. Probablement un emprunt à une langue étrangère.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 41:43",
      "texte": "Il le fit monter sur le second char du royaume ; on criait devant > lui : Avrêkh !"
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "interjection"
    ],
    "notes": "Le terme apparaît dans le cérémonial d'intronisation de Joseph comme vizir d'Égypte. Le héraut précède le char pour annoncer la dignité du nouveau fonctionnaire. Le protocole de la cour égyptienne exigeait la prosternation devant les hauts dignitaires et le souverain. L'hypothèse akkadienne (abarakku) est appuyée par la documentation mésopotamienne où…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Interjection"
  },
  {
    "id": 200081,
    "strong": "H87",
    "langue": "hebreu",
    "numero": 87,
    "mot_original": "אַבְרָם",
    "translitteration": "ʾaḇrām",
    "prononciation": "ʾaḇrām",
    "definition": "Abram, « le père (divin) est élevé » ou « père élevé ». Nom originel d'Abraham.",
    "categorie": "Noms de Dieu",
    "references": [
      "Genèse 11:27"
    ],
    "type": "nom propre",
    "occurrences": 61,
    "recherche": "h87 אַבְרָם ʾaḇrām abram, « le père (divin) est élevé » ou « père élevé ». nom originel d'abraham. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abram",
    "etymologie": "Composé de אָב (H0001, « père ») + רוּם (H7311, « être élevé, exalté »), probablement avec le sens « le père (divin) est exalté ».",
    "formes_derivees": [
      "H1",
      "H7311"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 11:27",
      "texte": "Abram engendra Lot."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Abram est le nom porté par le patriarche de sa naissance à Ur jusqu'à l'âge de 99 ans. La narration sacerdotale (Genèse 17) marque la transition d'Abram à Abraham comme l'instant de l'institution de la circoncision et de la promesse de descendance universelle. La distinction des noms Abram/Abraham structure la…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200082,
    "strong": "H88",
    "langue": "hebreu",
    "numero": 88,
    "mot_original": "אַבְשָׁלוֹם",
    "translitteration": "ʾaḇšālôm",
    "prononciation": "ʾaḇšālôm",
    "definition": "Absalom, « père de la paix » ou « mon père est paix ».",
    "categorie": "Paix",
    "references": [
      "2 Samuel 14:25"
    ],
    "type": "nom propre",
    "occurrences": 86,
    "recherche": "h88 אַבְשָׁלוֹם ʾaḇšālôm absalom, « père de la paix » ou « mon père est paix ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Absalom",
    "etymologie": "Forme contractée de אֲבִישָׁלוֹם (H0053), composé de אָב (H0001, « père ») + שָׁלוֹם (H7965, « paix »).",
    "formes_derivees": [
      "H1",
      "H53",
      "H7965"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 14:25",
      "texte": "Il n\\'y avait pas dans tout Israël un homme aussi beau qu\\'Absalom, > si digne de louange."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Absalom est le fils de David et de Maaka, fille de Talmaï roi de Geshur (petit royaume araméen au nord est du lac de Galilée). Sa carrière politique illustre les tensions successorales dans la monarchie davidique. Après le viol de sa sœur Tamar par Amnon, Absalom fait assassiner ce dernier…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200083,
    "strong": "H89",
    "langue": "hebreu",
    "numero": 89,
    "mot_original": "אֲבִישַׁלֹם",
    "translitteration": "ʾăḇîšālōm",
    "prononciation": "ʾăḇîšālōm",
    "definition": "Abishalom, variante pleine de Absalom (H0088). Voir H0053.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 15:2"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h89 אֲבִישַׁלֹם ʾăḇîšālōm abishalom, variante pleine de absalom (h0088). voir h0053. nom propre",
    "audio": "",
    "image": null,
    "racine": "H53",
    "sens_principal": "Abishalom",
    "etymologie": "Voir H0053 et H0088.",
    "formes_derivees": [
      "H53",
      "H88"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 15:2",
      "texte": "Il régna trois ans à Jérusalem. Le nom de sa mère était Maaka, > fille d\\'Abishalom."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Voir H0053 pour les notes contextuelles. Cette entrée est un doublet de H0053 dans la classification Strong. La distinction entre H0053 (אֲבִישָׁלוֹם) et H0089 (אֲבִישָׁלֹם) repose sur une variation orthographique mineure (plene vs. defective scriptio pour la voyelle ô). Les deux entrées désignent le même nom et probablement le même…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200084,
    "strong": "H90",
    "langue": "hebreu",
    "numero": 90,
    "mot_original": "אֶבְיָתָר",
    "translitteration": "ʾeḇyāṯār",
    "prononciation": "ʾeḇyāṯār",
    "definition": "Ébyatar. Voir H0054.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Samuel 22:20"
    ],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h90 אֶבְיָתָר ʾeḇyāṯār ébyatar. voir h0054. nom propre",
    "audio": "",
    "image": null,
    "racine": "H54",
    "sens_principal": "Ébyatar",
    "etymologie": "Voir H0054.",
    "formes_derivees": [
      "H54"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 22:20",
      "texte": "Un fils d\\'Ahimélek, fils d\\'Ahitub, s\\'échappa. Son nom était > Ébyatar."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Cette entrée Strong (H0090) est un doublet de H0054 (אֶבְיָתָר). La classification Strong attribue parfois deux numéros distincts à un même mot lorsque la forme est identique mais que l'occurrence ou la vocalisation varie. Pour les notes contextuelles complètes, voir H0054.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200085,
    "strong": "H91",
    "langue": "hebreu",
    "numero": 91,
    "mot_original": "אֲגָגִי",
    "translitteration": "ʾăḡāḡî",
    "prononciation": "ʾăḡāḡî",
    "definition": "Agaguite, descendant ou sujet d'Agag, roi amalécite.",
    "categorie": "Royaume",
    "references": [
      "Esther 3:1"
    ],
    "type": "adjectif gentilé / nom propre",
    "occurrences": 5,
    "recherche": "h91 אֲגָגִי ʾăḡāḡî agaguite, descendant ou sujet d'agag, roi amalécite. adjectif gentilé / nom propre",
    "audio": "",
    "image": null,
    "racine": "H90",
    "sens_principal": "Agaguite",
    "etymologie": "Gentilé dérivé de אֲגָג (H0090, Agag), roi d'Amalek vaincu par Saül (1 Samuel 15).",
    "formes_derivees": [
      "H90"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Esther 3:1",
      "texte": "Après ces choses, le roi Assuérus éleva Haman, fils de Hammedatha, > l\\'Agaguite."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "L'identification de Haman comme « Agaguite » est un élément narratif majeur du livre d'Esther. Agag est le roi amalécite épargné par Saül contre l'ordre divin, puis exécuté par Samuel (1 Samuel 15). Les Amalécites sont présentés dans le Pentateuque comme l'ennemi héréditaire d'Israël (Exode 17:8 16 ; Deutéronome 25:17…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200086,
    "strong": "H92",
    "langue": "hebreu",
    "numero": 92,
    "mot_original": "אֲגֻדָּה",
    "translitteration": "ʾăḡuddāh",
    "prononciation": "ʾăḡuddāh",
    "definition": "Bande, faisceau, lien, groupe lié.",
    "categorie": "Eau et baptême",
    "references": [
      "Exode 12:22",
      "Job 38:31"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h92 אֲגֻדָּה ʾăḡuddāh bande, faisceau, lien, groupe lié. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Bande",
    "etymologie": "Dérivé nominal féminin de la racine אגד (ʾGD, « lier, attacher »). Syriaque : ܐܓܕܐ (ʾeḡdā, « faisceau, lien ») Arabe : ʾajada (lier solidement)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 12:22",
      "texte": "Vous prendrez un bouquet d\\'hysope, vous le tremperez dans le sang. >"
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme décrit des objets formés par ligature. Le bouquet d'hysope (Exode 12:22) est un faisceau de branches liées utilisé pour l'aspersion du sang de l'agneau pascal sur les linteaux et les montants des portes, rite apotropaïque marquant la première Pâque. En Ésaïe 58:6, le jeûne authentique consiste à «…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200087,
    "strong": "H93",
    "langue": "hebreu",
    "numero": 93,
    "mot_original": "אֱגוֹז",
    "translitteration": "ʾĕḡôz",
    "prononciation": "ʾĕḡôz",
    "definition": "Noix, fruit du noyer (Juglans regia).",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h93 אֱגוֹז ʾĕḡôz noix, fruit du noyer (juglans regia). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Noix",
    "etymologie": "Mot sémitique commun. Syriaque : ܐܓܘܙܐ (ʾeḡōzā, « noix ») Arabe : ǧawz Persan : gawz",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Cantique des Cantiques 6:11",
      "texte": "Je suis descendu au jardin des noix."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le noyer est mentionné une seule fois dans la Bible hébraïque, dans le Cantique des Cantiques. Le « jardin des noix » (גִּנַּת אֱגוֹז) est le lieu de la rencontre amoureuse, symbole de fertilité et d'intimité. Le noyer, arbre à feuillage dense et à fruits protégés par une coque, est…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200088,
    "strong": "H94",
    "langue": "hebreu",
    "numero": 94,
    "mot_original": "אָגוּר",
    "translitteration": "ʾāḡûr",
    "prononciation": "ʾāḡûr",
    "definition": "Agur, nom du sage auteur du chapitre 30 des Proverbes.",
    "categorie": "Sagesse et connaissance",
    "references": [
      "Proverbes 30:1"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h94 אָגוּר ʾāḡûr agur, nom du sage auteur du chapitre 30 des proverbes. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Agur",
    "etymologie": "Nom d'origine incertaine.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Proverbes 30:1",
      "texte": "Paroles d\\'Agur, fils de Yaqé, de Massa."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Agur est présenté comme l'auteur du chapitre 30 des Proverbes. Le titre l'identifie comme « fils de Yaqé, de Massa ». Massa est une tribu nord arabique mentionnée parmi les descendants d'Ismaël (Genèse 25:14). Cette origine non israélite est remarquable dans le corpus sapientiel biblique. Les paroles d'Agur (Proverbes 30)…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200089,
    "strong": "H95",
    "langue": "hebreu",
    "numero": 95,
    "mot_original": "אֲגוֹרָה",
    "translitteration": "ʾăḡôrāh",
    "prononciation": "ʾăḡôrāh",
    "definition": "Pièce d'argent, petite monnaie, pourboire.",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Samuel 2:36"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h95 אֲגוֹרָה ʾăḡôrāh pièce d'argent, petite monnaie, pourboire. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Pièce d'argent",
    "etymologie": "Dérivé de la racine אגר (ʾGR, « collecter, rassembler »), d'où « ce qui est collecté, salaire ».",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 2:36",
      "texte": "Il dira : Attache-moi, je te prie, à l\\'une des fonctions sacerdotales, pour que j\\'aie un morceau de pain à manger."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme apparaît dans l'oracle de jugement contre la maison d'Éli (1 Samuel 2:31 36). Les descendants d'Éli, déchus du sacerdoce, viendront mendier une pièce d'argent (אֲגוֹרָה) et un morceau de pain auprès du prêtre légitime. L'agorah représente le plus petit montant monétaire, symbole de la déchéance économique des Élides.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200090,
    "strong": "H96",
    "langue": "hebreu",
    "numero": 96,
    "mot_original": "אֶגֶל",
    "translitteration": "ʾeḡel",
    "prononciation": "ʾeḡel",
    "definition": "Goutte, réserve d'eau. Variante poétique ou régionale de עֵגֶל (H5695, « veau ») ou mot distinct.",
    "categorie": "Eau et baptême",
    "references": [
      "Job 38:28"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h96 אֶגֶל ʾeḡel goutte, réserve d'eau. variante poétique ou régionale de עֵגֶל (h5695, « veau ») ou mot distinct. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Goutte",
    "etymologie": "Sens incertain. Probablement à distinguer de עֵגֶל (veau).",
    "formes_derivees": [
      "H5695"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Job 38:28",
      "texte": "La pluie a-t-elle un père ? Qui engendre les gouttes de rosée ?"
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme apparaît dans le discours divin à Job, dans une série de questions rhétoriques sur les phénomènes météorologiques. L'image des « gouttes de rosée » (אֶגְלֵי־טָל) personnifiées comme des enfants dont Dieu serait le géniteur appartient au genre poétique des théophanies de la tempête. La forme avec aleph initial…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200091,
    "strong": "H97",
    "langue": "hebreu",
    "numero": 97,
    "mot_original": "אֶגְלַיִם",
    "translitteration": "ʾeḡlayim",
    "prononciation": "ʾeḡlayim",
    "definition": "Églaïm, localité près de la mer Morte.",
    "categorie": "Mort et vie",
    "references": [
      "Ézéchiel 47:10"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h97 אֶגְלַיִם ʾeḡlayim églaïm, localité près de la mer morte. nom propre (toponyme)",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Églaïm",
    "etymologie": "Forme duelle de אֶגֶל (H0096, « goutte » ?) ou de עֵגֶל (veau).",
    "formes_derivees": [
      "H96"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ézéchiel 47:10",
      "texte": "Des pêcheurs se tiendront sur ses bords ; depuis En-Guédi jusqu\\'à > En-Églaïm."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "En Églaïm est mentionnée avec En Guédi comme les deux points extrêmes de la rive fertile de la mer Morte dans la vision eschatologique d'Ézéchiel 47. Le fleuve sortant du Temple transforme les eaux salées de la mer Morte en eau douce, permettant la pêche. Le toponyme « En Églaïm…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200092,
    "strong": "H98",
    "langue": "hebreu",
    "numero": 98,
    "mot_original": "אֲגַם",
    "translitteration": "ʾăḡam",
    "prononciation": "ʾăḡam",
    "definition": "Marais, étang, mare d'eau stagnante.",
    "categorie": "Eau et baptême",
    "references": [
      "Exode 7:19"
    ],
    "type": "nom commun",
    "occurrences": 9,
    "recherche": "h98 אֲגַם ʾăḡam marais, étang, mare d'eau stagnante. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Marais",
    "etymologie": "Racine sémitique ʾGM. Arabe : ʾaǧama (fourré, jungle, marais) Syriaque : ܐܓܡܐ (ʾaḡmā, « marais ») Akkadien : agammu (marais, lagune)",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 7:19",
      "texte": "YHWH dit à Moïse : Dis à Aaron : Prends ton bâton, étends ta main > sur les eaux de l\\'Égypte, sur leurs fleuves, sur leurs canaux, sur > leurs marais."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme désigne des étendues d'eau peu profondes et stagnantes, par opposition aux fleuves et rivières courantes. En Égypte, les agammîm sont les marais du Delta du Nil, écosystème riche en faune aquatique et en végétation palustre (papyrus, roseaux). Dans la littérature prophétique, le dessèchement des marais est un signe…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200093,
    "strong": "H99",
    "langue": "hebreu",
    "numero": 99,
    "mot_original": "אָגֵם",
    "translitteration": "ʾāḡēm",
    "prononciation": "ʾāḡēm",
    "definition": "Triste, affligé, abattu.",
    "categorie": "Deuil et lamentation",
    "references": [],
    "type": "adjectif",
    "occurrences": 1,
    "recherche": "h99 אָגֵם ʾāḡēm triste, affligé, abattu. adjectif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Triste",
    "etymologie": "D'origine incertaine.",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Proverbes 31:6",
      "texte": "Donnez de la boisson forte à celui qui périt, et du vin à ceux qui > ont l\\'amertume dans l\\'âme."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Le terme est d'attestation trop rare pour une analyse contextuelle détaillée. Le contexte de Proverbes 31:6 7 évoque la coutume de donner des boissons fortes aux personnes en détresse ou aux condamnés à mort, pratique documentée dans le Proche Orient ancien et le monde gréco romain.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200094,
    "strong": "H100",
    "langue": "hebreu",
    "numero": 100,
    "mot_original": "אַגְמוֹן",
    "translitteration": "ʾaḡmôn",
    "prononciation": "ʾaḡmôn",
    "definition": "Jonc, roseau ; métaphoriquement : crochet, hameçon.",
    "categorie": "Eau et baptême",
    "references": [
      "Job 40:26",
      "Ésaïe 58:5"
    ],
    "type": "nom commun",
    "occurrences": 5,
    "recherche": "h100 אַגְמוֹן ʾaḡmôn jonc, roseau ; métaphoriquement : crochet, hameçon. nom commun",
    "audio": "",
    "image": null,
    "racine": "H98",
    "sens_principal": "Jonc",
    "etymologie": "Dérivé de אֲגַם (H0098, « marais ») avec suffixe ôn, littéralement « plante de marais ». Syriaque : ܐܓܡܘܢܐ (ʾaḡmônā, « jonc, roseau »)",
    "formes_derivees": [
      "H98"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Job 40:26",
      "texte": "Lui passeras-tu un jonc dans les narines ?"
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le jonc est une plante caractéristique des zones marécageuses du Proche Orient. Sa tige flexible était utilisée pour la vannerie, la fabrication de cordes, et comme matériau d'écriture (calame). En Job 40:26, le terme désigne un instrument pour percer et maîtriser le crocodile (Léviathan), parallèle aux harpons de pêche nilotiques.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200285,
    "strong": "H101",
    "langue": "hebreu",
    "numero": 101,
    "mot_original": "אַגָּן",
    "translitteration": "ʾaggān",
    "prononciation": "ʾaggān",
    "definition": "Coupe, bassin, bol à libation.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 24:6",
      "Cantique des Cantiques 7:2"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h101 אַגָּן ʾaggān coupe, bassin, bol à libation.",
    "audio": "",
    "image": null
  },
  {
    "id": 200286,
    "strong": "H102",
    "langue": "hebreu",
    "numero": 102,
    "mot_original": "אֲגַף",
    "translitteration": "ʾăḡap̄",
    "prononciation": "ʾăḡap̄",
    "definition": "Aile, flanc ; corps de troupes, bande armée.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ézéchiel 12:14"
    ],
    "type": "",
    "occurrences": 7,
    "recherche": "h102 אֲגַף ʾăḡap̄ aile, flanc ; corps de troupes, bande armée.",
    "audio": "",
    "image": null
  },
  {
    "id": 200287,
    "strong": "H103",
    "langue": "hebreu",
    "numero": 103,
    "mot_original": "אָגַר",
    "translitteration": "ʾāḡar",
    "prononciation": "ʾāḡar",
    "definition": "Amasser, collecter, engranger.",
    "categorie": "Ange et messager",
    "references": [
      "Proverbes 6:8"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h103 אָגַר ʾāḡar amasser, collecter, engranger.",
    "audio": "",
    "image": null
  },
  {
    "id": 200288,
    "strong": "H104",
    "langue": "hebreu",
    "numero": 104,
    "mot_original": "אִגֶּרֶת",
    "translitteration": "ʾiggereṯ",
    "prononciation": "ʾiggereṯ",
    "definition": "Lettre, missive, document écrit.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Néhémie 2:8"
    ],
    "type": "",
    "occurrences": 10,
    "recherche": "h104 אִגֶּרֶת ʾiggereṯ lettre, missive, document écrit.",
    "audio": "",
    "image": null
  },
  {
    "id": 200289,
    "strong": "H105",
    "langue": "hebreu",
    "numero": 105,
    "mot_original": "אַגַרְטָל",
    "translitteration": "ʾăḡarṭāl",
    "prononciation": "ʾăḡarṭāl",
    "definition": "Bassin, cuvette, plat cultuel.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 1:9"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h105 אַגַרְטָל ʾăḡarṭāl bassin, cuvette, plat cultuel.",
    "audio": "",
    "image": null
  },
  {
    "id": 200290,
    "strong": "H106",
    "langue": "hebreu",
    "numero": 106,
    "mot_original": "אֶגְרֹף",
    "translitteration": "ʾeḡrōp̄",
    "prononciation": "ʾeḡrōp̄",
    "definition": "Poing fermé, main fermée.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 21:18",
      "Ésaïe 58:4"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h106 אֶגְרֹף ʾeḡrōp̄ poing fermé, main fermée.",
    "audio": "",
    "image": null
  },
  {
    "id": 200291,
    "strong": "H107",
    "langue": "hebreu",
    "numero": 107,
    "mot_original": "אִגֶּרֶת",
    "translitteration": "ʾiggereṯ",
    "prononciation": "ʾiggereṯ",
    "definition": "Lettre, missive. Doublet de H0104.",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "",
    "occurrences": 0,
    "recherche": "h107 אִגֶּרֶת ʾiggereṯ lettre, missive. doublet de h0104.",
    "audio": "",
    "image": null
  },
  {
    "id": 200292,
    "strong": "H108",
    "langue": "hebreu",
    "numero": 108,
    "mot_original": "אֵד",
    "translitteration": "ʾēḏ",
    "prononciation": "ʾēḏ",
    "definition": "Vapeur, brume, nuage de pluie.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 2:6",
      "Job 36:27"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h108 אֵד ʾēḏ vapeur, brume, nuage de pluie.",
    "audio": "",
    "image": null
  },
  {
    "id": 200293,
    "strong": "H109",
    "langue": "hebreu",
    "numero": 109,
    "mot_original": "אָדַב",
    "translitteration": "ʾāḏaḇ",
    "prononciation": "ʾāḏaḇ",
    "definition": "Languir, dépérir, être affligé.",
    "categorie": "Deuil et lamentation",
    "references": [
      "1 Samuel 2:33"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h109 אָדַב ʾāḏaḇ languir, dépérir, être affligé.",
    "audio": "",
    "image": null
  },
  {
    "id": 200294,
    "strong": "H110",
    "langue": "hebreu",
    "numero": 110,
    "mot_original": "אַדְבְּאֵל",
    "translitteration": "ʾaḏbəʾēl",
    "prononciation": "ʾaḏbəʾēl",
    "definition": "Adbéel, fils d'Ismaël.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 25:13"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h110 אַדְבְּאֵל ʾaḏbəʾēl adbéel, fils d'ismaël.",
    "audio": "",
    "image": null
  },
  {
    "id": 200295,
    "strong": "H111",
    "langue": "hebreu",
    "numero": 111,
    "mot_original": "אֲדַד",
    "translitteration": "ʾăḏaḏ",
    "prononciation": "ʾăḏaḏ",
    "definition": "Hadad, divinité cananéenne de l'orage et rois édomites.",
    "categorie": "Noms de Dieu",
    "references": [
      "Genèse 36:35"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h111 אֲדַד ʾăḏaḏ hadad, divinité cananéenne de l'orage et rois édomites.",
    "audio": "",
    "image": null
  },
  {
    "id": 200296,
    "strong": "H112",
    "langue": "hebreu",
    "numero": 112,
    "mot_original": "אִדּוֹ",
    "translitteration": "ʾiddô",
    "prononciation": "ʾiddô",
    "definition": "Iddo, plusieurs personnages bibliques.",
    "categorie": "Vocabulaire courant",
    "references": [
      "2 Chroniques 12:15"
    ],
    "type": "",
    "occurrences": 0,
    "recherche": "h112 אִדּוֹ ʾiddô iddo, plusieurs personnages bibliques.",
    "audio": "",
    "image": null
  },
  {
    "id": 200297,
    "strong": "H113",
    "langue": "hebreu",
    "numero": 113,
    "mot_original": "אָדוֹן",
    "translitteration": "ʾāḏôn",
    "prononciation": "ʾāḏôn",
    "definition": "Seigneur, maître, propriétaire, souverain.",
    "categorie": "Noms de Dieu",
    "references": [
      "Genèse 45:8",
      "Psaume 110:1"
    ],
    "type": "",
    "occurrences": 335,
    "recherche": "h113 אָדוֹן ʾāḏôn seigneur, maître, propriétaire, souverain.",
    "audio": "",
    "image": null
  },
  {
    "id": 200298,
    "strong": "H114",
    "langue": "hebreu",
    "numero": 114,
    "mot_original": "אַדּוֹן",
    "translitteration": "ʾaddôn",
    "prononciation": "ʾaddôn",
    "definition": "Addôn, localité babylonienne.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Néhémie 7:61"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h114 אַדּוֹן ʾaddôn addôn, localité babylonienne.",
    "audio": "",
    "image": null
  },
  {
    "id": 200299,
    "strong": "H115",
    "langue": "hebreu",
    "numero": 115,
    "mot_original": "אֲדוֹרַיִם",
    "translitteration": "ʾăḏôrayim",
    "prononciation": "ʾăḏôrayim",
    "definition": "Adoraïm, ville fortifiée de Juda.",
    "categorie": "Vocabulaire courant",
    "references": [
      "2 Chroniques 11:9"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h115 אֲדוֹרַיִם ʾăḏôrayim adoraïm, ville fortifiée de juda.",
    "audio": "",
    "image": null
  },
  {
    "id": 200300,
    "strong": "H116",
    "langue": "hebreu",
    "numero": 116,
    "mot_original": "אֱדַיִן",
    "translitteration": "ʾĕḏayin",
    "prononciation": "ʾĕḏayin",
    "definition": "Alors, ensuite, à ce moment-là.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 2:15"
    ],
    "type": "",
    "occurrences": 57,
    "recherche": "h116 אֱדַיִן ʾĕḏayin alors, ensuite, à ce moment-là.",
    "audio": "",
    "image": null
  },
  {
    "id": 200301,
    "strong": "H117",
    "langue": "hebreu",
    "numero": 117,
    "mot_original": "אַדִּיר",
    "translitteration": "ʾaddîr",
    "prononciation": "ʾaddîr",
    "definition": "Puissant, magnifique, majestueux, noble.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 15:11",
      "Psaume 8:2"
    ],
    "type": "",
    "occurrences": 27,
    "recherche": "h117 אַדִּיר ʾaddîr puissant, magnifique, majestueux, noble.",
    "audio": "",
    "image": null
  },
  {
    "id": 200302,
    "strong": "H118",
    "langue": "hebreu",
    "numero": 118,
    "mot_original": "אֲדַלְיָא",
    "translitteration": "ʾăḏalyāʾ",
    "prononciation": "ʾăḏalyāʾ",
    "definition": "Adalia, fils d'Haman.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esther 9:8"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h118 אֲדַלְיָא ʾăḏalyāʾ adalia, fils d'haman.",
    "audio": "",
    "image": null
  },
  {
    "id": 200303,
    "strong": "H119",
    "langue": "hebreu",
    "numero": 119,
    "mot_original": "אָדַם",
    "translitteration": "ʾāḏam",
    "prononciation": "ʾāḏam",
    "definition": "Être rouge, devenir rouge, rougir.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Lamentations 4:7"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h119 אָדַם ʾāḏam être rouge, devenir rouge, rougir.",
    "audio": "",
    "image": null
  },
  {
    "id": 200304,
    "strong": "H120",
    "langue": "hebreu",
    "numero": 120,
    "mot_original": "אָדָם",
    "translitteration": "ʾāḏām",
    "prononciation": "ʾāḏām",
    "definition": "Homme, être humain, humanité ; Adam.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 1:27",
      "Genèse 2:7",
      "Psaume 8:5"
    ],
    "type": "",
    "occurrences": 543,
    "recherche": "h120 אָדָם ʾāḏām homme, être humain, humanité ; adam.",
    "audio": "",
    "image": null
  },
  {
    "id": 200305,
    "strong": "H121",
    "langue": "hebreu",
    "numero": 121,
    "mot_original": "אָדָם",
    "translitteration": "ʾāḏām",
    "prononciation": "ʾāḏām",
    "definition": "Adam, nom du premier homme.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 5:1"
    ],
    "type": "",
    "occurrences": 34,
    "recherche": "h121 אָדָם ʾāḏām adam, nom du premier homme.",
    "audio": "",
    "image": null
  },
  {
    "id": 200306,
    "strong": "H122",
    "langue": "hebreu",
    "numero": 122,
    "mot_original": "אָדֹם",
    "translitteration": "ʾāḏōm",
    "prononciation": "ʾāḏōm",
    "definition": "Rouge, roux, vermeil.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 25:25",
      "Nombres 19:2"
    ],
    "type": "",
    "occurrences": 9,
    "recherche": "h122 אָדֹם ʾāḏōm rouge, roux, vermeil.",
    "audio": "",
    "image": null
  },
  {
    "id": 200307,
    "strong": "H123",
    "langue": "hebreu",
    "numero": 123,
    "mot_original": "אֱדוֹם",
    "translitteration": "ʾĕḏôm",
    "prononciation": "ʾĕḏôm",
    "definition": "Édom, peuple et territoire d'Ésaü.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 25:30"
    ],
    "type": "",
    "occurrences": 100,
    "recherche": "h123 אֱדוֹם ʾĕḏôm édom, peuple et territoire d'ésaü.",
    "audio": "",
    "image": null
  },
  {
    "id": 200308,
    "strong": "H124",
    "langue": "hebreu",
    "numero": 124,
    "mot_original": "אֹדֶם",
    "translitteration": "ʾōḏem",
    "prononciation": "ʾōḏem",
    "definition": "Rubis, escarboucle, pierre précieuse rouge.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 28:17"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h124 אֹדֶם ʾōḏem rubis, escarboucle, pierre précieuse rouge.",
    "audio": "",
    "image": null
  },
  {
    "id": 200309,
    "strong": "H125",
    "langue": "hebreu",
    "numero": 125,
    "mot_original": "אֲדַמְדָּם",
    "translitteration": "ʾăḏamḏām",
    "prononciation": "ʾăḏamḏām",
    "definition": "Rougeâtre, tirant sur le rouge.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Lévitique 13:19"
    ],
    "type": "",
    "occurrences": 6,
    "recherche": "h125 אֲדַמְדָּם ʾăḏamḏām rougeâtre, tirant sur le rouge.",
    "audio": "",
    "image": null
  },
  {
    "id": 200310,
    "strong": "H126",
    "langue": "hebreu",
    "numero": 126,
    "mot_original": "אַדְמָה",
    "translitteration": "ʾaḏmāh",
    "prononciation": "ʾaḏmāh",
    "definition": "Adma, ville de la plaine détruite avec Sodome.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 14:2"
    ],
    "type": "",
    "occurrences": 4,
    "recherche": "h126 אַדְמָה ʾaḏmāh adma, ville de la plaine détruite avec sodome.",
    "audio": "",
    "image": null
  },
  {
    "id": 200311,
    "strong": "H127",
    "langue": "hebreu",
    "numero": 127,
    "mot_original": "אֲדָמָה",
    "translitteration": "ʾăḏāmāh",
    "prononciation": "ʾăḏāmāh",
    "definition": "Sol, terre arable, terre cultivable, territoire.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 2:7",
      "Deutéronome 11:17"
    ],
    "type": "",
    "occurrences": 225,
    "recherche": "h127 אֲדָמָה ʾăḏāmāh sol, terre arable, terre cultivable, territoire.",
    "audio": "",
    "image": null
  },
  {
    "id": 200312,
    "strong": "H128",
    "langue": "hebreu",
    "numero": 128,
    "mot_original": "אֲדָמָה",
    "translitteration": "ʾăḏāmāh",
    "prononciation": "ʾăḏāmāh",
    "definition": "Adama, ville de Nephtali.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Josué 19:36"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h128 אֲדָמָה ʾăḏāmāh adama, ville de nephtali.",
    "audio": "",
    "image": null
  },
  {
    "id": 200313,
    "strong": "H129",
    "langue": "hebreu",
    "numero": 129,
    "mot_original": "אֲדָמִי",
    "translitteration": "ʾăḏāmî",
    "prononciation": "ʾăḏāmî",
    "definition": "Adami, toponyme Adami-Hanneqev, Nephtali.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Josué 19:33"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h129 אֲדָמִי ʾăḏāmî adami, toponyme adami-hanneqev, nephtali.",
    "audio": "",
    "image": null
  },
  {
    "id": 200314,
    "strong": "H130",
    "langue": "hebreu",
    "numero": 130,
    "mot_original": "אֱדֹמִי",
    "translitteration": "ʾĕḏōmî",
    "prononciation": "ʾĕḏōmî",
    "definition": "Édomite, habitant ou descendant d'Édom.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 23:8",
      "1 Samuel 21:8"
    ],
    "type": "",
    "occurrences": 10,
    "recherche": "h130 אֱדֹמִי ʾĕḏōmî édomite, habitant ou descendant d'édom.",
    "audio": "",
    "image": null
  },
  {
    "id": 200315,
    "strong": "H131",
    "langue": "hebreu",
    "numero": 131,
    "mot_original": "אֲדֻמִּים",
    "translitteration": "ʾăḏummîm",
    "prononciation": "ʾăḏummîm",
    "definition": "Adummim, col montagneux vers Jéricho.",
    "categorie": "Nature et création",
    "references": [
      "Josué 15:7"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h131 אֲדֻמִּים ʾăḏummîm adummim, col montagneux vers jéricho.",
    "audio": "",
    "image": null
  },
  {
    "id": 200316,
    "strong": "H132",
    "langue": "hebreu",
    "numero": 132,
    "mot_original": "אַדְמֹנִי",
    "translitteration": "ʾaḏmōnî",
    "prononciation": "ʾaḏmōnî",
    "definition": "Roux, rouquin.",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Samuel 16:12"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h132 אַדְמֹנִי ʾaḏmōnî roux, rouquin.",
    "audio": "",
    "image": null
  },
  {
    "id": 200317,
    "strong": "H133",
    "langue": "hebreu",
    "numero": 133,
    "mot_original": "אַדְמָתָא",
    "translitteration": "ʾaḏmāṯāʾ",
    "prononciation": "ʾaḏmāṯāʾ",
    "definition": "Admatha, conseiller du roi Assuérus.",
    "categorie": "Royaume",
    "references": [
      "Esther 1:14"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h133 אַדְמָתָא ʾaḏmāṯāʾ admatha, conseiller du roi assuérus.",
    "audio": "",
    "image": null
  },
  {
    "id": 200318,
    "strong": "H134",
    "langue": "hebreu",
    "numero": 134,
    "mot_original": "אֶדֶן",
    "translitteration": "ʾeḏen",
    "prononciation": "ʾeḏen",
    "definition": "Socle, base, support, piédestal.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 26:19",
      "Cantique des Cantiques 5:15"
    ],
    "type": "",
    "occurrences": 57,
    "recherche": "h134 אֶדֶן ʾeḏen socle, base, support, piédestal.",
    "audio": "",
    "image": null
  },
  {
    "id": 200319,
    "strong": "H135",
    "langue": "hebreu",
    "numero": 135,
    "mot_original": "אֶדֶן",
    "translitteration": "ʾeḏen",
    "prononciation": "ʾeḏen",
    "definition": "Éden, ville ou région (toponyme).",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "",
    "occurrences": 3,
    "recherche": "h135 אֶדֶן ʾeḏen éden, ville ou région (toponyme).",
    "audio": "",
    "image": null
  },
  {
    "id": 200320,
    "strong": "H136",
    "langue": "hebreu",
    "numero": 136,
    "mot_original": "אֲדֹנָי",
    "translitteration": "ʾăḏōnāy",
    "prononciation": "ʾăḏōnāy",
    "definition": "Seigneur, titre divin appliqué exclusivement à YHWH.",
    "categorie": "Noms de Dieu",
    "references": [
      "Genèse 15:2",
      "Psaume 110:1"
    ],
    "type": "",
    "occurrences": 434,
    "recherche": "h136 אֲדֹנָי ʾăḏōnāy seigneur, titre divin appliqué exclusivement à yhwh.",
    "audio": "",
    "image": null
  },
  {
    "id": 200321,
    "strong": "H137",
    "langue": "hebreu",
    "numero": 137,
    "mot_original": "אֲדֹנִי־בֶזֶק",
    "translitteration": "ʾăḏōnî-ḇezeq",
    "prononciation": "ʾăḏōnî-ḇezeq",
    "definition": "Adoni-Bézek, roi cananéen vaincu par Juda et Siméon.",
    "categorie": "Royaume",
    "references": [
      "Juges 1:7"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h137 אֲדֹנִי־בֶזֶק ʾăḏōnî-ḇezeq adoni-bézek, roi cananéen vaincu par juda et siméon.",
    "audio": "",
    "image": null
  },
  {
    "id": 200322,
    "strong": "H138",
    "langue": "hebreu",
    "numero": 138,
    "mot_original": "אֲדֹנִיָּה",
    "translitteration": "ʾăḏōnîyāh",
    "prononciation": "ʾăḏōnîyāh",
    "definition": "Adonija, YHWH est mon Seigneur.",
    "categorie": "Noms de Dieu",
    "references": [
      "1 Rois 1:5"
    ],
    "type": "",
    "occurrences": 26,
    "recherche": "h138 אֲדֹנִיָּה ʾăḏōnîyāh adonija, yhwh est mon seigneur.",
    "audio": "",
    "image": null
  },
  {
    "id": 200323,
    "strong": "H139",
    "langue": "hebreu",
    "numero": 139,
    "mot_original": "אֲדֹנִי־צֶדֶק",
    "translitteration": "ʾĂḏōnî-Ṣeḏeq",
    "prononciation": "ʾĂḏōnî-Ṣeḏeq",
    "definition": "Adoni-Tsédeq, roi cananéen de Jérusalem, chef d'une coalition de cinq rois vaincue par Josué.",
    "categorie": "Royaume",
    "references": [
      "Josué 10:1",
      "Josué 10:3"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h139 אֲדֹנִי־צֶדֶק ʾăḏōnî-ṣeḏeq adoni-tsédeq, roi cananéen de jérusalem, chef d'une coalition de cinq rois vaincue par josué.",
    "audio": "",
    "image": null
  },
  {
    "id": 200324,
    "strong": "H140",
    "langue": "hebreu",
    "numero": 140,
    "mot_original": "אֲדֹנִיקָם",
    "translitteration": "ʾăḏōnîqām",
    "prononciation": "ʾăḏōnîqām",
    "definition": "Adoniqam, mon seigneur s'est levé.",
    "categorie": "Noms de Dieu",
    "references": [
      "Esdras 2:13"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h140 אֲדֹנִיקָם ʾăḏōnîqām adoniqam, mon seigneur s'est levé.",
    "audio": "",
    "image": null
  },
  {
    "id": 200325,
    "strong": "H141",
    "langue": "hebreu",
    "numero": 141,
    "mot_original": "אֲדֹנִירָם",
    "translitteration": "ʾăḏōnîrām",
    "prononciation": "ʾăḏōnîrām",
    "definition": "Adoniram, mon seigneur est élevé.",
    "categorie": "Noms de Dieu",
    "references": [
      "1 Rois 4:6"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h141 אֲדֹנִירָם ʾăḏōnîrām adoniram, mon seigneur est élevé.",
    "audio": "",
    "image": null
  },
  {
    "id": 200326,
    "strong": "H142",
    "langue": "hebreu",
    "numero": 142,
    "mot_original": "אָדַר",
    "translitteration": "ʾāḏar",
    "prononciation": "ʾāḏar",
    "definition": "Être grand, magnifique, glorieux.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 15:11"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h142 אָדַר ʾāḏar être grand, magnifique, glorieux.",
    "audio": "",
    "image": null
  },
  {
    "id": 200327,
    "strong": "H143",
    "langue": "hebreu",
    "numero": 143,
    "mot_original": "אֲדָר",
    "translitteration": "ʾăḏār",
    "prononciation": "ʾăḏār",
    "definition": "Adar, douzième mois du calendrier.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esther 3:7"
    ],
    "type": "",
    "occurrences": 8,
    "recherche": "h143 אֲדָר ʾăḏār adar, douzième mois du calendrier.",
    "audio": "",
    "image": null
  },
  {
    "id": 200328,
    "strong": "H144",
    "langue": "hebreu",
    "numero": 144,
    "mot_original": "אֲדָר",
    "translitteration": "ʾăḏār",
    "prononciation": "ʾăḏār",
    "definition": "Adar, nom du mois en araméen. Doublet de H0143.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 6:15"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h144 אֲדָר ʾăḏār adar, nom du mois en araméen. doublet de h0143.",
    "audio": "",
    "image": null
  },
  {
    "id": 200329,
    "strong": "H145",
    "langue": "hebreu",
    "numero": 145,
    "mot_original": "אֶדֶר",
    "translitteration": "ʾeḏer",
    "prononciation": "ʾeḏer",
    "definition": "Manteau, cape, vêtement ample.",
    "categorie": "Eau et baptême",
    "references": [
      "Genèse 25:25",
      "Zacharie 13:4"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h145 אֶדֶר ʾeḏer manteau, cape, vêtement ample.",
    "audio": "",
    "image": null
  },
  {
    "id": 200330,
    "strong": "H146",
    "langue": "hebreu",
    "numero": 146,
    "mot_original": "אַדָּר",
    "translitteration": "ʾaddār",
    "prononciation": "ʾaddār",
    "definition": "Addar, descendant de Benjamin.",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Chroniques 8:3"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h146 אַדָּר ʾaddār addar, descendant de benjamin.",
    "audio": "",
    "image": null
  },
  {
    "id": 200331,
    "strong": "H147",
    "langue": "hebreu",
    "numero": 147,
    "mot_original": "אִדַּר",
    "translitteration": "ʾiddar",
    "prononciation": "ʾiddar",
    "definition": "Sens incertain. Possiblement aire de battage, grange.",
    "categorie": "Ange et messager",
    "references": [],
    "type": "",
    "occurrences": 1,
    "recherche": "h147 אִדַּר ʾiddar sens incertain. possiblement aire de battage, grange.",
    "audio": "",
    "image": null
  },
  {
    "id": 200332,
    "strong": "H148",
    "langue": "hebreu",
    "numero": 148,
    "mot_original": "אַדְרַגָּזֵר",
    "translitteration": "ʾaḏargāzēr",
    "prononciation": "ʾaḏargāzēr",
    "definition": "Conseiller, juge, haut fonctionnaire babylonien.",
    "categorie": "Onction",
    "references": [
      "Daniel 3:2"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h148 אַדְרַגָּזֵר ʾaḏargāzēr conseiller, juge, haut fonctionnaire babylonien.",
    "audio": "",
    "image": null
  },
  {
    "id": 200333,
    "strong": "H149",
    "langue": "hebreu",
    "numero": 149,
    "mot_original": "אַדְרַזְדָּא",
    "translitteration": "ʾaḏrazdāʾ",
    "prononciation": "ʾaḏrazdāʾ",
    "definition": "Avec soin, diligemment, exactement.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 7:23"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h149 אַדְרַזְדָּא ʾaḏrazdāʾ avec soin, diligemment, exactement.",
    "audio": "",
    "image": null
  },
  {
    "id": 200334,
    "strong": "H150",
    "langue": "hebreu",
    "numero": 150,
    "mot_original": "אֲדַרְכּוֹן",
    "translitteration": "ʾăḏarkōn",
    "prononciation": "ʾăḏarkōn",
    "definition": "Darique, pièce d'or perse.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 8:27"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h150 אֲדַרְכּוֹן ʾăḏarkōn darique, pièce d'or perse.",
    "audio": "",
    "image": null
  },
  {
    "id": 200335,
    "strong": "H151",
    "langue": "hebreu",
    "numero": 151,
    "mot_original": "אֲדֹרָם",
    "translitteration": "ʾăḏōrām",
    "prononciation": "ʾăḏōrām",
    "definition": "Adoram, forme abrégée de Adoniram.",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Rois 12:18"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h151 אֲדֹרָם ʾăḏōrām adoram, forme abrégée de adoniram.",
    "audio": "",
    "image": null
  },
  {
    "id": 200336,
    "strong": "H152",
    "langue": "hebreu",
    "numero": 152,
    "mot_original": "אַדְרַמֶּלֶךְ",
    "translitteration": "ʾaḏrammeleḵ",
    "prononciation": "ʾaḏrammeleḵ",
    "definition": "Adrammélek, le roi est magnifique.",
    "categorie": "Royaume",
    "references": [
      "2 Rois 19:37"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h152 אַדְרַמֶּלֶךְ ʾaḏrammeleḵ adrammélek, le roi est magnifique.",
    "audio": "",
    "image": null
  },
  {
    "id": 200337,
    "strong": "H153",
    "langue": "hebreu",
    "numero": 153,
    "mot_original": "אֶדְרָע",
    "translitteration": "ʾeḏrāʿ",
    "prononciation": "ʾeḏrāʿ",
    "definition": "Bras, avant-bras, force.",
    "categorie": "Puissance et autorité",
    "references": [
      "Daniel 2:32"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h153 אֶדְרָע ʾeḏrāʿ bras, avant-bras, force.",
    "audio": "",
    "image": null
  },
  {
    "id": 200338,
    "strong": "H154",
    "langue": "hebreu",
    "numero": 154,
    "mot_original": "אֶדְרֶעִי",
    "translitteration": "ʾeḏreʿî",
    "prononciation": "ʾeḏreʿî",
    "definition": "Édréï, deux villes bibliques.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Nombres 21:33"
    ],
    "type": "",
    "occurrences": 7,
    "recherche": "h154 אֶדְרֶעִי ʾeḏreʿî édréï, deux villes bibliques.",
    "audio": "",
    "image": null
  },
  {
    "id": 200339,
    "strong": "H155",
    "langue": "hebreu",
    "numero": 155,
    "mot_original": "אַדֶּרֶת",
    "translitteration": "ʾaddereṯ",
    "prononciation": "ʾaddereṯ",
    "definition": "Manteau, cape, vêtement ample et luxueux.",
    "categorie": "Eau et baptême",
    "references": [
      "1 Rois 19:19"
    ],
    "type": "",
    "occurrences": 0,
    "recherche": "h155 אַדֶּרֶת ʾaddereṯ manteau, cape, vêtement ample et luxueux.",
    "audio": "",
    "image": null
  },
  {
    "id": 200340,
    "strong": "H156",
    "langue": "hebreu",
    "numero": 156,
    "mot_original": "אָדַשׁ",
    "translitteration": "ʾāḏaš",
    "prononciation": "ʾāḏaš",
    "definition": "Fouler, battre le grain, dépiquer.",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "",
    "occurrences": 1,
    "recherche": "h156 אָדַשׁ ʾāḏaš fouler, battre le grain, dépiquer.",
    "audio": "",
    "image": null
  },
  {
    "id": 200341,
    "strong": "H157",
    "langue": "hebreu",
    "numero": 157,
    "mot_original": "אָהַב",
    "translitteration": "ʾāhaḇ",
    "prononciation": "ʾāhaḇ",
    "definition": "Aimer, avoir de l'affection pour, désirer.",
    "categorie": "Amour",
    "references": [
      "Deutéronome 6:5",
      "Lévitique 19:18",
      "1 Samuel 18:1"
    ],
    "type": "",
    "occurrences": 208,
    "recherche": "h157 אָהַב ʾāhaḇ aimer, avoir de l'affection pour, désirer.",
    "audio": "",
    "image": null
  },
  {
    "id": 200342,
    "strong": "H158",
    "langue": "hebreu",
    "numero": 158,
    "mot_original": "אַהַב",
    "translitteration": "ʾahaḇ",
    "prononciation": "ʾahaḇ",
    "definition": "Amour, affection, désir.",
    "categorie": "Amour",
    "references": [
      "Osée 2:7"
    ],
    "type": "",
    "occurrences": 7,
    "recherche": "h158 אַהַב ʾahaḇ amour, affection, désir.",
    "audio": "",
    "image": null
  },
  {
    "id": 200343,
    "strong": "H159",
    "langue": "hebreu",
    "numero": 159,
    "mot_original": "אֹהַב",
    "translitteration": "ʾōhaḇ",
    "prononciation": "ʾōhaḇ",
    "definition": "Amour, objet d'amour.",
    "categorie": "Amour",
    "references": [
      "Osée 9:10"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h159 אֹהַב ʾōhaḇ amour, objet d'amour.",
    "audio": "",
    "image": null
  },
  {
    "id": 200344,
    "strong": "H160",
    "langue": "hebreu",
    "numero": 160,
    "mot_original": "אַהֲבָה",
    "translitteration": "ʾahăḇāh",
    "prononciation": "ʾahăḇāh",
    "definition": "Amour, affection, bienveillance.",
    "categorie": "Amour",
    "references": [
      "Cantique des Cantiques 8:7",
      "Deutéronome 7:8"
    ],
    "type": "",
    "occurrences": 37,
    "recherche": "h160 אַהֲבָה ʾahăḇāh amour, affection, bienveillance.",
    "audio": "",
    "image": null
  },
  {
    "id": 200345,
    "strong": "H161",
    "langue": "hebreu",
    "numero": 161,
    "mot_original": "אֹהַד",
    "translitteration": "ʾōhaḏ",
    "prononciation": "ʾōhaḏ",
    "definition": "Ohad, fils de Siméon.",
    "categorie": "Adoption et filiation",
    "references": [
      "Genèse 46:10"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h161 אֹהַד ʾōhaḏ ohad, fils de siméon.",
    "audio": "",
    "image": null
  },
  {
    "id": 200346,
    "strong": "H162",
    "langue": "hebreu",
    "numero": 162,
    "mot_original": "אֲהָהּ",
    "translitteration": "ʾăhāh",
    "prononciation": "ʾăhāh",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Josué 7:7",
      "Jérémie 1:6"
    ],
    "type": "",
    "occurrences": 15,
    "recherche": "h162 אֲהָהּ ʾăhāh ah ! hélas ! exclamation de lamentation.",
    "audio": "",
    "image": null
  },
  {
    "id": 200347,
    "strong": "H163",
    "langue": "hebreu",
    "numero": 163,
    "mot_original": "אַהֲוָא",
    "translitteration": "ʾahăwāʾ",
    "prononciation": "ʾahăwāʾ",
    "definition": "Ahava, localité de Babylonie.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 8:15"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h163 אַהֲוָא ʾahăwāʾ ahava, localité de babylonie.",
    "audio": "",
    "image": null
  },
  {
    "id": 200348,
    "strong": "H164",
    "langue": "hebreu",
    "numero": 164,
    "mot_original": "אֵהוּד",
    "translitteration": "ʾēhûḏ",
    "prononciation": "ʾēhûḏ",
    "definition": "Éhoud, second juge d'Israël.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Juges 3:15"
    ],
    "type": "",
    "occurrences": 9,
    "recherche": "h164 אֵהוּד ʾēhûḏ éhoud, second juge d'israël.",
    "audio": "",
    "image": null
  },
  {
    "id": 200349,
    "strong": "H165",
    "langue": "hebreu",
    "numero": 165,
    "mot_original": "אֱהִי",
    "translitteration": "ʾĕhî",
    "prononciation": "ʾĕhî",
    "definition": "Où ? Où donc ? particule interrogative.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Osée 13:10"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h165 אֱהִי ʾĕhî où ? où donc ? particule interrogative.",
    "audio": "",
    "image": null
  },
  {
    "id": 200350,
    "strong": "H166",
    "langue": "hebreu",
    "numero": 166,
    "mot_original": "אָהַל",
    "translitteration": "ʾāhal",
    "prononciation": "ʾāhal",
    "definition": "Dresser la tente, camper.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 13:12"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h166 אָהַל ʾāhal dresser la tente, camper.",
    "audio": "",
    "image": null
  },
  {
    "id": 200351,
    "strong": "H167",
    "langue": "hebreu",
    "numero": 167,
    "mot_original": "אֹהֶל",
    "translitteration": "ʾōhel",
    "prononciation": "ʾōhel",
    "definition": "Dresser la tente. Doublet de H0166.",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "",
    "occurrences": 0,
    "recherche": "h167 אֹהֶל ʾōhel dresser la tente. doublet de h0166.",
    "audio": "",
    "image": null
  },
  {
    "id": 200352,
    "strong": "H168",
    "langue": "hebreu",
    "numero": 168,
    "mot_original": "אֹהֶל",
    "translitteration": "ʾōhel",
    "prononciation": "ʾōhel",
    "definition": "Tente, habitation temporaire, demeure.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 12:8",
      "Exode 33:7",
      "Psaume 27:5"
    ],
    "type": "",
    "occurrences": 345,
    "recherche": "h168 אֹהֶל ʾōhel tente, habitation temporaire, demeure.",
    "audio": "",
    "image": null
  },
  {
    "id": 200353,
    "strong": "H169",
    "langue": "hebreu",
    "numero": 169,
    "mot_original": "אֹהֶל",
    "translitteration": "ʾōhel",
    "prononciation": "ʾōhel",
    "definition": "Ohel, descendant de Juda par Zorobabel.",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Chroniques 3:20"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h169 אֹהֶל ʾōhel ohel, descendant de juda par zorobabel.",
    "audio": "",
    "image": null
  },
  {
    "id": 200354,
    "strong": "H170",
    "langue": "hebreu",
    "numero": 170,
    "mot_original": "אָהֳלָה",
    "translitteration": "ʾāholāh",
    "prononciation": "ʾāholāh",
    "definition": "Ohola, nom allégorique de Samarie.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ézéchiel 23:4"
    ],
    "type": "",
    "occurrences": 5,
    "recherche": "h170 אָהֳלָה ʾāholāh ohola, nom allégorique de samarie.",
    "audio": "",
    "image": null
  },
  {
    "id": 200355,
    "strong": "H171",
    "langue": "hebreu",
    "numero": 171,
    "mot_original": "אָהֳלִיאָב",
    "translitteration": "ʾāholîʾāḇ",
    "prononciation": "ʾāholîʾāḇ",
    "definition": "Oholiab, artisan assistant de Betsaléel.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 31:6"
    ],
    "type": "",
    "occurrences": 5,
    "recherche": "h171 אָהֳלִיאָב ʾāholîʾāḇ oholiab, artisan assistant de betsaléel.",
    "audio": "",
    "image": null
  },
  {
    "id": 200356,
    "strong": "H172",
    "langue": "hebreu",
    "numero": 172,
    "mot_original": "אָהֳלִיבָה",
    "translitteration": "ʾāholîḇāh",
    "prononciation": "ʾāholîḇāh",
    "definition": "Oholiba, nom allégorique de Jérusalem.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ézéchiel 23:4"
    ],
    "type": "",
    "occurrences": 6,
    "recherche": "h172 אָהֳלִיבָה ʾāholîḇāh oholiba, nom allégorique de jérusalem.",
    "audio": "",
    "image": null
  },
  {
    "id": 200357,
    "strong": "H173",
    "langue": "hebreu",
    "numero": 173,
    "mot_original": "אָהֳלִיבָמָה",
    "translitteration": "ʾāholîḇāmāh",
    "prononciation": "ʾāholîḇāmāh",
    "definition": "Oholibama, épouse d'Ésaü.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 36:2"
    ],
    "type": "",
    "occurrences": 8,
    "recherche": "h173 אָהֳלִיבָמָה ʾāholîḇāmāh oholibama, épouse d'ésaü.",
    "audio": "",
    "image": null
  },
  {
    "id": 200358,
    "strong": "H174",
    "langue": "hebreu",
    "numero": 174,
    "mot_original": "אֲהָלִים",
    "translitteration": "ʾăhālîm",
    "prononciation": "ʾăhālîm",
    "definition": "Aloès, bois d'aloès aromatique.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Psaume 45:9"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h174 אֲהָלִים ʾăhālîm aloès, bois d'aloès aromatique.",
    "audio": "",
    "image": null
  },
  {
    "id": 200359,
    "strong": "H175",
    "langue": "hebreu",
    "numero": 175,
    "mot_original": "אַהֲרוֹן",
    "translitteration": "ʾAhărôn",
    "prononciation": "ʾAhărôn",
    "definition": "Aaron, frère aîné de Moïse, premier grand-prêtre d'Israël, ancêtre de la lignée sacerdotale lévitique.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 4:14",
      "Exode 28:1"
    ],
    "type": "",
    "occurrences": 0,
    "recherche": "h175 אַהֲרוֹן ʾahărôn aaron, frère aîné de moïse, premier grand-prêtre d'israël, ancêtre de la lignée sacerdotale lévitique.",
    "audio": "",
    "image": null
  },
  {
    "id": 200360,
    "strong": "H176",
    "langue": "hebreu",
    "numero": 176,
    "mot_original": "אוֹ",
    "translitteration": "ʾô",
    "prononciation": "ʾô",
    "definition": "Ou, ou bien, soit.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 24:55"
    ],
    "type": "",
    "occurrences": 320,
    "recherche": "h176 אוֹ ʾô ou, ou bien, soit.",
    "audio": "",
    "image": null
  },
  {
    "id": 200361,
    "strong": "H177",
    "langue": "hebreu",
    "numero": 177,
    "mot_original": "אוּאֵל",
    "translitteration": "ʾûʾēl",
    "prononciation": "ʾûʾēl",
    "definition": "Uel, Israélite listé par Esdras.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 10:34"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h177 אוּאֵל ʾûʾēl uel, israélite listé par esdras.",
    "audio": "",
    "image": null
  },
  {
    "id": 200362,
    "strong": "H178",
    "langue": "hebreu",
    "numero": 178,
    "mot_original": "אוֹב",
    "translitteration": "ʾôḇ",
    "prononciation": "ʾôḇ",
    "definition": "Nécromancien, esprit des morts.",
    "categorie": "Mort et vie",
    "references": [
      "1 Samuel 28:7",
      "Lévitique 20:27"
    ],
    "type": "",
    "occurrences": 17,
    "recherche": "h178 אוֹב ʾôḇ nécromancien, esprit des morts.",
    "audio": "",
    "image": null
  },
  {
    "id": 200363,
    "strong": "H179",
    "langue": "hebreu",
    "numero": 179,
    "mot_original": "אוֹבִיל",
    "translitteration": "ʾôḇîl",
    "prononciation": "ʾôḇîl",
    "definition": "Obil, intendant des chameaux de David.",
    "categorie": "Eau et baptême",
    "references": [
      "1 Chroniques 27:30"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h179 אוֹבִיל ʾôḇîl obil, intendant des chameaux de david.",
    "audio": "",
    "image": null
  },
  {
    "id": 200364,
    "strong": "H180",
    "langue": "hebreu",
    "numero": 180,
    "mot_original": "אוֹבָל",
    "translitteration": "ʾôḇāl",
    "prononciation": "ʾôḇāl",
    "definition": "Obal, fils de Yoqtan.",
    "categorie": "Adoption et filiation",
    "references": [
      "Genèse 10:28"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h180 אוֹבָל ʾôḇāl obal, fils de yoqtan.",
    "audio": "",
    "image": null
  },
  {
    "id": 200365,
    "strong": "H181",
    "langue": "hebreu",
    "numero": 181,
    "mot_original": "אוּד",
    "translitteration": "ʾûḏ",
    "prononciation": "ʾûḏ",
    "definition": "Tison, brandon, bois à demi brûlé.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Amos 4:11",
      "Zacharie 3:2"
    ],
    "type": "",
    "occurrences": 3,
    "recherche": "h181 אוּד ʾûḏ tison, brandon, bois à demi brûlé.",
    "audio": "",
    "image": null
  },
  {
    "id": 200366,
    "strong": "H182",
    "langue": "hebreu",
    "numero": 182,
    "mot_original": "אוֹדוֹת",
    "translitteration": "ʾôḏôṯ",
    "prononciation": "ʾôḏôṯ",
    "definition": "Cause, raison, circonstance, concernant.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 21:11"
    ],
    "type": "",
    "occurrences": 11,
    "recherche": "h182 אוֹדוֹת ʾôḏôṯ cause, raison, circonstance, concernant.",
    "audio": "",
    "image": null
  },
  {
    "id": 200367,
    "strong": "H183",
    "langue": "hebreu",
    "numero": 183,
    "mot_original": "אָוָה",
    "translitteration": "ʾāwāh",
    "prononciation": "ʾāwāh",
    "definition": "Désirer ardemment, convoiter.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 5:18",
      "Psaume 106:14"
    ],
    "type": "",
    "occurrences": 26,
    "recherche": "h183 אָוָה ʾāwāh désirer ardemment, convoiter.",
    "audio": "",
    "image": null
  },
  {
    "id": 200368,
    "strong": "H184",
    "langue": "hebreu",
    "numero": 184,
    "mot_original": "אָוָה",
    "translitteration": "ʾāwāh",
    "prononciation": "ʾāwāh",
    "definition": "Marquer, tracer, délimiter.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Nombres 34:10"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h184 אָוָה ʾāwāh marquer, tracer, délimiter.",
    "audio": "",
    "image": null
  },
  {
    "id": 200369,
    "strong": "H185",
    "langue": "hebreu",
    "numero": 185,
    "mot_original": "אַוָּה",
    "translitteration": "ʾawwāh",
    "prononciation": "ʾawwāh",
    "definition": "Désir, souhait, volonté, convoitise.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 12:20"
    ],
    "type": "",
    "occurrences": 7,
    "recherche": "h185 אַוָּה ʾawwāh désir, souhait, volonté, convoitise.",
    "audio": "",
    "image": null
  },
  {
    "id": 200370,
    "strong": "H186",
    "langue": "hebreu",
    "numero": 186,
    "mot_original": "אוּזַי",
    "translitteration": "ʾûzay",
    "prononciation": "ʾûzay",
    "definition": "Uzaï, bâtisseur de la muraille de Jérusalem.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Néhémie 3:25"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h186 אוּזַי ʾûzay uzaï, bâtisseur de la muraille de jérusalem.",
    "audio": "",
    "image": null
  },
  {
    "id": 200371,
    "strong": "H187",
    "langue": "hebreu",
    "numero": 187,
    "mot_original": "אוּזָל",
    "translitteration": "ʾûzāl",
    "prononciation": "ʾûzāl",
    "definition": "Uzal, descendant de Yoqtan, région d'Arabie.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 10:27"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h187 אוּזָל ʾûzāl uzal, descendant de yoqtan, région d'arabie.",
    "audio": "",
    "image": null
  },
  {
    "id": 200372,
    "strong": "H188",
    "langue": "hebreu",
    "numero": 188,
    "mot_original": "אוֹי",
    "translitteration": "ʾôy",
    "prononciation": "ʾôy",
    "definition": "Malheur ! Hélas ! Cri de lamentation.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Ésaïe 6:5",
      "Nombres 21:29"
    ],
    "type": "",
    "occurrences": 23,
    "recherche": "h188 אוֹי ʾôy malheur ! hélas ! cri de lamentation.",
    "audio": "",
    "image": null
  },
  {
    "id": 200373,
    "strong": "H189",
    "langue": "hebreu",
    "numero": 189,
    "mot_original": "אֱוִי",
    "translitteration": "ʾĕwî",
    "prononciation": "ʾĕwî",
    "definition": "Évi, prince madianite tué par Israël.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Nombres 31:8"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h189 אֱוִי ʾĕwî évi, prince madianite tué par israël.",
    "audio": "",
    "image": null
  },
  {
    "id": 200374,
    "strong": "H190",
    "langue": "hebreu",
    "numero": 190,
    "mot_original": "אוֹיָה",
    "translitteration": "ʾôyāh",
    "prononciation": "ʾôyāh",
    "definition": "Malheur à moi ! Hélas !",
    "categorie": "Deuil et lamentation",
    "references": [
      "Psaume 120:5"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h190 אוֹיָה ʾôyāh malheur à moi ! hélas !",
    "audio": "",
    "image": null
  },
  {
    "id": 200375,
    "strong": "H191",
    "langue": "hebreu",
    "numero": 191,
    "mot_original": "אֱוִיל",
    "translitteration": "ʾĕwîl",
    "prononciation": "ʾĕwîl",
    "definition": "Insensé, sot, stupide.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Proverbes 1:7",
      "Proverbes 12:15"
    ],
    "type": "",
    "occurrences": 26,
    "recherche": "h191 אֱוִיל ʾĕwîl insensé, sot, stupide.",
    "audio": "",
    "image": null
  },
  {
    "id": 200376,
    "strong": "H192",
    "langue": "hebreu",
    "numero": 192,
    "mot_original": "אֱוִיל מְרֹדַךְ",
    "translitteration": "ʾĕwîl mərōḏaḵ",
    "prononciation": "ʾĕwîl mərōḏaḵ",
    "definition": "Évil-Merodak, roi de Babylone.",
    "categorie": "Royaume",
    "references": [
      "2 Rois 25:27"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h192 אֱוִיל מְרֹדַךְ ʾĕwîl mərōḏaḵ évil-merodak, roi de babylone.",
    "audio": "",
    "image": null
  },
  {
    "id": 200377,
    "strong": "H193",
    "langue": "hebreu",
    "numero": 193,
    "mot_original": "אוּל",
    "translitteration": "ʾûl",
    "prononciation": "ʾûl",
    "definition": "Ventre, corps, puissance corporelle.",
    "categorie": "Puissance et autorité",
    "references": [
      "Job 40:16"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h193 אוּל ʾûl ventre, corps, puissance corporelle.",
    "audio": "",
    "image": null
  },
  {
    "id": 200378,
    "strong": "H194",
    "langue": "hebreu",
    "numero": 194,
    "mot_original": "אוּלַי",
    "translitteration": "ʾûlay",
    "prononciation": "ʾûlay",
    "definition": "Peut-être, il se peut que.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 18:24",
      "Sophonie 2:3"
    ],
    "type": "",
    "occurrences": 42,
    "recherche": "h194 אוּלַי ʾûlay peut-être, il se peut que.",
    "audio": "",
    "image": null
  },
  {
    "id": 200379,
    "strong": "H195",
    "langue": "hebreu",
    "numero": 195,
    "mot_original": "אוּלַי",
    "translitteration": "ʾûlay",
    "prononciation": "ʾûlay",
    "definition": "Oulaï, fleuve d'Élam.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 8:2"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h195 אוּלַי ʾûlay oulaï, fleuve d'élam.",
    "audio": "",
    "image": null
  },
  {
    "id": 200380,
    "strong": "H196",
    "langue": "hebreu",
    "numero": 196,
    "mot_original": "אֱוִלִי",
    "translitteration": "ʾĕwilî",
    "prononciation": "ʾĕwilî",
    "definition": "Insensé, stupide. Variante de H0191.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Zacharie 11:15"
    ],
    "type": "",
    "occurrences": 1,
    "recherche": "h196 אֱוִלִי ʾĕwilî insensé, stupide. variante de h0191.",
    "audio": "",
    "image": null
  },
  {
    "id": 200381,
    "strong": "H197",
    "langue": "hebreu",
    "numero": 197,
    "mot_original": "אוּלָם",
    "translitteration": "ʾûlām",
    "prononciation": "ʾûlām",
    "definition": "Vestibule, portique, salle d'entrée.",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Rois 6:3"
    ],
    "type": "",
    "occurrences": 34,
    "recherche": "h197 אוּלָם ʾûlām vestibule, portique, salle d'entrée.",
    "audio": "",
    "image": null
  },
  {
    "id": 200382,
    "strong": "H198",
    "langue": "hebreu",
    "numero": 198,
    "mot_original": "אוּלָם",
    "translitteration": "ʾûlām",
    "prononciation": "ʾûlām",
    "definition": "Oulam, descendants de Manassé et Benjamin.",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Chroniques 8:39"
    ],
    "type": "",
    "occurrences": 2,
    "recherche": "h198 אוּלָם ʾûlām oulam, descendants de manassé et benjamin.",
    "audio": "",
    "image": null
  },
  {
    "id": 200383,
    "strong": "H199",
    "langue": "hebreu",
    "numero": 199,
    "mot_original": "אוּלָם",
    "translitteration": "ʾûlām",
    "prononciation": "ʾûlām",
    "definition": "Mais, cependant, toutefois.",
    "categorie": "Foi",
    "references": [
      "Job 1:11"
    ],
    "type": "",
    "occurrences": 12,
    "recherche": "h199 אוּלָם ʾûlām mais, cependant, toutefois.",
    "audio": "",
    "image": null
  },
  {
    "id": 200384,
    "strong": "H200",
    "langue": "hebreu",
    "numero": 200,
    "mot_original": "אִוֶּלֶת",
    "translitteration": "ʾiwweleṯ",
    "prononciation": "ʾiwweleṯ",
    "definition": "Folie, sottise, stupidité morale.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Proverbes 9:13",
      "Proverbes 14:29"
    ],
    "type": "",
    "occurrences": 25,
    "recherche": "h200 אִוֶּלֶת ʾiwweleṯ folie, sottise, stupidité morale.",
    "audio": "",
    "image": null
  },
  {
    "id": 200095,
    "strong": "H201",
    "langue": "hebreu",
    "numero": 201,
    "mot_original": "אוֹמָר",
    "translitteration": "ʾômār",
    "prononciation": "ʾômār",
    "definition": "Omar, nom d'un chef édomite, descendant d'Ésaü.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 36:11"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h201 אוֹמָר ʾômār omar, nom d'un chef édomite, descendant d'ésaü. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Omar",
    "etymologie": "Nom d'origine édomite ou sémitique. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 36:11",
      "texte": "Les fils d\\'Éliphaz furent : Téman, Omar, Tsepho, Gahtam et Qenaz."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Omar est répertorié dans les généalogies édomites de Genèse 36, chapitre consacré aux descendants d'Ésaü Édom. Les « chefs » (אַלּוּפִים) édomites correspondent probablement à des clans ou à des circonscriptions territoriales. Omar appartient à la branche d'Éliphaz, fils aîné d'Ésaü et d'Ada. Les noms de ces clans sont partiellement…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200096,
    "strong": "H202",
    "langue": "hebreu",
    "numero": 202,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "Vigueur, force, puissance virile ; richesse, prospérité.",
    "categorie": "Puissance et autorité",
    "references": [
      "Genèse 49:3",
      "Osée 12:9"
    ],
    "type": "nom commun",
    "occurrences": 12,
    "recherche": "h202 אוֹן ʾôn vigueur, force, puissance virile ; richesse, prospérité. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Vigueur",
    "etymologie": "Racine און (ʾWN, « être fort, vigoureux »). · Syriaque : ܐܘܢܐ (ʾawnā, « force ») · Arabe : ʾāna (être fort) · Akkadien : ūnu (force, puissance) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 49:3",
      "texte": "Ruben, tu es mon premier-né, ma force et les prémices de ma vigueur."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme ʾôn désigne la puissance dans ses manifestations concrètes : force génésique aboutissant à la descendance, puissance économique aboutissant à la richesse. La bénédiction de Jacob à Ruben (Genèse 49:3) utilise l'expression « prémices de ma vigueur » pour désigner le fils aîné comme premier produit de la puissance…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200097,
    "strong": "H203",
    "langue": "hebreu",
    "numero": 203,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "On, ville égyptienne, Héliopolis, centre du culte solaire.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 41:45"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 3,
    "recherche": "h203 אוֹן ʾôn on, ville égyptienne, héliopolis, centre du culte solaire. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "On",
    "etymologie": "Translittération de l'égyptien ỉwnw (Iounou, « la ville du pilier »). · Grec : Ἡλιούπολις (Hēlioupolis, « ville du soleil ») · Copte : ⲱⲛ (Ōn) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 41:45",
      "texte": "Il lui donna pour femme Asnath, fille de Poti-Phéra, prêtre d\\'On."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "On (Héliopolis) était l'un des principaux centres religieux de l'Égypte ancienne, situé au nord est de l'actuel Caire. La ville abritait le temple de Rê Atoum, divinité solaire, et son clergé détenait une influence théologique et politique considérable. Le mariage de Joseph avec Asnath, fille du prêtre d'On, intègre le…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200098,
    "strong": "H204",
    "langue": "hebreu",
    "numero": 204,
    "mot_original": "אוֹן",
    "translitteration": "ʾôn",
    "prononciation": "ʾôn",
    "definition": "On, nom de lieu. Probablement doublet ou variante de H0203 ou de אָוֶן (H0205).",
    "categorie": "Noms propres bibliques",
    "references": [],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h204 אוֹן ʾôn on, nom de lieu. probablement doublet ou variante de h0203 ou de אָוֶן (h0205). nom propre",
    "audio": "",
    "image": null,
    "racine": "H203",
    "sens_principal": "On",
    "etymologie": "Voir H0203 ou H0205. ·",
    "formes_derivees": [
      "H202",
      "H203",
      "H205"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Cette entrée Strong est problématique et probablement un doublet. La distinction entre On (Héliopolis, H0203), On (toponyme incertain, H0204) et Aven (vallée d'idolâtrie, H0205) repose sur des variations contextuelles que la graphie consonantique identique ne permet pas toujours de trancher.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200099,
    "strong": "H205",
    "langue": "hebreu",
    "numero": 205,
    "mot_original": "אָוֶן",
    "translitteration": "ʾāwen",
    "prononciation": "ʾāwen",
    "definition": "Malheur, iniquité, trouble ; vanité, néant ; idole.",
    "categorie": "Péché",
    "references": [
      "Psaume 90:10",
      "Osée 4:15"
    ],
    "type": "nom commun / nom propre",
    "occurrences": 78,
    "recherche": "h205 אָוֶן ʾāwen malheur, iniquité, trouble ; vanité, néant ; idole. nom commun / nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Malheur",
    "etymologie": "Racine און (ʾWN, « être trouble, néfaste, vain »). · Syriaque : ܐܘܢܐ (ʾawnā, « iniquité ») · Arabe : ʾāna (être fatigué, peiné) ·",
    "formes_derivees": [
      "H202"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Psaume 90:10",
      "texte": "Les jours de nos années sont de soixante-dix ans\\... et leur orgueil n\\'est que peine et malheur."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Le terme ʾāwen couvre trois champs sémantiques principaux : éthique (iniquité, injustice), existentiel (malheur, calamité) et cultuel (idole, vanité). Dans la littérature prophétique, ʾāwen désigne fréquemment les cultes idolâtriques. Le jeu de mots polémique entre Beth El (« maison de Dieu ») et Beth Aven (« maison de néant/idole »)…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200100,
    "strong": "H206",
    "langue": "hebreu",
    "numero": 206,
    "mot_original": "אָוֶן",
    "translitteration": "ʾāwen",
    "prononciation": "ʾāwen",
    "definition": "Aven, nom de lieu. Doublet toponymique de H0205.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Amos 1:5"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 0,
    "recherche": "h206 אָוֶן ʾāwen aven, nom de lieu. doublet toponymique de h0205. nom propre",
    "audio": "",
    "image": null,
    "racine": "H205",
    "sens_principal": "Aven",
    "etymologie": "Voir H0205. ·",
    "formes_derivees": [
      "H205"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Amos 1:5",
      "texte": "J\\'exterminerai l\\'habitant de la vallée d\\'Aven."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "La « vallée d'Aven » est mentionnée dans l'oracle d'Amos contre Damas. Elle est généralement identifiée à la Beqaa, large vallée entre le Liban et l'Anti Liban, site du culte de Baal Hadad. Beth Aven (« maison de néant ») est un surnom ironique de Béthel (« maison de Dieu…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200101,
    "strong": "H207",
    "langue": "hebreu",
    "numero": 207,
    "mot_original": "אוֹנוֹ",
    "translitteration": "ʾônô",
    "prononciation": "ʾônô",
    "definition": "Ono, ville de Benjamin, dans la plaine de Sharon.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Néhémie 6:2"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 5,
    "recherche": "h207 אוֹנוֹ ʾônô ono, ville de benjamin, dans la plaine de sharon. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ono",
    "etymologie": "Toponyme d'origine cananéenne. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Néhémie 6:2",
      "texte": "Viens, rencontrons-nous dans les villages de la vallée d\\'Ono."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Ono est identifiée à Kafr ʿĀna, au sud est de Tel Aviv, dans la plaine côtière. La « vallée d'Ono » est une zone fertile de la Shéphélah septentrionale. La ville fut repeuplée après l'exil (Esdras 2:33 ; Néhémie 7:37). Néhémie 6:2 mentionne la tentative de ses adversaires (Sanballat, Tobiah,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200102,
    "strong": "H208",
    "langue": "hebreu",
    "numero": 208,
    "mot_original": "אוֹנָם",
    "translitteration": "ʾônām",
    "prononciation": "ʾônām",
    "definition": "Onam, nom de deux descendants de Juda et d'Ésaü.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 36:23"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h208 אוֹנָם ʾônām onam, nom de deux descendants de juda et d'ésaü. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Onam",
    "etymologie": "Nom d'origine sémitique. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 36:23",
      "texte": "Voici les fils de Shobal : Alvan, Manahath, Ébal, Shepho et Onam."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Deux personnages distincts portent ce nom : un Horite (descendant de Séïr, population pré édomite de la montagne de Séïr) et un Judéen de la branche de Yerakhméel. L'homonymie reflète la récurrence des mêmes noms dans des lignées différentes.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200103,
    "strong": "H209",
    "langue": "hebreu",
    "numero": 209,
    "mot_original": "אוֹנָן",
    "translitteration": "ʾônān",
    "prononciation": "ʾônān",
    "definition": "Onan, second fils de Juda et de la fille de Shua.",
    "categorie": "Adoption et filiation",
    "references": [
      "Genèse 38:9"
    ],
    "type": "nom propre",
    "occurrences": 6,
    "recherche": "h209 אוֹנָן ʾônān onan, second fils de juda et de la fille de shua. nom propre",
    "audio": "",
    "image": null,
    "racine": "H202",
    "sens_principal": "Onan",
    "etymologie": "Dérivé de אוֹן (H0202, « vigueur, force ») avec suffixe ān. ·",
    "formes_derivees": [
      "H202"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 38:9",
      "texte": "S\\'il allait vers la femme de son frère, il se souillait à terre."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Onan est le deuxième fils de Juda. Après la mort de son frère aîné Er, il est tenu par la loi du lévirat (Deutéronome 25:5 10) d'épouser Tamar pour susciter une descendance à son frère défunt. Onan refuse cette obligation en pratiquant le coït interrompu. Son acte, motivé par le…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200104,
    "strong": "H210",
    "langue": "hebreu",
    "numero": 210,
    "mot_original": "אוּפָז",
    "translitteration": "ʾûp̄āz",
    "prononciation": "ʾûp̄āz",
    "definition": "Ophaz, région productrice d'or, peut-être identique à Ophir.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Daniel 10:5"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 2,
    "recherche": "h210 אוּפָז ʾûp̄āz ophaz, région productrice d'or, peut-être identique à ophir. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ophaz",
    "etymologie": "Toponyme d'origine incertaine. ·",
    "formes_derivees": [
      "H211",
      "H300"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Daniel 10:5",
      "texte": "Et voici un homme vêtu de lin, les reins ceints d\\'or d\\'Ophaz."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Ophaz est mentionné comme source d'or de qualité supérieure. La Septante lit parfois Ophir au lieu d'Ophaz, suggérant une identification ou une confusion entre les deux toponymes. L'or d'Ophaz est utilisé pour le placage des idoles (Jérémie 10:9) et pour la ceinture de l'ange en Daniel 10:5. La localisation exacte…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200105,
    "strong": "H211",
    "langue": "hebreu",
    "numero": 211,
    "mot_original": "אוֹפִיר",
    "translitteration": "ʾôp̄îr",
    "prononciation": "ʾôp̄îr",
    "definition": "Ophir, région légendaire productrice d'or fin, de pierres précieuses et de bois de santal.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 9:28"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 13,
    "recherche": "h211 אוֹפִיר ʾôp̄îr ophir, région légendaire productrice d'or fin, de pierres précieuses et de bois de santal. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ophir",
    "etymologie": "Nom de lieu d'origine incertaine. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 9:28",
      "texte": "Ils allèrent à Ophir et en rapportèrent quatre cent vingt talents d\\'or."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Ophir est célèbre dans la tradition biblique comme source de l'or le plus fin. Les expéditions commerciales de Salomon, menées avec l'aide des marins phéniciens de Hiram de Tyr, partaient d'Etsyôn Guéber (port sur la mer Rouge près d'Éilat) pour des voyages de trois ans. L'or d'Ophir (זְהַב אוֹפִיר) devint…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200106,
    "strong": "H212",
    "langue": "hebreu",
    "numero": 212,
    "mot_original": "אוֹפָן",
    "translitteration": "ʾôp̄ān",
    "prononciation": "ʾôp̄ān",
    "definition": "Roue, disque, tourbillon.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ézéchiel 1:16"
    ],
    "type": "nom commun",
    "occurrences": 15,
    "recherche": "h212 אוֹפָן ʾôp̄ān roue, disque, tourbillon. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Roue",
    "etymologie": "Racine אפן (ʾPN, « tourner, rouler »). · Syriaque : ܐܘܦܢܐ (ʾôp̄nā, « roue ») · Arabe : ʾafana (tourner) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ézéchiel 1:16",
      "texte": "L\\'aspect des roues et leur structure était comme l\\'éclat de la chrysolithe."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Les « roues » (ʾôp̄annîm) de la vision du char divin (Merkavah) en Ézéchiel 1 sont l'usage le plus célèbre du terme. Ces roues entrelacées, couvertes d'yeux, accompagnent les quatre créatures vivantes et symbolisent la mobilité universelle de la présence divine. La vision d'Ézéchiel a exercé une influence considérable sur…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200107,
    "strong": "H213",
    "langue": "hebreu",
    "numero": 213,
    "mot_original": "אוּץ",
    "translitteration": "ʾûṣ",
    "prononciation": "ʾûṣ",
    "definition": "Presser, se hâter, inciter, contraindre.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Proverbes 19:2"
    ],
    "type": "verbe",
    "occurrences": 10,
    "recherche": "h213 אוּץ ʾûṣ presser, se hâter, inciter, contraindre. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Presser",
    "etymologie": "Racine אוץ (ʾWṢ, « presser, pousser »). · Syriaque : ܐܘܨ (ʾûṣ, « presser, contraindre ») · Arabe : ʾāṣa (presser, pousser) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Proverbes 19:2",
      "texte": "Une âme sans connaissance n\\'est pas bonne, et celui qui se précipite de ses pieds commet une faute."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe exprime la hâte excessive et la précipitation, généralement déconseillée dans la littérature sapientielle. Proverbes 19:2 oppose la connaissance à la précipitation : agir sans réflexion conduit à la faute. En Exode 5:13, les surveillants égyptiens « pressent » les Hébreux d'achever leur quota de briques. En Ésaïe 22:4,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200108,
    "strong": "H214",
    "langue": "hebreu",
    "numero": 214,
    "mot_original": "אוֹצָר",
    "translitteration": "ʾôṣār",
    "prononciation": "ʾôṣār",
    "definition": "Trésor, magasin, entrepôt, réserve.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 28:12"
    ],
    "type": "nom commun",
    "occurrences": 79,
    "recherche": "h214 אוֹצָר ʾôṣār trésor, magasin, entrepôt, réserve. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Trésor",
    "etymologie": "Racine אצר (ʾṢR, « stocker, amasser, thésauriser »). · Syriaque : ܐܘܨܪܐ (ʾôṣārā, « trésor, magasin ») · Arabe : ʾaṣara (enfermer, contenir) · Akkadien : aṣāru (rassembler, collecter) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 28:12",
      "texte": "YHWH t\\'ouvrira son bon trésor, le ciel."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme désigne tout lieu de stockage de biens précieux : trésor royal, dépôt du Temple, grenier à grain, cellier à vin. Les « trésors du Temple » (אוֹצְרוֹת בֵּית־יְהוָה) contenaient les objets précieux, les métaux et les offrandes consacrées. Leur pillage par les ennemis (Shishaq, Ben Hadad, Nabuchodonosor) est…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200109,
    "strong": "H215",
    "langue": "hebreu",
    "numero": 215,
    "mot_original": "אוֹר",
    "translitteration": "ʾôr",
    "prononciation": "ʾôr",
    "definition": "Être lumineux, briller ; éclairer, illuminer.",
    "categorie": "Lumière et ténèbres",
    "references": [
      "Genèse 1:15"
    ],
    "type": "verbe",
    "occurrences": 43,
    "recherche": "h215 אוֹר ʾôr être lumineux, briller ; éclairer, illuminer. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Être lumineux",
    "etymologie": "Racine אור (ʾWR, « être brillant, lumineux »). · Syriaque : ܐܘܪ (ʾawwer, « illuminer ») · Arabe : ʾawira (être brillant) · Akkadien : urru (lumière, jour) · Ougaritique : ảr (lumière) ·",
    "formes_derivees": [
      "H216",
      "H3974"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 1:15",
      "texte": "Ils serviront de luminaires dans l\\'étendue du ciel pour éclairer la terre."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe et ses dérivés (אוֹר H0216, lumière ; מָאוֹר H3974, luminaire) forment un champ lexical fondamental de la cosmogonie biblique. Genèse 1 distingue la création de la lumière (אוֹר, jour 1) de la création des luminaires célestes (מְאֹרֹת, jour 4), subordonnant les astres à la lumière primordiale. La lumière…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200110,
    "strong": "H216",
    "langue": "hebreu",
    "numero": 216,
    "mot_original": "אוֹר",
    "translitteration": "ʾôr",
    "prononciation": "ʾôr",
    "definition": "Lumière, clarté, rayonnement.",
    "categorie": "Lumière et ténèbres",
    "references": [
      "Genèse 1:3",
      "Psaume 119:105"
    ],
    "type": "nom commun",
    "occurrences": 123,
    "recherche": "h216 אוֹר ʾôr lumière, clarté, rayonnement. nom commun",
    "audio": "",
    "image": null,
    "racine": "H215",
    "sens_principal": "Lumière",
    "etymologie": "Voir H0215. ·",
    "formes_derivees": [
      "H215"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 1:3",
      "texte": "Dieu dit : Que la lumière soit. Et la lumière fut."
    },
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La lumière est le premier élément créé dans le récit sacerdotal de la Genèse. Elle est distincte des luminaires célestes créés au quatrième jour, ce qui a suscité de nombreuses spéculations exégétiques. La lumière est associée à la vie, à la joie, à la justice et à la présence divine,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200111,
    "strong": "H217",
    "langue": "hebreu",
    "numero": 217,
    "mot_original": "אוּר",
    "translitteration": "ʾûr",
    "prononciation": "ʾûr",
    "definition": "Flamme, feu, lumière ardente.",
    "categorie": "Lumière et ténèbres",
    "references": [
      "Ésaïe 50:11"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h217 אוּר ʾûr flamme, feu, lumière ardente. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Flamme",
    "etymologie": "Variante de אוֹר (H0216, « lumière »), spécialisée pour la lumière du feu. · Syriaque : ܐܘܪܐ (ʾûrā, « feu, flamme ») · Arabe : ʾûr (feu, chaleur) ·",
    "formes_derivees": [
      "H216",
      "H224"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ésaïe 50:11",
      "texte": "Voici, vous tous qui allumez un feu, qui vous armez de torches : allez à la lumière de votre feu."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme ʾûr est une variante poétique et prophétique de ʾôr, spécifiquement associée au feu et à la chaleur. En Ésaïe 50:11, la lumière du feu allumé par les impies se retournera contre eux. La forme plurielle ʾûrîm désigne les Ourim (H0224), objets divinatoires associés au pectoral du grand prêtre.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200112,
    "strong": "H218",
    "langue": "hebreu",
    "numero": 218,
    "mot_original": "אוּר",
    "translitteration": "ʾûr",
    "prononciation": "ʾûr",
    "definition": "Ur, « Ur des Chaldéens », ville de Mésopotamie, patrie d'Abraham.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 11:31"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 4,
    "recherche": "h218 אוּר ʾûr ur, « ur des chaldéens », ville de mésopotamie, patrie d'abraham. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ur",
    "etymologie": "Translittération de l'akkadien Uru ou Uri(m). · Sumérien : Urim (nom de la ville) · Akkadien : Uru ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 11:31",
      "texte": "Ils sortirent avec eux d\\'Ur des Chaldéens."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Ur est identifiée à Tell el Muqayyar, dans le sud de l'Irak actuel, près de Nasiriyeh. Site majeur de la civilisation sumérienne, Ur fut un centre urbain et religieux de première importance, célèbre pour sa ziggourat dédiée au dieu lunaire Nanna/Sîn. Les fouilles de Sir Leonard Woolley (1922 1934) ont…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200113,
    "strong": "H219",
    "langue": "hebreu",
    "numero": 219,
    "mot_original": "אוֹרָה",
    "translitteration": "ʾôrāh",
    "prononciation": "ʾôrāh",
    "definition": "Lumière, clarté, aurore.",
    "categorie": "Lumière et ténèbres",
    "references": [
      "Psaume 139:12"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h219 אוֹרָה ʾôrāh lumière, clarté, aurore. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Lumière",
    "etymologie": "Forme féminine de אוֹר (H0216, « lumière »). ·",
    "formes_derivees": [
      "H216"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Psaume 139:12",
      "texte": "Même les ténèbres ne sont pas obscures pour toi, la nuit brille comme le jour, les ténèbres comme la lumière."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La forme féminine ʾôrāh est rare et exclusivement poétique. Elle apparaît dans des contextes d'antithèse lumière ténèbres, motif central de la spiritualité psalmique et prophétique. Ésaïe 26:19 l'emploie dans un oracle de résurrection : « ta rosée est une rosée de lumières » (טַל אוֹרֹת), métaphore de la revitalisation des…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200114,
    "strong": "H220",
    "langue": "hebreu",
    "numero": 220,
    "mot_original": "אֲוֵרָה",
    "translitteration": "ʾăwērāh",
    "prononciation": "ʾăwērāh",
    "definition": "Abri, étable, logement pour le bétail.",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h220 אֲוֵרָה ʾăwērāh abri, étable, logement pour le bétail. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Abri",
    "etymologie": "Racine אור (ʾWR) ou ארה (ʾRH, « rassembler, enfermer »). · Syriaque : ܐܪܘܬܐ (ʾārûṯā, « étable, crèche ») · Arabe : ʾarā (enfermer le bétail) ·",
    "formes_derivees": [
      "H221",
      "H300"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Rois 7:5",
      "texte": "Ils se levèrent au crépuscule pour aller au camp des Araméens ; ils arrivèrent à l\\'extrémité du camp."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'entrée Strong H0220 est problématique. Le terme n'est pas clairement attesté dans le texte massorétique standard. La lecture אֲוֵרוֹת en 2 Rois 7:5 est une conjecture de certains manuscrits ou commentaires, le texte reçu lisant généralement autre chose. L'entrée illustre les difficultés de la lexicographie des hapax à lecture incertaine.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200115,
    "strong": "H221",
    "langue": "hebreu",
    "numero": 221,
    "mot_original": "אוּרִי",
    "translitteration": "ʾûrî",
    "prononciation": "ʾûrî",
    "definition": "Ouri, « ma lumière » ou « lumière de YHWH » (forme abrégée de אוריה).",
    "categorie": "Lumière et ténèbres",
    "references": [
      "Exode 31:2"
    ],
    "type": "nom propre",
    "occurrences": 8,
    "recherche": "h221 אוּרִי ʾûrî ouri, « ma lumière » ou « lumière de yhwh » (forme abrégée de אוריה). nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ouri",
    "etymologie": "Forme abrégée de אוּרִיָּה (H0223, Ouriyah, « YHWH est ma lumière »), composé de אוּר (H0217, « lumière, feu ») + suffixe pronominal 1cs. ·",
    "formes_derivees": [
      "H217",
      "H223"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 31:2",
      "texte": "Vois, j\\'ai appelé par son nom Betsaléel, fils d\\'Ouri."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ouri, père de Betsaléel, appartient à la tribu de Juda. Son fils est le principal artisan du tabernacle, rempli de l'Esprit divin pour exécuter les ouvrages d'art sacré. La généalogie de Betsaléel le rattache à la lignée de Juda par Hetsrôn et Caleb (1 Chroniques 2:18 20). L'Ouri intendant de…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200116,
    "strong": "H222",
    "langue": "hebreu",
    "numero": 222,
    "mot_original": "אוּרִיאֵל",
    "translitteration": "ʾûrîʾēl",
    "prononciation": "ʾûrîʾēl",
    "definition": "Ouriel, « Dieu est ma lumière » ou « lumière de Dieu ».",
    "categorie": "Noms de Dieu",
    "references": [
      "1 Chroniques 15:5"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h222 אוּרִיאֵל ʾûrîʾēl ouriel, « dieu est ma lumière » ou « lumière de dieu ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ouriel",
    "etymologie": "Composé de אוּר (H0217, « lumière, feu ») + אֵל (H0410, « Dieu ») avec suffixe pronominal 1cs. ·",
    "formes_derivees": [
      "H217",
      "H410"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 15:5",
      "texte": "Pour les fils de Qehath : le chef Ouriel."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ouriel est un nom théophore yahwiste à élément El, porté par plusieurs personnages de l'époque davidique. Le chef lévite Ouriel participe au transfert de l'arche d'alliance à Jérusalem (1 Chroniques 15). La tradition apocryphe et rabbinique a développé la figure de l'ange Ouriel, l'un des quatre archanges, mais cet ange…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200117,
    "strong": "H223",
    "langue": "hebreu",
    "numero": 223,
    "mot_original": "אוּרִיָּה",
    "translitteration": "ʾûrîyāh",
    "prononciation": "ʾûrîyāh",
    "definition": "Ouriyah (Urie), « YHWH est ma lumière ».",
    "categorie": "Lumière et ténèbres",
    "references": [
      "2 Samuel 11:3"
    ],
    "type": "nom propre",
    "occurrences": 35,
    "recherche": "h223 אוּרִיָּה ʾûrîyāh ouriyah (urie), « yhwh est ma lumière ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ouriyah (Urie)",
    "etymologie": "Composé de אוּר (H0217, « lumière ») + יָהּ (H3050, abréviation de YHWH) avec suffixe pronominal 1cs. ·",
    "formes_derivees": [
      "H217",
      "H3050"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 11:3",
      "texte": "Il dit : N\\'est-ce pas Bethsabée\\... la femme d\\'Urie le Hittite ?"
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Urie le Hittite est l'un des personnages les plus tragiques de la Bible. Officier de l'armée davidique, d'origine étrangère (hittite ou hourrite), il fait preuve d'une loyauté exemplaire en refusant de dormir chez lui pendant la guerre. David, après l'avoir adultéré avec Bethsabée, ordonne son exposition au combat, causant sa…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200118,
    "strong": "H224",
    "langue": "hebreu",
    "numero": 224,
    "mot_original": "אוּרִים",
    "translitteration": "ʾûrîm",
    "prononciation": "ʾûrîm",
    "definition": "Ourim, objet divinatoire associé au pectoral du grand-prêtre.",
    "categorie": "Noms de Dieu",
    "references": [
      "Exode 28:30"
    ],
    "type": "nom commun (pluriel lexicalisé)",
    "occurrences": 7,
    "recherche": "h224 אוּרִים ʾûrîm ourim, objet divinatoire associé au pectoral du grand-prêtre. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ourim",
    "etymologie": "Pluriel de אוּר (H0217, « lumière, feu »). · Syriaque : ܐܘܪܝܡ (ʾûrîm) ·",
    "formes_derivees": [
      "H217"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 28:30",
      "texte": "Tu placeras dans le pectoral du jugement les Ourim et les Thoummim."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Les Ourim et Thoummim sont les objets divinatoires les plus mystérieux de la Bible. Placés dans le pectoral du grand prêtre, ils servaient à consulter YHWH dans les décisions importantes. Leur fonctionnement exact est inconnu : tirages au sort binaire (oui/non), manipulation de pierres précieuses, ou consultation oraculaire. La disparition…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200119,
    "strong": "H225",
    "langue": "hebreu",
    "numero": 225,
    "mot_original": "אוּת",
    "translitteration": "ʾûṯ",
    "prononciation": "ʾûṯ",
    "definition": "Consentir, accepter, être d'accord.",
    "categorie": "Vocabulaire courant",
    "references": [
      "2 Rois 12:9"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h225 אוּת ʾûṯ consentir, accepter, être d'accord. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Consentir",
    "etymologie": "Racine אות (ʾWT, « consentir, être d'accord »). · Syriaque : ܐܘܬ (ʾawweṯ, « consentir, accepter ») · Arabe : ʾāta (obéir, consentir) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Rois 12:9",
      "texte": "Les prêtres consentirent à ne plus prendre d\\'argent du peuple."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe apparaît dans le récit de la réparation du Temple sous Joas (2 Rois 12). Les prêtres acceptent de ne plus collecter directement les dons des fidèles, confiant la gestion financière à l'administration royale. Ce compromis reflète les tensions entre le sacerdoce et la couronne sur le contrôle des…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200120,
    "strong": "H226",
    "langue": "hebreu",
    "numero": 226,
    "mot_original": "אוֹת",
    "translitteration": "ʾôṯ",
    "prononciation": "ʾôṯ",
    "definition": "Signe, signal, marque, prodige, miracle.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 9:13",
      "Exode 31:13"
    ],
    "type": "nom commun",
    "occurrences": 79,
    "recherche": "h226 אוֹת ʾôṯ signe, signal, marque, prodige, miracle. nom commun",
    "audio": "",
    "image": null,
    "racine": "H184",
    "sens_principal": "Signe",
    "etymologie": "Racine אוה (ʾWH, « marquer, indiquer »), voir H0184. · Syriaque : ܐܬܐ (ʾāṯā, « signe, prodige ») · Arabe : ʾāyatun (signe, verset coranique) · Akkadien : ittu (signe, présage) ·",
    "formes_derivees": [
      "H184"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 9:13",
      "texte": "J\\'ai placé mon arc dans la nuée, et il sera signe d\\'alliance."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le concept de « signe » (ʾôṯ) est central dans la théologie biblique. Les signes miraculeux de l'Exode (plaies, traversée de la mer) fondent la foi d'Israël. Les signes d'alliance (arc en ciel, circoncision, sabbat) sont des mémoriaux permanents de l'engagement divin. La demande de signes prophétiques (Ésaïe 7:14 :…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200121,
    "strong": "H227",
    "langue": "hebreu",
    "numero": 227,
    "mot_original": "אָז",
    "translitteration": "ʾāz",
    "prononciation": "ʾāz",
    "definition": "Alors, à ce moment-là, en ce temps-là.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 15:1",
      "Psaume 126:2"
    ],
    "type": "adverbe",
    "occurrences": 140,
    "recherche": "h227 אָז ʾāz alors, à ce moment-là, en ce temps-là. adverbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Alors",
    "etymologie": "Particule temporelle sémitique. · Syriaque : ܐܝܙ (ʾāz, « alors ») · Arabe : ʾiḏ (quand, lorsque) · Akkadien : ez(zu) (alors) · Ougaritique : ảz (alors) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 15:1",
      "texte": "Alors Moïse et les fils d\\'Israël chantèrent."
    },
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "L'adverbe ʾāz structure la narration biblique en marquant les articulations temporelles majeures. Son usage dans le cantique de la mer (Exode 15:1), les cantiques de Débora (Juges 5) et les psaumes eschatologiques lui confère une solennité poétique. Il introduit fréquemment des actions divines décisives dans l'histoire.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200122,
    "strong": "H228",
    "langue": "hebreu",
    "numero": 228,
    "mot_original": "אֲזָא",
    "translitteration": "ʾăzāʾ",
    "prononciation": "ʾăzāʾ",
    "definition": "Aller, s'en aller (araméen). Doublet probable de H0230.",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "verbe (araméen)",
    "occurrences": 1,
    "recherche": "h228 אֲזָא ʾăzāʾ aller, s'en aller (araméen). doublet probable de h0230. verbe",
    "audio": "",
    "image": null,
    "racine": "H230",
    "sens_principal": "Aller",
    "etymologie": "Racine אזל (ʾZL, « aller, partir ») en araméen. · Syriaque : ܐܙܠ (ʾezal, « aller ») ·",
    "formes_derivees": [
      "H230"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Daniel 2:5",
      "texte": "Le roi répondit aux Chaldéens : La parole m\\'a échappé."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "verbe"
    ],
    "notes": "L'entrée Strong H0228 est problématique et probablement un doublet erroné de H0230 (אֲזַל) ou une confusion avec le mot perse אַזְדָּא (H0230). La lecture du passage de Daniel 2:5 est discutée. Pour les notes contextuelles, voir H0230.",
    "dialecte": "araméen",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200123,
    "strong": "H229",
    "langue": "hebreu",
    "numero": 229,
    "mot_original": "אֶזְבַּי",
    "translitteration": "ʾezbay",
    "prononciation": "ʾezbay",
    "definition": "Ezbay, père d'un guerrier de David.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 11:37"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h229 אֶזְבַּי ʾezbay ezbay, père d'un guerrier de david. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ezbay",
    "etymologie": "Nom d'origine incertaine. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 11:37",
      "texte": "Naaraï, fils d\\'Ezbay."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ezbay n'est connu que comme père de Naaraï, l'un des Trente guerriers de David (1 Chroniques 11:37). La liste parallèle de 2 Samuel 23:35 donne « Paaraï l'Arbite » au lieu de « Naaraï fils d'Ezbay », suggérant une variante textuelle ou une identification différente.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200124,
    "strong": "H230",
    "langue": "hebreu",
    "numero": 230,
    "mot_original": "אַזְדָּא",
    "translitteration": "ʾazdāʾ",
    "prononciation": "ʾazdāʾ",
    "definition": "Certain, sûr, décidé ; échapper (sens incertain en araméen).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 2:5"
    ],
    "type": "adjectif / participe (araméen)",
    "occurrences": 2,
    "recherche": "h230 אַזְדָּא ʾazdāʾ certain, sûr, décidé ; échapper (sens incertain en araméen). adjectif / participe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Certain",
    "etymologie": "Emprunt au vieux perse azdā (« connu, certain, annoncé »). · Syriaque : ܐܙܕܐ (ʾazdā, « certain, connu ») ·",
    "formes_derivees": [
      "H231",
      "H300"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Daniel 2:5",
      "texte": "La parole m\\'a échappé"
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "adjectif"
    ],
    "notes": "Le terme araméen ʾazdāʾ en Daniel 2:5 a donné lieu à deux interprétations concurrentes depuis l'Antiquité. La première (« la chose est décidée/ferme ») correspond au sens étymologique perse et est suivie par la Vulgate et de nombreuses versions modernes. La seconde (« la parole m'a échappé ») est une…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200125,
    "strong": "H231",
    "langue": "hebreu",
    "numero": 231,
    "mot_original": "אֵזוֹב",
    "translitteration": "ʾēzôḇ",
    "prononciation": "ʾēzôḇ",
    "definition": "Hysope, plante aromatique utilisée pour l'aspersion rituelle.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 12:22",
      "Psaume 51:9"
    ],
    "type": "nom commun",
    "occurrences": 10,
    "recherche": "h231 אֵזוֹב ʾēzôḇ hysope, plante aromatique utilisée pour l'aspersion rituelle. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Hysope",
    "etymologie": "Mot d'origine sémitique. · Syriaque : ܙܘܦܐ (zôp̄ā) · Arabe : zūfā · Grec : ὕσσωπος (hyssōpos, emprunt au sémitique) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 12:22",
      "texte": "Vous prendrez un bouquet d\\'hysope, vous le tremperez dans le sang."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'hysope biblique est probablement l'origan syrien (Origanum syriacum), plante aromatique vivace de la famille des Lamiacées, commune sur les coteaux rocailleux du Levant. Ses tiges ligneuses et ses feuilles velues retiennent bien les liquides, ce qui en fait un aspersoir naturel. Elle est utilisée dans les rites de purification (lépreux…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200126,
    "strong": "H232",
    "langue": "hebreu",
    "numero": 232,
    "mot_original": "אֵזוֹר",
    "translitteration": "ʾēzôr",
    "prononciation": "ʾēzôr",
    "definition": "Ceinture, pagne, écharpe portée autour des reins.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Jérémie 13:1"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h232 אֵזוֹר ʾēzôr ceinture, pagne, écharpe portée autour des reins. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ceinture",
    "etymologie": "Racine אזר (ʾZR, « ceindre, entourer »). · Syriaque : ܐܙܪܐ (ʾezārā, « ceinture ») · Arabe : ʾizār (pagne, vêtement de dessous) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Jérémie 13:1",
      "texte": "Va, achète-toi une ceinture de lin."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'ēzôr est un vêtement porté à même le corps, autour des reins, servant à maintenir les vêtements de dessus et à protéger le bas ventre. La ceinture de lin de Jérémie (Jérémie 13) est le support d'un acte prophétique symbolique : Jérémie l'enterre au bord de l'Euphrate, puis la retrouve…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200127,
    "strong": "H233",
    "langue": "hebreu",
    "numero": 233,
    "mot_original": "אֲזַי",
    "translitteration": "ʾăzay",
    "prononciation": "ʾăzay",
    "definition": "Alors, à ce moment-là. Variante poétique de אָז (H0227).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Psaume 124:3"
    ],
    "type": "adverbe",
    "occurrences": 3,
    "recherche": "h233 אֲזַי ʾăzay alors, à ce moment-là. variante poétique de אָז (h0227). adverbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Alors",
    "etymologie": "Forme allongée de אָז (H0227, « alors ») avec suffixe adverbial ay. ·",
    "formes_derivees": [
      "H227"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Psaume 124:3",
      "texte": "Alors ils nous auraient engloutis vivants."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "La forme allongée ʾăzay n'apparaît que dans le Psaume 124, cantique des montées attribué à David. Son usage exclusif dans ce psaume pourrait refléter une particularité stylistique ou dialectale du poète. Les trois occurrences structurent l'évocation rétrospective du danger évité.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200128,
    "strong": "H234",
    "langue": "hebreu",
    "numero": 234,
    "mot_original": "אַזְכָּרָה",
    "translitteration": "ʾazkārāh",
    "prononciation": "ʾazkārāh",
    "definition": "Mémorial, portion commémorative, offrande consumée sur l'autel en souvenir.",
    "categorie": "Sacrifice et offrande",
    "references": [
      "Lévitique 2:2"
    ],
    "type": "nom commun",
    "occurrences": 7,
    "recherche": "h234 אַזְכָּרָה ʾazkārāh mémorial, portion commémorative, offrande consumée sur l'autel en souvenir. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Mémorial",
    "etymologie": "Dérivé de la racine זכר (ZKR, « se souvenir, mentionner ») avec aleph prosthétique et suffixe āh. · Syriaque : ܐܕܟܪܢܐ (ʾaḏkārānā, « mémorial ») ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Lévitique 2:2",
      "texte": "Le prêtre en fera fumer la portion commémorative sur l\\'autel."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'azkārāh est une portion de l'offrande végétale (minḥah) prélevée par le prêtre et consumée sur l'autel. Le reste de l'offrande revient aux prêtres pour leur subsistance. La combustion de la « portion commémorative » produit une fumée odorante qui « fait souvenir » YHWH de l'offrant. Le terme est technique,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200129,
    "strong": "H235",
    "langue": "hebreu",
    "numero": 235,
    "mot_original": "אָזַל",
    "translitteration": "ʾāzal",
    "prononciation": "ʾāzal",
    "definition": "Aller, s'en aller, partir, disparaître.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 32:36"
    ],
    "type": "verbe",
    "occurrences": 6,
    "recherche": "h235 אָזַל ʾāzal aller, s'en aller, partir, disparaître. verbe",
    "audio": "",
    "image": null,
    "racine": "H236",
    "sens_principal": "Aller",
    "etymologie": "Racine אזל (ʾZL, « aller, partir »). · Syriaque : ܐܙܠ (ʾezal, « aller ») · Araméen : אֲזַל (H0236) · Arabe : ʾazala (disparaître, s'en aller) ·",
    "formes_derivees": [
      "H236",
      "H1980"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 32:36",
      "texte": "YHWH jugera son peuple\\... quand il verra que leur force est partie."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe ʾāzal est un synonyme rare de hālaḵ (aller), attesté dans des contextes poétiques ou archaïsants. L'expression « la force est partie » (אָזְלַת יָד, Deutéronome 32:36) signifie l'épuisement total. En Proverbes 20:14, l'acheteur « s'en va » après avoir déprécié la marchandise. La rareté du verbe en hébreu…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200130,
    "strong": "H236",
    "langue": "hebreu",
    "numero": 236,
    "mot_original": "אֲזַל",
    "translitteration": "ʾăzal",
    "prononciation": "ʾăzal",
    "definition": "Aller, s'en aller. Correspondance araméenne de l'hébreu אָזַל (H0235).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 5:8"
    ],
    "type": "verbe (araméen)",
    "occurrences": 7,
    "recherche": "h236 אֲזַל ʾăzal aller, s'en aller. correspondance araméenne de l'hébreu אָזַל (h0235). verbe",
    "audio": "",
    "image": null,
    "racine": "H235",
    "sens_principal": "Aller",
    "etymologie": "Voir H0235. ·",
    "formes_derivees": [
      "H235"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Esdras 5:8",
      "texte": "Nous sommes allés dans la province de Judée."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "verbe"
    ],
    "notes": "Le verbe ʾăzal est le verbe standard pour « aller » en araméen, correspondant à l'hébreu הָלַךְ. En Esdras, il apparaît dans les documents administratifs perses et les rapports des fonctionnaires. En Daniel, il est utilisé dans les récits de la cour babylonienne.",
    "dialecte": "araméen",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200131,
    "strong": "H237",
    "langue": "hebreu",
    "numero": 237,
    "mot_original": "אֶזֶל",
    "translitteration": "ʾezel",
    "prononciation": "ʾezel",
    "definition": "Ézel, nom d'une pierre ou d'un lieu près de Guibéa.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Samuel 20:19"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h237 אֶזֶל ʾezel ézel, nom d'une pierre ou d'un lieu près de guibéa. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ézel",
    "etymologie": "Nom de lieu d'origine incertaine. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 20:19",
      "texte": "Tu te tiendras près de la pierre d\\'Ézel."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "La pierre d'Ézel est le lieu convenu entre David et Jonathan pour communiquer secrètement les intentions de Saül (1 Samuel 20). Jonathan tire trois flèches comme signal, et le dialogue avec son serviteur code le message pour David caché à proximité. La scène est l'un des récits d'amitié les plus…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200132,
    "strong": "H238",
    "langue": "hebreu",
    "numero": 238,
    "mot_original": "אָזַן",
    "translitteration": "ʾāzan",
    "prononciation": "ʾāzan",
    "definition": "Prêter l'oreille, écouter attentivement, être attentif.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 32:1"
    ],
    "type": "verbe",
    "occurrences": 41,
    "recherche": "h238 אָזַן ʾāzan prêter l'oreille, écouter attentivement, être attentif. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Prêter l'oreille",
    "etymologie": "Verbe dénominatif de אֹזֶן (H0241, « oreille »). · Syriaque : ܐܕܢ (ʾaḏen, « écouter ») · Arabe : ʾuḏun (oreille) · Akkadien : uzun (oreille) ·",
    "formes_derivees": [
      "H241"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 32:1",
      "texte": "Cieux, prêtez l\\'oreille, et je parlerai."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe heʾĕzîn est un terme poétique et rhétorique, souvent utilisé en parallélisme avec שָׁמַע (entendre). Il introduit fréquemment des discours solennels, des appels prophétiques ou des cantiques. L'impératif haʾăzînû (« prêtez l'oreille ! ») est caractéristique des ouvertures de cantiques (Deutéronome 32, cantique de Moïse ; Juges 5, cantique…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200133,
    "strong": "H239",
    "langue": "hebreu",
    "numero": 239,
    "mot_original": "אָזַן",
    "translitteration": "ʾāzan",
    "prononciation": "ʾāzan",
    "definition": "Peser, équilibrer ; examiner attentivement.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ecclésiaste 12:9"
    ],
    "type": "verbe (piel)",
    "occurrences": 1,
    "recherche": "h239 אָזַן ʾāzan peser, équilibrer ; examiner attentivement. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Peser",
    "etymologie": "Racine probablement distincte de אזן « oreille », liée à מאזנים (balance). · Syriaque : ܐܙܢ (ʾezzan, « peser ») · Arabe : wazana (peser) ·",
    "formes_derivees": [
      "H238",
      "H3976"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ecclésiaste 12:9",
      "texte": "Il a pesé, examiné et arrangé beaucoup de proverbes."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "La distinction Strong entre H0238 (écouter) et H0239 (peser) sépare deux racines homographes. Le sens « peser, évaluer » apparaît en Ecclésiaste 12:9, décrivant le travail éditorial du Qohélet : il a collecté, évalué et organisé les proverbes. Ce sens est lié à מֹאזְנַיִם (balance, H3976).",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200134,
    "strong": "H240",
    "langue": "hebreu",
    "numero": 240,
    "mot_original": "אָזֵן",
    "translitteration": "ʾāzēn",
    "prononciation": "ʾāzēn",
    "definition": "Outil, instrument, arme ; variante rare de אֹזֶן ou mot distinct.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 23:14"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h240 אָזֵן ʾāzēn outil, instrument, arme ; variante rare de אֹזֶן ou mot distinct. nom commun",
    "audio": "",
    "image": null,
    "racine": "H241",
    "sens_principal": "Outil",
    "etymologie": "Voir H0241 ou racine distincte אזן « équiper, armer ». ·",
    "formes_derivees": [
      "H241",
      "H300"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 23:14",
      "texte": "Tu auras un piquet sur ton équipement"
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'entrée Strong H0240 est problématique et repose sur une lecture incertaine de Deutéronome 23:14. Le mot אֲזֵנֶךָ dans ce verset est généralement interprété comme dérivé de אֹזֶן (oreille) au sens métaphorique de « anse, poignée » ou rattaché à une racine distincte. La plupart des traductions modernes lisent « ton…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200135,
    "strong": "H241",
    "langue": "hebreu",
    "numero": 241,
    "mot_original": "אֹזֶן",
    "translitteration": "ʾōzen",
    "prononciation": "ʾōzen",
    "definition": "Oreille, organe de l'ouïe ; anse, poignée.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 29:3",
      "Psaume 40:7"
    ],
    "type": "nom commun",
    "occurrences": 187,
    "recherche": "h241 אֹזֶן ʾōzen oreille, organe de l'ouïe ; anse, poignée. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Oreille",
    "etymologie": "Racine אזן (ʾZN, « entendre, écouter »). · Ougaritique : ủdn (oreille) · Syriaque : ܐܕܢܐ (ʾeḏnā) · Arabe : ʾuḏun · Akkadien : uzun ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 29:3",
      "texte": "YHWH ne vous a pas donné un cœur pour connaître, ni des yeux pour voir, ni des oreilles pour entendre."
    },
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'oreille est présentée dans la Bible comme l'organe de l'obéissance autant que de l'audition. L'expression « découvrir l'oreille » (גָּלָה אֹזֶן) signifie révéler un secret ou communiquer une révélation divine. Le percement de l'oreille de l'esclave volontaire (Exode 21:6) est un rite de passage marquant l'appartenance permanente au maître. La…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200136,
    "strong": "H242",
    "langue": "hebreu",
    "numero": 242,
    "mot_original": "אוּזֵן שֶׁאֱרָה",
    "translitteration": "ʾûzēn šeʾĕrāh",
    "prononciation": "ʾûzēn šeʾĕrāh",
    "definition": "Ouzen-Shééra, ville bâtie par Shééra, fille d'Éphraïm.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 7:24"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h242 אוּזֵן שֶׁאֱרָה ʾûzēn šeʾĕrāh ouzen-shééra, ville bâtie par shééra, fille d'éphraïm. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ouzen Shééra",
    "etymologie": "Composé de אוּזֵן (peut être « oreille » au sens de « sommet, hauteur » ou nom propre) + שֶׁאֱרָה (nom de personne féminin). ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 7:24",
      "texte": "Sa fille Shééra bâtit Beth-Horon le Bas, Beth-Horon le Haut, et Ouzen-Shééra."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Shééra est l'une des rares femmes mentionnées comme fondatrices de villes dans la Bible. Descendante d'Éphraïm, elle édifie Beth Horon (le Bas et le Haut) et Ouzen Shééra. Ces localités sont situées dans le territoire éphraïmite, au nord ouest de Jérusalem. La notice des Chroniques conserve le souvenir d'une figure…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200137,
    "strong": "H243",
    "langue": "hebreu",
    "numero": 243,
    "mot_original": "אַזְנוֹת תָּבוֹר",
    "translitteration": "ʾAznôwth Tâbôwr",
    "prononciation": "ʾAznôwth Tâbôwr",
    "definition": "Aznoth-Tabor, localité frontalière du territoire de Nephtali, près du mont Thabor.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Josué 19:34"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h243 אַזְנוֹת תָּבוֹר ʾaznôwth tâbôwr aznoth-tabor, localité frontalière du territoire de nephtali, près du mont thabor. nom propre",
    "audio": "",
    "image": null,
    "racine": "H242",
    "sens_principal": "Ouzen",
    "etymologie": "Voir H0242. ·",
    "formes_derivees": [
      "H242"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Cette entrée Strong est un doublet artificiel de H0242, isolant le premier élément du toponyme composé. Pour les notes contextuelles, voir H0242.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200138,
    "strong": "H244",
    "langue": "hebreu",
    "numero": 244,
    "mot_original": "אָזְנִי",
    "translitteration": "ʾāznî",
    "prononciation": "ʾāznî",
    "definition": "Ozni, ancêtre éponyme du clan oznite, de la tribu de Gad.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Nombres 26:16"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h244 אָזְנִי ʾāznî ozni, ancêtre éponyme du clan oznite, de la tribu de gad. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ozni",
    "etymologie": "Nom d'origine incertaine. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 26:16",
      "texte": "D\\'Ozni, la famille des Oznites."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ozni est le chef éponyme d'un clan gadite. La divergence onomastique entre Nombres 26:16 (אָזְנִי) et Genèse 46:16 (אֶצְבֹּן) illustre les variantes dans les listes généalogiques des tribus. Le clan oznite fait partie des sept clans de Gad recensés dans les plaines de Moab avant l'entrée en Canaan.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200139,
    "strong": "H245",
    "langue": "hebreu",
    "numero": 245,
    "mot_original": "אֲזַנְיָה",
    "translitteration": "ʾăzanyāh",
    "prononciation": "ʾăzanyāh",
    "definition": "Azaniah, « YHWH a entendu » ou « YHWH écoute ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Néhémie 10:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h245 אֲזַנְיָה ʾăzanyāh azaniah, « yhwh a entendu » ou « yhwh écoute ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Azaniah",
    "etymologie": "Composé de אָזַן (H0238, « écouter, prêter l'oreille ») + יָהּ (H3050, abréviation de YHWH). ·",
    "formes_derivees": [
      "H238",
      "H3050"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Néhémie 10:10",
      "texte": "Josué, fils d\\'Azaniah."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Azaniah est le père d'un des signataires lévitiques de l'engagement solennel de Néhémie 10. Ce document, scellé par les chefs du peuple, les prêtres et les lévites, énumère les obligations acceptées par la communauté post exilique : observance du sabbat, année sabbatique, contributions au Temple, offrandes et dîmes.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200140,
    "strong": "H246",
    "langue": "hebreu",
    "numero": 246,
    "mot_original": "אֲזִקִּים",
    "translitteration": "ʾăziqqîm",
    "prononciation": "ʾăziqqîm",
    "definition": "Chaînes, menottes, liens.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Jérémie 40:1"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h246 אֲזִקִּים ʾăziqqîm chaînes, menottes, liens. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Chaînes",
    "etymologie": "Racine אזק (ʾZQ, « lier, enchaîner »). · Syriaque : ܐܙܩܐ (ʾezqā, « chaîne, anneau ») · Arabe : ʾaziqa (être lié) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Jérémie 40:1",
      "texte": "Enchaîné parmi tous les déportés de Jérusalem."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme apparaît dans le récit de la libération de Jérémie après la chute de Jérusalem (587 avant l'ère courante). Le prophète, enchaîné avec les autres déportés, est libéré par Nebouzaradan, chef des gardes de Nabuchodonosor, conformément aux ordres du roi babylonien (Jérémie 39:11 14). Le terme technique désigne les…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200141,
    "strong": "H247",
    "langue": "hebreu",
    "numero": 247,
    "mot_original": "אָזַר",
    "translitteration": "ʾāzar",
    "prononciation": "ʾāzar",
    "definition": "Ceindre, entourer, revêtir (spécialement d'une ceinture ou de force).",
    "categorie": "Puissance et autorité",
    "references": [
      "Jérémie 1:17",
      "Psaume 93:1"
    ],
    "type": "verbe",
    "occurrences": 16,
    "recherche": "h247 אָזַר ʾāzar ceindre, entourer, revêtir (spécialement d'une ceinture ou de force). verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ceindre",
    "etymologie": "Racine אזר (ʾZR, « ceindre, entourer »). · Syriaque : ܐܙܪ (ʾezar, « ceindre ») · Arabe : ʾazara (entourer, ceindre) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Jérémie 1:17",
      "texte": "Toi, tu ceindras tes reins."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "L'action de ceindre les reins consiste à retrousser et attacher le vêtement long à la taille pour libérer les jambes, geste préparatoire au travail, au combat ou à la marche rapide. L'expression « ceins tes reins » (אֱזֹר מָתְנֶיךָ) est un ordre de préparation immédiate à l'action (Jérémie 1:17 ;…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200142,
    "strong": "H248",
    "langue": "hebreu",
    "numero": 248,
    "mot_original": "אֶזְרוֹעַ",
    "translitteration": "ʾezrôaʿ",
    "prononciation": "ʾezrôaʿ",
    "definition": "Bras, avant-bras. Variante poétique de זְרוֹעַ (H2220).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Jérémie 32:21"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h248 אֶזְרוֹעַ ʾezrôaʿ bras, avant-bras. variante poétique de זְרוֹעַ (h2220). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Bras",
    "etymologie": "Forme avec aleph prosthétique de זְרוֹעַ (H2220, « bras »), racine זרע (ZRʿ, « semer, étendre »). · Syriaque : ܕܪܥܐ (dərāʿā) · Arabe : ḏirāʿ ·",
    "formes_derivees": [
      "H2220"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Jérémie 32:21",
      "texte": "Tu fis sortir ton peuple Israël du pays d\\'Égypte\\... à main forte et à bras étendu."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme est une variante poétique de זְרוֹעַ (bras), utilisée exclusivement dans des contextes solennels. L'expression « à main forte et à bras étendu » est la formule deutéronomique standard pour décrire la puissance divine lors de l'Exode. Le bras est le symbole de la force agissante de Dieu dans…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200143,
    "strong": "H249",
    "langue": "hebreu",
    "numero": 249,
    "mot_original": "אֶזְרָח",
    "translitteration": "ʾezrāḥ",
    "prononciation": "ʾezrāḥ",
    "definition": "Autochtone, indigène, citoyen de naissance.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Lévitique 19:34"
    ],
    "type": "nom commun / adjectif",
    "occurrences": 18,
    "recherche": "h249 אֶזְרָח ʾezrāḥ autochtone, indigène, citoyen de naissance. nom commun / adjectif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Autochtone",
    "etymologie": "Racine זרח (ZRḤ, « se lever, briller »), avec aleph prosthétique. Littéralement « celui qui s'est levé [du sol] », c'est à dire « indigène, né dans le pays ». · Syriaque : ܐܙܪܚܐ (ʾezrāḥā, « indigène, citoyen ») ·…",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Lévitique 19:34",
      "texte": "L\\'étranger résidant parmi vous sera pour vous comme l\\'autochtone."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "La distinction entre ʾezrāḥ (autochtone) et gēr (étranger résident) est fondamentale dans la législation sacerdotale. L'ʾezrāḥ jouit de la plénitude des droits civils et cultuels ; le gēr bénéficie d'une protection juridique étendue mais reste partiellement exclu de certains privilèges (possession de la terre). Lévitique 19:34 ordonne d'aimer le gēr…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200144,
    "strong": "H250",
    "langue": "hebreu",
    "numero": 250,
    "mot_original": "אֶזְרָחִי",
    "translitteration": "ʾezrāḥî",
    "prononciation": "ʾezrāḥî",
    "definition": "Ezrahite, membre du clan d'Ézer ou de Zérah.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 5:11"
    ],
    "type": "nom propre / adjectif gentilé",
    "occurrences": 3,
    "recherche": "h250 אֶזְרָחִי ʾezrāḥî ezrahite, membre du clan d'ézer ou de zérah. nom propre / adjectif gentilé",
    "audio": "",
    "image": null,
    "racine": "H249",
    "sens_principal": "Ezrahite",
    "etymologie": "Dérivé de אֶזְרָח (H0249, « autochtone ») avec suffixe î, ou gentilé de זֶרַח (H2226, Zérah). ·",
    "formes_derivees": [
      "H249",
      "H251",
      "H300",
      "H2226"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 5:11",
      "texte": "Il fut plus sage que tout homme, plus qu\\'Éthan l\\'Ezrahite."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Éthan et Hémân l'Ezrahite sont cités comme des sages renommés, comparés à Salomon (1 Rois 5:11). Les Psaumes 88 et 89 leur sont attribués. L'identification précise de ce clan ou titre reste débattue : certains y voient des membres du clan judéen de Zérah, d'autres des sages « autochtones »…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200145,
    "strong": "H251",
    "langue": "hebreu",
    "numero": 251,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Frère, parent, compatriote, prochain.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 4:9",
      "Lévitique 19:17"
    ],
    "type": "nom commun",
    "occurrences": 629,
    "recherche": "h251 אָח ʾāḥ frère, parent, compatriote, prochain. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Frère",
    "etymologie": "Racine sémitique ʾḤ. · Akkadien : aḫu · Ougaritique : ảḫ · Syriaque : ܐܚܐ (ʾaḥā) · Arabe : ʾaḫ ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 4:9",
      "texte": "Suis-je le gardien de mon frère ?"
    },
    "niveau": "Très fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme ʾāḥ couvre un spectre relationnel étendu : lien biologique, appartenance clanique, solidarité nationale. La législation deutéronomique et sacerdotale utilise systématiquement « ton frère » pour désigner le compatissable israélite, fondant l'éthique sociale sur la métaphore familiale. La « fraternité » israélite implique des obligations concrètes : rachat du…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200146,
    "strong": "H252",
    "langue": "hebreu",
    "numero": 252,
    "mot_original": "אַח",
    "translitteration": "ʾaḥ",
    "prononciation": "ʾaḥ",
    "definition": "Frère. Correspondance araméenne de l'hébreu אָח (H0251).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 7:18"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 1,
    "recherche": "h252 אַח ʾaḥ frère. correspondance araméenne de l'hébreu אָח (h0251). nom commun",
    "audio": "",
    "image": null,
    "racine": "H251",
    "sens_principal": "Frère",
    "etymologie": "Voir H0251. ·",
    "formes_derivees": [
      "H251"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Esdras 7:18",
      "texte": "Ce qui te semblera bon, à toi et à tes frères."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "Le terme araméen ʾaḥ est rare dans la Bible. Il apparaît dans les documents administratifs d'Esdras. La distinction Strong entre H0251 (hébreu) et H0252 (araméen) est purement contextuelle, la graphie consonantique étant souvent identique.",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200147,
    "strong": "H253",
    "langue": "hebreu",
    "numero": 253,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Ézéchiel 6:11"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h253 אָח ʾāḥ ah ! hélas ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ah ! Hélas ! Exclamation de",
    "etymologie": "Onomatopée, distincte du nom אָח (frère). · Syriaque : ܐܚ (ʾāḥ, exclamation de douleur) · Arabe : ʾāḥ (hélas) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ézéchiel 6:11",
      "texte": "Frappe de ta main, tape du pied, et dis : Ah !"
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "interjection"
    ],
    "notes": "L'interjection ʾāḥ est un cri de lamentation prophétique, accompagné de gestes de deuil (frapper des mains, taper du pied). Elle exprime l'horreur devant les abominations et le châtiment imminent. Distincte du nom « frère » par le contexte et probablement la vocalisation, elle illustre l'homonymie fréquente dans le lexique hébreu.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Interjection"
  },
  {
    "id": 200148,
    "strong": "H254",
    "langue": "hebreu",
    "numero": 254,
    "mot_original": "אָח",
    "translitteration": "ʾāḥ",
    "prononciation": "ʾāḥ",
    "definition": "Brasero, foyer, réchaud.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Jérémie 36:22"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h254 אָח ʾāḥ brasero, foyer, réchaud. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Brasero",
    "etymologie": "Racine אחח (ʾḤḤ, « brûler, être chaud ») ou mot distinct de אָח (frère). · Syriaque : ܐܚܐ (ʾāḥā, « brasero ») · Arabe : ʾaḫḫa (être chaud, brûler) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Jérémie 36:22",
      "texte": "Le roi était assis dans la maison d\\'hiver\\... avec un brasero allumé devant lui."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le brasero est mentionné dans le récit de la destruction du rouleau de Jérémie par le roi Yoyaqim (Jérémie 36). Le roi, assis dans ses appartements d'hiver, coupe le rouleau avec un canif et le jette au feu du brasero. Cet épisode illustre le rejet de la parole prophétique par…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200149,
    "strong": "H255",
    "langue": "hebreu",
    "numero": 255,
    "mot_original": "אֹחַ",
    "translitteration": "ʾōaḥ",
    "prononciation": "ʾōaḥ",
    "definition": "Hibou, chat-huant, animal des ruines.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ésaïe 13:21"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h255 אֹחַ ʾōaḥ hibou, chat-huant, animal des ruines. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Hibou",
    "etymologie": "Onomatopée imitant le cri de l'animal. · Syriaque : ܐܚܐ (ʾāḥā, « hibou ») · Arabe : ʾūḥ (cri du hibou) ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Ésaïe 13:21",
      "texte": "Les bêtes du désert y auront leur gîte, les hiboux rempliront leurs maisons."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le hibou figure dans l'oracle contre Babylone (Ésaïe 13) parmi les animaux sauvages qui hanteront les ruines de la ville après sa destruction. Ce bestiaire des ruines (hiboux, autruches, chacals, hyènes) est un motif récurrent des oracles prophétiques contre les nations. La présence de ces animaux symbolise la désolation totale…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200150,
    "strong": "H256",
    "langue": "hebreu",
    "numero": 256,
    "mot_original": "אַחְאָב",
    "translitteration": "ʾaḥʾāḇ",
    "prononciation": "ʾaḥʾāḇ",
    "definition": "Achab, « frère du père » ou « oncle paternel ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 16:30"
    ],
    "type": "nom propre",
    "occurrences": 93,
    "recherche": "h256 אַחְאָב ʾaḥʾāḇ achab, « frère du père » ou « oncle paternel ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Achab",
    "etymologie": "Composé de אָח (H0251, « frère ») + אָב (H0001, « père »). ·",
    "formes_derivees": [
      "H1",
      "H251"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 16:30",
      "texte": "Achab, fils d\\'Omri, fit ce qui est mal aux yeux de YHWH, plus que tous ceux qui l\\'avaient précédé."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Achab est l'un des rois les plus documentés de l'Ancien Testament. Les sources assyriennes (monolithe de Kurkh) mentionnent sa participation à la coalition anti assyrienne de Qarqar (853 avant l'ère courante) avec 2000 chars et 10 000 fantassins, contingent le plus important après celui de Damas. La Bible présente Achab…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200151,
    "strong": "H257",
    "langue": "hebreu",
    "numero": 257,
    "mot_original": "אַחְבָּן",
    "translitteration": "ʾaḥbān",
    "prononciation": "ʾaḥbān",
    "definition": "Ahban, descendant de Juda par Yerakhméel.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 2:29"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h257 אַחְבָּן ʾaḥbān ahban, descendant de juda par yerakhméel. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahban",
    "etymologie": "Nom d'origine incertaine. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 2:29",
      "texte": "Les fils d\\'Abishur furent\\... Ahban et Molid."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahban est mentionné dans la généalogie de Yerakhméel (1 Chroniques 2:25 41), branche de la tribu de Juda. Ces listes généalogiques, caractéristiques du Chroniste, conservent les noms de clans judéens dont l'histoire n'est pas rapportée ailleurs.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200152,
    "strong": "H258",
    "langue": "hebreu",
    "numero": 258,
    "mot_original": "אָחַד",
    "translitteration": "ʾāḥaḏ",
    "prononciation": "ʾāḥaḏ",
    "definition": "S'unir, être uni, ne faire qu'un.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 49:6"
    ],
    "type": "verbe",
    "occurrences": 3,
    "recherche": "h258 אָחַד ʾāḥaḏ s'unir, être uni, ne faire qu'un. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "S'unir",
    "etymologie": "Racine אחד (ʾḤD, « être un, unique »). · Syriaque : ܐܚܕ (ʾeḥaḏ, « unir, saisir ») · Arabe : ʾaḥada (prendre, saisir) ·",
    "formes_derivees": [
      "H259"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 49:6",
      "texte": "Que mon âme n\\'entre pas dans leur conseil, que ma gloire ne s\\'unisse pas à leur assemblée."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe est rare et poétique. En Genèse 49:6, Jacob refuse que son honneur « s'unisse » à l'assemblée de Siméon et Lévi après le massacre de Sichem. L'expression exprime la dissociation morale et la réprobation. En Michée 2:12, Dieu promet de « rassembler » et « unir » le…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200153,
    "strong": "H259",
    "langue": "hebreu",
    "numero": 259,
    "mot_original": "אֶחָד",
    "translitteration": "ʾeḥāḏ",
    "prononciation": "ʾeḥāḏ",
    "definition": "Un, unique, premier, seul.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 6:4",
      "Genèse 2:24"
    ],
    "type": "adjectif numéral",
    "occurrences": 962,
    "recherche": "h259 אֶחָד ʾeḥāḏ un, unique, premier, seul. adjectif numéral",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Un",
    "etymologie": "Racine אחד (ʾḤD, « être un »). · Ougaritique : ảḥd · Syriaque : ܚܕ (ḥaḏ) · Arabe : ʾaḥad · Akkadien : ēdu ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Deutéronome 6:4",
      "texte": "Écoute, Israël : YHWH notre Dieu, YHWH est un."
    },
    "niveau": "Très fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Le numéral ʾeḥāḏ a une importance théologique considérable. Le Shéma Israël (Deutéronome 6:4) proclame l'unicité de YHWH, fondement du monothéisme israélite. La formule « une seule chair » (Genèse 2:24) fonde la conception biblique du mariage. L'unicité du sanctuaire central (Deutéronome 12) découle de l'unicité divine. Le terme exprime aussi…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200154,
    "strong": "H260",
    "langue": "hebreu",
    "numero": 260,
    "mot_original": "אָחוּ",
    "translitteration": "ʾāḥû",
    "prononciation": "ʾāḥû",
    "definition": "Jonc, roseau, papyrus ; pâturage marécageux.",
    "categorie": "Eau et baptême",
    "references": [
      "Genèse 41:2"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h260 אָחוּ ʾāḥû jonc, roseau, papyrus ; pâturage marécageux. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Jonc",
    "etymologie": "Emprunt à l'égyptien ỉḥy ou ʾḥ (« fourré de papyrus »). · Syriaque : ܐܚܘ (ʾāḥû, « jonc, papyrus ») · Copte : ⲁϩⲱ (ahō, « champ, prairie ») ·",
    "formes_derivees": [
      "H261",
      "H300"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 41:2",
      "texte": "Sept vaches montèrent du Nil\\... et elles paissaient dans les joncs."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme ʾāḥû désigne la végétation palustre du Nil dans le songe de Pharaon (Genèse 41). Les vaches paissant dans les joncs représentent l'Égypte nilotique. Le mot est un emprunt direct à l'égyptien, confirmant l'ancrage du récit de Joseph dans l'environnement égyptien. En Job 8:11, le jonc qui croît sans…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200155,
    "strong": "H261",
    "langue": "hebreu",
    "numero": 261,
    "mot_original": "אֵחוּד",
    "translitteration": "ʾēḥûḏ",
    "prononciation": "ʾēḥûḏ",
    "definition": "Éhoud, chef benjaminite. Variante orthographique de אֵהוּד (H0164).",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 8:6"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h261 אֵחוּד ʾēḥûḏ éhoud, chef benjaminite. variante orthographique de אֵהוּד (h0164). nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Éhoud",
    "etymologie": "Variante graphique de אֵהוּד (H0164). ·",
    "formes_derivees": [
      "H164"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 8:6",
      "texte": "Voici les fils d\\'Éhoud ; ce sont les chefs de famille."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Éhoud ben Guéra est mentionné dans la généalogie benjaminite de 1 Chroniques 8 parmi les chefs de famille. Le même nom est porté par le juge libérateur (H0164). La distinction entre les deux personnages est probable : le juge Éhoud appartient à une époque antérieure. La variante orthographique (aleph au…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200156,
    "strong": "H262",
    "langue": "hebreu",
    "numero": 262,
    "mot_original": "אַחְוָה",
    "translitteration": "ʾaḥwāh",
    "prononciation": "ʾaḥwāh",
    "definition": "Déclaration, parole, annonce.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Psaume 19:3",
      "Zacharie 11:7"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h262 אַחְוָה ʾaḥwāh déclaration, parole, annonce. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Déclaration",
    "etymologie": "Racine חוה (ḤWH, « annoncer, déclarer ») pour le Psaume 19 ; racine אח (ʾḤ, « frère ») pour Zacharie 11. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Psaume 19:3",
      "texte": "Le jour au jour en fait le récit, la nuit à la nuit en donne connaissance."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme présente deux acceptions distinctes selon les occurrences. En Psaume 19:3, il s'agit d'une déclaration orale (sens lié à la racine חוה). En Zacharie 11, le prophète incarne un berger symbolique dont les deux houlettes portent des noms allégoriques : Grâce (נֹעַם) et Union (אַחְוָה, dérivé de אָח, frère).…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200157,
    "strong": "H263",
    "langue": "hebreu",
    "numero": 263,
    "mot_original": "אַחְוָה",
    "translitteration": "ʾaḥwāh",
    "prononciation": "ʾaḥwāh",
    "definition": "Déclaration, explication, interprétation.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 5:12"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 1,
    "recherche": "h263 אַחְוָה ʾaḥwāh déclaration, explication, interprétation. nom commun",
    "audio": "",
    "image": null,
    "racine": "H262",
    "sens_principal": "Déclaration",
    "etymologie": "Forme araméenne correspondant à l'hébreu אַחְוָה (H0262, « déclaration »). · Syriaque : ܐܚܘܝܬܐ (ʾaḥwāyṯā, « déclaration, explication ») ·",
    "formes_derivees": [
      "H262"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Daniel 5:12",
      "texte": "En qui se trouve un esprit supérieur\\... pour donner des explications."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "Le terme araméen apparaît dans le discours de la reine mère à Belschatsar (Daniel 5). Elle recommande Daniel pour interpréter l'inscription sur le mur, louant sa capacité à « donner des explications » (אַחְוָיַת) de mystères. Le terme est technique, désignant le déchiffrement de signes énigmatiques.",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200158,
    "strong": "H264",
    "langue": "hebreu",
    "numero": 264,
    "mot_original": "אַחֲוָה",
    "translitteration": "ʾaḥăwāh",
    "prononciation": "ʾaḥăwāh",
    "definition": "Fraternité, union fraternelle. Variante orthographique de H0262.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Zacharie 11:14"
    ],
    "type": "nom commun",
    "occurrences": 0,
    "recherche": "h264 אַחֲוָה ʾaḥăwāh fraternité, union fraternelle. variante orthographique de h0262. nom commun",
    "audio": "",
    "image": null,
    "racine": "H262",
    "sens_principal": "Fraternité",
    "etymologie": "Voir H0262. ·",
    "formes_derivees": [
      "H262"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Zacharie 11:14",
      "texte": "Je brisai ma seconde houlette, Union, pour rompre la fraternité entre Juda et Israël."
    },
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Cette entrée est un doublet de H0262. Pour les notes contextuelles, voir H0262. La forme אַחֲוָה avec patah sous le ḥet est la vocalisation spécifique de Zacharie 11:14.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200159,
    "strong": "H265",
    "langue": "hebreu",
    "numero": 265,
    "mot_original": "אֲחוֹחַ",
    "translitteration": "ʾăḥôaḥ",
    "prononciation": "ʾăḥôaḥ",
    "definition": "Ahoah, descendant de Benjamin, ancêtre du clan ahoahite.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 8:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h265 אֲחוֹחַ ʾăḥôaḥ ahoah, descendant de benjamin, ancêtre du clan ahoahite. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahoah",
    "etymologie": "Nom d'origine incertaine. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 8:4",
      "texte": "Les fils de Béla furent\\... et Ahoah."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahoah est l'ancêtre éponyme des Ahoahites, clan benjaminite de guerriers d'élite. Les Ahoahites sont mentionnés parmi les Trente guerriers de David (2 Samuel 23:9, 28 ; 1 Chroniques 11:12, 29). Le clan était réputé pour sa vaillance militaire.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200160,
    "strong": "H266",
    "langue": "hebreu",
    "numero": 266,
    "mot_original": "אֲחוֹחִי",
    "translitteration": "ʾăḥôḥî",
    "prononciation": "ʾăḥôḥî",
    "definition": "Ahoahite, membre du clan d'Ahoah.",
    "categorie": "Vocabulaire courant",
    "references": [
      "2 Samuel 23:9"
    ],
    "type": "adjectif gentilé",
    "occurrences": 4,
    "recherche": "h266 אֲחוֹחִי ʾăḥôḥî ahoahite, membre du clan d'ahoah. adjectif gentilé",
    "audio": "",
    "image": null,
    "racine": "H265",
    "sens_principal": "Ahoahite",
    "etymologie": "Gentilé dérivé de אֲחוֹחַ (H0265). ·",
    "formes_derivees": [
      "H265"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 23:9",
      "texte": "Éléazar, fils de Dodo, fils d\\'Ahoah."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Voir H0265. Éléazar ben Dodo l'Ahoahite est l'un des Trois guerriers d'élite de David (2 Samuel 23:9 10), célèbre pour avoir combattu les Philistins jusqu'à l'épuisement.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200161,
    "strong": "H267",
    "langue": "hebreu",
    "numero": 267,
    "mot_original": "אֲחוּמַי",
    "translitteration": "ʾăḥûmay",
    "prononciation": "ʾăḥûmay",
    "definition": "Ahoumaï, descendant de Juda par Shobal.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 4:2"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h267 אֲחוּמַי ʾăḥûmay ahoumaï, descendant de juda par shobal. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahoumaï",
    "etymologie": "Nom d'origine incertaine. ·",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 4:2",
      "texte": "Reaïa, fils de Shobal, engendra Yaḥath\\... Ce sont les familles des Ahoumites."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahoumaï est l'ancêtre éponyme d'un clan judéen rattaché à la lignée de Shobal, lui même descendant de Juda par Hetsrôn. La généalogie de 1 Chroniques 4 énumère les clans de Juda avec leurs localités et leurs activités économiques (potiers, tisserands).",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200162,
    "strong": "H268",
    "langue": "hebreu",
    "numero": 268,
    "mot_original": "אָחוֹר",
    "translitteration": "ʾāḥôr",
    "prononciation": "ʾāḥôr",
    "definition": "Arrière, dos, partie postérieure ; en arrière.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 49:17",
      "Jérémie 7:24"
    ],
    "type": "nom commun / adverbe",
    "occurrences": 41,
    "recherche": "h268 אָחוֹר ʾāḥôr arrière, dos, partie postérieure ; en arrière. nom commun / adverbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Arrière",
    "etymologie": "Racine אחר (ʾḤR, « être derrière, après »). · Syriaque : ܐܚܘܪ (ʾāḥôr, « arrière ») · Arabe : ʾuḫur (derrière, après) · Akkadien : aḫar (derrière) ·",
    "formes_derivees": [
      "H310"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 49:17",
      "texte": "Dan sera un serpent sur le chemin\\... mordant les talons du cheval, et le cavalier tombe en arrière."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme ʾāḥôr et sa forme locative ʾāḥōrannîṯ (« en arrière ») sont fréquents dans la littérature prophétique pour décrire l'apostasie ou la défaite. « Aller en arrière et non en avant » (Jérémie 7:24) est une métaphore de la régression spirituelle. La chute en arrière du cavalier (Genèse 49:17)…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200163,
    "strong": "H269",
    "langue": "hebreu",
    "numero": 269,
    "mot_original": "אָחוֹת",
    "translitteration": "ʾāḥôṯ",
    "prononciation": "ʾāḥôṯ",
    "definition": "Sœur, parente, compagne.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ézéchiel 16:45"
    ],
    "type": "nom commun",
    "occurrences": 114,
    "recherche": "h269 אָחוֹת ʾāḥôṯ sœur, parente, compagne. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Sœur",
    "etymologie": "Forme féminine de אָח (H0251, « frère »). · Syriaque : ܚܬܐ (ḥāṯā) · Arabe : ʾuḫt · Akkadien : aḫātu ·",
    "formes_derivees": [
      "H251"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Cantique des Cantiques 4:9",
      "texte": "Tu m\\'as ravi le cœur, ma sœur, ma fiancée."
    },
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Le terme ʾāḥôṯ a des usages relationnels et métaphoriques étendus. Dans le Cantique des Cantiques, « ma sœur, ma fiancée » (4:9 10, 12 ; 5:1 2) est une expression d'affection érotique, empruntée à la poésie amoureuse égyptienne. En Ézéchiel 16 et 23, les « sœurs » Ohola et Oholiba…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200164,
    "strong": "H270",
    "langue": "hebreu",
    "numero": 270,
    "mot_original": "אָחַז",
    "translitteration": "ʾāḥaz",
    "prononciation": "ʾāḥaz",
    "definition": "Saisir, prendre, tenir, posséder.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 25:26",
      "Exode 15:14"
    ],
    "type": "verbe",
    "occurrences": 69,
    "recherche": "h270 אָחַז ʾāḥaz saisir, prendre, tenir, posséder. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Saisir",
    "etymologie": "Racine אחז (ʾḤZ, « tenir, saisir »). · Syriaque : ܐܚܕ (ʾeḥaḏ, « saisir, tenir ») · Arabe : ʾaḫaḏa (prendre, saisir) · Akkadien : aḫāzu (prendre, épouser) · Ougaritique : ảḥḏ (saisir) ·",
    "formes_derivees": [
      "H271",
      "H300"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 25:26",
      "texte": "Sa main tenait le talon d\\'Ésaü."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Le verbe ʾāḥaz exprime la prise physique, la saisie ou la possession. La « prise » de territoires (Genèse 47:27 ; Josué 22:9) décrit l'installation et l'occupation. L'expression « l'angoisse saisit » (Exode 15:14) est une métaphore de l'effroi subit. La saisie des cornes de l'autel (1 Rois 1:51) est…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200165,
    "strong": "H271",
    "langue": "hebreu",
    "numero": 271,
    "mot_original": "אָחָז",
    "translitteration": "ʾāḥāz",
    "prononciation": "ʾāḥāz",
    "definition": "Achaz, « il a saisi », roi de Juda, fils de Yotam, père d'Ézéchias.",
    "categorie": "Royaume",
    "references": [
      "2 Rois 16:1"
    ],
    "type": "nom propre",
    "occurrences": 41,
    "recherche": "h271 אָחָז ʾāḥāz achaz, « il a saisi », roi de juda, fils de yotam, père d'ézéchias. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Achaz",
    "etymologie": "Forme abrégée de יְהוֹאָחָז (H3059, « YHWH a saisi »), composé de יָהּ + אָחַז (H0270, « saisir, tenir »). ·",
    "formes_derivees": [
      "H270",
      "H3059"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Rois 16:1",
      "texte": "La dix-septième année de Péqah, fils de Remalyahou, Achaz, fils de Yotam, roi de Juda, devint roi."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Achaz régna sur Juda pendant la guerre syro éphraïmite (vers 734 732 avant l'ère courante). Attaqué par Péqah d'Israël et Retsîn de Damas, il refusa l'alliance anti assyrienne proposée par les coalisés et fit appel à Tiglath Piléser III d'Assyrie, devenant son vassal. Ésaïe 7 relate la rencontre entre le…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200166,
    "strong": "H272",
    "langue": "hebreu",
    "numero": 272,
    "mot_original": "אֲחֻזָּה",
    "translitteration": "ʾăḥuzzāh",
    "prononciation": "ʾăḥuzzāh",
    "definition": "Propriété foncière, possession, domaine héréditaire.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 23:4",
      "Lévitique 25:24"
    ],
    "type": "nom commun",
    "occurrences": 66,
    "recherche": "h272 אֲחֻזָּה ʾăḥuzzāh propriété foncière, possession, domaine héréditaire. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Propriété foncière",
    "etymologie": "Dérivé nominal féminin de אָחַז (H0270, « saisir, posséder »). · Syriaque : ܐܚܘܕܬܐ (ʾāḥûḏṯā, « possession ») · Arabe : ʾaḫaḏa (prendre, posséder) ·",
    "formes_derivees": [
      "H270"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 23:4",
      "texte": "Je suis un étranger et un résident parmi vous ; donnez-moi une propriété funéraire."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "L'ʾăḥuzzāh est la propriété foncière inaliénable, idéalement transmise au sein de la famille. L'acquisition du champ de Makpéla par Abraham (Genèse 23) est le premier achat de terre en Canaan, gage de la promesse divine. La législation du jubilé (Lévitique 25) prévoit le retour de chaque famille sur sa terre…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200167,
    "strong": "H273",
    "langue": "hebreu",
    "numero": 273,
    "mot_original": "אַחְזַי",
    "translitteration": "ʾaḥzay",
    "prononciation": "ʾaḥzay",
    "definition": "Ahzaï, prêtre du temps de Néhémie.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Néhémie 11:13"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h273 אַחְזַי ʾaḥzay ahzaï, prêtre du temps de néhémie. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahzaï",
    "etymologie": "Nom d'origine incertaine. ·",
    "formes_derivees": [
      "H270",
      "H274"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Néhémie 11:13",
      "texte": "Ses frères, chefs de famille\\... Amashsaï, fils d\\'Azaréel, fils d\\'Ahzaï."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahzaï est mentionné dans la liste des habitants de Jérusalem sous Néhémie (Néhémie 11). Ce chapitre énumère les chefs du peuple, les prêtres, les lévites et les portiers qui résidaient volontairement dans la capitale pour la repeupler après l'exil.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200168,
    "strong": "H274",
    "langue": "hebreu",
    "numero": 274,
    "mot_original": "אֲחַזְיָה",
    "translitteration": "ʾăḥazyāh",
    "prononciation": "ʾăḥazyāh",
    "definition": "Achaziah, « YHWH a saisi ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 22:52"
    ],
    "type": "nom propre",
    "occurrences": 37,
    "recherche": "h274 אֲחַזְיָה ʾăḥazyāh achaziah, « yhwh a saisi ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Achaziah",
    "etymologie": "Composé de אָחַז (H0270, « saisir ») + יָהּ (H3050, abréviation de YHWH). ·",
    "formes_derivees": [
      "H270",
      "H3050"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 22:52",
      "texte": "Achaziah, fils d\\'Achab, régna sur Israël."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Deux rois portent ce nom. Achaziah d'Israël (règne : environ 853 852) tombe d'une fenêtre à Samarie et consulte Baal Zeboub, dieu d'Éqron, attirant la condamnation d'Élie (2 Rois 1). Achaziah de Juda (règne : environ 842) est tué lors de la purge de Jéhu contre la maison d'Omri (2…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200169,
    "strong": "H275",
    "langue": "hebreu",
    "numero": 275,
    "mot_original": "אֲחֻזָּם",
    "translitteration": "ʾăḥuzzām",
    "prononciation": "ʾăḥuzzām",
    "definition": "Ahuzzam, descendant de Juda.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 4:6"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h275 אֲחֻזָּם ʾăḥuzzām ahuzzam, descendant de juda. nom propre",
    "audio": "",
    "image": null,
    "racine": "H270",
    "sens_principal": "Ahuzzam",
    "etymologie": "Dérivé de אָחַז (H0270, « saisir, posséder ») avec suffixe ām. ·",
    "formes_derivees": [
      "H270"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 4:6",
      "texte": "Naara lui enfanta Ahuzzam."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahuzzam est mentionné dans la généalogie de Juda par Ashour, fondateur de Teqoa (1 Chroniques 4:5 7). Ces généalogies judéennes énumèrent les clans et les fondateurs de localités dans la région d'Hébron et du désert de Juda.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200170,
    "strong": "H276",
    "langue": "hebreu",
    "numero": 276,
    "mot_original": "אֲחֻזַּת",
    "translitteration": "ʾăḥuzzaṯ",
    "prononciation": "ʾăḥuzzaṯ",
    "definition": "Ahuzzath, conseiller d'Abimélek, roi philistin de Guérar.",
    "categorie": "Royaume",
    "references": [
      "Genèse 26:26"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h276 אֲחֻזַּת ʾăḥuzzaṯ ahuzzath, conseiller d'abimélek, roi philistin de guérar. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahuzzath",
    "etymologie": "Nom identique à אֲחֻזָּה (H0272, « possession »). ·",
    "formes_derivees": [
      "H272"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 26:26",
      "texte": "Abimélek vint à lui depuis Guérar, avec Ahuzzath, son ami."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahuzzath accompagne Abimélek, roi de Guérar, lors de la conclusion d'une alliance avec Isaac à Beer Sheva. Son titre de « ami » (מֵרֵעַ) pourrait désigner une fonction officielle de conseiller ou de confident royal. Le récit de Genèse 26 présente Isaac comme un patriarche en conflit avec les Philistins…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200171,
    "strong": "H277",
    "langue": "hebreu",
    "numero": 277,
    "mot_original": "אֲחִי",
    "translitteration": "ʾăḥî",
    "prononciation": "ʾăḥî",
    "definition": "Ahi, « mon frère ». Nom de deux personnages.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 5:15"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h277 אֲחִי ʾăḥî ahi, « mon frère ». nom de deux personnages. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahi",
    "etymologie": "Forme abrégée d'un nom composé avec אָח (H0251, « frère ») ou signifiant simplement « mon frère ». ·",
    "formes_derivees": [
      "H251",
      "H281"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 5:15",
      "texte": "Ahi, fils d\\'Abdiel."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Deux personnages distincts portent ce nom très court. Ahi le Gadite (1 Chroniques 5:15) est un chef de clan en Transjordanie. Ahi l'Ashérite (1 Chroniques 7:34) est répertorié dans une généalogie de la tribu d'Asher. La brièveté du nom suggère une forme abrégée ou archaïque.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200172,
    "strong": "H278",
    "langue": "hebreu",
    "numero": 278,
    "mot_original": "אֵחִי",
    "translitteration": "ʾēḥî",
    "prononciation": "ʾēḥî",
    "definition": "Éhi, fils de Benjamin.",
    "categorie": "Adoption et filiation",
    "references": [
      "Genèse 46:21"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h278 אֵחִי ʾēḥî éhi, fils de benjamin. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Éhi",
    "etymologie": "Nom d'origine incertaine. ·",
    "formes_derivees": [
      "H277"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Genèse 46:21",
      "texte": "Fils de Benjamin : Béla, Békher, Ashbel, Guéra, Naaman, Éhi, Rosh."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Éhi est mentionné parmi les fils de Benjamin dans la généalogie de Genèse 46. La liste des descendants de Benjamin varie selon les sources (Genèse 46, Nombres 26, 1 Chroniques 7 8), reflétant l'histoire complexe de cette tribu et les traditions généalogiques concurrentes.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200173,
    "strong": "H279",
    "langue": "hebreu",
    "numero": 279,
    "mot_original": "אֲחִיאָם",
    "translitteration": "ʾăḥîʾām",
    "prononciation": "ʾăḥîʾām",
    "definition": "Ahiam, « frère de la mère » ou « frère du peuple ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "2 Samuel 23:33"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h279 אֲחִיאָם ʾăḥîʾām ahiam, « frère de la mère » ou « frère du peuple ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahiam",
    "etymologie": "Composé de אָח (H0251, « frère ») + אֵם (H0517, « mère ») ou עָם (H5971, « peuple »). ·",
    "formes_derivees": [
      "H251",
      "H517",
      "H5971"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 23:33",
      "texte": "Ahiam, fils de Sharar."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahiam figure parmi les Trente guerriers de David (2 Samuel 23:33). La liste des Trente présente des variantes onomastiques entre Samuel et Chroniques (son père est Sharar en Samuel, Harar en Chroniques), phénomène courant dans les listes administratives transmises par la tradition.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200174,
    "strong": "H280",
    "langue": "hebreu",
    "numero": 280,
    "mot_original": "אֲחִידָה",
    "translitteration": "ʾăḥîḏāh",
    "prononciation": "ʾăḥîḏāh",
    "definition": "Énigme, question difficile, problème à résoudre.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 5:12"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 2,
    "recherche": "h280 אֲחִידָה ʾăḥîḏāh énigme, question difficile, problème à résoudre. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Énigme",
    "etymologie": "Racine אחוד ou אחד en araméen, liée à l'hébreu חִידָה (H2420, « énigme »). · Syriaque : ܐܚܝܕܬܐ (ʾăḥîḏṯā, « énigme, parabole ») ·",
    "formes_derivees": [
      "H281",
      "H300",
      "H2420"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Daniel 5:12",
      "texte": "En qui se trouve un esprit supérieur\\... et qui résout les énigmes."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "Le terme araméen apparaît dans la présentation de Daniel à Belschatsar (Daniel 5). La reine mère énumère les qualités de Daniel : esprit supérieur, intelligence, interprétation des songes, résolution d'énigmes (אֲחִידָן). Le terme appartient au vocabulaire sapientiel de la cour babylonienne. Je poursuis avec H0281 H0300. Confirmez vous ? SECTION…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200175,
    "strong": "H281",
    "langue": "hebreu",
    "numero": 281,
    "mot_original": "אֲחִיָּה",
    "translitteration": "ʾăḥîyāh",
    "prononciation": "ʾăḥîyāh",
    "definition": "Ahiyah, « frère de YHWH » ou « YHWH est mon frère ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 11:29"
    ],
    "type": "nom propre",
    "occurrences": 24,
    "recherche": "h281 אֲחִיָּה ʾăḥîyāh ahiyah, « frère de yhwh » ou « yhwh est mon frère ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahiyah",
    "etymologie": "Composé de אָח (H0251, « frère ») + יָהּ (H3050, abréviation de YHWH). ·",
    "formes_derivees": [
      "H251",
      "H3050"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 11:29",
      "texte": "Le prophète Ahiyah de Silo le rencontra."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahiyah de Silo est le prophète qui annonça à Jéroboam la division du royaume après Salomon (1 Rois 11:29 39). Il lui donna dix parts du manteau déchiré, symbolisant les dix tribus du Nord. Plus tard, il prononça le jugement contre la maison de Jéroboam pour son idolâtrie (1 Rois…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200176,
    "strong": "H282",
    "langue": "hebreu",
    "numero": 282,
    "mot_original": "אֲחִיהוּד",
    "translitteration": "ʾăḥîhûḏ",
    "prononciation": "ʾăḥîhûḏ",
    "definition": "Ahihoud, « frère de majesté » ou « frère est majesté ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Nombres 34:27"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h282 אֲחִיהוּד ʾăḥîhûḏ ahihoud, « frère de majesté » ou « frère est majesté ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahihoud",
    "etymologie": "Composé de אָח (H0251, « frère ») + הוֹד (H1935, « majesté, splendeur »). ·",
    "formes_derivees": [
      "H251",
      "H1935"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 34:27",
      "texte": "Pour la tribu des fils d\\'Asher : le prince Ahihoud, fils de Shelomi."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahihoud ben Shelomi est le représentant de la tribu d'Asher dans la commission de partage du pays (Nombres 34). Ces douze princes, nommés par YHWH, assistent Josué et Éléazar pour la répartition du territoire entre les tribus. Leur liste légitime l'organisation territoriale de l'Israël pré monarchique.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200177,
    "strong": "H283",
    "langue": "hebreu",
    "numero": 283,
    "mot_original": "אַחְיוֹ",
    "translitteration": "ʾaḥyô",
    "prononciation": "ʾaḥyô",
    "definition": "Ahyo, « son frère » ou « fraternel ». Nom d'un conducteur de l'arche.",
    "categorie": "Noms propres bibliques",
    "references": [
      "2 Samuel 6:3"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h283 אַחְיוֹ ʾaḥyô ahyo, « son frère » ou « fraternel ». nom d'un conducteur de l'arche. nom propre",
    "audio": "",
    "image": null,
    "racine": "H251",
    "sens_principal": "Ahyo",
    "etymologie": "Dérivé de אָח (H0251, « frère ») avec suffixe pronominal 3ms ou suffixe hypocoristique yô. ·",
    "formes_derivees": [
      "H251"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 6:3",
      "texte": "Ils placèrent l\\'arche de Dieu sur un char neuf\\... Ouzza et Ahyo, fils d\\'Abinadab, conduisaient le char."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahyo est l'un des fils d'Abinadab, chez qui l'arche avait séjourné vingt ans à Qiryat Yéarim. Avec son frère Ouzza, il conduit le char transportant l'arche vers Jérusalem. Le récit de 2 Samuel 6 relate la mort d'Ouzza, frappé pour avoir touché l'arche, tandis qu'Ahyo n'est pas mentionné comme puni.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200178,
    "strong": "H284",
    "langue": "hebreu",
    "numero": 284,
    "mot_original": "אֲחִיחֻד",
    "translitteration": "ʾăḥîḥuḏ",
    "prononciation": "ʾăḥîḥuḏ",
    "definition": "Ahihoud, variante orthographique de H0282.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 8:7"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h284 אֲחִיחֻד ʾăḥîḥuḏ ahihoud, variante orthographique de h0282. nom propre",
    "audio": "",
    "image": null,
    "racine": "H282",
    "sens_principal": "Ahihoud",
    "etymologie": "Variante de אֲחִיהוּד (H0282) avec ח pour ה. ·",
    "formes_derivees": [
      "H282"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 8:7",
      "texte": "Ahihoud\\... il engendra Ouzza."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Cette entrée est un doublet orthographique de H0282 dans la classification Strong. Pour les notes contextuelles, voir H0282.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200179,
    "strong": "H285",
    "langue": "hebreu",
    "numero": 285,
    "mot_original": "אֲחִיטוּב",
    "translitteration": "ʾăḥîṭûḇ",
    "prononciation": "ʾăḥîṭûḇ",
    "definition": "Ahitub, « mon frère est bonté » ou « frère de bonté ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Samuel 14:3"
    ],
    "type": "nom propre",
    "occurrences": 16,
    "recherche": "h285 אֲחִיטוּב ʾăḥîṭûḇ ahitub, « mon frère est bonté » ou « frère de bonté ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahitub",
    "etymologie": "Composé de אָח (H0251, « frère ») + טוּב (H2898, « bonté, bien »). ·",
    "formes_derivees": [
      "H251",
      "H2898"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 14:3",
      "texte": "Ahiyah, fils d\\'Ahitub, frère d\\'Ikabod."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Deux personnages sacerdotaux majeurs portent ce nom. L'Ahitub de 1 Samuel est le grand père d'Ahimélek, prêtre de Nob massacré par Saül ; son petit fils Ébyatar survit et devient prêtre de David. L'Ahitub père de Tsadoq est l'ancêtre de la lignée sacerdotale légitime du Temple de Jérusalem (les Tsadoqites),…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200180,
    "strong": "H286",
    "langue": "hebreu",
    "numero": 286,
    "mot_original": "אֲחִילוּד",
    "translitteration": "ʾăḥîlûḏ",
    "prononciation": "ʾăḥîlûḏ",
    "definition": "Ahiloud, « frère d'enfantement » ou « frère est né ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "2 Samuel 8:16"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h286 אֲחִילוּד ʾăḥîlûḏ ahiloud, « frère d'enfantement » ou « frère est né ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahiloud",
    "etymologie": "Composé de אָח (H0251, « frère ») + יָלַד (H3205, « enfanter, engendrer »). ·",
    "formes_derivees": [
      "H251",
      "H3205"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 8:16",
      "texte": "Joshaphat, fils d\\'Ahiloud, était archiviste."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahiloud est le père de deux hauts fonctionnaires de l'administration davidique et salomonienne. Son fils Joshaphat occupe la charge de mazkîr (archiviste, secrétaire royal), fonction attestée dans les cours proche orientales. Son fils Baana est préfet du district de Taanak et Megiddo (1 Rois 4:12), puis responsable de la corvée…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200181,
    "strong": "H287",
    "langue": "hebreu",
    "numero": 287,
    "mot_original": "אֲחִימוֹת",
    "translitteration": "ʾăḥîmôṯ",
    "prononciation": "ʾăḥîmôṯ",
    "definition": "Ahimoth, « mon frère est mort » ou « frère de la mort ».",
    "categorie": "Mort et vie",
    "references": [
      "1 Chroniques 6:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h287 אֲחִימוֹת ʾăḥîmôṯ ahimoth, « mon frère est mort » ou « frère de la mort ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahimoth",
    "etymologie": "Composé de אָח (H0251, « frère ») + מוֹת (H4194, « mort »). ·",
    "formes_derivees": [
      "H251",
      "H4194"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 6:10",
      "texte": "Fils d\\'Ahimoth, fils d\\'Elqana."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahimoth est répertorié dans la généalogie lévitique de 1 Chroniques 6, parmi les descendants de Qehath. Les listes généalogiques des Chroniques établissent la légitimité cultuelle des officiants du Second Temple en les rattachant à la lignée de Lévi.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200182,
    "strong": "H288",
    "langue": "hebreu",
    "numero": 288,
    "mot_original": "אֲחִימֶלֶךְ",
    "translitteration": "ʾăḥîmeleḵ",
    "prononciation": "ʾăḥîmeleḵ",
    "definition": "Ahimélek, « mon frère est roi » ou « frère du roi ».",
    "categorie": "Royaume",
    "references": [
      "1 Samuel 21:2"
    ],
    "type": "nom propre",
    "occurrences": 17,
    "recherche": "h288 אֲחִימֶלֶךְ ʾăḥîmeleḵ ahimélek, « mon frère est roi » ou « frère du roi ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahimélek",
    "etymologie": "Composé de אָח (H0251, « frère ») + מֶלֶךְ (H4428, « roi »). ·",
    "formes_derivees": [
      "H251",
      "H4428"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 21:2",
      "texte": "David vint à Nob, vers Ahimélek le prêtre."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahimélek de Nob est un personnage tragique. Il donne à David en fuite les pains de proposition et l'épée de Goliath (1 Samuel 21), ignorant le conflit entre David et Saül. Dénoncé par Doëg l'Édomite, il est massacré avec les prêtres de Nob sur ordre de Saül (1 Samuel 22).…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200183,
    "strong": "H289",
    "langue": "hebreu",
    "numero": 289,
    "mot_original": "אֲחִימַן",
    "translitteration": "ʾăḥîman",
    "prononciation": "ʾăḥîman",
    "definition": "Ahiman, « mon frère est un don » ou signification incertaine.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Nombres 13:22"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h289 אֲחִימַן ʾăḥîman ahiman, « mon frère est un don » ou signification incertaine. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahiman",
    "etymologie": "Composé de אָח (H0251, « frère ») + élément מַן d'origine incertaine. ·",
    "formes_derivees": [
      "H251",
      "H4490"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 13:22",
      "texte": "Les fils d\\'Anaq : Ahiman, Shéshaï et Talmaï."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahiman, Shéshaï et Talmaï sont les trois fils d'Anaq, géants habitant Hébron. Leur présence terrifie les explorateurs israélites (Nombres 13:22, 28, 33). Plus tard, Caleb les chasse d'Hébron (Josué 15:14 ; Juges 1:10). Ces « Anaqim » sont présentés comme les descendants des Nephilim, population légendaire de géants pré israélites.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200184,
    "strong": "H290",
    "langue": "hebreu",
    "numero": 290,
    "mot_original": "אֲחִימַעַץ",
    "translitteration": "ʾăḥîmaʿaṣ",
    "prononciation": "ʾăḥîmaʿaṣ",
    "definition": "Ahimaats, « mon frère est colère » ou signification incertaine.",
    "categorie": "Noms propres bibliques",
    "references": [
      "2 Samuel 18:19"
    ],
    "type": "nom propre",
    "occurrences": 15,
    "recherche": "h290 אֲחִימַעַץ ʾăḥîmaʿaṣ ahimaats, « mon frère est colère » ou signification incertaine. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahimaats",
    "etymologie": "Composé de אָח (H0251, « frère ») + élément מַעַץ d'origine incertaine. ·",
    "formes_derivees": [
      "H251",
      "H291",
      "H300",
      "H4600"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "2 Samuel 18:19",
      "texte": "Ahimaats, fils de Tsadoq, dit : Laisse-moi courir annoncer la bonne nouvelle au roi."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahimaats ben Tsadoq est un personnage secondaire mais mémorable du récit de la révolte d'Absalom. Fidèle à David, il sert d'agent de renseignement à Jérusalem avec Jonathan ben Ébyatar. Après la victoire, il court porter la nouvelle au roi, mais par délicatesse, il tait la mort d'Absalom (2 Samuel 18:19…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200185,
    "strong": "H291",
    "langue": "hebreu",
    "numero": 291,
    "mot_original": "אַחְיָן",
    "translitteration": "ʾaḥyān",
    "prononciation": "ʾaḥyān",
    "definition": "Ahyan, descendant de Manassé.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 7:19"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h291 אַחְיָן ʾaḥyān ahyan, descendant de manassé. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahyan",
    "etymologie": "Nom d'origine incertaine. ·",
    "formes_derivees": [
      "H251"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 7:19",
      "texte": "Les fils de Shemida furent : Ahyan et Shekhem."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahyan est répertorié dans la généalogie de Manassé (1 Chroniques 7:14 19). La notice mentionne sa sœur Hammoléketh et ses frères, dont Shekhem, toponyme qui évoque la célèbre ville cananéenne et centre tribal. La généalogie manassite documente les liens entre clans et territoires.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200186,
    "strong": "H292",
    "langue": "hebreu",
    "numero": 292,
    "mot_original": "אֲחִינָדָב",
    "translitteration": "ʾăḥînāḏāḇ",
    "prononciation": "ʾăḥînāḏāḇ",
    "definition": "Ahinadab, « mon frère est noble » ou « frère de noblesse ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 4:14"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h292 אֲחִינָדָב ʾăḥînāḏāḇ ahinadab, « mon frère est noble » ou « frère de noblesse ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahinadab",
    "etymologie": "Composé de אָח (H0251, « frère ») + נָדִיב (H5081, « noble, généreux »). ·",
    "formes_derivees": [
      "H251",
      "H5081"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Rois 4:14",
      "texte": "Ahinadab, fils d\\'Iddo, à Mahanaïm."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahinadab ben Iddo est l'un des douze préfets salomoniens (1 Rois 4:7 19). Il administre le district de Mahanaïm, en Transjordanie, région stratégique entre Galaad et le Bashan. L'organisation administrative de Salomon divise le territoire en douze districts fiscaux, ne correspondant pas exactement aux frontières tribales.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200187,
    "strong": "H293",
    "langue": "hebreu",
    "numero": 293,
    "mot_original": "אֲחִינֹעַם",
    "translitteration": "ʾăḥînōʿam",
    "prononciation": "ʾăḥînōʿam",
    "definition": "Ahinoam, « mon frère est plaisir » ou « frère de douceur ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Samuel 25:43"
    ],
    "type": "nom propre",
    "occurrences": 7,
    "recherche": "h293 אֲחִינֹעַם ʾăḥînōʿam ahinoam, « mon frère est plaisir » ou « frère de douceur ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahinoam",
    "etymologie": "Composé de אָח (H0251, « frère ») + נֹעַם (H5278, « plaisir, douceur, agrément »). ·",
    "formes_derivees": [
      "H251",
      "H5278"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Samuel 25:43",
      "texte": "David prit aussi Ahinoam de Jezréel."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Deux femmes nommées Ahinoam apparaissent dans les récits de la royauté naissante. L'Ahinoam épouse de Saül est la mère de Jonathan et de ses frères. L'Ahinoam de Jezréel est l'une des épouses de David, prise alors qu'il était fugitif dans le sud judéen. Elle est la mère d'Amnon, fils aîné…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200188,
    "strong": "H294",
    "langue": "hebreu",
    "numero": 294,
    "mot_original": "אֲחִיסָמָךְ",
    "translitteration": "ʾăḥîsāmāḵ",
    "prononciation": "ʾăḥîsāmāḵ",
    "definition": "Ahisamak, « mon frère soutient » ou « frère de soutien ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Exode 31:6"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h294 אֲחִיסָמָךְ ʾăḥîsāmāḵ ahisamak, « mon frère soutient » ou « frère de soutien ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahisamak",
    "etymologie": "Composé de אָח (H0251, « frère ») + סָמַךְ (H5564, « soutenir, appuyer »). ·",
    "formes_derivees": [
      "H251",
      "H5564"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Exode 31:6",
      "texte": "Et moi, voici que j\\'ai donné avec lui Oholiab, fils d\\'Ahisamak."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahisamak est le père d'Oholiab, l'assistant de Betsaléel pour la construction du tabernacle. Originaire de la tribu de Dan, il appartient à une lignée d'artisans qualifiés. La mention répétée du patronyme « ben Ahisamak » souligne l'importance de l'appartenance familiale dans la transmission des compétences artisanales.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200189,
    "strong": "H295",
    "langue": "hebreu",
    "numero": 295,
    "mot_original": "אֲחִיעֶזֶר",
    "translitteration": "ʾăḥîʿezer",
    "prononciation": "ʾăḥîʿezer",
    "definition": "Ahiézer, « mon frère est secours » ou « frère de secours ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Nombres 1:12"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h295 אֲחִיעֶזֶר ʾăḥîʿezer ahiézer, « mon frère est secours » ou « frère de secours ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahiézer",
    "etymologie": "Composé de אָח (H0251, « frère ») + עֵזֶר (H5828, « secours, aide »). ·",
    "formes_derivees": [
      "H251",
      "H5828"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 1:12",
      "texte": "Pour Dan : Ahiézer, fils d\\'Ammishaddaï."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahiézer ben Ammishaddaï représente la tribu de Dan parmi les douze princes assistant Moïse pour le recensement du Sinaï (Nombres 1). Il commande le camp de Dan, positionné au nord du tabernacle. Son nom est un théophore exprimant la confiance en l'aide divine.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200190,
    "strong": "H296",
    "langue": "hebreu",
    "numero": 296,
    "mot_original": "אֲחִיקָם",
    "translitteration": "ʾăḥîqām",
    "prononciation": "ʾăḥîqām",
    "definition": "Ahiqam, « mon frère s'est levé » ou « frère de relèvement ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Jérémie 26:24"
    ],
    "type": "nom propre",
    "occurrences": 20,
    "recherche": "h296 אֲחִיקָם ʾăḥîqām ahiqam, « mon frère s'est levé » ou « frère de relèvement ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahiqam",
    "etymologie": "Composé de אָח (H0251, « frère ») + קוּם (H6965, « se lever »). ·",
    "formes_derivees": [
      "H251",
      "H6965"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Jérémie 26:24",
      "texte": "Mais la main d\\'Ahiqam, fils de Shaphan, fut avec Jérémie."
    },
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahiqam ben Shaphan est un haut fonctionnaire judéen, membre de la famille influente des Shaphanides. Son père Shaphan était scribe sous Josias (2 Rois 22). Ahiqam protège Jérémie contre la condamnation à mort (Jérémie 26:24). Son fils Guedalia est nommé gouverneur de Juda par les Babyloniens après 587. La famille…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200191,
    "strong": "H297",
    "langue": "hebreu",
    "numero": 297,
    "mot_original": "אֲחִירָם",
    "translitteration": "ʾăḥîrām",
    "prononciation": "ʾăḥîrām",
    "definition": "Ahiram, « mon frère est élevé » ou « frère du Très-Haut ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Nombres 26:38"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h297 אֲחִירָם ʾăḥîrām ahiram, « mon frère est élevé » ou « frère du très-haut ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahiram",
    "etymologie": "Composé de אָח (H0251, « frère ») + רוּם (H7311, « être élevé, exalté »). ·",
    "formes_derivees": [
      "H251",
      "H7311"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 26:38",
      "texte": "Fils de Benjamin selon leurs familles\\... d\\'Ahiram, la famille des Ahiramites."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahiram est l'ancêtre éponyme du clan ahiramite, l'une des familles de la tribu de Benjamin recensée dans les plaines de Moab (Nombres 26). La liste des clans benjaminites présente des variantes entre Genèse 46, Nombres 26 et 1 Chroniques 7 8, reflétant l'histoire complexe de cette tribu.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200192,
    "strong": "H298",
    "langue": "hebreu",
    "numero": 298,
    "mot_original": "אֲחִירָמִי",
    "translitteration": "ʾăḥîrāmî",
    "prononciation": "ʾăḥîrāmî",
    "definition": "Ahiramite, membre du clan d'Ahiram.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Nombres 26:38"
    ],
    "type": "adjectif gentilé",
    "occurrences": 1,
    "recherche": "h298 אֲחִירָמִי ʾăḥîrāmî ahiramite, membre du clan d'ahiram. adjectif gentilé",
    "audio": "",
    "image": null,
    "racine": "H297",
    "sens_principal": "Ahiramite",
    "etymologie": "Gentilé dérivé de אֲחִירָם (H0297). ·",
    "formes_derivees": [
      "H297"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 26:38",
      "texte": "D\\'Ahiram, la famille des Ahiramites."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Voir H0297. Le gentilé est formé régulièrement avec le suffixe î sur le nom de l'ancêtre éponyme. Les listes de clans (Nombres 26) utilisent systématiquement cette formation pour chaque famille.",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200193,
    "strong": "H299",
    "langue": "hebreu",
    "numero": 299,
    "mot_original": "אֲחִירַע",
    "translitteration": "ʾăḥîraʿ",
    "prononciation": "ʾăḥîraʿ",
    "definition": "Ahira, « mon frère est mauvais » ou « frère du mal ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "Nombres 1:15"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h299 אֲחִירַע ʾăḥîraʿ ahira, « mon frère est mauvais » ou « frère du mal ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahira",
    "etymologie": "Composé de אָח (H0251, « frère ») + רַע (H7451, « mauvais, mal »). ·",
    "formes_derivees": [
      "H251",
      "H7451"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "Nombres 1:15",
      "texte": "Pour Nephtali : Ahira, fils d\\'Énan."
    },
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahira ben Énan est le prince de Nephtali, l'un des douze chefs tribaux assistant Moïse et Aaron. Il est le dernier mentionné dans les listes, Nephtali occupant l'extrémité nord du camp. Il apporte l'offrande de sa tribu au douzième jour de la dédicace du tabernacle (Nombres 7:78 83).",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200194,
    "strong": "H300",
    "langue": "hebreu",
    "numero": 300,
    "mot_original": "אֲחִישַׁחַר",
    "translitteration": "ʾăḥîšaḥar",
    "prononciation": "ʾăḥîšaḥar",
    "definition": "Ahishahar, « mon frère est aurore » ou « frère de l'aube ».",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 7:10"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h300 אֲחִישַׁחַר ʾăḥîšaḥar ahishahar, « mon frère est aurore » ou « frère de l'aube ». nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahishahar",
    "etymologie": "Composé de אָח (H0251, « frère ») + שַׁחַר (H7837, « aurore, aube »). ·",
    "formes_derivees": [
      "H201",
      "H251",
      "H291",
      "H7837"
    ],
    "synonymes": [],
    "premiere_occurrence": {
      "reference": "1 Chroniques 7:10",
      "texte": "Fils de Yediaël\\... Ahishahar."
    },
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Ahishahar est répertorié dans la généalogie benjaminite de 1 Chroniques 7. L'élément Shahar (aurore) est un nom divin cananéen attesté à Ougarit (Shahar, dieu de l'aube, fils d'El). La présence de cet élément théophore dans un nom israélite illustre la persistance de l'onomastique cananéenne dans les tribus du Nord. Ceci…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200195,
    "strong": "H311",
    "langue": "hebreu",
    "numero": 311,
    "mot_original": "אַחֲרֵי",
    "translitteration": "ʾaḥărê",
    "prononciation": "akh-ar-ay'",
    "definition": "Après, derrière, à la suite de.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 5:4",
      "Exode 14:4",
      "Deutéronome 4:3",
      "1 Rois 1:6",
      "Jérémie 2:2"
    ],
    "type": "préposition / conjonction",
    "occurrences": 769,
    "recherche": "h311 אַחֲרֵי ʾaḥărê après, derrière, à la suite de. préposition / conjonction",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Après",
    "etymologie": "· Données attestées : Forme allongée de אַחַר (H0310, « après, derrière »). Racine אחר (ʾḤR, « être derrière, après »). · Cognats sémitiques : Ougaritique : ảḫr (après). Syriaque : ܒܬܪ (bāṯar). Arabe : ʾāḫir (dernier). Akkadien : aḫar…",
    "formes_derivees": [
      "H268",
      "H309",
      "H310",
      "H314",
      "H319"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "conjonction"
    ],
    "notes": "Contexte historique et culturel : La préposition ʾaḥărê structure l'expression du temps et de l'espace en hébreu biblique. Son usage pour décrire la poursuite (« courir après ») reflète la réalité d'une société pastorale et militaire où la chasse, la guerre et la poursuite des ennemis sont des expériences quotidiennes.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Conjonction"
  },
  {
    "id": 200196,
    "strong": "H312",
    "langue": "hebreu",
    "numero": 312,
    "mot_original": "אַחֵר",
    "translitteration": "ʾaḥēr",
    "prononciation": "akh-air'",
    "definition": "Autre, différent, second.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 4:25",
      "Exode 20:3",
      "Lévitique 13:5",
      "Deutéronome 5:7",
      "Psaume 109:8"
    ],
    "type": "adjectif",
    "occurrences": 166,
    "recherche": "h312 אַחֵר ʾaḥēr autre, différent, second. adjectif",
    "audio": "",
    "image": null,
    "racine": "H310",
    "sens_principal": "Autre",
    "etymologie": "· Données attestées : Dérivé adjectival de la racine אחר (ʾḤR, « être derrière, après »). Littéralement « postérieur, qui vient après », d'où « autre, différent ». · Cognats sémitiques : Syriaque : ܐܚܪܢܐ (ʾaḥrānā, « autre »). Arabe…",
    "formes_derivees": [
      "H309",
      "H310",
      "H311",
      "H313",
      "H314",
      "H319",
      "H400"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : L'adjectif ʾaḥēr exprime l'altérité et la différence. Dans le Décalogue (Exode 20:3 ; Deutéronome 5:7), l'interdiction d'avoir « d'autres dieux » (אֱלֹהִים אֲחֵרִים) est le fondement du monothéisme exclusif israélite. La notion de « dieux autres » présuppose l'existence reconnue d'autres divinités dans l'environnement religieux…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200197,
    "strong": "H313",
    "langue": "hebreu",
    "numero": 313,
    "mot_original": "אַחֵר",
    "translitteration": "ʾaḥēr",
    "prononciation": "akh-air'",
    "definition": "Aher, nom d'un descendant de Benjamin.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 7:12"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h313 אַחֵר ʾaḥēr aher, nom d'un descendant de benjamin. nom propre",
    "audio": "",
    "image": null,
    "racine": "H312",
    "sens_principal": "Aher",
    "etymologie": "· Données attestées : Forme identique à l'adjectif אַחֵר (H0312, « autre »). Nom propre dérivé de la racine אחר (ʾḤR, « être derrière, après »). · Cognats sémitiques : Voir H0312. · Hypothèses linguistiques : Le nom pourrait être…",
    "formes_derivees": [
      "H309",
      "H310",
      "H311",
      "H312"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Aher est répertorié dans la généalogie de la tribu de Benjamin en 1 Chroniques 7:6 12. Ce chapitre énumère les descendants des trois fils de Benjamin (Béla, Békher, Yediaël) et leurs liens avec les autres tribus. La notice est brève et ne fournit aucun détail…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200198,
    "strong": "H314",
    "langue": "hebreu",
    "numero": 314,
    "mot_original": "אַחֲרוֹן",
    "translitteration": "ʾaḥărôn",
    "prononciation": "akh-ar-one'",
    "definition": "Dernier, ultérieur, final.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 33:2",
      "Deutéronome 17:7",
      "Ésaïe 44:6",
      "Ésaïe 48:12",
      "Daniel 8:3"
    ],
    "type": "adjectif",
    "occurrences": 51,
    "recherche": "h314 אַחֲרוֹן ʾaḥărôn dernier, ultérieur, final. adjectif",
    "audio": "",
    "image": null,
    "racine": "H310",
    "sens_principal": "Dernier",
    "etymologie": "· Données attestées : Dérivé adjectival de אַחַר (H0310, « après ») avec suffixe ôn indiquant l'extrémité ou la position finale. · Cognats sémitiques : Syriaque : ܐܚܪܝܐ (ʾaḥrāyā, « dernier, final »). Arabe : ʾāḫir (dernier). · Hypothèses linguistiques…",
    "formes_derivees": [
      "H309",
      "H310",
      "H311",
      "H312",
      "H319"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : L'adjectif ʾaḥărôn forme un couple antithétique fondamental avec רִאשׁוֹן (premier). Cette polarité structure la conception biblique du temps et de l'histoire. L'expression « je suis le premier et je suis le dernier » (Ésaïe 44:6 ; 48:12) appliquée à YHWH exprime l'éternité divine embrassant la…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200199,
    "strong": "H315",
    "langue": "hebreu",
    "numero": 315,
    "mot_original": "אַחְרַח",
    "translitteration": "ʾaḥraḥ",
    "prononciation": "akh-rakh'",
    "definition": "Ahrah, descendant de Juda.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 2:25"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h315 אַחְרַח ʾaḥraḥ ahrah, descendant de juda. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahrah",
    "etymologie": "· Données attestées : Nom composé de אָח (H0251, « frère ») + élément רַח d'origine incertaine. · Cognats sémitiques : Non attestés. · Hypothèses linguistiques : L'élément רַח pourrait dériver de רוּחַ (souffle, esprit) ou d'une racine signifiant «…",
    "formes_derivees": [
      "H251"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Ahrah est répertorié dans la généalogie de Yerakhméel (1 Chroniques 2:25 41). Cette branche de la tribu de Juda est détaillée avec un soin particulier par le Chroniste, probablement en raison de l'importance des Yerakhméélites dans le sud judéen à l'époque post exilique. La liste…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200200,
    "strong": "H316",
    "langue": "hebreu",
    "numero": 316,
    "mot_original": "אֲחַרְחֵל",
    "translitteration": "ʾăḥarḥēl",
    "prononciation": "akh-ar-khale'",
    "definition": "Aharhel, descendant de Juda.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 4:8"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h316 אֲחַרְחֵל ʾăḥarḥēl aharhel, descendant de juda. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Aharhel",
    "etymologie": "· Données attestées : Nom composé de אַחַר (H0310, « après ») + élément חֵל d'origine incertaine. · Cognats sémitiques : Non attestés. · Hypothèses linguistiques : L'élément חֵל pourrait dériver de חַיִל (force, armée) ou חֵיל (rempart). Signification incertaine.…",
    "formes_derivees": [
      "H310"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Aharhel est mentionné dans la généalogie de Juda (1 Chroniques 4), chapitre qui énumère les clans judéens avec leurs activités économiques. La notice est brève mais significative : Aharhel est rattaché à une famille de tisserands (1 Chroniques 4:21 23 mentionne les ouvriers du lin…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200201,
    "strong": "H317",
    "langue": "hebreu",
    "numero": 317,
    "mot_original": "אׇחֳרִי",
    "translitteration": "ʾoḥŏrî",
    "prononciation": "okh-or-ee'",
    "definition": "Autre, différent. Correspondance araméenne de l'hébreu אַחֵר (H0312).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 2:11",
      "Daniel 2:39",
      "Daniel 7:5"
    ],
    "type": "adjectif (araméen)",
    "occurrences": 5,
    "recherche": "h317 אׇחֳרִי ʾoḥŏrî autre, différent. correspondance araméenne de l'hébreu אַחֵר (h0312). adjectif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Autre",
    "etymologie": "· Données attestées : Forme araméenne correspondant à l'hébreu אַחֵר (H0312). Racine אחר (ʾḤR). · Cognats sémitiques : Syriaque : ܐܚܪܢܐ (ʾaḥrānā, « autre »). Mandéen : ahura. · Hypothèses linguistiques : La forme araméenne avec suffixe ān (אָחֳרָן) est…",
    "formes_derivees": [
      "H309",
      "H311",
      "H312",
      "H321"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : L'adjectif araméen apparaît exclusivement dans le livre de Daniel, dans les récits de la cour babylonienne. Les sages chaldéens confessent qu'« aucun autre » (וְאָחֳרָן לָא אִיתַי) ne peut répondre à la demande du roi (Daniel 2:11). En Daniel 2:39, un « autre royaume »…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200202,
    "strong": "H318",
    "langue": "hebreu",
    "numero": 318,
    "mot_original": "אׇחֳרֵין",
    "translitteration": "ʾoḥŏrên",
    "prononciation": "okh-or-ane'",
    "definition": "Enfin, finalement, à la fin.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 2:31"
    ],
    "type": "adverbe (araméen)",
    "occurrences": 1,
    "recherche": "h318 אׇחֳרֵין ʾoḥŏrên enfin, finalement, à la fin. adverbe",
    "audio": "",
    "image": null,
    "racine": "H317",
    "sens_principal": "Enfin",
    "etymologie": "· Données attestées : Forme adverbiale araméenne dérivée de la racine אחר (ʾḤR, « être derrière, après »). · Cognats sémitiques : Syriaque : ܐܚܪܝܬ (ʾaḥrāyṯ, « enfin, finalement »). · Hypothèses linguistiques : La forme avec suffixe ên est…",
    "formes_derivees": [
      "H116",
      "H309",
      "H317",
      "H319",
      "H400"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : L'adverbe apparaît dans la vision de la statue de Nabuchodonosor (Daniel 2). Il marque la transition entre la succession des empires (tête d'or, poitrine d'argent, ventre d'airain, jambes de fer, pieds de fer et d'argile) et l'apparition de la pierre qui pulvérise la statue. L'adverbe…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200203,
    "strong": "H319",
    "langue": "hebreu",
    "numero": 319,
    "mot_original": "אַחֲרִית",
    "translitteration": "ʾaḥărîṯ",
    "prononciation": "akh-ar-eeth'",
    "definition": "Fin, issue, avenir, postérité, reste.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Nombres 23:10",
      "Deutéronome 4:30",
      "Proverbes 14:12",
      "Ésaïe 46:10",
      "Daniel 12:8"
    ],
    "type": "nom commun",
    "occurrences": 61,
    "recherche": "h319 אַחֲרִית ʾaḥărîṯ fin, issue, avenir, postérité, reste. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Fin",
    "etymologie": "· Données attestées : Dérivé nominal féminin de אַחַר (H0310, « après »), avec suffixe abstractif îṯ. Littéralement « ce qui est après, ce qui vient en dernier ». · Cognats sémitiques : Syriaque : ܐܚܪܝܬܐ (ʾaḥrāyṯā, « fin, avenir…",
    "formes_derivees": [
      "H309",
      "H310",
      "H311",
      "H312",
      "H314",
      "H320"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le terme ʾaḥărîṯ est central dans la conception biblique du temps et de l'histoire. L'expression « la suite des jours » (אַחֲרִית הַיָּמִים) est la formule eschatologique standard de l'Ancien Testament. Elle désigne un horizon temporel ultime où Dieu interviendra pour restaurer Israël et juger…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200204,
    "strong": "H320",
    "langue": "hebreu",
    "numero": 320,
    "mot_original": "אַחֲרִית",
    "translitteration": "ʾaḥărîṯ",
    "prononciation": "akh-ar-eeth'",
    "definition": "Fin, avenir. Correspondance araméenne de l'hébreu אַחֲרִית (H0319).",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "nom commun (araméen)",
    "occurrences": 0,
    "recherche": "h320 אַחֲרִית ʾaḥărîṯ fin, avenir. correspondance araméenne de l'hébreu אַחֲרִית (h0319). nom commun",
    "audio": "",
    "image": null,
    "racine": "H319",
    "sens_principal": "Fin",
    "etymologie": "· Données attestées : Voir H0319. · Cognats sémitiques : Voir H0319. · Hypothèses linguistiques : Voir H0319. Famille lexicale : · H0319 (אַחֲרִית, hébreu) Racine Strong : H0309 Première occurrence biblique : Voir H0319 Occurrences principales par livre :…",
    "formes_derivees": [
      "H309",
      "H319"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Cette entrée Strong est un doublet de H0319. La classification Strong crée parfois des entrées distinctes pour un même mot apparaissant dans des contextes linguistiques différents (hébreu vs araméen), même lorsque la forme est identique. Aucune occurrence araméenne distincte n'est attestée pour ce terme dans…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200205,
    "strong": "H321",
    "langue": "hebreu",
    "numero": 321,
    "mot_original": "אָחֳרָן",
    "translitteration": "ʾoḥŏrān",
    "prononciation": "okh-or-awn'",
    "definition": "Autre, différent. Variante araméenne de אָחֳרִי (H0317).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 2:11",
      "Daniel 3:29",
      "Daniel 6:16"
    ],
    "type": "adjectif (araméen)",
    "occurrences": 5,
    "recherche": "h321 אָחֳרָן ʾoḥŏrān autre, différent. variante araméenne de אָחֳרִי (h0317). adjectif",
    "audio": "",
    "image": null,
    "racine": "H317",
    "sens_principal": "Autre",
    "etymologie": "· Données attestées : Forme araméenne avec suffixe adjectival ān, correspondant à l'hébreu אַחֵר (H0312). Racine אחר (ʾḤR). · Cognats sémitiques : Syriaque : ܐܚܪܢܐ (ʾaḥrānā, « autre »). · Hypothèses linguistiques : Le suffixe ān est un morphème adjectival…",
    "formes_derivees": [
      "H309",
      "H312",
      "H317",
      "H322",
      "H400"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : Voir H0317. La forme ʾoḥŏrān est une variante morphologique de ʾoḥŏrî, les deux étant utilisées dans les mêmes contextes en Daniel. La coexistence des deux formes (avec suffixe î et suffixe ān) est un trait de l'araméen d'empire, qui admet des variantes dialectales ou stylistiques.…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200206,
    "strong": "H322",
    "langue": "hebreu",
    "numero": 322,
    "mot_original": "אֲחֹרַנִּית",
    "translitteration": "ʾăḥōrannîṯ",
    "prononciation": "akh-o-ran-neeth'",
    "definition": "En arrière, à reculons, vers l'arrière.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 9:23",
      "1 Samuel 4:18",
      "2 Rois 20:10",
      "Ésaïe 38:8"
    ],
    "type": "adverbe",
    "occurrences": 7,
    "recherche": "h322 אֲחֹרַנִּית ʾăḥōrannîṯ en arrière, à reculons, vers l'arrière. adverbe",
    "audio": "",
    "image": null,
    "racine": "H268",
    "sens_principal": "En arrière",
    "etymologie": "· Données attestées : Forme adverbiale dérivée de אָחוֹר (H0268, « arrière, dos ») avec suffixe adverbial annîṯ indiquant la direction. · Cognats sémitiques : Syriaque : ܐܚܪܢܝܬ (ʾaḥrānāyṯ, « en arrière »). · Hypothèses linguistiques : Le suffixe annîṯ…",
    "formes_derivees": [
      "H268",
      "H309",
      "H310",
      "H314"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : L'adverbe décrit un mouvement orienté vers l'arrière. En Genèse 9:23, Sem et Japhet couvrent la nudité de leur père Noé en marchant à reculons pour ne pas le voir, geste de piété filiale contrastant avec l'attitude de Cham. En 1 Samuel 4:18, le grand prêtre…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200207,
    "strong": "H323",
    "langue": "hebreu",
    "numero": 323,
    "mot_original": "אֲחַשְׁדַּרְפָּן",
    "translitteration": "ʾăḥašdarpan",
    "prononciation": "akh-ash-dar-pawn'",
    "definition": "Satrape, gouverneur d'une province de l'Empire perse.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esther 3:12",
      "Esther 8:9",
      "Daniel 3:2",
      "Daniel 6:2"
    ],
    "type": "nom commun",
    "occurrences": 13,
    "recherche": "h323 אֲחַשְׁדַּרְפָּן ʾăḥašdarpan satrape, gouverneur d'une province de l'empire perse. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Satrape",
    "etymologie": "· Données attestées : Emprunt au vieux perse xšaçapāvan (« protecteur du royaume »), composé de xšaça (royaume, empire) + pāvan (protecteur). · Cognats sémitiques : Syriaque : ܐܚܫܕܪܦܢܐ (ʾaḥašdarpanā). Grec : σατράπης (satrapēs, emprunt au perse via le grec).…",
    "formes_derivees": [
      "H324",
      "H400"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "Contexte historique et culturel : L'Empire achéménide (550 330 avant l'ère courante) était divisé en une vingtaine de satrapies, chacune administrée par un satrape (gouverneur) nommé par le roi. Les satrapes étaient responsables de la collecte des impôts, du maintien de l'ordre et de la levée des troupes. Le livre…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200208,
    "strong": "H324",
    "langue": "hebreu",
    "numero": 324,
    "mot_original": "אֲחַשְׁדַּרְפָּן",
    "translitteration": "ʾăḥašdarpan",
    "prononciation": "akh-ash-dar-pawn'",
    "definition": "Satrape. Correspondance araméenne de H0323.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Daniel 3:2",
      "Daniel 6:2"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 9,
    "recherche": "h324 אֲחַשְׁדַּרְפָּן ʾăḥašdarpan satrape. correspondance araméenne de h0323. nom commun",
    "audio": "",
    "image": null,
    "racine": "H323",
    "sens_principal": "Satrape",
    "etymologie": "· Données attestées : Voir H0323. · Cognats sémitiques : Voir H0323. · Hypothèses linguistiques : Voir H0323. Famille lexicale : · H0323 (אֲחַשְׁדַּרְפָּן, hébreu) Racine Strong : Non applicable (emprunt) Première occurrence biblique : Daniel 3:2 Occurrences principales par…",
    "formes_derivees": [
      "H323"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Voir H0323. Les occurrences araméennes du terme apparaissent exclusivement dans le livre de Daniel, dans les récits de la cour babylonienne et médo perse. La forme araméenne avec l'article emphatique ayyāʾ est la forme déterminée standard de l'araméen d'empire. Notes lexicales : · Particularités grammaticales…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200209,
    "strong": "H325",
    "langue": "hebreu",
    "numero": 325,
    "mot_original": "אֲחַשְׁוֵרוֹשׁ",
    "translitteration": "ʾăḥašwērôš",
    "prononciation": "akh-ash-vay-rosh'",
    "definition": "Assuérus, nom de plusieurs rois perses dans la Bible. Identifié à Xerxès Ier (486-465 avant l'ère courante) dans le livre d'Esther.",
    "categorie": "Royaume",
    "references": [
      "Esther 1:1",
      "Esther 2:16",
      "Esdras 4:6",
      "Daniel 9:1"
    ],
    "type": "nom propre",
    "occurrences": 31,
    "recherche": "h325 אֲחַשְׁוֵרוֹשׁ ʾăḥašwērôš assuérus, nom de plusieurs rois perses dans la bible. identifié à xerxès ier (486-465 avant l'ère courante) dans le livre d'esther. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Assuérus",
    "etymologie": "· Données attestées : Translittération hébraïque du vieux perse Xšayāršā (Xerxès), composé de xšaya (régner) + aršan (homme, héros). Signifie « héros parmi les rois » ou « qui règne sur les héros ». · Cognats sémitiques : Syriaque :…",
    "formes_derivees": [
      "H326",
      "H400"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Xerxès Ier (486 465 avant l'ère courante) est le fils de Darius Ier et d'Atossa. Il est connu dans les sources classiques (Hérodote, Eschyle) pour sa campagne contre la Grèce (480 479), marquée par les batailles des Thermopyles, de Salamine et de Platées. Le livre…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200210,
    "strong": "H326",
    "langue": "hebreu",
    "numero": 326,
    "mot_original": "אֲחַשְׁתָּרִי",
    "translitteration": "ʾăḥaštārî",
    "prononciation": "akh-ash-taw-ree'",
    "definition": "Ahashtari, descendant de Juda.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 4:6"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h326 אֲחַשְׁתָּרִי ʾăḥaštārî ahashtari, descendant de juda. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ahashtari",
    "etymologie": "· Données attestées : Nom d'origine incertaine. · Cognats sémitiques : Non attestés. · Hypothèses linguistiques : Possible dérivation du vieux perse ou d'une racine sémitique signifiant « royal, noble » (comparer le nom de la déesse Ishtar). Signification incertaine.…",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Ahashtari est mentionné dans la généalogie de Juda par Ashour, fondateur de Teqoa (1 Chroniques 4:5 7). Ashour eut deux femmes : Héla et Naara. Ahashtari est le quatrième fils de Naara. La notice généalogique de 1 Chroniques 4 énumère les clans judéens associés à…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200211,
    "strong": "H327",
    "langue": "hebreu",
    "numero": 327,
    "mot_original": "אֲחַשְׁתָּרָן",
    "translitteration": "ʾăḥaštārān",
    "prononciation": "akh-ash-taw-rawn'",
    "definition": "Coursier, cheval rapide, monture royale.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esther 8:10",
      "Esther 8:14"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h327 אֲחַשְׁתָּרָן ʾăḥaštārān coursier, cheval rapide, monture royale. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Coursier",
    "etymologie": "· Données attestées : Emprunt au vieux perse xšaça (royaume) + tara (rapide) ou dérivé de xšaçapāvan (satrape) avec altération. Alternativement, possible dérivation de l'akkadien aššatār. · Cognats sémitiques : Syriaque : ܐܚܫܬܪܢܐ (ʾaḥaštərānā, « courrier royal »). · Hypothèses…",
    "formes_derivees": [
      "H328",
      "H400"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Les ʾăḥaštərānîm sont les montures du système postal achéménide (angareion), célèbre dans l'Antiquité pour sa rapidité. Hérodote (8.98) décrit ce système : « Rien au monde ne va plus vite que ces courriers perses... Ni la neige, ni la pluie, ni la chaleur, ni la…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200212,
    "strong": "H328",
    "langue": "hebreu",
    "numero": 328,
    "mot_original": "אַט",
    "translitteration": "ʾaṭ",
    "prononciation": "at",
    "definition": "Lentement, doucement, à pas lents.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 33:14",
      "2 Samuel 18:5",
      "1 Rois 21:27",
      "Ésaïe 8:6",
      "Job 15:11"
    ],
    "type": "adverbe",
    "occurrences": 6,
    "recherche": "h328 אַט ʾaṭ lentement, doucement, à pas lents. adverbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Lentement",
    "etymologie": "· Données attestées : Racine אטה ou אטט (ʾṬṬ, « être lent, doux »). · Cognats sémitiques : Syriaque : ܐܛ (ʾaṭ, « lentement »). Arabe : ʾaṭṭa (être lent, tarder). · Hypothèses linguistiques : La racine apparentée אטט exprime…",
    "formes_derivees": [
      "H329",
      "H819"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : L'adverbe décrit un déplacement lent et mesuré, adapté aux troupeaux et aux enfants (Genèse 33:14 : Jacob ralentit pour ne pas épuiser son bétail et sa famille). En 2 Samuel 18:5, David ordonne à ses généraux de traiter « doucement » le rebelle Absalom. L'expression…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200213,
    "strong": "H329",
    "langue": "hebreu",
    "numero": 329,
    "mot_original": "אָטָד",
    "translitteration": "ʾāṭāḏ",
    "prononciation": "aw-tawd'",
    "definition": "Jujubier, épine, buisson épineux.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 50:10",
      "Juges 9:14",
      "Psaume 58:10"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h329 אָטָד ʾāṭāḏ jujubier, épine, buisson épineux. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Jujubier",
    "etymologie": "· Données attestées : Racine אטד (ʾṬD, « être pointu, épineux »). · Cognats sémitiques : Syriaque : ܐܛܕܐ (ʾaṭdā, « épine, buisson »). Arabe : ʾaṭada (être pointu). · Hypothèses linguistiques : Identification botanique probable : Ziziphus spina christi…",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le jujubier épineux est un arbuste commun dans les régions semi arides du Levant. Dans la fable de Yotam (Juges 9:8 15), les arbres cherchent un roi : l'olivier, le figuier et la vigne refusent, mais le buisson d'épines accepte. Cette satire anti monarchique, prononcée…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200214,
    "strong": "H330",
    "langue": "hebreu",
    "numero": 330,
    "mot_original": "אֵטוּן",
    "translitteration": "ʾēṭûn",
    "prononciation": "ay-toon'",
    "definition": "Lin fin, étoffe précieuse, tissu d'Égypte.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Proverbes 7:16"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h330 אֵטוּן ʾēṭûn lin fin, étoffe précieuse, tissu d'égypte. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Lin fin",
    "etymologie": "· Données attestées : Emprunt à l'égyptien ỉdmỉ (lin fin, étoffe rouge) ou ỉtn (lin). · Cognats sémitiques : Syriaque : ܐܛܘܢܐ (ʾeṭṭûnā, « lin fin »). · Hypothèses linguistiques : L'étymologie égyptienne est généralement acceptée. Le mot désigne un…",
    "formes_derivees": [
      "H331",
      "H400"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le lin égyptien était réputé dans tout le Proche Orient ancien pour sa finesse et sa qualité. Les textiles égyptiens, blanchis ou teints, constituaient un produit d'exportation de luxe. En Proverbes 7:16, la femme adultère déploie tout le luxe de sa chambre pour séduire le…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200215,
    "strong": "H331",
    "langue": "hebreu",
    "numero": 331,
    "mot_original": "אָטַם",
    "translitteration": "ʾāṭam",
    "prononciation": "aw-tam'",
    "definition": "Boucher, fermer, obstruer (spécialement les oreilles).",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Rois 6:4",
      "Psaume 58:5",
      "Proverbes 21:13",
      "Ésaïe 33:15"
    ],
    "type": "verbe",
    "occurrences": 8,
    "recherche": "h331 אָטַם ʾāṭam boucher, fermer, obstruer (spécialement les oreilles). verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Boucher",
    "etymologie": "· Données attestées : Racine אטם (ʾṬM, « être fermé, bouché, obstrué »). · Cognats sémitiques : Syriaque : ܐܛܡ (ʾeṭam, « boucher, fermer »). Arabe : ʾaṭama (fermer, obstruer). · Hypothèses linguistiques : Aucune hypothèse spécifique. Famille lexicale :…",
    "formes_derivees": [
      "H332",
      "H483"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Contexte historique et culturel : Le verbe décrit l'action de fermer hermétiquement. Les fenêtres du Temple de Salomon (1 Rois 6:4) sont décrites comme « des fenêtres à treillis obturées » (חַלּוֹנֵי שְׁקֻפִים אֲטֻמִים), probablement des ouvertures ébrasées avec un grillage fixe. Dans les Psaumes et les Proverbes, l'image du…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200216,
    "strong": "H332",
    "langue": "hebreu",
    "numero": 332,
    "mot_original": "אָטַר",
    "translitteration": "ʾāṭar",
    "prononciation": "aw-tar'",
    "definition": "Fermer, boucher, retenir.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 20:18",
      "Psaume 69:16"
    ],
    "type": "verbe",
    "occurrences": 2,
    "recherche": "h332 אָטַר ʾāṭar fermer, boucher, retenir. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Fermer",
    "etymologie": "· Données attestées : Racine אטר (ʾṬR, « fermer, entourer, retenir »). · Cognats sémitiques : Syriaque : ܐܛܪ (ʾeṭar, « fermer, enfermer »). Arabe : ʾaṭara (entourer, enfermer). · Hypothèses linguistiques : Racine distincte de אטם (H0331), mais sémantiquement…",
    "formes_derivees": [
      "H331",
      "H333"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Contexte historique et culturel : En Genèse 20:18, la fermeture des seinins des femmes de la maison d'Abimélek est une intervention divine pour protéger Sara. La stérilité imposée est une punition temporaire, levée après l'intercession d'Abraham. Dans la culture proche orientale ancienne, la capacité d'enfanter était un signe de bénédiction…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200217,
    "strong": "H333",
    "langue": "hebreu",
    "numero": 333,
    "mot_original": "אָטֵר",
    "translitteration": "ʾāṭēr",
    "prononciation": "aw-tare'",
    "definition": "Ater, « borgne » ou « fermé ». Ancêtre d'une famille de rapatriés de l'exil.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Esdras 2:16",
      "Esdras 2:42",
      "Néhémie 7:21",
      "Néhémie 10:18"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h333 אָטֵר ʾāṭēr ater, « borgne » ou « fermé ». ancêtre d'une famille de rapatriés de l'exil. nom propre",
    "audio": "",
    "image": null,
    "racine": "H332",
    "sens_principal": "Ater",
    "etymologie": "· Données attestées : Dérivé de la racine אטר (ʾṬR, « fermer, boucher »). Le nom signifie probablement « borgne » (celui qui a un œil fermé). · Cognats sémitiques : Syriaque : ܐܛܪܐ (ʾaṭrā, « borgne »). Arabe :…",
    "formes_derivees": [
      "H332"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Ater est l'ancêtre éponyme d'un clan de 98 membres revenus de l'exil avec Zorobabel (Esdras 2:16). Une autre liste (Esdras 2:42 ; Néhémie 7:45) mentionne des « fils d'Ater » parmi les portiers du Temple, totalisant 139 personnes. Un Ater figure aussi parmi les signataires…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200218,
    "strong": "H334",
    "langue": "hebreu",
    "numero": 334,
    "mot_original": "אִטֵּר",
    "translitteration": "ʾiṭṭēr",
    "prononciation": "it-tare'",
    "definition": "Gaucher, empêché de la main droite.",
    "categorie": "Justice et jugement",
    "references": [
      "Juges 3:15",
      "Juges 20:16"
    ],
    "type": "adjectif",
    "occurrences": 2,
    "recherche": "h334 אִטֵּר ʾiṭṭēr gaucher, empêché de la main droite. adjectif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Gaucher",
    "etymologie": "· Données attestées : Racine אטר (ʾṬR, « fermer, lier, empêcher »). Littéralement « celui qui a la main droite fermée, liée ». · Cognats sémitiques : Syriaque : ܐܛܪܐ (ʾaṭrā, « borgne, gaucher »). Arabe : ʾaṭar (être gaucher).…",
    "formes_derivees": [
      "H332"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : La gaucherie est mentionnée comme particularité distinctive. Éhoud le gaucher (Juges 3:15) utilise cette caractéristique pour dissimuler un poignard sur sa cuisse droite et assassiner le roi moabite Églôn. Les 700 guerriers benjaminites gauchers (Juges 20:16), capables de lancer une pierre avec une précision redoutable,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200219,
    "strong": "H335",
    "langue": "hebreu",
    "numero": 335,
    "mot_original": "אַי",
    "translitteration": "ʾay",
    "prononciation": "ah'ee",
    "definition": "Où ? Où donc ?",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 4:9",
      "Deutéronome 32:37",
      "Psaume 42:4",
      "Psaume 115:2"
    ],
    "type": "adverbe interrogatif",
    "occurrences": 0,
    "recherche": "h335 אַי ʾay où ? où donc ? adverbe interrogatif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Où ? Où donc ?",
    "etymologie": "· Données attestées : Particule interrogative sémitique. · Cognats sémitiques : Syriaque : ܐܝܟܐ (ʾaykā, « où ? »). Arabe : ʾayna (où ?). Akkadien : ayyu (quel ? où ?). Ougaritique : ay (où ?). · Hypothèses linguistiques :…",
    "formes_derivees": [
      "H336",
      "H344",
      "H346"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : L'adverbe interrogatif ʾay est la forme la plus simple pour demander « où ? ». La question de YHWH à Caïn (« Où est Abel, ton frère ? », Genèse 4:9) est la première interrogation divine adressée à l'homme après la faute. Dans les Psaumes,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200220,
    "strong": "H336",
    "langue": "hebreu",
    "numero": 336,
    "mot_original": "אִי",
    "translitteration": "ʾî",
    "prononciation": "ee",
    "definition": "Non, pas, il n'y a pas. Particule de négation.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Job 22:30"
    ],
    "type": "adverbe",
    "occurrences": 1,
    "recherche": "h336 אִי ʾî non, pas, il n'y a pas. particule de négation. adverbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Non",
    "etymologie": "· Données attestées : Racine איי (ʾYY, « être sans, ne pas exister »). Comparer אַיִן (H0369, « il n'y a pas ») et אִי (H0339, « île »). · Cognats sémitiques : Syriaque : ܐܝ (ʾî, « non, il…",
    "formes_derivees": [
      "H339",
      "H369"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : Le verset de Job 22:30 est l'un des plus difficiles du livre. Éliphaz affirme que Dieu délivre même le coupable s'il se repent. La lecture אִי־נָקִי peut signifier « celui qui n'est pas innocent » (négation) ou « l'île de l'innocent » (nom). La Septante,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200221,
    "strong": "H337",
    "langue": "hebreu",
    "numero": 337,
    "mot_original": "אִי",
    "translitteration": "ʾî",
    "prononciation": "ee",
    "definition": "Hélas ! Malheur ! Exclamation de lamentation.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Ecclésiaste 4:10"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h337 אִי ʾî hélas ! malheur ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Hélas ! Malheur ! Exclamation de",
    "etymologie": "· Données attestées : Interjection onomatopéique, variante de אוֹי (H0188) et הוֹי (H1945). · Cognats sémitiques : Syriaque : ܘܝ (way). Arabe : way. · Hypothèses linguistiques : Forme abrégée de l'interjection standard. Famille lexicale : · H0188 (אוֹי, malheur…",
    "formes_derivees": [
      "H188",
      "H1945"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "interjection"
    ],
    "notes": "Contexte historique et culturel : L'interjection apparaît dans un contexte sapientiel sur les avantages de la solidarité. Qohélet (Ecclésiaste 4:9 12) vante la supériorité de l'entraide : deux valent mieux qu'un, car ils ont un bon salaire pour leur travail, ils se relèvent mutuellement, ils ont chaud ensemble, et ils…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Interjection"
  },
  {
    "id": 200222,
    "strong": "H338",
    "langue": "hebreu",
    "numero": 338,
    "mot_original": "אִי",
    "translitteration": "ʾî",
    "prononciation": "ee",
    "definition": "Chacal, animal hurlant des ruines.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ésaïe 13:22",
      "Ésaïe 34:14",
      "Jérémie 50:39"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h338 אִי ʾî chacal, animal hurlant des ruines. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Chacal",
    "etymologie": "· Données attestées : Onomatopée imitant le cri plaintif du chacal. · Cognats sémitiques : Syriaque : ܐܝܒܐ (ʾîḇā, « chacal, hyène »). Arabe : ʾawā (hurler, aboyer). · Hypothèses linguistiques : L'identification zoologique précise est débattue entre chacal, hyène…",
    "formes_derivees": [
      "H339",
      "H344"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Les ʾiyyîm (chacals) font partie du bestiaire des ruines dans les oracles prophétiques contre les nations. Leur hurlement nocturne, sinistre et plaintif, symbolise la désolation des villes détruites. Ésaïe 13:22 annonce que Babylone, la superbe, deviendra un repaire de chacals. Ésaïe 34:14 applique la même…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200223,
    "strong": "H339",
    "langue": "hebreu",
    "numero": 339,
    "mot_original": "אִי",
    "translitteration": "ʾî",
    "prononciation": "ee",
    "definition": "Île, région côtière, terre lointaine accessible par mer.",
    "categorie": "Loi et commandement",
    "references": [
      "Genèse 10:5",
      "Ésaïe 41:1",
      "Ésaïe 42:4",
      "Psaume 97:1"
    ],
    "type": "nom commun",
    "occurrences": 36,
    "recherche": "h339 אִי ʾî île, région côtière, terre lointaine accessible par mer. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Île",
    "etymologie": "· Données attestées : Racine אוה (ʾWH, « être proche, adjacent » ?) ou racine distincte signifiant « étendue d'eau entourée de terre ». · Cognats sémitiques : Syriaque : ܐܝܐ (ʾî, « île, péninsule »). Arabe : ʾay (côte,…",
    "formes_derivees": [
      "H336",
      "H338"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Les ʾiyyîm dans la Bible désignent les terres lointaines accessibles par la Méditerranée : îles grecques, côtes d'Asie Mineure, Phénicie, voire l'Occident méditerranéen. Dans la Table des Nations (Genèse 10:5), les descendants de Japhet peuplent « les îles des nations ». Le prophète Ésaïe (surtout…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200224,
    "strong": "H340",
    "langue": "hebreu",
    "numero": 340,
    "mot_original": "אָיַב",
    "translitteration": "ʾāyaḇ",
    "prononciation": "aw-yab'",
    "definition": "Être hostile, être ennemi, haïr.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 23:22",
      "Deutéronome 30:7",
      "Psaume 83:3"
    ],
    "type": "verbe",
    "occurrences": 0,
    "recherche": "h340 אָיַב ʾāyaḇ être hostile, être ennemi, haïr. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Être hostile",
    "etymologie": "· Données attestées : Racine איב (ʾYB, « être hostile, ennemi »). · Cognats sémitiques : Syriaque : ܐܝܒ (ʾîḇ, « être hostile »). Arabe : ʾāba (être en colère, hostile). Akkadien : ābu (ennemi). Ougaritique : ỉb (ennemi). ·…",
    "formes_derivees": [
      "H341",
      "H342",
      "H343",
      "H350"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Contexte historique et culturel : Le verbe est surtout attesté sous sa forme participiale אֹיֵב (ennemi), qui constitue l'un des termes les plus fréquents du vocabulaire militaire et conflictuel de la Bible. La promesse divine d'être « l'ennemi des ennemis » d'Israël (Exode 23:22) fonde la théologie de la guerre…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200225,
    "strong": "H341",
    "langue": "hebreu",
    "numero": 341,
    "mot_original": "אֹיֵב",
    "translitteration": "ʾōyēḇ",
    "prononciation": "o-yabe'",
    "definition": "Ennemi, adversaire.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 22:17",
      "Exode 15:6",
      "Psaume 8:3",
      "Psaume 110:1",
      "Ésaïe 1:24"
    ],
    "type": "nom commun (participe substantivé)",
    "occurrences": 282,
    "recherche": "h341 אֹיֵב ʾōyēḇ ennemi, adversaire. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ennemi",
    "etymologie": "· Données attestées : Participe actif Qal substantivé de אָיַב (H0340, « être hostile, être ennemi »). · Cognats sémitiques : Syriaque : ܐܝܒܐ (ʾîḇā, « ennemi »). Arabe : ʾādū (ennemi). Akkadien : ābu (ennemi). Ougaritique : ỉb (ennemi).…",
    "formes_derivees": [
      "H340",
      "H342",
      "H343"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le terme ʾōyēḇ est le mot standard pour « ennemi » en hébreu biblique, couvrant tout le spectre de l'hostilité : militaire, personnelle, politique et religieuse. Dans les Psaumes, l'ennemi est une figure récurrente dont le psalmiste implore la défaite. La formulation « YHWH dit…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200226,
    "strong": "H342",
    "langue": "hebreu",
    "numero": 342,
    "mot_original": "אֵיבָה",
    "translitteration": "ʾēḇāh",
    "prononciation": "ay-baw'",
    "definition": "Inimitié, hostilité, haine.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 3:15",
      "Nombres 35:21",
      "Ézéchiel 25:15",
      "Ézéchiel 35:5"
    ],
    "type": "nom commun",
    "occurrences": 5,
    "recherche": "h342 אֵיבָה ʾēḇāh inimitié, hostilité, haine. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Inimitié",
    "etymologie": "· Données attestées : Dérivé nominal féminin de אָיַב (H0340, « être hostile »). · Cognats sémitiques : Syriaque : ܐܝܒܘܬܐ (ʾîḇûṯā, « inimitié »). Arabe : ʾadāwa (inimitié). · Hypothèses linguistiques : Aucune hypothèse spécifique. Famille lexicale : ·…",
    "formes_derivees": [
      "H340",
      "H341"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le terme ʾēḇāh apparaît pour la première fois dans l'oracle de Genèse 3:15, appelé traditionnellement « protévangile ». YHWH instaure une hostilité durable entre le serpent et la femme, leurs descendances respectives. Cette inimitié fondatrice structure la vision biblique du conflit entre le bien et…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200227,
    "strong": "H343",
    "langue": "hebreu",
    "numero": 343,
    "mot_original": "אֵיד",
    "translitteration": "ʾêḏ",
    "prononciation": "ade",
    "definition": "Calamité, détresse, ruine, malheur soudain.",
    "categorie": "Deuil et lamentation",
    "references": [
      "Deutéronome 32:35",
      "Job 18:12",
      "Proverbes 1:26",
      "Ésaïe 47:11"
    ],
    "type": "nom commun",
    "occurrences": 24,
    "recherche": "h343 אֵיד ʾêḏ calamité, détresse, ruine, malheur soudain. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Calamité",
    "etymologie": "· Données attestées : Racine איד (ʾYD, « être lourd, pesant, accablant »). Lien possible avec אָוֶן (H0205, « malheur, iniquité »). · Cognats sémitiques : Syriaque : ܐܝܕܐ (ʾîḏā, « calamité »). Arabe : ʾāda (être lourd, accabler). ·…",
    "formes_derivees": [
      "H205",
      "H341"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le terme ʾêḏ désigne une catastrophe soudaine et irréversible, souvent présentée comme la conséquence inéluctable de la méchanceté. Dans le cantique de Moïse (Deutéronome 32:35), Dieu se réserve la vengeance au « jour de leur calamité ». La littérature sapientielle en fait un thème majeur…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200228,
    "strong": "H344",
    "langue": "hebreu",
    "numero": 344,
    "mot_original": "אַיָּה",
    "translitteration": "ʾayyāh",
    "prononciation": "ah-yaw'",
    "definition": "Faucon, busard, oiseau de proie.",
    "categorie": "Royaume",
    "references": [
      "Lévitique 11:14",
      "Deutéronome 14:13",
      "Job 28:7"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h344 אַיָּה ʾayyāh faucon, busard, oiseau de proie. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Faucon",
    "etymologie": "· Données attestées : Racine אוה (ʾWH, « crier, hurler » ?) ou onomatopée imitant le cri perçant du faucon. · Cognats sémitiques : Syriaque : ܐܝܐ (ʾayyā, « faucon, milan »). Arabe : yuʾyuʾ (faucon). Akkadien : ayyu (oiseau…",
    "formes_derivees": [
      "H335",
      "H346"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le faucon figure dans la liste des oiseaux impurs (Lévitique 11:14 ; Deutéronome 14:13), interdits à la consommation. Les oiseaux de proie étaient considérés comme impurs en raison de leur régime carnivore et de leur contact avec le sang et les cadavres. Dans le Proche…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200229,
    "strong": "H345",
    "langue": "hebreu",
    "numero": 345,
    "mot_original": "אַיָּה",
    "translitteration": "ʾayyāh",
    "prononciation": "ah-yaw'",
    "definition": "Aya, « faucon ». Nom de deux personnages bibliques.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 36:24",
      "2 Samuel 3:7",
      "2 Samuel 21:8"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h345 אַיָּה ʾayyāh aya, « faucon ». nom de deux personnages bibliques. nom propre",
    "audio": "",
    "image": null,
    "racine": "H344",
    "sens_principal": "Aya",
    "etymologie": "· Données attestées : Identique au nom de l'oiseau אַיָּה (H0344, « faucon »). Le nom propre dérive probablement du nom de l'animal. · Cognats sémitiques : Voir H0344. · Hypothèses linguistiques : Le nom d'animal comme anthroponyme est un…",
    "formes_derivees": [
      "H344"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Deux personnages distincts portent ce nom. Aya le Horite (Genèse 36:24) est mentionné dans une notice énigmatique : « il trouva les sources chaudes dans le désert en faisant paître les ânes de Tsibéôn, son père ». Cette notice étiologique pourrait conserver le souvenir d'une…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200230,
    "strong": "H346",
    "langue": "hebreu",
    "numero": 346,
    "mot_original": "אַיֵּה",
    "translitteration": "ʾayyēh",
    "prononciation": "ah-yay'",
    "definition": "Où ? Où donc ?",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 18:9",
      "Genèse 22:7",
      "2 Rois 2:14",
      "Psaume 42:4"
    ],
    "type": "adverbe interrogatif",
    "occurrences": 45,
    "recherche": "h346 אַיֵּה ʾayyēh où ? où donc ? adverbe interrogatif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Où ? Où donc ?",
    "etymologie": "· Données attestées : Forme allongée de אַי (H0335, « où ? ») avec suffixe locatif ou emphatique ēh. · Cognats sémitiques : Syriaque : ܐܝܟܐ (ʾaykā, « où ? »). Arabe : ʾayna. · Hypothèses linguistiques : Le suffixe…",
    "formes_derivees": [
      "H335",
      "H344",
      "H375"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : L'adverbe ʾayyēh est la forme la plus courante pour demander « où ? » en hébreu biblique. La question des visiteurs à Abraham : « Où est Sara, ta femme ? » (Genèse 18:9) introduit l'annonce de la naissance d'Isaac. La question d'Isaac : «…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200231,
    "strong": "H347",
    "langue": "hebreu",
    "numero": 347,
    "mot_original": "אִיּוֹב",
    "translitteration": "ʾîyôḇ",
    "prononciation": "ee-yobe'",
    "definition": "Job, « l'assailli », « l'hostilisé » ou « où est le père ? ». Patriarche juste et patient.",
    "categorie": "Justice et jugement",
    "references": [
      "Job 1:1",
      "Job 42:10",
      "Ézéchiel 14:14"
    ],
    "type": "nom propre",
    "occurrences": 58,
    "recherche": "h347 אִיּוֹב ʾîyôḇ job, « l'assailli », « l'hostilisé » ou « où est le père ? ». patriarche juste et patient. nom propre",
    "audio": "",
    "image": null,
    "racine": "H340",
    "sens_principal": "Job",
    "etymologie": "· Données attestées : Nom d'origine incertaine. · Cognats sémitiques : Akkadien : Ayyābu (nom propre attesté dans les textes d'Amarna et de Mari). Ougaritique : ayab (ennemi ?). · Hypothèses linguistiques : 1. Dérivé de אָיַב (H0340, « être…",
    "formes_derivees": [
      "H340",
      "H341"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Job est présenté comme un patriarche non israélite, vivant au pays d'Outs (probablement en Édom ou en Arabie du nord). Le livre qui porte son nom est un chef d'œuvre de la littérature sapientielle, abordant la question de la souffrance du juste. Job, homme intègre…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200232,
    "strong": "H348",
    "langue": "hebreu",
    "numero": 348,
    "mot_original": "אִיזָבֶל",
    "translitteration": "ʾîzāḇel",
    "prononciation": "ee-zeh'-bel",
    "definition": "Jézabel, reine d'Israël, épouse d'Achab, fille du roi de Sidon.",
    "categorie": "Royaume",
    "references": [
      "1 Rois 16:31",
      "1 Rois 18:4",
      "1 Rois 21:5",
      "2 Rois 9:30"
    ],
    "type": "nom propre",
    "occurrences": 22,
    "recherche": "h348 אִיזָבֶל ʾîzāḇel jézabel, reine d'israël, épouse d'achab, fille du roi de sidon. nom propre",
    "audio": "",
    "image": null,
    "racine": "H349",
    "sens_principal": "Jézabel",
    "etymologie": "· Données attestées : Variante de אִיזָבֶל (H0349). · Cognats sémitiques : Voir H0349. · Hypothèses linguistiques : Voir H0349. Famille lexicale : · H0349 (אִיזָבֶל, Jézabel) Racine Strong : Non applicable (nom propre) Première occurrence biblique : 1 Rois…",
    "formes_derivees": [
      "H349"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Cette entrée Strong est une variante orthographique de H0349. La forme אִיזֶבֶל avec segol sous le zayin est une variante textuelle mineure. Pour les notes complètes, voir H0349. Notes lexicales : · Particularités grammaticales : Voir H0349. · Particularités sémantiques : Voir H0349. · Questions…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200233,
    "strong": "H349",
    "langue": "hebreu",
    "numero": 349,
    "mot_original": "אֵיךְ",
    "translitteration": "ʾêyk",
    "prononciation": "ake",
    "definition": "Comment ? de quelle manière ? (parfois aussi : où ?).",
    "categorie": "Foi",
    "references": [],
    "type": "adverbe interrogatif",
    "occurrences": 0,
    "recherche": "h349 אֵיךְ ʾêyk comment ? de quelle manière ? (parfois aussi : où ?). adverbe interrogatif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Jézabel",
    "etymologie": "· Données attestées : Nom phénicien, probablement composé de אִי (île, côte ?) + זָבַל (H2082, « élever, honorer, habiter »). · Cognats sémitiques : Phénicien : (ʾbzl, nom attesté sur un sceau). Syriaque : ܐܝܙܒܠ (ʾîzāḇel). · Hypothèses linguistiques…",
    "formes_derivees": [
      "H348",
      "H2082"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Jézabel, princesse phénicienne, fille du roi prêtre Éthbaal de Sidon (règne : environ 887 856 avant l'ère courante selon Ménandre d'Éphèse cité par Josèphe), épousa Achab roi d'Israël pour sceller une alliance politique et commerciale. Elle introduisit en Israël le culte de Baal Melqart (divinité…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200234,
    "strong": "H350",
    "langue": "hebreu",
    "numero": 350,
    "mot_original": "אִי־כָבוֹד",
    "translitteration": "ʾî-ḵāḇôḏ",
    "prononciation": "ee-kaw-bode'",
    "definition": "I-Kabod, « pas de gloire » ou « où est la gloire ? ». Fils de Phinéas, né après la capture de l'arche.",
    "categorie": "Loi et commandement",
    "references": [
      "1 Samuel 4:21"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h350 אִי־כָבוֹד ʾî-ḵāḇôḏ i-kabod, « pas de gloire » ou « où est la gloire ? ». fils de phinéas, né après la capture de l'arche. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "I Kabod",
    "etymologie": "· Données attestées : Composé de אִי (H0336, « non, il n'y a pas » ou « où ? ») + כָּבוֹד (H3519, « gloire, honneur, présence divine »). · Cognats sémitiques : Non attestés comme nom propre. · Hypothèses…",
    "formes_derivees": [
      "H336",
      "H351",
      "H360",
      "H3519"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : I Kabod est né dans des circonstances tragiques. Sa mère, épouse de Phinéas (fils du grand prêtre Éli), apprenant coup sur coup la mort de son mari, la mort de son beau père et la capture de l'arche d'alliance par les Philistins, entre en travail…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200235,
    "strong": "H351",
    "langue": "hebreu",
    "numero": 351,
    "mot_original": "אֵיכֹה",
    "translitteration": "ʾêḵōh",
    "prononciation": "ay-ko'",
    "definition": "Où ? Vers où ? Comment ?",
    "categorie": "Vocabulaire courant",
    "references": [
      "2 Rois 6:13",
      "Cantiques 1:7"
    ],
    "type": "adverbe interrogatif",
    "occurrences": 3,
    "recherche": "h351 אֵיכֹה ʾêḵōh où ? vers où ? comment ? adverbe interrogatif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Où ? Vers où ? Comment",
    "etymologie": "· Données attestées : Forme allongée de אֵי (H0335, « où ? ») + suffixe kōh (directif ou emphatique). · Cognats sémitiques : Syriaque : ܐܝܟܐ (ʾaykā, « où ? »). Arabe : ʾayna. · Hypothèses linguistiques : Le suffixe…",
    "formes_derivees": [
      "H335",
      "H346",
      "H349",
      "H375"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : La forme ʾêḵōh est une variante archaïque ou poétique de l'adverbe interrogatif de lieu. En 2 Rois 6:13, le roi de Syrie cherche à localiser le prophète Élisée qui déjoue ses plans militaires. Dans le Cantique des Cantiques 1:7, la bien aimée demande où son…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200236,
    "strong": "H352",
    "langue": "hebreu",
    "numero": 352,
    "mot_original": "אַיִל",
    "translitteration": "ʾayil",
    "prononciation": "ah'-yil",
    "definition": "Bélier, mâle de l'ovin.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 15:9",
      "Genèse 22:13",
      "Exode 29:15",
      "Lévitique 8:18"
    ],
    "type": "nom commun",
    "occurrences": 185,
    "recherche": "h352 אַיִל ʾayil bélier, mâle de l'ovin. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Bélier",
    "etymologie": "· Données attestées : Racine אול (ʾWL, « être fort, puissant, premier »). Le bélier est « le fort, le puissant » du troupeau. · Cognats sémitiques : Syriaque : ܐܝܠܐ (ʾaylā, « bélier, cerf »). Arabe : ʾayyil (cerf,…",
    "formes_derivees": [
      "H193",
      "H353",
      "H354",
      "H410"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le bélier était l'un des principaux animaux sacrificiels en Israël. Il était offert en holocauste (ʿolāh), en sacrifice de culpabilité (ʾāšām) et lors de la consécration des prêtres (Exode 29 ; Lévitique 8). Le sacrifice d'Isaac (Genèse 22) culmine avec le bélier substitué à l'enfant,…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200237,
    "strong": "H353",
    "langue": "hebreu",
    "numero": 353,
    "mot_original": "אֱיָל",
    "translitteration": "ʾĕyāl",
    "prononciation": "eh-yawl'",
    "definition": "Force, vigueur, puissance.",
    "categorie": "Puissance et autorité",
    "references": [
      "Psaume 22:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h353 אֱיָל ʾĕyāl force, vigueur, puissance. nom commun",
    "audio": "",
    "image": null,
    "racine": "H352",
    "sens_principal": "Force",
    "etymologie": "· Données attestées : Dérivé de la racine אול (ʾWL, « être fort, puissant »), apparenté à אַיִל (H0352, « bélier, chef, pilier »). · Cognats sémitiques : Syriaque : ܐܝܠܐ (ʾaylā, « force, secours »). Arabe : ʾayyil (cerf,…",
    "formes_derivees": [
      "H193",
      "H352",
      "H354",
      "H360"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le terme apparaît dans le Psaume 22, lamentation individuelle citée par Jésus en croix (« Mon Dieu, mon Dieu, pourquoi m'as tu abandonné ? »). Le verset 20 est un appel pressant au secours divin. La « force » (אֱיָלוּתִי) personnifiée est invoquée comme attribut…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200238,
    "strong": "H354",
    "langue": "hebreu",
    "numero": 354,
    "mot_original": "אַיָּל",
    "translitteration": "ʾayyāl",
    "prononciation": "ah-yawl'",
    "definition": "Cerf, daim, chevreuil.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 12:15",
      "Deutéronome 12:22",
      "1 Rois 5:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h354 אַיָּל ʾayyāl cerf, daim, chevreuil. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Cerf",
    "etymologie": "· Données attestées : Racine אול (ʾWL, « être fort, vigoureux »). Le cerf est « le fort, le vigoureux » par excellence. · Cognats sémitiques : Syriaque : ܐܝܠܐ (ʾaylā, « cerf »). Arabe : ʾayyil (cerf, bouquetin). Akkadien…",
    "formes_derivees": [
      "H193",
      "H352",
      "H353",
      "H355"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le cerf est mentionné parmi les animaux purs comestibles, avec la gazelle (צְּבִי), le chevreuil (יַחְמוּר) et le bouquetin (אַקּוֹ). La législation deutéronomique (12:15, 22) permet l'abattage profane de ces animaux, sans ritualisation sacrificielle au sanctuaire central. À la table de Salomon (1 Rois 5:3),…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200239,
    "strong": "H355",
    "langue": "hebreu",
    "numero": 355,
    "mot_original": "אַיָּלָה",
    "translitteration": "ʾayyālāh",
    "prononciation": "ah-yaw-law'",
    "definition": "Biche, femelle du cerf.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 49:21",
      "Psaume 18:34",
      "Psaume 42:2",
      "Cantiques 2:7",
      "Habacuc 3:19"
    ],
    "type": "nom commun",
    "occurrences": 7,
    "recherche": "h355 אַיָּלָה ʾayyālāh biche, femelle du cerf. nom commun",
    "audio": "",
    "image": null,
    "racine": "H354",
    "sens_principal": "Biche",
    "etymologie": "· Données attestées : Forme féminine de אַיָּל (H0354, « cerf »). Voir H0354. · Cognats sémitiques : Voir H0354. · Hypothèses linguistiques : Voir H0354. Famille lexicale : · H0354 (אַיָּל, cerf) · H0352 (אַיִל, bélier) Racine Strong :…",
    "formes_derivees": [
      "H193",
      "H352",
      "H354"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : La biche est le symbole poétique de la grâce, de l'agilité et du désir ardent. En Genèse 49:21, Jacob bénit Nephtali en le comparant à « une biche élancée ». Les Psaumes comparent le psalmiste à la biche assoiffée cherchant l'eau (Psaume 42:2) et décrivent…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200240,
    "strong": "H356",
    "langue": "hebreu",
    "numero": 356,
    "mot_original": "אֵילוֹן",
    "translitteration": "ʾêlôn",
    "prononciation": "ay-lone'",
    "definition": "Élon, « grand arbre, chêne, térébinthe ». Nom de trois personnages et d'un lieu.",
    "categorie": "Royaume",
    "references": [
      "Genèse 26:34",
      "Juges 12:11",
      "Genèse 46:14",
      "Josué 19:43"
    ],
    "type": "nom propre (toponyme / anthroponyme)",
    "occurrences": 10,
    "recherche": "h356 אֵילוֹן ʾêlôn élon, « grand arbre, chêne, térébinthe ». nom de trois personnages et d'un lieu. nom propre",
    "audio": "",
    "image": null,
    "racine": "H352",
    "sens_principal": "Élon",
    "etymologie": "· Données attestées : Dérivé de אַיִל (H0352, « bélier, pilier ») avec suffixe ôn. Le sens est « grand arbre, térébinthe, chêne » (comparer אֵלָה, H0424, térébinthe). · Cognats sémitiques : Syriaque : ܐܝܠܢܐ (ʾîlānā, « arbre »). Arabe…",
    "formes_derivees": [
      "H352",
      "H424",
      "H436"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Plusieurs personnages distincts portent ce nom. Élon le Hittite (Genèse 26:34 ; 36:2) est le beau père d'Ésaü, témoignant des alliances matrimoniales entre les patriarches et les populations locales cananéennes. Élon de Zabulon (Juges 12:11 12) est l'un des juges « mineurs » : la…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200241,
    "strong": "H357",
    "langue": "hebreu",
    "numero": 357,
    "mot_original": "אַיָּלוֹן",
    "translitteration": "ʾayyālôn",
    "prononciation": "ah-yaw-lone'",
    "definition": "Ayyalôn, « lieu des cerfs » ou « grande biche ». Nom de plusieurs localités.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Josué 10:12",
      "Josué 19:42",
      "Juges 1:35",
      "2 Chroniques 11:10"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 10,
    "recherche": "h357 אַיָּלוֹן ʾayyālôn ayyalôn, « lieu des cerfs » ou « grande biche ». nom de plusieurs localités. nom propre",
    "audio": "",
    "image": null,
    "racine": "H354",
    "sens_principal": "Ayyalôn",
    "etymologie": "· Données attestées : Dérivé de אַיָּל (H0354, « cerf ») avec suffixe ôn. Signifie « lieu des cerfs » ou « grande biche ». · Cognats sémitiques : Syriaque : ܐܝܠܢܐ (ʾîlānā, « arbre » lien incertain). · Hypothèses…",
    "formes_derivees": [
      "H354",
      "H355"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Contexte historique et culturel : Ayyalôn (Tell Qoqʿa ou Yalo, à 20 km à l'ouest de Jérusalem) est célèbre pour le miracle de Josué arrêtant le soleil et la lune (Josué 10:12 14). La vallée d'Ayyalôn, large couloir naturel entre la plaine côtière et les monts de Judée, était une…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200242,
    "strong": "H358",
    "langue": "hebreu",
    "numero": 358,
    "mot_original": "אֵילוֹן בֵּית חָנָן",
    "translitteration": "ʾêlôn bêṯ ḥānān",
    "prononciation": "ay-lone' bayth khaw-nawn'",
    "definition": "Élon-Beth-Hanan, « grand arbre de la maison de grâce ». Localité du district de Salomon.",
    "categorie": "Grâce et miséricorde",
    "references": [
      "1 Rois 4:9"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h358 אֵילוֹן בֵּית חָנָן ʾêlôn bêṯ ḥānān élon-beth-hanan, « grand arbre de la maison de grâce ». localité du district de salomon. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Élon Beth Hanan",
    "etymologie": "· Données attestées : Composé de אֵילוֹן (H0356, « grand arbre, chêne ») + בַּיִת (H1004, « maison ») + חָנָן (H2603, « grâce, miséricorde »). · Cognats sémitiques : Non attestés comme toponyme composé. · Hypothèses linguistiques : Le…",
    "formes_derivees": [
      "H356",
      "H1004",
      "H2603"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Contexte historique et culturel : Élon Beth Hanan est mentionnée dans la liste des douze districts fiscaux de Salomon (1 Rois 4:7 19). Elle fait partie du deuxième district, administré par Ben Déqer, qui couvrait une partie de la Shéphélah et de la plaine côtière (Shaalbîm, Beth Shémesh). La localisation…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200243,
    "strong": "H359",
    "langue": "hebreu",
    "numero": 359,
    "mot_original": "אֵילַת",
    "translitteration": "ʾêlaṯ",
    "prononciation": "ay-lawth'",
    "definition": "Élath, port sur la mer Rouge (golfe d'Aqaba).",
    "categorie": "Noms propres bibliques",
    "references": [
      "Deutéronome 2:8",
      "1 Rois 9:26",
      "2 Rois 14:22"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 3,
    "recherche": "h359 אֵילַת ʾêlaṯ élath, port sur la mer rouge (golfe d'aqaba). nom propre",
    "audio": "",
    "image": null,
    "racine": "H352",
    "sens_principal": "Élath",
    "etymologie": "· Données attestées : Toponyme d'origine sémitique, probablement dérivé de אַיִל (H0352, « bélier, pilier ») ou אֵלָה (H0424, « térébinthe »). · Cognats sémitiques : Akkadien : Elatu (nom de lieu). Arabe : Ayla (nom médiéval d'Aqaba). · Hypothèses…",
    "formes_derivees": [
      "H352",
      "H360",
      "H424"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Élath (Eilat) est un port stratégique à la pointe nord du golfe d'Aqaba, donnant accès à la mer Rouge et au commerce avec l'Arabie, l'Afrique orientale et l'Inde. Salomon y établit une flotte commerciale avec l'aide de Hiram de Tyr (1 Rois 9:26 28). Perdue…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200244,
    "strong": "H360",
    "langue": "hebreu",
    "numero": 360,
    "mot_original": "אֵילוֹת",
    "translitteration": "ʾêlôṯ",
    "prononciation": "ay-loth'",
    "definition": "Éloth, variante orthographique de Élath (H0359).",
    "categorie": "Noms propres bibliques",
    "references": [],
    "type": "nom propre (toponyme)",
    "occurrences": 3,
    "recherche": "h360 אֵילוֹת ʾêlôṯ éloth, variante orthographique de élath (h0359). nom propre",
    "audio": "",
    "image": null,
    "racine": "H359",
    "sens_principal": "Éloth",
    "etymologie": "· Données attestées : Variante de אֵילַת (H0359). · Cognats sémitiques : Voir H0359. · Hypothèses linguistiques : L'alternance at / ôt est un phénomène morphologique connu pour les toponymes. Famille lexicale : · H0359 (אֵילַת, Élath) Racine Strong :…",
    "formes_derivees": [
      "H359",
      "H361",
      "H370"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Cette entrée est une variante orthographique de H0359. La forme אֵילוֹת (pluriel ou féminin pluriel) alterne avec אֵילַת (féminin singulier) pour désigner le même port. Pour les notes complètes, voir H0359. Notes lexicales : · Particularités grammaticales : La forme אֵילוֹת est un pluriel féminin…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200245,
    "strong": "H361",
    "langue": "hebreu",
    "numero": 361,
    "mot_original": "אֵילָם",
    "translitteration": "ʾêlām",
    "prononciation": "ay-lawm'",
    "definition": "Vestibule, portique, galerie à colonnes.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ézéchiel 40:16",
      "Ézéchiel 41:15"
    ],
    "type": "nom commun",
    "occurrences": 15,
    "recherche": "h361 אֵילָם ʾêlām vestibule, portique, galerie à colonnes. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Vestibule",
    "etymologie": "· Données attestées : Variante de אוּלָם (H0197, « vestibule, portique »), avec métathèse ou alternance vocalique. · Cognats sémitiques : Syriaque : ܐܝܠܡܐ (ʾêlāmā, « portique »). Arabe : ʾaylama (être devant). · Hypothèses linguistiques : La forme אֵילָם…",
    "formes_derivees": [
      "H197"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le terme apparaît exclusivement dans la vision du Temple eschatologique d'Ézéchiel (chapitres 40 48). Les ʾêlammôt sont les vestibules ou portiques des portes et des parvis du Temple idéal. Ézéchiel, prêtre et prophète exilé à Babylone (593 571 avant l'ère courante), décrit avec une précision…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200246,
    "strong": "H362",
    "langue": "hebreu",
    "numero": 362,
    "mot_original": "אֵילִם",
    "translitteration": "ʾêlim",
    "prononciation": "ay-leem'",
    "definition": "Élim, « grands arbres, térébinthes ». Oasis dans le désert après le passage de la mer.",
    "categorie": "Sagesse et connaissance",
    "references": [
      "Exode 15:27",
      "Exode 16:1",
      "Nombres 33:9"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 6,
    "recherche": "h362 אֵילִם ʾêlim élim, « grands arbres, térébinthes ». oasis dans le désert après le passage de la mer. nom propre",
    "audio": "",
    "image": null,
    "racine": "H352",
    "sens_principal": "Élim",
    "etymologie": "· Données attestées : Pluriel de אַיִל (H0352, « bélier, pilier ») au sens de « grand arbre, térébinthe » (comparer אֵלָה, H0424). · Cognats sémitiques : Voir H0352. · Hypothèses linguistiques : Le toponyme signifie « les grands arbres…",
    "formes_derivees": [
      "H352",
      "H424"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Élim est la seconde station après le passage de la mer des Joncs, succédant à Mara (les eaux amères). L'oasis offre un contraste saisissant avec le désert : douze sources (une par tribu) et soixante dix palmiers (symbole de plénitude). La localisation traditionnelle est le…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200247,
    "strong": "H363",
    "langue": "hebreu",
    "numero": 363,
    "mot_original": "אִילָן",
    "translitteration": "ʾîlān",
    "prononciation": "ee-lawn'",
    "definition": "Arbre. Correspondance araméenne de l'hébreu אֵיל (arbre).",
    "categorie": "Nature et création",
    "references": [
      "Daniel 4:7",
      "Daniel 4:17"
    ],
    "type": "nom commun (araméen)",
    "occurrences": 6,
    "recherche": "h363 אִילָן ʾîlān arbre. correspondance araméenne de l'hébreu אֵיל (arbre). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Arbre",
    "etymologie": "· Données attestées : Forme araméenne correspondant à l'hébreu אֵיל (grand arbre) ou אֵלָה (térébinthe). Racine אול (ʾWL, « être fort »). · Cognats sémitiques : Syriaque : ܐܝܠܢܐ (ʾîlānā, « arbre »). Arabe : ʾayl (arbre). Mandéen : ailana.…",
    "formes_derivees": [
      "H352",
      "H424",
      "H436"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom"
    ],
    "notes": "Contexte historique et culturel : L'ʾîlān du songe de Nabuchodonosor (Daniel 4) est un arbre cosmique, image répandue dans l'iconographie et la littérature proche orientale. L'arbre atteint le ciel, nourrit toutes les créatures et abrite les oiseaux. Il symbolise l'empire babylonien et son roi. Sa coupe par le « Guetteur…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200248,
    "strong": "H364",
    "langue": "hebreu",
    "numero": 364,
    "mot_original": "אֵיל פָּארָן",
    "translitteration": "ʾêl pāʾrān",
    "prononciation": "ale paw-rawn'",
    "definition": "Él-Paran, « grand arbre de Paran » ou « térébinthe de Paran ». Localité du désert.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 14:6"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h364 אֵיל פָּארָן ʾêl pāʾrān él-paran, « grand arbre de paran » ou « térébinthe de paran ». localité du désert. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Él Paran",
    "etymologie": "· Données attestées : Composé de אֵיל (grand arbre, térébinthe) + פָּארָן (H6290, Paran, désert du Sinaï). · Cognats sémitiques : Non attestés. · Hypothèses linguistiques : Le toponyme signifie « le grand arbre de Paran » ou « le…",
    "formes_derivees": [
      "H352",
      "H6290"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Contexte historique et culturel : Él Paran est mentionné dans le récit de la campagne des quatre rois orientaux (Genèse 14). Cette coalition mésopotamienne (Amraphel de Shinear, Ariok d'Ellasar, Kedorlaomer d'Élam, Tideal de Goyim) soumet les populations de Transjordanie et du Néguev. Él Paran marque la limite méridionale de leur…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200249,
    "strong": "H365",
    "langue": "hebreu",
    "numero": 365,
    "mot_original": "אַיֶּלֶת",
    "translitteration": "ʾayyeleṯ",
    "prononciation": "ah-yeh´-leth",
    "definition": "Biche, forme apparentée à H0355 utilisée notamment dans un titre de psaume (« Biche de l'aurore »).",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "nom commun (forme construite)",
    "occurrences": 0,
    "recherche": "h365 אַיֶּלֶת ʾayyeleṯ biche, forme apparentée à h0355 utilisée notamment dans un titre de psaume (« biche de l'aurore »). nom commun",
    "audio": "",
    "image": null,
    "racine": "H355",
    "sens_principal": "Biche",
    "etymologie": "· Données attestées : Voir H0355. · Cognats sémitiques : Voir H0355. · Hypothèses linguistiques : Voir H0355. Famille lexicale : · H0355 (אַיָּלָה, biche) Racine Strong : H0354 Première occurrence biblique : Voir H0355 Occurrences principales par livre :…",
    "formes_derivees": [
      "H354",
      "H355"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Cette entrée Strong est un doublet de H0355. La classification Strong attribue parfois deux numéros au même mot en fonction de variations contextuelles ou de traditions de comptage différentes. Pour les notes complètes, voir H0355. Notes lexicales : · Particularités grammaticales : Voir H0355. ·…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200250,
    "strong": "H366",
    "langue": "hebreu",
    "numero": 366,
    "mot_original": "אָיֹם",
    "translitteration": "ʾāyōm",
    "prononciation": "aw-yome'",
    "definition": "Terrible, redoutable, imposant.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Cantiques 6:4",
      "Cantiques 6:10",
      "Habacuc 1:7"
    ],
    "type": "adjectif",
    "occurrences": 3,
    "recherche": "h366 אָיֹם ʾāyōm terrible, redoutable, imposant. adjectif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Terrible",
    "etymologie": "· Données attestées : Racine אים (ʾYM, « être terrible, effrayant »). · Cognats sémitiques : Syriaque : ܐܝܡܐ (ʾêmā, « terreur, effroi »). Arabe : ʾāma (être terrifiant). Akkadien : emu (terreur). · Hypothèses linguistiques : La racine est…",
    "formes_derivees": [
      "H367",
      "H368"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : L'adjectif qualifie une beauté imposante qui inspire la crainte et l'admiration. Dans le Cantique des Cantiques, la bien aimée est décrite comme « redoutable comme des bataillons » (6:4, 10), oxymore poétique associant la beauté et la terreur. En Habacuc 1:7, les Chaldéens (Babyloniens) sont…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200251,
    "strong": "H367",
    "langue": "hebreu",
    "numero": 367,
    "mot_original": "אֵימָה",
    "translitteration": "ʾêmāh",
    "prononciation": "ay-maw'",
    "definition": "Terreur, effroi, épouvante.",
    "categorie": "Royaume",
    "references": [
      "Genèse 15:12",
      "Exode 15:16",
      "Exode 23:27",
      "Job 9:34"
    ],
    "type": "nom commun",
    "occurrences": 17,
    "recherche": "h367 אֵימָה ʾêmāh terreur, effroi, épouvante. nom commun",
    "audio": "",
    "image": null,
    "racine": "H366",
    "sens_principal": "Terreur",
    "etymologie": "· Données attestées : Dérivé nominal féminin de la racine אים (ʾYM, « être terrible, effrayant »). Voir H0366. · Cognats sémitiques : Syriaque : ܐܝܡܐ (ʾêmā, « terreur »). Arabe : ʾāma (terreur, effroi). Akkadien : emmu (terreur). ·…",
    "formes_derivees": [
      "H366",
      "H368"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : La ʾêmāh est une terreur d'origine divine, souvent associée aux théophanies et aux interventions guerrières de YHWH. En Genèse 15:12, une « terreur de grande obscurité » saisit Abraham lors de la conclusion de l'alliance. En Exode 15:16, « la terreur et l'épouvante » tombent…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200252,
    "strong": "H368",
    "langue": "hebreu",
    "numero": 368,
    "mot_original": "אֵימִים",
    "translitteration": "ʾêmîm",
    "prononciation": "ay-meem'",
    "definition": "Émim, « les terribles ». Peuple légendaire de Transjordanie, identifié aux Rephaïm.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 14:5",
      "Deutéronome 2:10"
    ],
    "type": "nom propre (ethnonyme)",
    "occurrences": 3,
    "recherche": "h368 אֵימִים ʾêmîm émim, « les terribles ». peuple légendaire de transjordanie, identifié aux rephaïm. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Émim",
    "etymologie": "· Données attestées : Pluriel de אֵימָה (H0367, « terreur »). Signifie « les terribles, les redoutables ». · Cognats sémitiques : Moabite : ʾmym (attesté dans les inscriptions). Akkadien : emu (terreur). · Hypothèses linguistiques : Le nom est…",
    "formes_derivees": [
      "H366",
      "H367",
      "H7497"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Les Émim sont mentionnés parmi les populations pré israélites de Transjordanie. La tradition biblique les assimile aux Rephaïm et aux Anaqim, peuples légendaires de géants. Deutéronome 2:10 11 précise que les Moabites les appelaient Émim (« les terribles »). Ils furent vaincus par Kedorlaomer (Genèse…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200253,
    "strong": "H369",
    "langue": "hebreu",
    "numero": 369,
    "mot_original": "אַיִן",
    "translitteration": "ʾayin",
    "prononciation": "ah'-yin",
    "definition": "Il n'y a pas, rien, néant, non-existence.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 2:5",
      "Exode 5:11",
      "Deutéronome 4:35",
      "Psaume 14:1",
      "Ésaïe 45:5"
    ],
    "type": "adverbe / nom commun",
    "occurrences": 790,
    "recherche": "h369 אַיִן ʾayin il n'y a pas, rien, néant, non-existence. adverbe / nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Il n'y a pas",
    "etymologie": "· Données attestées : Composé de אִי (H0336, « non, il n'y a pas ») + suffixe ן. Racine איי (ʾYY, « être sans, ne pas exister »). · Cognats sémitiques : Syriaque : ܠܝܬ (layṯ, « il n'y a…",
    "formes_derivees": [
      "H336",
      "H360",
      "H657"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : ʾAyin / ʾên est la principale négation d'existence en hébreu biblique. Elle nie la présence ou l'existence d'un être, d'un objet ou d'un état. La formule « il n'y a pas de Dieu » (אֵין אֱלֹהִים, Psaume 14:1) est l'expression de l'athéisme pratique de l'insensé.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200254,
    "strong": "H370",
    "langue": "hebreu",
    "numero": 370,
    "mot_original": "אַיִן",
    "translitteration": "ʾayin",
    "prononciation": "ah'-yin",
    "definition": "Où ? D'où ?",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 16:8",
      "Job 1:7",
      "Job 28:12",
      "Jonas 1:8"
    ],
    "type": "adverbe interrogatif (homographe de h0369)",
    "occurrences": 0,
    "recherche": "h370 אַיִן ʾayin où ? d'où ? adverbe interrogatif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Où ? D'où ?",
    "etymologie": "· Données attestées : Forme renforcée de אַי (H0335, « où ? ») avec suffixe ן. Distinct de אַיִן (H0369, « il n'y a pas ») par l'étymologie et l'usage. · Cognats sémitiques : Syriaque : ܐܝܢܐ (ʾaynā, « où…",
    "formes_derivees": [
      "H335",
      "H346",
      "H369",
      "H371",
      "H380"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : La forme מֵאַיִן (mê ʾayin, « d'où ? ») est la formule standard pour interroger sur l'origine géographique ou existentielle. En Genèse 16:8, l'ange de YHWH interroge Hagar sur sa provenance. En Job 1:7, YHWH demande à Satan : « D'où viens tu ? »…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200255,
    "strong": "H371",
    "langue": "hebreu",
    "numero": 371,
    "mot_original": "אִין",
    "translitteration": "ʾîn",
    "prononciation": "een",
    "definition": "Est-ce qu'il n'y a pas ? N'y a-t-il pas ? Particule interrogative négative.",
    "categorie": "Vocabulaire courant",
    "references": [
      "1 Samuel 21:9"
    ],
    "type": "adverbe interrogatif / particule",
    "occurrences": 1,
    "recherche": "h371 אִין ʾîn est-ce qu'il n'y a pas ? n'y a-t-il pas ? particule interrogative négative. adverbe interrogatif / particule",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Est ce qu'il n'y a pas",
    "etymologie": "· Données attestées : Contraction de אִי (H0336, « non, il n'y a pas ») + interrogation, ou variante de אַיִן (H0369, « il n'y a pas »). · Cognats sémitiques : Syriaque : ܐܝܢ (ʾîn, « n'y a t…",
    "formes_derivees": [
      "H336",
      "H369"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : La forme rare ʾîn apparaît dans la question de David au prêtre Ahimélek de Nob. David, en fuite devant Saül, cherche une arme. Le prêtre lui donne l'épée de Goliath, conservée dans le sanctuaire. La question introduite par ʾîn exprime l'urgence et l'espoir d'une réponse…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200256,
    "strong": "H372",
    "langue": "hebreu",
    "numero": 372,
    "mot_original": "אִיעֶזֶר",
    "translitteration": "ʾîʿezer",
    "prononciation": "ee-eh'-zer",
    "definition": "Iézer, forme abrégée de Abiézer (H0044). Nom d'un guerrier de David.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Chroniques 27:12"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h372 אִיעֶזֶר ʾîʿezer iézer, forme abrégée de abiézer (h0044). nom d'un guerrier de david. nom propre",
    "audio": "",
    "image": null,
    "racine": "H44",
    "sens_principal": "Iézer",
    "etymologie": "· Données attestées : Forme contractée de אֲבִיעֶזֶר (H0044, « mon père est secours »). · Cognats sémitiques : Voir H0044. · Hypothèses linguistiques : La contraction du nom par aphérèse (chute de la syllabe initiale) est un phénomène onomastique…",
    "formes_derivees": [
      "H33",
      "H44"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Cette entrée Strong est une variante rare ou une erreur de lecture pour Abiézer (H0044). La forme contractée אִיעֶזֶר n'est pas clairement attestée dans le texte massorétique standard. Pour les notes complètes, voir H0044. Notes lexicales : · Particularités grammaticales : Variante onomastique par aphérèse.…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200257,
    "strong": "H373",
    "langue": "hebreu",
    "numero": 373,
    "mot_original": "אִיעֶזְרִי",
    "translitteration": "ʾîʿezrî",
    "prononciation": "ee-ez-ree'",
    "definition": "Iézrite, membre du clan d'Iézer.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Nombres 26:30"
    ],
    "type": "adjectif gentilé",
    "occurrences": 1,
    "recherche": "h373 אִיעֶזְרִי ʾîʿezrî iézrite, membre du clan d'iézer. adjectif gentilé",
    "audio": "",
    "image": null,
    "racine": "H372",
    "sens_principal": "Iézrite",
    "etymologie": "· Données attestées : Gentilé dérivé de אִיעֶזֶר (H0372), forme contractée de אֲבִיעֶזֶר (H0044). · Cognats sémitiques : Voir H0044. · Hypothèses linguistiques : Voir H0372. Famille lexicale : · H0372 (אִיעֶזֶר, Iézer) · H0044 (אֲבִיעֶזֶר, Abiézer) · H0033 (אֲבִי…",
    "formes_derivees": [
      "H33",
      "H44",
      "H372"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : Les Iézrites sont un clan de la tribu de Manassé, recensé dans les plaines de Moab (Nombres 26). Ils descendent de Galaad par Iézer. Le clan est identique aux Abiézerites (H0033), dont est issu Gédéon (Juges 6:11). La variation entre אִיעֶזְרִי (Nombres) et אֲבִי הָעֶזְרִי…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200258,
    "strong": "H374",
    "langue": "hebreu",
    "numero": 374,
    "mot_original": "אֵיפָה",
    "translitteration": "ʾêp̄āh",
    "prononciation": "ay-faw'",
    "definition": "Épha, unité de mesure de capacité pour les matières sèches (environ 22 litres).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Exode 16:36",
      "Lévitique 19:36",
      "Deutéronome 25:14",
      "Zacharie 5:6"
    ],
    "type": "nom commun",
    "occurrences": 35,
    "recherche": "h374 אֵיפָה ʾêp̄āh épha, unité de mesure de capacité pour les matières sèches (environ 22 litres). nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Épha",
    "etymologie": "· Données attestées : Emprunt à l'égyptien ỉp.t (mesure de grain, boisseau). · Cognats sémitiques : Syriaque : ܐܝܦܐ (ʾêp̄ā). Arabe : ʾifā (mesure). Akkadien : epû (mesure de grain). · Hypothèses linguistiques : L'emprunt à l'égyptien est généralement accepté,…",
    "formes_derivees": [
      "H375"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : L'épha est l'unité de mesure standard pour les matières sèches en Israël. Elle équivaut à environ 22 litres (un dixième du homer). La loi exige des poids et mesures justes (Lévitique 19:36 ; Deutéronome 25:14 15). Les prophètes dénoncent la fraude sur l'épha (Amos 8:5…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200259,
    "strong": "H375",
    "langue": "hebreu",
    "numero": 375,
    "mot_original": "אֵיפֹה",
    "translitteration": "ʾêp̄ōh",
    "prononciation": "ay-fo'",
    "definition": "Où donc ? Où ?",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 37:16",
      "Job 38:4",
      "Ésaïe 49:21"
    ],
    "type": "adverbe interrogatif",
    "occurrences": 10,
    "recherche": "h375 אֵיפֹה ʾêp̄ōh où donc ? où ? adverbe interrogatif",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Où donc ? Où ?",
    "etymologie": "· Données attestées : Forme renforcée de אֵי (où ?) + פֹּה (ici, donc) ou suffixe emphatique pōh. · Cognats sémitiques : Syriaque : ܐܝܟܐ (ʾaykā, « où ? »). · Hypothèses linguistiques : Le suffixe pōh pourrait être un…",
    "formes_derivees": [
      "H335",
      "H346",
      "H351"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : ʾêp̄ōh est une forme emphatique de l'adverbe interrogatif de lieu. Job 38:4 (« Où étais tu quand je fondais la terre ? ») est l'une des questions les plus solennelles de la Bible, par laquelle YHWH interpelle Job depuis la tempête. La question de Joseph…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200260,
    "strong": "H376",
    "langue": "hebreu",
    "numero": 376,
    "mot_original": "אִישׁ",
    "translitteration": "ʾîš",
    "prononciation": "eesh",
    "definition": "Homme, être humain mâle, mari, chacun.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 2:23",
      "Genèse 6:9",
      "Deutéronome 22:22",
      "Psaume 1:1",
      "Ésaïe 2:9"
    ],
    "type": "nom commun",
    "occurrences": 2183,
    "recherche": "h376 אִישׁ ʾîš homme, être humain mâle, mari, chacun. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Homme",
    "etymologie": "· Données attestées : Racine אישׁ (ʾYŠ) ou אשׁשׁ (ʾŠŠ, « être fort, ferme »). Le pluriel אֲנָשִׁים est supplétif, dérivé d'une autre racine (אנשׁ, « être sociable, humain »). · Cognats sémitiques : Ougaritique : ỉš (homme, mari). Phénicien…",
    "formes_derivees": [
      "H120",
      "H582",
      "H802",
      "H1397"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : ʾÎš est le terme standard pour désigner l'homme adulte de sexe masculin, par opposition à la femme (אִשָּׁה), à l'enfant (יֶלֶד) et à Dieu (אֱלֹהִים). Le jeu de mots étymologique entre ʾîš et ʾiššāh (Genèse 2:23) exprime l'unité du couple humain. L'expression « homme de…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200261,
    "strong": "H377",
    "langue": "hebreu",
    "numero": 377,
    "mot_original": "אִישׁ",
    "translitteration": "ʾîš",
    "prononciation": "eesh",
    "definition": "Agir en homme, se comporter virilement. Sens hypothétique.",
    "categorie": "Vocabulaire courant",
    "references": [],
    "type": "verbe (dénominal)",
    "occurrences": 0,
    "recherche": "h377 אִישׁ ʾîš agir en homme, se comporter virilement. sens hypothétique. verbe",
    "audio": "",
    "image": null,
    "racine": "H376",
    "sens_principal": "Agir en homme",
    "etymologie": "· Données attestées : Forme verbale hypothétique dérivée de אִישׁ (H0376, « homme »). · Cognats sémitiques : Non attestés sous forme verbale. · Hypothèses linguistiques : La racine verbale אשׁשׁ (être fort) pourrait exister, mais n'est pas documentée en…",
    "formes_derivees": [
      "H376"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Contexte historique et culturel : Cette entrée Strong est probablement une erreur de classification. Le verbe « agir en homme » n'est pas attesté dans la Bible hébraïque sous la racine אשׁשׁ ou אישׁ. Certains lexicographes ont pu postuler un verbe dénominal d'après l'arabe ou le syriaque, mais la Bible…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200262,
    "strong": "H378",
    "langue": "hebreu",
    "numero": 378,
    "mot_original": "אִישׁ־בֹּשֶׁת",
    "translitteration": "ʾîš-bōšeṯ",
    "prononciation": "eesh-bo'-sheth",
    "definition": "Ish-Bosheth, « homme de honte ». Fils de Saül, éphémère roi d'Israël.",
    "categorie": "Royaume",
    "references": [
      "2 Samuel 2:8",
      "2 Samuel 3:7",
      "2 Samuel 4:5"
    ],
    "type": "nom propre",
    "occurrences": 11,
    "recherche": "h378 אִישׁ־בֹּשֶׁת ʾîš-bōšeṯ ish-bosheth, « homme de honte ». fils de saül, éphémère roi d'israël. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ish Bosheth",
    "etymologie": "· Données attestées : Composé de אִישׁ (H0376, « homme ») + בֹּשֶׁת (H1322, « honte »). Il s'agit d'une substitution polémique du nom original אֶשְׁבַּעַל (« homme de Baal » ou « Baal existe »). · Cognats sémitiques :…",
    "formes_derivees": [
      "H376",
      "H792",
      "H1322"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Ish Bosheth (Eshbaal) était le quatrième fils de Saül. Après la mort de son père et de ses frères à Guilboa, Abner, chef de l'armée, le proclama roi à Mahanaïm. Il régna deux ans sur les tribus du Nord pendant que David régnait à Hébron…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200263,
    "strong": "H379",
    "langue": "hebreu",
    "numero": 379,
    "mot_original": "אִישְׁהוֹד",
    "translitteration": "ʾÎysh-hôwd",
    "prononciation": "eesh-hode´",
    "definition": "Ishehod, un Israélite de la tribu de Manassé.",
    "categorie": "Noms propres bibliques",
    "references": [],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h379 אִישְׁהוֹד ʾîysh-hôwd ishehod, un israélite de la tribu de manassé. nom propre",
    "audio": "",
    "image": null,
    "racine": "H376",
    "sens_principal": "L'homme israélite",
    "etymologie": "· Données attestées : Voir H0376 et H3478. · Cognats sémitiques : Voir H0376 et H3478. · Hypothèses linguistiques : Cette entrée Strong est probablement une erreur de classification. Famille lexicale : · H0376 (אִישׁ, homme) · H3478 (יִשְׂרָאֵל, Israël)…",
    "formes_derivees": [
      "H376",
      "H3478"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : Cette entrée Strong est probablement une erreur de la classification. L'expression אִישׁ יִשְׂרְאֵל (homme d'Israël) est une construction syntaxique ordinaire, non une entrée lexicale autonome. Strong a parfois isolé des expressions comme lemmes distincts, créant des numéros sans correspondance linguistique réelle. Notes lexicales : ·…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200264,
    "strong": "H380",
    "langue": "hebreu",
    "numero": 380,
    "mot_original": "אִישׁוֹן",
    "translitteration": "ʾîšôn",
    "prononciation": "ee-shone'",
    "definition": "Prunelle, pupille de l'œil ; partie centrale, milieu.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 32:10",
      "Psaume 17:8",
      "Proverbes 7:2"
    ],
    "type": "nom commun",
    "occurrences": 5,
    "recherche": "h380 אִישׁוֹן ʾîšôn prunelle, pupille de l'œil ; partie centrale, milieu. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Prunelle",
    "etymologie": "· Données attestées : Diminutif de אִישׁ (H0376, « homme »). Littéralement « petit homme », parce que la pupille reflète l'image miniature de celui qui s'y mire. · Cognats sémitiques : Syriaque : ܐܝܫܘܢܐ (ʾîšônā, « pupille »). Arabe…",
    "formes_derivees": [
      "H376",
      "H381",
      "H390",
      "H1322"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : La prunelle de l'œil est une métaphore de ce qui est le plus précieux et le plus vulnérable. Deutéronome 32:10 décrit la protection divine sur Israël au désert comme celle qu'on accorde à la pupille. Le Psaume 17:8 (« Garde moi comme la prunelle de…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200265,
    "strong": "H381",
    "langue": "hebreu",
    "numero": 381,
    "mot_original": "אִישׁ־חַיִל",
    "translitteration": "ʾîš-ḥayil",
    "prononciation": "eesh-khah'-yil",
    "definition": "Homme de valeur, guerrier vaillant, homme de bien.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ruth 2:1",
      "Juges 6:12",
      "1 Samuel 9:1",
      "1 Samuel 16:18"
    ],
    "type": "nom commun (expression composée)",
    "occurrences": 0,
    "recherche": "h381 אִישׁ־חַיִל ʾîš-ḥayil homme de valeur, guerrier vaillant, homme de bien. nom commun",
    "audio": "",
    "image": null,
    "racine": "H376",
    "sens_principal": "Homme de valeur",
    "etymologie": "· Données attestées : Composé de אִישׁ (H0376, « homme ») + חַיִל (H2428, « force, valeur, richesse, armée »). · Cognats sémitiques : Voir H0376 et H2428. · Hypothèses linguistiques : Aucune hypothèse spécifique. L'expression est standard. Famille lexicale…",
    "formes_derivees": [
      "H376",
      "H2428"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": null,
    "difficulte": null,
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : L'expression ʾîš ḥayil désigne initialement le guerrier valeureux, l'homme capable de combattre et de conduire des troupes. Gédéon est salué comme « vaillant héros » (Juges 6:12). Le terme qualifie aussi Jephté (Juges 11:1), Saül et son père (1 Samuel 9:1), David (1 Samuel 16:18).…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200266,
    "strong": "H382",
    "langue": "hebreu",
    "numero": 382,
    "mot_original": "אִישׁ־טוֹב",
    "translitteration": "ʾîš-ṭôḇ",
    "prononciation": "eesh-tobe'",
    "definition": "Ish-Tob, « homme de Tob » ou « homme bon ». Région de Transjordanie.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Juges 11:3",
      "2 Samuel 10:6"
    ],
    "type": "nom propre (toponyme) / expression composée",
    "occurrences": 4,
    "recherche": "h382 אִישׁ־טוֹב ʾîš-ṭôḇ ish-tob, « homme de tob » ou « homme bon ». région de transjordanie. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ish Tob",
    "etymologie": "· Données attestées : Composé de אִישׁ (H0376, « homme ») + טוֹב (H2896, « bon »). Peut être interprétation hébraïque d'un toponyme étranger. · Cognats sémitiques : Akkadien : māt Tūbu (pays de Tob, attesté dans les lettres d'Amarna).…",
    "formes_derivees": [
      "H376",
      "H2896"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom propre",
      "toponyme"
    ],
    "notes": "Contexte historique et culturel : Le pays de Tob est une région de Transjordanie septentrionale, probablement entre Galaad et le Bashan. Jephté y trouva refuge et rassembla une bande de mercenaires (Juges 11:3). Le royaume de Tob fournit des troupes aux Ammonites contre David (2 Samuel 10:6 8). Les lettres…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200267,
    "strong": "H383",
    "langue": "hebreu",
    "numero": 383,
    "mot_original": "אִיתַי",
    "translitteration": "ʾîṯay",
    "prononciation": "ee-thah'ee",
    "definition": "Il y a, il existe. Correspondance araméenne de l'hébreu יֵשׁ (H3426).",
    "categorie": "Vocabulaire courant",
    "references": [
      "Esdras 4:16",
      "Daniel 2:10",
      "Daniel 3:14"
    ],
    "type": "adverbe / particule d'existence (araméen)",
    "occurrences": 17,
    "recherche": "h383 אִיתַי ʾîṯay il y a, il existe. correspondance araméenne de l'hébreu יֵשׁ (h3426). adverbe / particule d'existence",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Il y a",
    "etymologie": "· Données attestées : Racine אית (ʾYT, « être, exister ») en araméen. · Cognats sémitiques : Syriaque : ܐܝܬ (ʾîṯ, « il y a »). Mandéen : ait. Arabe : laysa (ne pas être négation). · Hypothèses linguistiques :…",
    "formes_derivees": [
      "H369",
      "H3426"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : ʾÎṯay est la particule d'existence standard en araméen biblique. Elle apparaît dans les documents administratifs d'Esdras (correspondance avec la cour perse) et dans les récits de Daniel à la cour babylonienne. Sa forme négative est לָא אִיתַי (il n'y a pas). Notes lexicales : ·…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200268,
    "strong": "H384",
    "langue": "hebreu",
    "numero": 384,
    "mot_original": "אִיתִיאֵל",
    "translitteration": "ʾîṯîʾēl",
    "prononciation": "eeth-ee-ale'",
    "definition": "Ithiel, « Dieu est avec moi » ou « Dieu existe ».",
    "categorie": "Noms de Dieu",
    "references": [
      "Proverbes 30:1",
      "Néhémie 11:7"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h384 אִיתִיאֵל ʾîṯîʾēl ithiel, « dieu est avec moi » ou « dieu existe ». nom propre",
    "audio": "",
    "image": null,
    "racine": "H383",
    "sens_principal": "Ithiel",
    "etymologie": "· Données attestées : Composé de אִית (forme araméenne ou archaïque de יֵשׁ, « il y a ») + אֵל (H0410, « Dieu »). Signifie « Dieu est avec moi » ou « Dieu existe ». · Cognats sémitiques :…",
    "formes_derivees": [
      "H383",
      "H410"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Ithiel est mentionné dans le titre énigmatique de Proverbes 30:1. Le texte est difficile : certains lisent « Oracle de cet homme : Je me suis fatigué, ô Dieu, je me suis fatigué, ô Dieu, et je suis épuisé ». D'autres y voient les noms…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200269,
    "strong": "H385",
    "langue": "hebreu",
    "numero": 385,
    "mot_original": "אִיתָמָר",
    "translitteration": "ʾîṯāmār",
    "prononciation": "eeth-aw-mawr'",
    "definition": "Ithamar, « île de palmier » ou « père du palmier ». Quatrième fils d'Aaron, ancêtre d'une lignée sacerdotale.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Exode 6:23",
      "Exode 28:1",
      "Lévitique 10:6",
      "1 Chroniques 24:1"
    ],
    "type": "nom propre",
    "occurrences": 21,
    "recherche": "h385 אִיתָמָר ʾîṯāmār ithamar, « île de palmier » ou « père du palmier ». quatrième fils d'aaron, ancêtre d'une lignée sacerdotale. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Ithamar",
    "etymologie": "· Données attestées : Nom d'origine incertaine. · Cognats sémitiques : Non attestés clairement. · Hypothèses linguistiques : 1. Composé de אִי (île, côte) + תָּמָר (palmier) : « île de palmier » ou « côte des palmiers ». 2.…",
    "formes_derivees": [
      "H8558"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Ithamar est le quatrième et plus jeune fils d'Aaron. Avec ses frères, il fut consacré prêtre (Exode 28:1). Après la mort de Nadab et Abihu (Lévitique 10), seuls Éléazar et Ithamar restèrent pour exercer le sacerdoce. Ithamar fut responsable du transport des matériaux du tabernacle…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200270,
    "strong": "H386",
    "langue": "hebreu",
    "numero": 386,
    "mot_original": "אֵיתָן",
    "translitteration": "ʾêṯān",
    "prononciation": "ay-thawn'",
    "definition": "Permanent, durable, constant ; puissant, fort.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 49:24",
      "Amos 5:24",
      "Michée 6:2",
      "Psaume 74:15"
    ],
    "type": "adjectif / nom propre",
    "occurrences": 13,
    "recherche": "h386 אֵיתָן ʾêṯān permanent, durable, constant ; puissant, fort. adjectif / nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Permanent",
    "etymologie": "· Données attestées : Racine יתן (YTN, « être durable, permanent, fort »). · Cognats sémitiques : Syriaque : ܐܝܬܢܐ (ʾêṯānā, « permanent, fort »). Arabe : ʾaṯana (être permanent). · Hypothèses linguistiques : La racine est apparentée à תָּנָה…",
    "formes_derivees": [
      "H854",
      "H4977"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : L'adjectif ʾêṯān qualifie ce qui est durable, inébranlable : la force de Joseph (Genèse 49:24), le torrent impétueux (Amos 5:24 : « que le droit coule comme les eaux, et la justice comme un torrent permanent »), les fondements de la terre (Michée 6:2). Éthan…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200271,
    "strong": "H387",
    "langue": "hebreu",
    "numero": 387,
    "mot_original": "אֵיתָן",
    "translitteration": "ʾêṯān",
    "prononciation": "ay-thawn'",
    "definition": "Éthan, « permanent, durable ». Nom de plusieurs personnages.",
    "categorie": "Noms propres bibliques",
    "references": [
      "1 Rois 5:11",
      "Psaume 89:1",
      "1 Chroniques 6:27"
    ],
    "type": "nom propre",
    "occurrences": 8,
    "recherche": "h387 אֵיתָן ʾêṯān éthan, « permanent, durable ». nom de plusieurs personnages. nom propre",
    "audio": "",
    "image": null,
    "racine": "H386",
    "sens_principal": "Éthan",
    "etymologie": "· Données attestées : Voir H0386 (adjectif). · Cognats sémitiques : Voir H0386. · Hypothèses linguistiques : Voir H0386. Famille lexicale : · H0386 (אֵיתָן, permanent, durable) Racine Strong : H0386 Première occurrence biblique : 1 Rois 5:11 Occurrences principales…",
    "formes_derivees": [
      "H386"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Voir H0386. Éthan l'Ezrahite est un sage renommé, à qui la tradition attribue le Psaume 89, méditation sur l'alliance davidique. L'Éthan lévite est un descendant de Merari, chantre sous David (1 Chroniques 15:17 19). Notes lexicales : · Particularités grammaticales : Nom propre masculin. ·…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200272,
    "strong": "H388",
    "langue": "hebreu",
    "numero": 388,
    "mot_original": "אֵיתָנִים",
    "translitteration": "ʾêṯānîm",
    "prononciation": "ay-thaw-neem'",
    "definition": "Éthanim, « les [mois] permanents » ou « les [cours d'eau] permanents ». Septième mois du calendrier cananéen, correspondant à Tishri.",
    "categorie": "Eau et baptême",
    "references": [
      "1 Rois 8:2"
    ],
    "type": "nom propre (mois du calendrier)",
    "occurrences": 1,
    "recherche": "h388 אֵיתָנִים ʾêṯānîm éthanim, « les [mois] permanents » ou « les [cours d'eau] permanents ». septième mois du calendrier cananéen, correspondant à tishri. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Éthanim",
    "etymologie": "· Données attestées : Pluriel de אֵיתָן (H0386, « permanent, durable »). Le mois est nommé ainsi parce que les cours d'eau sont permanents (pleins après les pluies d'automne). · Cognats sémitiques : Phénicien : ytnm (nom de mois ?).…",
    "formes_derivees": [
      "H386",
      "H945",
      "H2099"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Éthanim est l'ancien nom cananéen du septième mois (septembre octobre), remplacé après l'exil par le nom babylonien Tishri. C'est le mois de la fête des Tentes (Sukkot). Salomon choisit ce mois pour la dédicace du Temple (1 Rois 8:2), rassemblant tout Israël pour cette célébration…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200273,
    "strong": "H389",
    "langue": "hebreu",
    "numero": 389,
    "mot_original": "אַךְ",
    "translitteration": "ʾaḵ",
    "prononciation": "ak",
    "definition": "Seulement, cependant, certes, vraiment, mais.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Genèse 7:23",
      "Genèse 9:4",
      "Psaume 73:1",
      "Ésaïe 14:15"
    ],
    "type": "adverbe / conjonction",
    "occurrences": 155,
    "recherche": "h389 אַךְ ʾaḵ seulement, cependant, certes, vraiment, mais. adverbe / conjonction",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Seulement",
    "etymologie": "· Données attestées : Particule restrictive sémitique. · Cognats sémitiques : Syriaque : ܐܟ (ʾaḵ, « mais, seulement »). Arabe : ʾak (certes). Akkadien : ak (mais, seulement). Ougaritique : ảk (certes). · Hypothèses linguistiques : Particule primitive, pan sémitique.…",
    "formes_derivees": [
      "H403"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "adverbe"
    ],
    "notes": "Contexte historique et culturel : La particule ʾaḵ est un opérateur logique polyvalent. Comme restrictif (« seulement »), elle délimite une exception ou une condition. Comme adversatif (« mais, cependant »), elle introduit une objection. Comme emphatique (« certes, vraiment »), elle renforce une affirmation. Le Psaume 73 s'ouvre sur…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adverbe"
  },
  {
    "id": 200274,
    "strong": "H390",
    "langue": "hebreu",
    "numero": 390,
    "mot_original": "אַכַּד",
    "translitteration": "ʾakkaḏ",
    "prononciation": "ak-kad'",
    "definition": "Akkad, ville de Mésopotamie, capitale de l'Empire akkadien fondé par Sargon.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Genèse 10:10"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h390 אַכַּד ʾakkaḏ akkad, ville de mésopotamie, capitale de l'empire akkadien fondé par sargon. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Akkad",
    "etymologie": "· Données attestées : Translittération de l'akkadien Akkadû (Akkad). · Cognats sémitiques : Akkadien : Akkadu. Sumérien : Agade. Syriaque : ܐܟܕ (ʾakkaḏ). · Hypothèses linguistiques : Le nom sumérien est Agade ; l'akkadien Akkadu en dérive. Le nom est…",
    "formes_derivees": [
      "H391",
      "H400"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Contexte historique et culturel : Akkad est la capitale de l'Empire akkadien (XXIVe XXIIe siècles avant l'ère courante), fondé par Sargon d'Akkad. La ville n'a pas été localisée archéologiquement avec certitude. Dans la Table des Nations (Genèse 10), elle est associée à Nimrod, fondateur mythique de la civilisation mésopotamienne. La…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200275,
    "strong": "H391",
    "langue": "hebreu",
    "numero": 391,
    "mot_original": "אַכְזָב",
    "translitteration": "ʾaḵzāḇ",
    "prononciation": "ak-zawb'",
    "definition": "Trompeur, décevant, tarissant ; comme un ruisseau qui se dessèche.",
    "categorie": "Eau et baptême",
    "references": [
      "Jérémie 15:18",
      "Michée 1:14"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 2,
    "recherche": "h391 אַכְזָב ʾaḵzāḇ trompeur, décevant, tarissant ; comme un ruisseau qui se dessèche. adjectif / nom commun",
    "audio": "",
    "image": null,
    "racine": "H3576",
    "sens_principal": "Trompeur",
    "etymologie": "· Données attestées : Dérivé de la racine כזב (KZB, « mentir, tromper, décevoir, tarir »). Le aleph initial est prosthétique. · Cognats sémitiques : Syriaque : ܟܕܒ (kaḏḏeḇ, « mentir »). Arabe : kaḏaba (mentir). · Hypothèses linguistiques :…",
    "formes_derivees": [
      "H392",
      "H3576",
      "H3577"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le terme décrit une source ou un oued qui coule pendant la saison des pluies mais tarit en été, décevant le voyageur assoiffé. Jérémie utilise cette image pour exprimer sa plainte envers Dieu : le prophète accuse YHWH d'être pour lui « comme une source…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200276,
    "strong": "H392",
    "langue": "hebreu",
    "numero": 392,
    "mot_original": "אַכְזִיב",
    "translitteration": "ʾaḵzîḇ",
    "prononciation": "ak-zeeb'",
    "definition": "Akzib, « trompeur, tarissant ». Nom de deux villes.",
    "categorie": "Noms propres bibliques",
    "references": [
      "Josué 15:44",
      "Juges 1:31",
      "Michée 1:14"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 4,
    "recherche": "h392 אַכְזִיב ʾaḵzîḇ akzib, « trompeur, tarissant ». nom de deux villes. nom propre",
    "audio": "",
    "image": null,
    "racine": "H391",
    "sens_principal": "Akzib",
    "etymologie": "· Données attestées : Dérivé de אַכְזָב (H0391, « trompeur, tarissant »). · Cognats sémitiques : Phénicien : ʾkzb (nom de lieu). · Hypothèses linguistiques : Le toponyme signifie probablement « source tarissante » ou « lieu de déception ».…",
    "formes_derivees": [
      "H391",
      "H3576"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom propre",
      "toponyme"
    ],
    "notes": "Contexte historique et culturel : Deux villes portent ce nom. L'Akzib judéenne (Josué 15:44) est située dans la Shéphélah, identifiée à Tell el Beida ou Khirbet ʿEn el Kizbe. L'Akzib asherite (Juges 1:31), sur la côte méditerranéenne au nord d'Acco, est l'actuelle ez Zib en Israël, site occupé de l'âge…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200277,
    "strong": "H393",
    "langue": "hebreu",
    "numero": 393,
    "mot_original": "אַכְזָר",
    "translitteration": "ʾaḵzār",
    "prononciation": "ak-zawr'",
    "definition": "Cruel, féroce, impitoyable.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Deutéronome 32:33",
      "Job 30:21",
      "Proverbes 12:10",
      "Jérémie 30:14"
    ],
    "type": "adjectif",
    "occurrences": 6,
    "recherche": "h393 אַכְזָר ʾaḵzār cruel, féroce, impitoyable. adjectif",
    "audio": "",
    "image": null,
    "racine": "H394",
    "sens_principal": "Cruel",
    "etymologie": "· Données attestées : Racine�זר (KZR, « être cruel, féroce »), avec aleph prosthétique. · Cognats sémitiques : Syriaque : ܐܟܙܪ (ʾaḵzar, « cruel »). Arabe : kaḏira (être féroce). · Hypothèses linguistiques : La racine pourrait être une variante…",
    "formes_derivees": [
      "H394",
      "H395"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : L'adjectif qualifie une cruauté impitoyable. Dans le cantique de Moïse (Deutéronome 32:33), le venin des serpents est qualifié de « cruel ». Proverbes 12:10 oppose le juste qui prend soin de son bétail au méchant dont les « entrailles sont cruelles ». Jérémie décrit les…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200278,
    "strong": "H394",
    "langue": "hebreu",
    "numero": 394,
    "mot_original": "אַכְזָרִי",
    "translitteration": "ʾaḵzārî",
    "prononciation": "ak-zaw-ree'",
    "definition": "Cruel, féroce. Variante adjectivale de H0393.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Ésaïe 13:9",
      "Jérémie 30:14",
      "Jérémie 50:42"
    ],
    "type": "adjectif",
    "occurrences": 5,
    "recherche": "h394 אַכְזָרִי ʾaḵzārî cruel, féroce. variante adjectivale de h0393. adjectif",
    "audio": "",
    "image": null,
    "racine": "H393",
    "sens_principal": "Cruel",
    "etymologie": "· Données attestées : Dérivé adjectival de אַכְזָר (H0393) avec suffixe î. Voir H0393. · Cognats sémitiques : Voir H0393. · Hypothèses linguistiques : Le suffixe î forme un adjectif d'appartenance ou de qualité. Famille lexicale : · H0393 (אַכְזָר,…",
    "formes_derivees": [
      "H393",
      "H395"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "adjectif"
    ],
    "notes": "Contexte historique et culturel : La distinction Strong entre H0393 et H0394 est morphologique. Les deux formes sont interchangeables et désignent la même qualité de cruauté impitoyable. Voir H0393 pour le contexte complet. Notes lexicales : · Particularités grammaticales : La forme en î est un adjectif qualificatif standard. ·…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Adjectif"
  },
  {
    "id": 200279,
    "strong": "H395",
    "langue": "hebreu",
    "numero": 395,
    "mot_original": "אַכְזְרִיּוּת",
    "translitteration": "ʾaḵzərîyûṯ",
    "prononciation": "ak-ze-ree-ooth'",
    "definition": "Cruauté, férocité.",
    "categorie": "Vocabulaire courant",
    "references": [
      "Proverbes 27:4"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h395 אַכְזְרִיּוּת ʾaḵzərîyûṯ cruauté, férocité. nom commun",
    "audio": "",
    "image": null,
    "racine": "H394",
    "sens_principal": "Cruauté",
    "etymologie": "· Données attestées : Nom abstrait féminin dérivé de אַכְזָרִי (H0394, « cruel ») avec suffixe abstractif ûṯ. · Cognats sémitiques : Non attestés comme nom abstrait. · Hypothèses linguistiques : La formation en ûṯ est un procédé productif pour…",
    "formes_derivees": [
      "H393",
      "H394"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le proverbe compare trois forces destructrices : la cruauté de la colère (אַכְזְרִיּוּת חֵמָה), le débordement de la fureur (שֶׁטֶף אָף), et la jalousie (קִנְאָה). La pointe est que la jalousie est plus redoutable encore que la colère la plus cruelle. La forme abstraite en…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200280,
    "strong": "H396",
    "langue": "hebreu",
    "numero": 396,
    "mot_original": "אַכִּילָה",
    "translitteration": "ʾakkîlāh",
    "prononciation": "ak-ee-law'",
    "definition": "Nourriture, aliment, repas.",
    "categorie": "Pain et nourriture",
    "references": [
      "1 Rois 19:8"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h396 אַכִּילָה ʾakkîlāh nourriture, aliment, repas. nom commun",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Nourriture",
    "etymologie": "· Données attestées : Dérivé nominal féminin de אָכַל (H0398, « manger »). · Cognats sémitiques : Syriaque : ܐܟܠܬܐ (ʾeḵlāṯā, « nourriture »). Arabe : ʾakila (nourriture). · Hypothèses linguistiques : La forme avec redoublement du kaph et suffixe…",
    "formes_derivees": [
      "H398",
      "H400",
      "H402",
      "H3978"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très rare",
    "difficulte": "Expert",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : Le terme apparaît dans le récit de la fuite d'Élie au désert. Découragé, le prophète s'endort sous un genêt. Un ange le touche et lui offre une galette cuite et une cruche d'eau. Par la force de cette nourriture miraculeuse, Élie marche quarante jours jusqu'à…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  },
  {
    "id": 200281,
    "strong": "H397",
    "langue": "hebreu",
    "numero": 397,
    "mot_original": "אָכִישׁ",
    "translitteration": "ʾāḵîš",
    "prononciation": "aw-keesh'",
    "definition": "Akish, roi philistin de Gath, contemporain de David.",
    "categorie": "Royaume",
    "references": [
      "1 Samuel 21:11",
      "1 Samuel 27:1",
      "1 Samuel 28:1",
      "1 Samuel 29:1"
    ],
    "type": "nom propre",
    "occurrences": 21,
    "recherche": "h397 אָכִישׁ ʾāḵîš akish, roi philistin de gath, contemporain de david. nom propre",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Akish",
    "etymologie": "· Données attestées : Nom d'origine philistine, probablement pré indo européenne ou anatolienne. · Cognats sémitiques : Inscriptions philistines : ʾkyš (nom propre ?). Akkadien : Ikausu (nom d'un roi d'Éqron). · Hypothèses linguistiques : Le nom pourrait être apparenté…",
    "formes_derivees": [],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom propre",
      "personnage"
    ],
    "notes": "Contexte historique et culturel : Akish régnait sur Gath, l'une des cinq cités de la pentapole philistine. David, fuyant Saül, chercha refuge auprès de lui à deux reprises. La première fois (1 Samuel 21:11 16), il simula la folie. La seconde (1 Samuel 27), il devint vassal d'Akish, recevant la…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom propre"
  },
  {
    "id": 200282,
    "strong": "H398",
    "langue": "hebreu",
    "numero": 398,
    "mot_original": "אָכַל",
    "translitteration": "ʾāḵal",
    "prononciation": "aw-kal'",
    "definition": "Manger, consommer, dévorer.",
    "categorie": "Ange et messager",
    "references": [
      "Genèse 2:16",
      "Genèse 3:6",
      "Exode 12:15",
      "Deutéronome 4:24"
    ],
    "type": "verbe",
    "occurrences": 810,
    "recherche": "h398 אָכַל ʾāḵal manger, consommer, dévorer. verbe",
    "audio": "",
    "image": null,
    "racine": null,
    "sens_principal": "Manger",
    "etymologie": "· Données attestées : Racine אכל (ʾKL, « manger, consommer »). · Cognats sémitiques : Syriaque : ܐܟܠ (ʾeḵal). Arabe : ʾakala. Akkadien : akālu. Ougaritique : ảkl. · Hypothèses linguistiques : Racine pan sémitique fondamentale. Famille lexicale : ·…",
    "formes_derivees": [
      "H396",
      "H400",
      "H402",
      "H3978"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Très fréquent",
    "difficulte": "Enfant",
    "tags": [
      "hébreu",
      "verbe"
    ],
    "notes": "Contexte historique et culturel : Le verbe ʾāḵal est l'un des plus fondamentaux du vocabulaire hébreu. Il couvre toute ingestion : nourriture humaine et animale, mais aussi destruction par le feu, l'épée ou les insectes. « YHWH ton Dieu est un feu dévorant » (Deutéronome 4:24) utilise la métaphore alimentaire…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200283,
    "strong": "H399",
    "langue": "hebreu",
    "numero": 399,
    "mot_original": "אֲכַל",
    "translitteration": "ʾăḵal",
    "prononciation": "ak-al'",
    "definition": "Manger, dévorer. Correspondance araméenne de l'hébreu אָכַל (H0398).",
    "categorie": "Ange et messager",
    "references": [
      "Daniel 3:8",
      "Daniel 7:5"
    ],
    "type": "verbe (araméen)",
    "occurrences": 7,
    "recherche": "h399 אֲכַל ʾăḵal manger, dévorer. correspondance araméenne de l'hébreu אָכַל (h0398). verbe",
    "audio": "",
    "image": null,
    "racine": "H398",
    "sens_principal": "Manger",
    "etymologie": "· Données attestées : Voir H0398. · Cognats sémitiques : Voir H0398. · Hypothèses linguistiques : Voir H0398. Famille lexicale : · H0398 (אָכַל, hébreu) Racine Strong : H0398 Première occurrence biblique : Daniel 3:8 Occurrences principales par livre :…",
    "formes_derivees": [
      "H398"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Rare",
    "difficulte": "Expert",
    "tags": [
      "araméen",
      "verbe"
    ],
    "notes": "Contexte historique et culturel : En araméen biblique, le verbe conserve le sens de « manger » mais développe l'idiome « manger les morceaux de quelqu'un » (אֲכַל קַרְצֵי), signifiant « accuser, calomnier ». En Daniel 7, les bêtes sauvages qui « dévorent beaucoup de chair » symbolisent la violence…",
    "dialecte": "araméen",
    "categorie_grammaticale": "Verbe"
  },
  {
    "id": 200284,
    "strong": "H400",
    "langue": "hebreu",
    "numero": 400,
    "mot_original": "אֹכֶל",
    "translitteration": "ʾōḵel",
    "prononciation": "o'-khel",
    "definition": "Nourriture, aliment, vivres.",
    "categorie": "Pain et nourriture",
    "references": [
      "Genèse 2:9",
      "Genèse 3:6",
      "Psaume 104:21",
      "Psaume 145:15"
    ],
    "type": "nom commun",
    "occurrences": 44,
    "recherche": "h400 אֹכֶל ʾōḵel nourriture, aliment, vivres. nom commun",
    "audio": "",
    "image": null,
    "racine": "H398",
    "sens_principal": "Nourriture",
    "etymologie": "· Données attestées : Dérivé nominal de אָכַל (H0398, « manger »). · Cognats sémitiques : Syriaque : ܐܘܟܠܐ (ʾûḵālā, « nourriture »). Arabe : ʾukl. · Hypothèses linguistiques : Aucune hypothèse spécifique. Famille lexicale : · H0398 (אָכַל, manger)…",
    "formes_derivees": [
      "H396",
      "H398",
      "H401",
      "H402",
      "H410",
      "H3978"
    ],
    "synonymes": [],
    "premiere_occurrence": null,
    "niveau": "Commun",
    "difficulte": "Intermédiaire",
    "tags": [
      "hébreu",
      "nom"
    ],
    "notes": "Contexte historique et culturel : ʾŌḵel est le terme générique pour la nourriture en hébreu biblique. Dans le Psaume 104, tous les êtres vivants attendent leur nourriture de Dieu. Le Psaume 145:15 16 (« Les yeux de tous espèrent en toi, et tu leur donnes leur nourriture en son temps…",
    "dialecte": "hébreu",
    "categorie_grammaticale": "Nom"
  }
];
