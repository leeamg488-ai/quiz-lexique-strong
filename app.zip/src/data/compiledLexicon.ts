import { StrongEntry } from '../types';

// Fiches lexicographiques compilées manuellement par l'auteur de l'app
// (morphologie, étymologie, occurrences, exemples bibliques sourcés BDB/HALOT/
// Gesenius). Complété au fur et à mesure ; actuellement H0006–H0100.
export const compiledLexicon: StrongEntry[] = [
  {
    "id": 200000,
    "strong": "H6",
    "langue": "hebreu",
    "numero": 6,
    "mot_original": "אָבַד",
    "translitteration": "ʾāḇaḏ",
    "prononciation": "ʾāḇaḏ",
    "definition": "Périr, être détruit, disparaître, s'égarer.",
    "categorie": "Verbe",
    "references": [
      "Nombres 21:29",
      "Psaume 2:12"
    ],
    "type": "verbe",
    "occurrences": 184,
    "recherche": "h6 אָבַד ʾāḇaḏ périr, être détruit, disparaître, s'égarer. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200001,
    "strong": "H7",
    "langue": "hebreu",
    "numero": 7,
    "mot_original": "אֲבַד",
    "translitteration": "ʾăḇaḏ",
    "prononciation": "ʾăḇaḏ",
    "definition": "Périr, détruire. Correspondance araméenne de l'hébreu אָבַד (H0006).",
    "categorie": "Verbe",
    "references": [
      "Jérémie 10:11",
      "Daniel 7:11"
    ],
    "type": "verbe",
    "occurrences": 7,
    "recherche": "h7 אֲבַד ʾăḇaḏ périr, détruire. correspondance araméenne de l'hébreu אָבַד (h0006). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200002,
    "strong": "H8",
    "langue": "hebreu",
    "numero": 8,
    "mot_original": "אֹבֵד",
    "translitteration": "ʾōḇēḏ",
    "prononciation": "ʾōḇēḏ",
    "definition": "Destruction, ruine ; ce qui est sur le point de périr.",
    "categorie": "Nom commun (substantif dérivé du participe",
    "references": [
      "Proverbes 31:6"
    ],
    "type": "nom commun (substantif dérivé du participe",
    "occurrences": 2,
    "recherche": "h8 אֹבֵד ʾōḇēḏ destruction, ruine ; ce qui est sur le point de périr. nom commun (substantif dérivé du participe",
    "audio": "",
    "image": null
  },
  {
    "id": 200003,
    "strong": "H9",
    "langue": "hebreu",
    "numero": 9,
    "mot_original": "אֲבֵדָה",
    "translitteration": "ʾăḇēḏāh",
    "prononciation": "ʾăḇēḏāh",
    "definition": "Chose perdue, objet égaré.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 22:3"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h9 אֲבֵדָה ʾăḇēḏāh chose perdue, objet égaré. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200004,
    "strong": "H10",
    "langue": "hebreu",
    "numero": 10,
    "mot_original": "אֲבַדֹּה",
    "translitteration": "ʾăḇaddōh",
    "prononciation": "ʾăḇaddōh",
    "definition": "Ruine, destruction, lieu de perdition.",
    "categorie": "Nom commun",
    "references": [
      "Proverbes 27:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h10 אֲבַדֹּה ʾăḇaddōh ruine, destruction, lieu de perdition. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200005,
    "strong": "H11",
    "langue": "hebreu",
    "numero": 11,
    "mot_original": "אֲבַדּוֹן",
    "translitteration": "ʾăḇaddōn",
    "prononciation": "ʾăḇaddōn",
    "definition": "Abaddon. Lieu de destruction ; personnification du monde souterrain.",
    "categorie": "Nom commun / nom propre",
    "references": [
      "Job 26:6",
      "Proverbes 15:11"
    ],
    "type": "nom commun / nom propre",
    "occurrences": 5,
    "recherche": "h11 אֲבַדּוֹן ʾăḇaddōn abaddon. lieu de destruction ; personnification du monde souterrain. nom commun / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200006,
    "strong": "H12",
    "langue": "hebreu",
    "numero": 12,
    "mot_original": "אַבְדָן",
    "translitteration": "ʾaḇdān",
    "prononciation": "ʾaḇdān",
    "definition": "Destruction, anéantissement.",
    "categorie": "Nom commun",
    "references": [
      "Esther 9:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h12 אַבְדָן ʾaḇdān destruction, anéantissement. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200007,
    "strong": "H13",
    "langue": "hebreu",
    "numero": 13,
    "mot_original": "אָבְדַן",
    "translitteration": "ʾoḇdan",
    "prononciation": "ʾoḇdan",
    "definition": "Destruction. Correspondance araméenne de l'hébreu אַבְדָן (H0012).",
    "categorie": "Nom commun",
    "references": [
      "Daniel 2:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h13 אָבְדַן ʾoḇdan destruction. correspondance araméenne de l'hébreu אַבְדָן (h0012). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200008,
    "strong": "H14",
    "langue": "hebreu",
    "numero": 14,
    "mot_original": "אָבָה",
    "translitteration": "ʾāḇāh",
    "prononciation": "ʾāḇāh",
    "definition": "Consentir, vouloir, être disposé à, accepter.",
    "categorie": "Verbe",
    "references": [
      "Deutéronome 25:7",
      "Ésaïe 1:19"
    ],
    "type": "verbe",
    "occurrences": 54,
    "recherche": "h14 אָבָה ʾāḇāh consentir, vouloir, être disposé à, accepter. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200009,
    "strong": "H15",
    "langue": "hebreu",
    "numero": 15,
    "mot_original": "אָבֶה",
    "translitteration": "ʾāḇeh",
    "prononciation": "ʾāḇeh",
    "definition": "Souhait, désir, volonté.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 23:6"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h15 אָבֶה ʾāḇeh souhait, désir, volonté. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200010,
    "strong": "H16",
    "langue": "hebreu",
    "numero": 16,
    "mot_original": "אֵבֶה",
    "translitteration": "ʾēḇeh",
    "prononciation": "ʾēḇeh",
    "definition": "Roseau, papyrus, plante aquatique.",
    "categorie": "Nom commun",
    "references": [
      "Job 9:26"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h16 אֵבֶה ʾēḇeh roseau, papyrus, plante aquatique. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200011,
    "strong": "H17",
    "langue": "hebreu",
    "numero": 17,
    "mot_original": "אֲבוֹי",
    "translitteration": "ʾăḇôy",
    "prononciation": "ʾăḇôy",
    "definition": "Ah ! Hélas ! Exclamation de lamentation.",
    "categorie": "Interjection",
    "references": [
      "Proverbes 23:29"
    ],
    "type": "interjection",
    "occurrences": 1,
    "recherche": "h17 אֲבוֹי ʾăḇôy ah ! hélas ! exclamation de lamentation. interjection",
    "audio": "",
    "image": null
  },
  {
    "id": 200012,
    "strong": "H18",
    "langue": "hebreu",
    "numero": 18,
    "mot_original": "אֵבוּס",
    "translitteration": "ʾēḇûs",
    "prononciation": "ʾēḇûs",
    "definition": "Mangeoire, crèche pour le bétail.",
    "categorie": "Nom commun",
    "references": [
      "Ésaïe 1:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h18 אֵבוּס ʾēḇûs mangeoire, crèche pour le bétail. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200013,
    "strong": "H19",
    "langue": "hebreu",
    "numero": 19,
    "mot_original": "אִבְחָה",
    "translitteration": "ʾiḇḥāh",
    "prononciation": "ʾiḇḥāh",
    "definition": "Épée, lame, pointe. Plus probablement : frayeur, terreur soudaine.",
    "categorie": "Nom commun",
    "references": [
      "Ézéchiel 21:20"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h19 אִבְחָה ʾiḇḥāh épée, lame, pointe. plus probablement : frayeur, terreur soudaine. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200014,
    "strong": "H20",
    "langue": "hebreu",
    "numero": 20,
    "mot_original": "אֲבַטִּיחַ",
    "translitteration": "ʾăḇaṭṭîaḥ",
    "prononciation": "ʾăḇaṭṭîaḥ",
    "definition": "Pastèque, melon d'eau (Citrullus lanatus).",
    "categorie": "Nom commun",
    "references": [
      "Nombres 11:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h20 אֲבַטִּיחַ ʾăḇaṭṭîaḥ pastèque, melon d'eau (citrullus lanatus). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200015,
    "strong": "H21",
    "langue": "hebreu",
    "numero": 21,
    "mot_original": "אֲבִי",
    "translitteration": "ʾăḇî",
    "prononciation": "ʾăḇî",
    "definition": "Abi, nom propre féminin. Mère du roi Ézéchias.",
    "categorie": "Nom propre",
    "references": [
      "2 Rois 18:2"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h21 אֲבִי ʾăḇî abi, nom propre féminin. mère du roi ézéchias. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200016,
    "strong": "H22",
    "langue": "hebreu",
    "numero": 22,
    "mot_original": "אֲבִיאֵל",
    "translitteration": "ʾăḇîʾēl",
    "prononciation": "ʾăḇîʾēl",
    "definition": "Abiel, « Dieu est mon père » ou « mon père est Dieu ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 9:1"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h22 אֲבִיאֵל ʾăḇîʾēl abiel, « dieu est mon père » ou « mon père est dieu ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200017,
    "strong": "H23",
    "langue": "hebreu",
    "numero": 23,
    "mot_original": "אֲבִיאָסָף",
    "translitteration": "ʾăḇîʾāsāp̄",
    "prononciation": "ʾăḇîʾāsāp̄",
    "definition": "Abiasaph, « mon père a rassemblé » ou « le père du rassemblement ».",
    "categorie": "Nom propre",
    "references": [
      "Exode 6:24"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h23 אֲבִיאָסָף ʾăḇîʾāsāp̄ abiasaph, « mon père a rassemblé » ou « le père du rassemblement ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200018,
    "strong": "H24",
    "langue": "hebreu",
    "numero": 24,
    "mot_original": "אָבִיב",
    "translitteration": "ʾāḇîḇ",
    "prononciation": "ʾāḇîḇ",
    "definition": "Épi mûr, épi tendre ; mois des épis (printemps).",
    "categorie": "Nom commun",
    "references": [
      "Exode 13:4"
    ],
    "type": "nom commun",
    "occurrences": 8,
    "recherche": "h24 אָבִיב ʾāḇîḇ épi mûr, épi tendre ; mois des épis (printemps). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200019,
    "strong": "H25",
    "langue": "hebreu",
    "numero": 25,
    "mot_original": "אֲבִי גִבְעוֹן",
    "translitteration": "ʾăḇî ḡiḇʿôn",
    "prononciation": "ʾăḇî ḡiḇʿôn",
    "definition": "Abi-Gibeon, « père de Gibeon ». Nom ou titre d'un personnage benjaminite.",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:29"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h25 אֲבִי גִבְעוֹן ʾăḇî ḡiḇʿôn abi-gibeon, « père de gibeon ». nom ou titre d'un personnage benjaminite. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200020,
    "strong": "H26",
    "langue": "hebreu",
    "numero": 26,
    "mot_original": "אֲבִיגַיִל",
    "translitteration": "ʾăḇîḡayil",
    "prononciation": "ʾăḇîḡayil",
    "definition": "Abigaïl, « mon père est joie » ou « père de l'exultation ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 25:3"
    ],
    "type": "nom propre",
    "occurrences": 17,
    "recherche": "h26 אֲבִיגַיִל ʾăḇîḡayil abigaïl, « mon père est joie » ou « père de l'exultation ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200021,
    "strong": "H27",
    "langue": "hebreu",
    "numero": 27,
    "mot_original": "אֲבִידָן",
    "translitteration": "ʾăḇîḏān",
    "prononciation": "ʾăḇîḏān",
    "definition": "Abidan, « mon père a jugé » ou « père du jugement ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 1:11"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h27 אֲבִידָן ʾăḇîḏān abidan, « mon père a jugé » ou « père du jugement ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200022,
    "strong": "H28",
    "langue": "hebreu",
    "numero": 28,
    "mot_original": "אֲבִידָע",
    "translitteration": "ʾăḇîḏāʿ",
    "prononciation": "ʾăḇîḏāʿ",
    "definition": "Abida, « mon père a connu » ou « père de la connaissance ».",
    "categorie": "Nom propre",
    "references": [
      "Genèse 25:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h28 אֲבִידָע ʾăḇîḏāʿ abida, « mon père a connu » ou « père de la connaissance ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200023,
    "strong": "H29",
    "langue": "hebreu",
    "numero": 29,
    "mot_original": "אֲבִיָּה",
    "translitteration": "ʾăḇîyāh",
    "prononciation": "ʾăḇîyāh",
    "definition": "Abiya, Abiyahu, « YHWH est mon père ».",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 14:1"
    ],
    "type": "nom propre",
    "occurrences": 25,
    "recherche": "h29 אֲבִיָּה ʾăḇîyāh abiya, abiyahu, « yhwh est mon père ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200024,
    "strong": "H30",
    "langue": "hebreu",
    "numero": 30,
    "mot_original": "אֲבִיהוּא",
    "translitteration": "ʾăḇîhûʾ",
    "prononciation": "ʾăḇîhûʾ",
    "definition": "Abihu, « lui (YHWH) est mon père ».",
    "categorie": "Nom propre",
    "references": [
      "Lévitique 10:1"
    ],
    "type": "nom propre",
    "occurrences": 12,
    "recherche": "h30 אֲבִיהוּא ʾăḇîhûʾ abihu, « lui (yhwh) est mon père ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200025,
    "strong": "H31",
    "langue": "hebreu",
    "numero": 31,
    "mot_original": "אֲבִיהוּד",
    "translitteration": "ʾăḇîhûḏ",
    "prononciation": "ʾăḇîhûḏ",
    "definition": "Abihud, « mon père est majesté » ou « père de gloire ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:3"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h31 אֲבִיהוּד ʾăḇîhûḏ abihud, « mon père est majesté » ou « père de gloire ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200026,
    "strong": "H32",
    "langue": "hebreu",
    "numero": 32,
    "mot_original": "אֲבִיהַיִל",
    "translitteration": "ʾăḇîhayil",
    "prononciation": "ʾăḇîhayil",
    "definition": "Abihail, « mon père est force » ou « père de la force ».",
    "categorie": "Nom propre",
    "references": [
      "Esther 2:15"
    ],
    "type": "nom propre",
    "occurrences": 6,
    "recherche": "h32 אֲבִיהַיִל ʾăḇîhayil abihail, « mon père est force » ou « père de la force ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200027,
    "strong": "H33",
    "langue": "hebreu",
    "numero": 33,
    "mot_original": "אֲבִי הָעֶזְרִי",
    "translitteration": "ʾăḇî hāʿezrî",
    "prononciation": "ʾăḇî hāʿezrî",
    "definition": "Abiézerite, membre du clan d'Abiézer, de la tribu de Manassé.",
    "categorie": "Nom propre (gentilé)",
    "references": [
      "Juges 6:11"
    ],
    "type": "nom propre (gentilé)",
    "occurrences": 3,
    "recherche": "h33 אֲבִי הָעֶזְרִי ʾăḇî hāʿezrî abiézerite, membre du clan d'abiézer, de la tribu de manassé. nom propre (gentilé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200028,
    "strong": "H34",
    "langue": "hebreu",
    "numero": 34,
    "mot_original": "אֶבְיוֹן",
    "translitteration": "ʾeḇyôn",
    "prononciation": "ʾeḇyôn",
    "definition": "Pauvre, indigent, nécessiteux, celui qui manque de ressources.",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Exode 23:11",
      "Deutéronome 15:7"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 61,
    "recherche": "h34 אֶבְיוֹן ʾeḇyôn pauvre, indigent, nécessiteux, celui qui manque de ressources. adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200029,
    "strong": "H35",
    "langue": "hebreu",
    "numero": 35,
    "mot_original": "אֲבִיּוֹנָה",
    "translitteration": "ʾăḇîyônāh",
    "prononciation": "ʾăḇîyônāh",
    "definition": "Câpre, fruit du câprier (Capparis spinosa).",
    "categorie": "Nom commun",
    "references": [
      "Ecclésiaste 12:5"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h35 אֲבִיּוֹנָה ʾăḇîyônāh câpre, fruit du câprier (capparis spinosa). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200030,
    "strong": "H36",
    "langue": "hebreu",
    "numero": 36,
    "mot_original": "אֲבִיטוּב",
    "translitteration": "ʾăḇîṭûḇ",
    "prononciation": "ʾăḇîṭûḇ",
    "definition": "Abitub, « mon père est bonté » ou « père de la bonté ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 8:11"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h36 אֲבִיטוּב ʾăḇîṭûḇ abitub, « mon père est bonté » ou « père de la bonté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200031,
    "strong": "H37",
    "langue": "hebreu",
    "numero": 37,
    "mot_original": "אֲבִיטָל",
    "translitteration": "ʾăḇîṭāl",
    "prononciation": "ʾăḇîṭāl",
    "definition": "Abital, « mon père est rosée » ou « père de la rosée ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 3:4"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h37 אֲבִיטָל ʾăḇîṭāl abital, « mon père est rosée » ou « père de la rosée ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200032,
    "strong": "H38",
    "langue": "hebreu",
    "numero": 38,
    "mot_original": "אֲבִיָּם",
    "translitteration": "ʾăḇîyām",
    "prononciation": "ʾăḇîyām",
    "definition": "Abiyam, \"mon père est Yām (Mer)\" ou forme alternative de Abiya. Roi de Juda, fils de Roboam.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 14:31"
    ],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h38 אֲבִיָּם ʾăḇîyām abiyam, \"mon père est yām (mer)\" ou forme alternative de abiya. roi de juda, fils de roboam. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200033,
    "strong": "H39",
    "langue": "hebreu",
    "numero": 39,
    "mot_original": "אֲבִימָאֵל",
    "translitteration": "ʾăḇîmāʾēl",
    "prononciation": "ʾăḇîmāʾēl",
    "definition": "Abimaël, \"mon père est vraiment Dieu\" ou \"le père est de Dieu\". Descendant de Sem.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 10:28"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h39 אֲבִימָאֵל ʾăḇîmāʾēl abimaël, \"mon père est vraiment dieu\" ou \"le père est de dieu\". descendant de sem. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200034,
    "strong": "H40",
    "langue": "hebreu",
    "numero": 40,
    "mot_original": "אֲבִימֶלֶךְ",
    "translitteration": "ʾăḇîmeleḵ",
    "prononciation": "ʾăḇîmeleḵ",
    "definition": "Abimélek, \"mon père est roi\" ou \"le père (divin) est roi\".",
    "categorie": "Nom propre",
    "references": [
      "Genèse 20:2"
    ],
    "type": "nom propre",
    "occurrences": 67,
    "recherche": "h40 אֲבִימֶלֶךְ ʾăḇîmeleḵ abimélek, \"mon père est roi\" ou \"le père (divin) est roi\". nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200035,
    "strong": "H41",
    "langue": "hebreu",
    "numero": 41,
    "mot_original": "אֲבִינָדָב",
    "translitteration": "ʾăḇînāḏāḇ",
    "prononciation": "ʾăḇînāḏāḇ",
    "definition": "Abinadab, « mon père est noble » ou « père de la noblesse ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 7:1"
    ],
    "type": "nom propre",
    "occurrences": 12,
    "recherche": "h41 אֲבִינָדָב ʾăḇînāḏāḇ abinadab, « mon père est noble » ou « père de la noblesse ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200036,
    "strong": "H42",
    "langue": "hebreu",
    "numero": 42,
    "mot_original": "אֲבִינֹעַם",
    "translitteration": "ʾăḇînōʿam",
    "prononciation": "ʾăḇînōʿam",
    "definition": "Abinoam, « mon père est plaisir » ou « père de la douceur ».",
    "categorie": "Nom propre",
    "references": [
      "Juges 4:6"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h42 אֲבִינֹעַם ʾăḇînōʿam abinoam, « mon père est plaisir » ou « père de la douceur ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200037,
    "strong": "H43",
    "langue": "hebreu",
    "numero": 43,
    "mot_original": "אֶבְיָסָף",
    "translitteration": "ʾeḇyāsāp̄",
    "prononciation": "ʾeḇyāsāp̄",
    "definition": "Ebyasaph, variante orthographique de Abiasaph (H0023).",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 6:8"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h43 אֶבְיָסָף ʾeḇyāsāp̄ ebyasaph, variante orthographique de abiasaph (h0023). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200038,
    "strong": "H44",
    "langue": "hebreu",
    "numero": 44,
    "mot_original": "אֲבִיעֶזֶר",
    "translitteration": "ʾăḇîʿezer",
    "prononciation": "ʾăḇîʿezer",
    "definition": "Abiézer, « mon père est secours » ou « père du secours ».",
    "categorie": "Nom propre",
    "references": [
      "Juges 6:34"
    ],
    "type": "nom propre",
    "occurrences": 7,
    "recherche": "h44 אֲבִיעֶזֶר ʾăḇîʿezer abiézer, « mon père est secours » ou « père du secours ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200039,
    "strong": "H45",
    "langue": "hebreu",
    "numero": 45,
    "mot_original": "אֲבִי־עַלְבוֹן",
    "translitteration": "ʾăḇî-ʿalḇôn",
    "prononciation": "ʾăḇî-ʿalḇôn",
    "definition": "Abi-Albon, « père de force » ou nom composé incluant עַלְבוֹן.",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 23:31"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h45 אֲבִי־עַלְבוֹן ʾăḇî-ʿalḇôn abi-albon, « père de force » ou nom composé incluant עַלְבוֹן. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200040,
    "strong": "H46",
    "langue": "hebreu",
    "numero": 46,
    "mot_original": "אָבִיר",
    "translitteration": "ʾāḇîr",
    "prononciation": "ʾāḇîr",
    "definition": "Fort, puissant, taureau (métaphore de puissance).",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Genèse 49:24",
      "Ésaïe 1:24"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 6,
    "recherche": "h46 אָבִיר ʾāḇîr fort, puissant, taureau (métaphore de puissance). adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200041,
    "strong": "H47",
    "langue": "hebreu",
    "numero": 47,
    "mot_original": "אַבִּיר",
    "translitteration": "ʾabbîr",
    "prononciation": "ʾabbîr",
    "definition": "Puissant, fort, taureau ; coursier, destrier.",
    "categorie": "Adjectif / nom commun",
    "references": [
      "Juges 5:22",
      "Psaume 22:13"
    ],
    "type": "adjectif / nom commun",
    "occurrences": 17,
    "recherche": "h47 אַבִּיר ʾabbîr puissant, fort, taureau ; coursier, destrier. adjectif / nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200042,
    "strong": "H48",
    "langue": "hebreu",
    "numero": 48,
    "mot_original": "אֲבִירָם",
    "translitteration": "ʾăḇîrām",
    "prononciation": "ʾăḇîrām",
    "definition": "Abiram, « mon père est exalté » ou « le père (divin) est exalté ».",
    "categorie": "Nom propre",
    "references": [
      "Nombres 16:1",
      "1 Rois 16:34"
    ],
    "type": "nom propre",
    "occurrences": 11,
    "recherche": "h48 אֲבִירָם ʾăḇîrām abiram, « mon père est exalté » ou « le père (divin) est exalté ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200043,
    "strong": "H49",
    "langue": "hebreu",
    "numero": 49,
    "mot_original": "אֲבִישַׁג",
    "translitteration": "ʾăḇîšaḡ",
    "prononciation": "ʾăḇîšaḡ",
    "definition": "Abishag, « mon père est errance » ou signification incertaine.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 1:3"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h49 אֲבִישַׁג ʾăḇîšaḡ abishag, « mon père est errance » ou signification incertaine. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200044,
    "strong": "H50",
    "langue": "hebreu",
    "numero": 50,
    "mot_original": "אֲבִישׁוּעַ",
    "translitteration": "ʾăḇîšûaʿ",
    "prononciation": "ʾăḇîšûaʿ",
    "definition": "Abishua, « mon père est salut » ou « père du salut ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 5:30"
    ],
    "type": "nom propre",
    "occurrences": 5,
    "recherche": "h50 אֲבִישׁוּעַ ʾăḇîšûaʿ abishua, « mon père est salut » ou « père du salut ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200045,
    "strong": "H51",
    "langue": "hebreu",
    "numero": 51,
    "mot_original": "אֲבִישׁוּר",
    "translitteration": "ʾăḇîšûr",
    "prononciation": "ʾăḇîšûr",
    "definition": "Abishur, « mon père est muraille » ou « père de la muraille ».",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 2:28"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h51 אֲבִישׁוּר ʾăḇîšûr abishur, « mon père est muraille » ou « père de la muraille ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200046,
    "strong": "H52",
    "langue": "hebreu",
    "numero": 52,
    "mot_original": "אֲבִישַׁי",
    "translitteration": "ʾăḇîšay",
    "prononciation": "ʾăḇîšay",
    "definition": "Abishaï, « mon père est présent » ou « père du don ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 26:8"
    ],
    "type": "nom propre",
    "occurrences": 25,
    "recherche": "h52 אֲבִישַׁי ʾăḇîšay abishaï, « mon père est présent » ou « père du don ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200047,
    "strong": "H53",
    "langue": "hebreu",
    "numero": 53,
    "mot_original": "אֲבִישָׁלוֹם",
    "translitteration": "ʾăḇîšālôm",
    "prononciation": "ʾăḇîšālôm",
    "definition": "Abishalom, « mon père est paix » ou « père de la paix ». Variante de Absalom.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 15:2"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h53 אֲבִישָׁלוֹם ʾăḇîšālôm abishalom, « mon père est paix » ou « père de la paix ». variante de absalom. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200048,
    "strong": "H54",
    "langue": "hebreu",
    "numero": 54,
    "mot_original": "אֶבְיָתָר",
    "translitteration": "ʾeḇyāṯār",
    "prononciation": "ʾeḇyāṯār",
    "definition": "Ébyatar, Abiathar, « le père (divin) a pourvu » ou « père de l'abondance ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 22:20"
    ],
    "type": "nom propre",
    "occurrences": 30,
    "recherche": "h54 אֶבְיָתָר ʾeḇyāṯār ébyatar, abiathar, « le père (divin) a pourvu » ou « père de l'abondance ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200049,
    "strong": "H55",
    "langue": "hebreu",
    "numero": 55,
    "mot_original": "אָבַךְ",
    "translitteration": "ʾāḇaḵ",
    "prononciation": "ʾāḇaḵ",
    "definition": "S'enrouler, monter en spirale, tourbillonner (en parlant de fumée ou de poussière).",
    "categorie": "Verbe",
    "references": [
      "Juges 7:13"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h55 אָבַךְ ʾāḇaḵ s'enrouler, monter en spirale, tourbillonner (en parlant de fumée ou de poussière). verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200050,
    "strong": "H56",
    "langue": "hebreu",
    "numero": 56,
    "mot_original": "אָבַל",
    "translitteration": "ʾāḇal",
    "prononciation": "ʾāḇal",
    "definition": "Être en deuil, mener le deuil, se lamenter.",
    "categorie": "Verbe",
    "references": [
      "Ésaïe 24:4"
    ],
    "type": "verbe",
    "occurrences": 8,
    "recherche": "h56 אָבַל ʾāḇal être en deuil, mener le deuil, se lamenter. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200051,
    "strong": "H57",
    "langue": "hebreu",
    "numero": 57,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "En deuil, affligé, portant le deuil.",
    "categorie": "Adjectif",
    "references": [
      "Ésaïe 61:3"
    ],
    "type": "adjectif",
    "occurrences": 8,
    "recherche": "h57 אָבֵל ʾāḇēl en deuil, affligé, portant le deuil. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200052,
    "strong": "H58",
    "langue": "hebreu",
    "numero": 58,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "Prairie, pâturage arrosé, cours d'eau.",
    "categorie": "Nom commun",
    "references": [
      "Juges 11:33"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h58 אָבֵל ʾāḇēl prairie, pâturage arrosé, cours d'eau. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200053,
    "strong": "H59",
    "langue": "hebreu",
    "numero": 59,
    "mot_original": "אָבֵל",
    "translitteration": "ʾāḇēl",
    "prononciation": "ʾāḇēl",
    "definition": "Abel, nom de plusieurs localités en Israël et en Transjordanie.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "2 Samuel 20:18"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 7,
    "recherche": "h59 אָבֵל ʾāḇēl abel, nom de plusieurs localités en israël et en transjordanie. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200054,
    "strong": "H60",
    "langue": "hebreu",
    "numero": 60,
    "mot_original": "אֵבֶל",
    "translitteration": "ʾēḇel",
    "prononciation": "ʾēḇel",
    "definition": "Deuil, lamentation funèbre, cérémonie de deuil.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 50:11"
    ],
    "type": "nom commun",
    "occurrences": 24,
    "recherche": "h60 אֵבֶל ʾēḇel deuil, lamentation funèbre, cérémonie de deuil. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200055,
    "strong": "H61",
    "langue": "hebreu",
    "numero": 61,
    "mot_original": "אֲבָל",
    "translitteration": "ʾăḇāl",
    "prononciation": "ʾăḇāl",
    "definition": "Mais, cependant, toutefois, vraiment, certainement.",
    "categorie": "Adverbe / conjonction",
    "references": [
      "Genèse 17:19",
      "2 Samuel 14:5"
    ],
    "type": "adverbe / conjonction",
    "occurrences": 11,
    "recherche": "h61 אֲבָל ʾăḇāl mais, cependant, toutefois, vraiment, certainement. adverbe / conjonction",
    "audio": "",
    "image": null
  },
  {
    "id": 200056,
    "strong": "H62",
    "langue": "hebreu",
    "numero": 62,
    "mot_original": "אָבֵל בֵּית־מַעֲכָה",
    "translitteration": "ʾāḇēl bêṯ-maʿăḵāh",
    "prononciation": "ʾāḇēl bêṯ-maʿăḵāh",
    "definition": "Abel-Beth-Maaka, « prairie de la maison de Maaka », ville fortifiée du nord d'Israël.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "2 Samuel 20:14"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 4,
    "recherche": "h62 אָבֵל בֵּית־מַעֲכָה ʾāḇēl bêṯ-maʿăḵāh abel-beth-maaka, « prairie de la maison de maaka », ville fortifiée du nord d'israël. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200057,
    "strong": "H63",
    "langue": "hebreu",
    "numero": 63,
    "mot_original": "אָבֵל הַשִּׁטִּים",
    "translitteration": "ʾāḇēl haššiṭṭîm",
    "prononciation": "ʾāḇēl haššiṭṭîm",
    "definition": "Abel-Shittim, « prairie des acacias », dernier campement israélite en Transjordanie.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Nombres 33:49"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h63 אָבֵל הַשִּׁטִּים ʾāḇēl haššiṭṭîm abel-shittim, « prairie des acacias », dernier campement israélite en transjordanie. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200058,
    "strong": "H64",
    "langue": "hebreu",
    "numero": 64,
    "mot_original": "אָבֵל כְּרָמִים",
    "translitteration": "ʾāḇēl kərāmîm",
    "prononciation": "ʾāḇēl kərāmîm",
    "definition": "Abel-Keramim, « prairie des vignes », localité ammonite.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Juges 11:33"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h64 אָבֵל כְּרָמִים ʾāḇēl kərāmîm abel-keramim, « prairie des vignes », localité ammonite. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200059,
    "strong": "H65",
    "langue": "hebreu",
    "numero": 65,
    "mot_original": "אָבֵל מְחוֹלָה",
    "translitteration": "ʾāḇēl məḥôlāh",
    "prononciation": "ʾāḇēl məḥôlāh",
    "definition": "Abel-Meholah, « prairie de la danse », ville de la vallée du Jourdain.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "1 Rois 19:16"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 3,
    "recherche": "h65 אָבֵל מְחוֹלָה ʾāḇēl məḥôlāh abel-meholah, « prairie de la danse », ville de la vallée du jourdain. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200060,
    "strong": "H66",
    "langue": "hebreu",
    "numero": 66,
    "mot_original": "אָבֵל מַיִם",
    "translitteration": "ʾāḇēl mayim",
    "prononciation": "ʾāḇēl mayim",
    "definition": "Abel-Maïm, « prairie des eaux », variante de Abel-Beth-Maaka.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "2 Chroniques 16:4"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h66 אָבֵל מַיִם ʾāḇēl mayim abel-maïm, « prairie des eaux », variante de abel-beth-maaka. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200061,
    "strong": "H67",
    "langue": "hebreu",
    "numero": 67,
    "mot_original": "אָבֵל מִצְרַיִם",
    "translitteration": "ʾāḇēl miṣrayim",
    "prononciation": "ʾāḇēl miṣrayim",
    "definition": "Abel-Mitsraïm, « deuil de l'Égypte », nom donné à l'aire d'Atad après la cérémonie funèbre de Jacob.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "Genèse 50:11"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 1,
    "recherche": "h67 אָבֵל מִצְרַיִם ʾāḇēl miṣrayim abel-mitsraïm, « deuil de l'égypte », nom donné à l'aire d'atad après la cérémonie funèbre de jacob. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200062,
    "strong": "H68",
    "langue": "hebreu",
    "numero": 68,
    "mot_original": "אֶבֶן",
    "translitteration": "ʾeḇen",
    "prononciation": "ʾeḇen",
    "definition": "Pierre, roche, bloc de pierre.",
    "categorie": "Nom commun",
    "references": [
      "Genèse 28:18",
      "Exode 31:18"
    ],
    "type": "nom commun",
    "occurrences": 273,
    "recherche": "h68 אֶבֶן ʾeḇen pierre, roche, bloc de pierre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200063,
    "strong": "H69",
    "langue": "hebreu",
    "numero": 69,
    "mot_original": "אֶבֶן",
    "translitteration": "ʾeḇen",
    "prononciation": "ʾeḇen",
    "definition": "Pierre. Correspondance araméenne de l'hébreu אֶבֶן (H0068).",
    "categorie": "Nom commun",
    "references": [
      "Daniel 2:34",
      "Esdras 6:4"
    ],
    "type": "nom commun",
    "occurrences": 8,
    "recherche": "h69 אֶבֶן ʾeḇen pierre. correspondance araméenne de l'hébreu אֶבֶן (h0068). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200064,
    "strong": "H70",
    "langue": "hebreu",
    "numero": 70,
    "mot_original": "אֹבֶן",
    "translitteration": "ʾōḇen",
    "prononciation": "ʾōḇen",
    "definition": "Siège d'accouchement, pierres sur lesquelles la femme s'accroupissait pour accoucher.",
    "categorie": "Nom commun",
    "references": [
      "Exode 1:16",
      "Jérémie 18:3"
    ],
    "type": "nom commun",
    "occurrences": 2,
    "recherche": "h70 אֹבֶן ʾōḇen siège d'accouchement, pierres sur lesquelles la femme s'accroupissait pour accoucher. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200065,
    "strong": "H71",
    "langue": "hebreu",
    "numero": 71,
    "mot_original": "אֲבָנָה",
    "translitteration": "ʾăḇānāh",
    "prononciation": "ʾăḇānāh",
    "definition": "Abana, rivière de Damas mentionnée par Naaman.",
    "categorie": "Nom propre",
    "references": [
      "2 Rois 5:12"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h71 אֲבָנָה ʾăḇānāh abana, rivière de damas mentionnée par naaman. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200066,
    "strong": "H72",
    "langue": "hebreu",
    "numero": 72,
    "mot_original": "אֶבֶן הָעֵזֶר",
    "translitteration": "ʾeḇen hāʿēzer",
    "prononciation": "ʾeḇen hāʿēzer",
    "definition": "Eben-Ezer, « pierre du secours ». Nom commémoratif donné par Samuel à un lieu de victoire contre les Philistins.",
    "categorie": "Nom propre (toponyme composé)",
    "references": [
      "1 Samuel 7:12"
    ],
    "type": "nom propre (toponyme composé)",
    "occurrences": 3,
    "recherche": "h72 אֶבֶן הָעֵזֶר ʾeḇen hāʿēzer eben-ezer, « pierre du secours ». nom commémoratif donné par samuel à un lieu de victoire contre les philistins. nom propre (toponyme composé)",
    "audio": "",
    "image": null
  },
  {
    "id": 200067,
    "strong": "H73",
    "langue": "hebreu",
    "numero": 73,
    "mot_original": "אַבְנֵט",
    "translitteration": "ʾaḇnēṭ",
    "prononciation": "ʾaḇnēṭ",
    "definition": "Ceinture, écharpe, baudrier sacerdotal.",
    "categorie": "Nom commun",
    "references": [
      "Exode 28:4"
    ],
    "type": "nom commun",
    "occurrences": 9,
    "recherche": "h73 אַבְנֵט ʾaḇnēṭ ceinture, écharpe, baudrier sacerdotal. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200068,
    "strong": "H74",
    "langue": "hebreu",
    "numero": 74,
    "mot_original": "אַבְנֵר",
    "translitteration": "ʾaḇnēr",
    "prononciation": "ʾaḇnēr",
    "definition": "Abner, « mon père est lampe » ou « père de la lumière ».",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 14:50"
    ],
    "type": "nom propre",
    "occurrences": 62,
    "recherche": "h74 אַבְנֵר ʾaḇnēr abner, « mon père est lampe » ou « père de la lumière ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200069,
    "strong": "H75",
    "langue": "hebreu",
    "numero": 75,
    "mot_original": "אָבַס",
    "translitteration": "ʾāḇas",
    "prononciation": "ʾāḇas",
    "definition": "Engraisser, nourrir abondamment le bétail à l'étable.",
    "categorie": "Verbe",
    "references": [
      "Proverbes 15:17"
    ],
    "type": "verbe",
    "occurrences": 2,
    "recherche": "h75 אָבַס ʾāḇas engraisser, nourrir abondamment le bétail à l'étable. verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200070,
    "strong": "H76",
    "langue": "hebreu",
    "numero": 76,
    "mot_original": "אֲבַעְבֻּעָה",
    "translitteration": "ʾăḇaʿbuʿāh",
    "prononciation": "ʾăḇaʿbuʿāh",
    "definition": "Pustule, ampoule, vésicule cutanée (sixième plaie d'Égypte).",
    "categorie": "Nom commun",
    "references": [
      "Exode 9:9"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h76 אֲבַעְבֻּעָה ʾăḇaʿbuʿāh pustule, ampoule, vésicule cutanée (sixième plaie d'égypte). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200071,
    "strong": "H77",
    "langue": "hebreu",
    "numero": 77,
    "mot_original": "אֶבֶץ",
    "translitteration": "ʾeḇeṣ",
    "prononciation": "ʾeḇeṣ",
    "definition": "Ébets, ville de la tribu d'Issachar.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "Josué 19:20"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h77 אֶבֶץ ʾeḇeṣ ébets, ville de la tribu d'issachar. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200072,
    "strong": "H78",
    "langue": "hebreu",
    "numero": 78,
    "mot_original": "אִבְצָן",
    "translitteration": "ʾiḇṣān",
    "prononciation": "ʾiḇṣān",
    "definition": "Ibtsan, juge d'Israël originaire de Bethléem.",
    "categorie": "Nom propre",
    "references": [
      "Juges 12:8"
    ],
    "type": "nom propre",
    "occurrences": 2,
    "recherche": "h78 אִבְצָן ʾiḇṣān ibtsan, juge d'israël originaire de bethléem. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200073,
    "strong": "H79",
    "langue": "hebreu",
    "numero": 79,
    "mot_original": "אַבְשַׁי",
    "translitteration": "ʾaḇšay",
    "prononciation": "ʾaḇšay",
    "definition": "Abshaï, variante abrégée de Abishaï (H0052).",
    "categorie": "Nom propre",
    "references": [
      "1 Chroniques 11:20"
    ],
    "type": "nom propre",
    "occurrences": 4,
    "recherche": "h79 אַבְשַׁי ʾaḇšay abshaï, variante abrégée de abishaï (h0052). nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200074,
    "strong": "H80",
    "langue": "hebreu",
    "numero": 80,
    "mot_original": "אָבָק",
    "translitteration": "ʾāḇāq",
    "prononciation": "ʾāḇāq",
    "definition": "Poussière fine, poudre impalpable.",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 28:24",
      "Ésaïe 29:5"
    ],
    "type": "nom commun",
    "occurrences": 6,
    "recherche": "h80 אָבָק ʾāḇāq poussière fine, poudre impalpable. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200075,
    "strong": "H81",
    "langue": "hebreu",
    "numero": 81,
    "mot_original": "אֲבָקָה",
    "translitteration": "ʾăḇāqāh",
    "prononciation": "ʾăḇāqāh",
    "definition": "Poudre aromatique, parfum en poudre.",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h81 אֲבָקָה ʾăḇāqāh poudre aromatique, parfum en poudre. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200076,
    "strong": "H82",
    "langue": "hebreu",
    "numero": 82,
    "mot_original": "אָבַר",
    "translitteration": "ʾāḇar",
    "prononciation": "ʾāḇar",
    "definition": "Sens incertain. Possible « planer, voler » ou « être fort, puissant ».",
    "categorie": "Verbe",
    "references": [
      "Job 39:26"
    ],
    "type": "verbe",
    "occurrences": 1,
    "recherche": "h82 אָבַר ʾāḇar sens incertain. possible « planer, voler » ou « être fort, puissant ». verbe",
    "audio": "",
    "image": null
  },
  {
    "id": 200077,
    "strong": "H83",
    "langue": "hebreu",
    "numero": 83,
    "mot_original": "אֵבֶר",
    "translitteration": "ʾēḇer",
    "prononciation": "ʾēḇer",
    "definition": "Aile, penne, rémige (plume de l'aile).",
    "categorie": "Nom commun",
    "references": [
      "Psaume 55:7",
      "Ézéchiel 17:3"
    ],
    "type": "nom commun",
    "occurrences": 3,
    "recherche": "h83 אֵבֶר ʾēḇer aile, penne, rémige (plume de l'aile). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200078,
    "strong": "H84",
    "langue": "hebreu",
    "numero": 84,
    "mot_original": "אֶבְרָה",
    "translitteration": "ʾeḇrāh",
    "prononciation": "ʾeḇrāh",
    "definition": "Penne, aile, plumage (forme féminine de H0083).",
    "categorie": "Nom commun",
    "references": [
      "Deutéronome 32:11",
      "Psaume 91:4"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h84 אֶבְרָה ʾeḇrāh penne, aile, plumage (forme féminine de h0083). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200079,
    "strong": "H85",
    "langue": "hebreu",
    "numero": 85,
    "mot_original": "אַבְרָהָם",
    "translitteration": "ʾaḇrāhām",
    "prononciation": "ʾaḇrāhām",
    "definition": "Abraham, « père d'une multitude » ou « père élevé ». Patriarche fondateur d'Israël.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 17:5"
    ],
    "type": "nom propre",
    "occurrences": 175,
    "recherche": "h85 אַבְרָהָם ʾaḇrāhām abraham, « père d'une multitude » ou « père élevé ». patriarche fondateur d'israël. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200080,
    "strong": "H86",
    "langue": "hebreu",
    "numero": 86,
    "mot_original": "אַבְרֵךְ",
    "translitteration": "ʾaḇrēḵ",
    "prononciation": "ʾaḇrēḵ",
    "definition": "À genoux ! Prosternez-vous ! Cri acclamant la dignité de Joseph comme vizir d'Égypte.",
    "categorie": "Interjection ou titre",
    "references": [
      "Genèse 41:43"
    ],
    "type": "interjection ou titre",
    "occurrences": 1,
    "recherche": "h86 אַבְרֵךְ ʾaḇrēḵ à genoux ! prosternez-vous ! cri acclamant la dignité de joseph comme vizir d'égypte. interjection ou titre",
    "audio": "",
    "image": null
  },
  {
    "id": 200081,
    "strong": "H87",
    "langue": "hebreu",
    "numero": 87,
    "mot_original": "אַבְרָם",
    "translitteration": "ʾaḇrām",
    "prononciation": "ʾaḇrām",
    "definition": "Abram, « le père (divin) est élevé » ou « père élevé ». Nom originel d'Abraham.",
    "categorie": "Nom propre",
    "references": [
      "Genèse 11:27"
    ],
    "type": "nom propre",
    "occurrences": 61,
    "recherche": "h87 אַבְרָם ʾaḇrām abram, « le père (divin) est élevé » ou « père élevé ». nom originel d'abraham. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200082,
    "strong": "H88",
    "langue": "hebreu",
    "numero": 88,
    "mot_original": "אַבְשָׁלוֹם",
    "translitteration": "ʾaḇšālôm",
    "prononciation": "ʾaḇšālôm",
    "definition": "Absalom, « père de la paix » ou « mon père est paix ».",
    "categorie": "Nom propre",
    "references": [
      "2 Samuel 14:25"
    ],
    "type": "nom propre",
    "occurrences": 86,
    "recherche": "h88 אַבְשָׁלוֹם ʾaḇšālôm absalom, « père de la paix » ou « mon père est paix ». nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200083,
    "strong": "H89",
    "langue": "hebreu",
    "numero": 89,
    "mot_original": "אֲבִישַׁלֹם",
    "translitteration": "ʾăḇîšālōm",
    "prononciation": "ʾăḇîšālōm",
    "definition": "Abishalom, variante pleine de Absalom (H0088). Voir H0053.",
    "categorie": "Nom propre",
    "references": [
      "1 Rois 15:2"
    ],
    "type": "nom propre",
    "occurrences": 3,
    "recherche": "h89 אֲבִישַׁלֹם ʾăḇîšālōm abishalom, variante pleine de absalom (h0088). voir h0053. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200084,
    "strong": "H90",
    "langue": "hebreu",
    "numero": 90,
    "mot_original": "אֶבְיָתָר",
    "translitteration": "ʾeḇyāṯār",
    "prononciation": "ʾeḇyāṯār",
    "definition": "Ébyatar. Voir H0054.",
    "categorie": "Nom propre",
    "references": [
      "1 Samuel 22:20"
    ],
    "type": "nom propre",
    "occurrences": 0,
    "recherche": "h90 אֶבְיָתָר ʾeḇyāṯār ébyatar. voir h0054. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200085,
    "strong": "H91",
    "langue": "hebreu",
    "numero": 91,
    "mot_original": "אֲגָגִי",
    "translitteration": "ʾăḡāḡî",
    "prononciation": "ʾăḡāḡî",
    "definition": "Agaguite, descendant ou sujet d'Agag, roi amalécite.",
    "categorie": "Adjectif gentilé / nom propre",
    "references": [
      "Esther 3:1"
    ],
    "type": "adjectif gentilé / nom propre",
    "occurrences": 5,
    "recherche": "h91 אֲגָגִי ʾăḡāḡî agaguite, descendant ou sujet d'agag, roi amalécite. adjectif gentilé / nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200086,
    "strong": "H92",
    "langue": "hebreu",
    "numero": 92,
    "mot_original": "אֲגֻדָּה",
    "translitteration": "ʾăḡuddāh",
    "prononciation": "ʾăḡuddāh",
    "definition": "Bande, faisceau, lien, groupe lié.",
    "categorie": "Nom commun",
    "references": [
      "Exode 12:22",
      "Job 38:31"
    ],
    "type": "nom commun",
    "occurrences": 4,
    "recherche": "h92 אֲגֻדָּה ʾăḡuddāh bande, faisceau, lien, groupe lié. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200087,
    "strong": "H93",
    "langue": "hebreu",
    "numero": 93,
    "mot_original": "אֱגוֹז",
    "translitteration": "ʾĕḡôz",
    "prononciation": "ʾĕḡôz",
    "definition": "Noix, fruit du noyer (Juglans regia).",
    "categorie": "Nom commun",
    "references": [],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h93 אֱגוֹז ʾĕḡôz noix, fruit du noyer (juglans regia). nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200088,
    "strong": "H94",
    "langue": "hebreu",
    "numero": 94,
    "mot_original": "אָגוּר",
    "translitteration": "ʾāḡûr",
    "prononciation": "ʾāḡûr",
    "definition": "Agur, nom du sage auteur du chapitre 30 des Proverbes.",
    "categorie": "Nom propre",
    "references": [
      "Proverbes 30:1"
    ],
    "type": "nom propre",
    "occurrences": 1,
    "recherche": "h94 אָגוּר ʾāḡûr agur, nom du sage auteur du chapitre 30 des proverbes. nom propre",
    "audio": "",
    "image": null
  },
  {
    "id": 200089,
    "strong": "H95",
    "langue": "hebreu",
    "numero": 95,
    "mot_original": "אֲגוֹרָה",
    "translitteration": "ʾăḡôrāh",
    "prononciation": "ʾăḡôrāh",
    "definition": "Pièce d'argent, petite monnaie, pourboire.",
    "categorie": "Nom commun",
    "references": [
      "1 Samuel 2:36"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h95 אֲגוֹרָה ʾăḡôrāh pièce d'argent, petite monnaie, pourboire. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200090,
    "strong": "H96",
    "langue": "hebreu",
    "numero": 96,
    "mot_original": "אֶגֶל",
    "translitteration": "ʾeḡel",
    "prononciation": "ʾeḡel",
    "definition": "Goutte, réserve d'eau. Variante poétique ou régionale de עֵגֶל (H5695, « veau ») ou mot distinct.",
    "categorie": "Nom commun",
    "references": [
      "Job 38:28"
    ],
    "type": "nom commun",
    "occurrences": 1,
    "recherche": "h96 אֶגֶל ʾeḡel goutte, réserve d'eau. variante poétique ou régionale de עֵגֶל (h5695, « veau ») ou mot distinct. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200091,
    "strong": "H97",
    "langue": "hebreu",
    "numero": 97,
    "mot_original": "אֶגְלַיִם",
    "translitteration": "ʾeḡlayim",
    "prononciation": "ʾeḡlayim",
    "definition": "Églaïm, localité près de la mer Morte.",
    "categorie": "Nom propre (toponyme)",
    "references": [
      "Ézéchiel 47:10"
    ],
    "type": "nom propre (toponyme)",
    "occurrences": 1,
    "recherche": "h97 אֶגְלַיִם ʾeḡlayim églaïm, localité près de la mer morte. nom propre (toponyme)",
    "audio": "",
    "image": null
  },
  {
    "id": 200092,
    "strong": "H98",
    "langue": "hebreu",
    "numero": 98,
    "mot_original": "אֲגַם",
    "translitteration": "ʾăḡam",
    "prononciation": "ʾăḡam",
    "definition": "Marais, étang, mare d'eau stagnante.",
    "categorie": "Nom commun",
    "references": [
      "Exode 7:19"
    ],
    "type": "nom commun",
    "occurrences": 9,
    "recherche": "h98 אֲגַם ʾăḡam marais, étang, mare d'eau stagnante. nom commun",
    "audio": "",
    "image": null
  },
  {
    "id": 200093,
    "strong": "H99",
    "langue": "hebreu",
    "numero": 99,
    "mot_original": "אָגֵם",
    "translitteration": "ʾāḡēm",
    "prononciation": "ʾāḡēm",
    "definition": "Triste, affligé, abattu.",
    "categorie": "Adjectif",
    "references": [],
    "type": "adjectif",
    "occurrences": 1,
    "recherche": "h99 אָגֵם ʾāḡēm triste, affligé, abattu. adjectif",
    "audio": "",
    "image": null
  },
  {
    "id": 200094,
    "strong": "H100",
    "langue": "hebreu",
    "numero": 100,
    "mot_original": "אַגְמוֹן",
    "translitteration": "ʾaḡmôn",
    "prononciation": "ʾaḡmôn",
    "definition": "Jonc, roseau ; métaphoriquement : crochet, hameçon.",
    "categorie": "Nom commun",
    "references": [
      "Job 40:26",
      "Ésaïe 58:5"
    ],
    "type": "nom commun",
    "occurrences": 5,
    "recherche": "h100 אַגְמוֹן ʾaḡmôn jonc, roseau ; métaphoriquement : crochet, hameçon. nom commun",
    "audio": "",
    "image": null
  }
];
