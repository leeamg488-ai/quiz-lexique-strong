import React, { useState } from 'react';
import { StrongEntry } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, ArrowRight, Shuffle, BookOpen } from 'lucide-react';
import versesLSG from '../data/versesLSG.json';

interface VerseQuizProps {
  entries: StrongEntry[];
}

type Direction = 'verset_to_reference' | 'reference_to_verset';

interface VerseQuestion {
  direction: Direction;
  entry: StrongEntry;
  correctReference: string;
  correctVerseText: string;
  // options : soit des références (verset_to_reference), soit des textes de versets (reference_to_verset)
  options: string[];
  correctAnswer: string;
}

const LETTERS = ['A', 'B', 'C', 'D'];

function shuffleArray<T>(array: T[]): T[] {
  return [...array].sort(() => Math.random() - 0.5);
}

// Choisit une entrée aléatoire possédant au moins une référence biblique.
function pickEntryWithReference(entries: StrongEntry[]): { entry: StrongEntry; reference: string } {
  const pool = entries.filter((e) => e.references.length > 0);
  const entry = pool[Math.floor(Math.random() * pool.length)];
  const reference = entry.references[Math.floor(Math.random() * entry.references.length)];
  return { entry, reference };
}

// Rassemble un lot de références distinctes (une par entrée) pour servir de distracteurs.
function pickDistractorReferences(entries: StrongEntry[], excludeRef: string, count: number): string[] {
  const pool = entries.filter((e) => e.references.length > 0);
  const shuffled = shuffleArray(pool);
  const refs = new Set<string>();
  for (const e of shuffled) {
    const r = e.references[Math.floor(Math.random() * e.references.length)];
    if (r !== excludeRef) refs.add(r);
    if (refs.size >= count) break;
  }
  return Array.from(refs);
}

const VERSES: Record<string, string> = versesLSG;

export default function VerseQuiz({ entries }: VerseQuizProps) {
  const [question, setQuestion] = useState<VerseQuestion | null>(() => buildQuestion(entries));
  const [selected, setSelected] = useState<string | null>(null);
  const [score, setScore] = useState({ correct: 0, total: 0 });

  function buildQuestion(entries: StrongEntry[]): VerseQuestion | null {
    const direction: Direction = Math.random() < 0.5 ? 'verset_to_reference' : 'reference_to_verset';
    const { entry, reference } = pickEntryWithReference(entries);
    const correctVerseText = VERSES[reference];
    if (!correctVerseText) return null;

    if (direction === 'verset_to_reference') {
      const distractorRefs = pickDistractorReferences(entries, reference, 3);
      return {
        direction,
        entry,
        correctReference: reference,
        correctVerseText,
        options: shuffleArray([reference, ...distractorRefs]),
        correctAnswer: reference,
      };
    } else {
      const distractorRefs = pickDistractorReferences(entries, reference, 3);
      const distractorTexts = distractorRefs.map((r) => VERSES[r]).filter((t): t is string => !!t);
      return {
        direction,
        entry,
        correctReference: reference,
        correctVerseText,
        options: shuffleArray([correctVerseText, ...distractorTexts.slice(0, 3)]),
        correctAnswer: correctVerseText,
      };
    }
  }

  const isAnswered = selected !== null;
  const isCorrect = question ? selected === question.correctAnswer : false;

  const handleSelect = (option: string) => {
    if (isAnswered || !question) return;
    setSelected(option);
    setScore((s) => ({
      correct: s.correct + (option === question.correctAnswer ? 1 : 0),
      total: s.total + 1,
    }));
  };

  const handleNext = () => {
    setQuestion(buildQuestion(entries));
    setSelected(null);
  };

  const handleReset = () => {
    setScore({ correct: 0, total: 0 });
    setQuestion(buildQuestion(entries));
    setSelected(null);
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      {/* Score */}
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-mono text-gray-400 uppercase tracking-wider">
          Score : {score.correct} / {score.total}
        </span>
        <button
          onClick={handleReset}
          className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-400 hover:text-amber-600 transition-colors cursor-pointer"
        >
          <Shuffle className="h-3.5 w-3.5" /> Recommencer
        </button>
      </div>

      <div className="bg-neutral-900 p-6 md:p-8 rounded-3xl border border-neutral-800 shadow-xl space-y-6 min-h-[360px] flex flex-col justify-center">
        {!question && (
          <p className="text-center text-neutral-400 text-sm py-12">Aucun verset disponible.</p>
        )}

        {question && (
          <>
            {/* Énoncé */}
            <div className="text-center space-y-3 pb-4 border-b border-neutral-800">
              <span className="inline-block px-4 py-1.5 rounded-lg text-xs font-bold tracking-widest uppercase font-mono bg-neutral-800 text-neutral-300">
                Versets bibliques
              </span>

              {question.direction === 'verset_to_reference' ? (
                <>
                  <p className="text-[11px] font-bold tracking-widest uppercase text-neutral-500">Verset</p>
                  <p className="text-neutral-100 text-lg font-semibold leading-relaxed italic">
                    « {question.correctVerseText} »
                  </p>
                </>
              ) : (
                <>
                  <p className="text-[11px] font-bold tracking-widest uppercase text-neutral-500">Référence</p>
                  <p className="text-amber-300 text-3xl font-black">{question.correctReference}</p>
                </>
              )}
            </div>

            {/* Question */}
            <p className="text-center font-bold text-neutral-200 text-lg uppercase tracking-wide">
              {question.direction === 'verset_to_reference'
                ? 'Quelle est la bonne référence ?'
                : 'Quel est le bon verset ?'}
            </p>

            {/* Options */}
            <div className="space-y-3">
              {question.options.map((option, i) => {
                const isSelected = selected === option;
                const isTheCorrectOne = option === question.correctAnswer;
                let card = 'border-neutral-800 bg-neutral-800/40 hover:border-neutral-600 hover:bg-neutral-800';
                let badge = 'bg-neutral-700 text-neutral-300';
                if (isAnswered) {
                  if (isTheCorrectOne) {
                    card = 'border-green-600 bg-green-950/40';
                    badge = 'bg-green-600 text-white';
                  } else if (isSelected) {
                    card = 'border-red-600 bg-red-950/40';
                    badge = 'bg-red-600 text-white';
                  } else {
                    card = 'border-neutral-800 bg-neutral-900 opacity-40';
                  }
                }
                return (
                  <button
                    key={i}
                    onClick={() => handleSelect(option)}
                    disabled={isAnswered}
                    className={`w-full text-left px-4 py-4 rounded-2xl border-2 transition-all flex items-center gap-3 ${card} ${
                      isAnswered ? 'cursor-default' : 'cursor-pointer'
                    }`}
                  >
                    <span className={`shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm ${badge}`}>
                      {LETTERS[i]}
                    </span>
                    <span
                      className={`text-neutral-100 font-semibold flex-1 ${
                        question.direction === 'reference_to_verset' ? 'text-sm italic leading-relaxed' : 'text-base'
                      }`}
                    >
                      {question.direction === 'reference_to_verset' ? `« ${option} »` : option}
                    </span>
                    {isAnswered && isTheCorrectOne && <CheckCircle2 className="h-5 w-5 shrink-0 text-green-500" />}
                    {isAnswered && isSelected && !isTheCorrectOne && <XCircle className="h-5 w-5 shrink-0 text-red-500" />}
                  </button>
                );
              })}
            </div>

            {/* Fiche de correction */}
            <AnimatePresence>
              {isAnswered && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="space-y-4"
                >
                  <div
                    className={`p-5 rounded-2xl border space-y-3 ${
                      isCorrect ? 'bg-green-950/30 border-green-800' : 'bg-red-950/30 border-red-800'
                    }`}
                  >
                    <div className={`flex items-center gap-2 font-black text-base ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                      {isCorrect ? <CheckCircle2 className="h-5 w-5 shrink-0" /> : <XCircle className="h-5 w-5 shrink-0" />}
                      {isCorrect ? 'Bonne réponse !' : 'Réponse correcte :'}
                    </div>

                    <div className="text-sm text-neutral-300 space-y-1">
                      <p><span className="font-bold text-neutral-100">Référence :</span> {question.correctReference}</p>
                      <p className="italic leading-relaxed">« {question.correctVerseText} »</p>
                    </div>

                    <div className="pt-2 border-t border-neutral-800 text-sm text-neutral-300 space-y-1">
                      <div className="flex items-center gap-1.5 text-neutral-100 font-bold mb-1 text-sm">
                        <BookOpen className="h-4 w-4 shrink-0" /> Mot Strong associé
                      </div>
                      <p>
                        <span className={question.entry.langue === 'hebreu' ? 'font-serif' : 'font-sans'}>
                          {question.entry.mot_original}
                        </span>{' '}
                        ({question.entry.strong}) — {question.entry.translitteration}
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <button
                      onClick={handleNext}
                      className="px-6 py-3.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 text-sm font-black rounded-xl shadow-lg shadow-amber-500/20 transition-all cursor-pointer flex items-center gap-2"
                    >
                      Question suivante <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}
      </div>
    </div>
  );
}
