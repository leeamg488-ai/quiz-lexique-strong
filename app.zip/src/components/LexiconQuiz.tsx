import React, { useState, useMemo } from 'react';
import { StrongEntry } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, ArrowRight, BookOpen, Shuffle, ChevronUp, ChevronDown } from 'lucide-react';

interface LexiconQuizProps {
  entries: StrongEntry[];
}

type QuestionType =
  | 'strong_to_definition'
  | 'mot_to_definition'
  | 'prononciation_to_mot'
  | 'mot_to_strong'
  | 'triple_to_categorie';

interface Question {
  entry: StrongEntry;
  type: QuestionType;
  prompt: string;
  options: string[];
  correctAnswer: string;
}

const LETTERS = ['A', 'B', 'C', 'D'];

function shuffleArray<T>(array: T[]): T[] {
  return [...array].sort(() => Math.random() - 0.5);
}

function pickDistractors(
  entries: StrongEntry[],
  currentId: number,
  field: keyof StrongEntry,
  sameLangue?: 'hebreu' | 'grec'
): string[] {
  const pool = entries.filter(
    (e) =>
      e.id !== currentId &&
      (!sameLangue || e.langue === sameLangue) &&
      String(e[field]).trim().length > 0
  );
  const shuffled = shuffleArray(pool);
  const values = new Set<string>();
  for (const e of shuffled) {
    const val = String(e[field]);
    if (!values.has(val)) values.add(val);
    if (values.size >= 3) break;
  }
  if (values.size < 3) {
    const fallbackPool = entries.filter((e) => e.id !== currentId && String(e[field]).trim().length > 0);
    for (const e of shuffleArray(fallbackPool)) {
      const val = String(e[field]);
      if (!values.has(val)) values.add(val);
      if (values.size >= 3) break;
    }
  }
  return Array.from(values);
}

function buildQuestion(entries: StrongEntry[]): Question {
  const entry = entries[Math.floor(Math.random() * entries.length)];
  const types: QuestionType[] = [
    'strong_to_definition',
    'mot_to_definition',
    'prononciation_to_mot',
    'mot_to_strong',
    'triple_to_categorie',
  ];
  const type = types[Math.floor(Math.random() * types.length)];

  switch (type) {
    case 'strong_to_definition':
    case 'mot_to_definition': {
      const distractors = pickDistractors(entries, entry.id, 'definition');
      return {
        entry,
        type,
        prompt: 'Quelle est la bonne définition ?',
        options: shuffleArray([entry.definition, ...distractors]),
        correctAnswer: entry.definition,
      };
    }
    case 'prononciation_to_mot': {
      const distractors = pickDistractors(entries, entry.id, 'mot_original', entry.langue);
      return {
        entry,
        type,
        prompt: 'Quel mot correspond à cette prononciation ?',
        options: shuffleArray([entry.mot_original, ...distractors]),
        correctAnswer: entry.mot_original,
      };
    }
    case 'mot_to_strong': {
      const distractors = pickDistractors(entries, entry.id, 'strong', entry.langue);
      return {
        entry,
        type,
        prompt: 'Quel est le numéro Strong de ce mot ?',
        options: shuffleArray([entry.strong, ...distractors]),
        correctAnswer: entry.strong,
      };
    }
    case 'triple_to_categorie': {
      const distractors = pickDistractors(entries, entry.id, 'categorie');
      return {
        entry,
        type,
        prompt: 'Quel est le thème de ce mot ?',
        options: shuffleArray([entry.categorie, ...distractors]),
        correctAnswer: entry.categorie,
      };
    }
  }
}

// Masque le champ qui constitue la réponse à trouver dans l'en-tête / les indices.
function visibleFields(type: QuestionType) {
  return {
    strong: type !== 'mot_to_strong',
    mot: type !== 'prononciation_to_mot',
    categorie: type !== 'triple_to_categorie',
  };
}

export default function LexiconQuiz({ entries }: LexiconQuizProps) {
  const [question, setQuestion] = useState<Question>(() => buildQuestion(entries));
  const [selected, setSelected] = useState<string | null>(null);
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const [showHints, setShowHints] = useState(true);

  const fields = useMemo(() => visibleFields(question.type), [question.type]);
  const isAnswered = selected !== null;
  const isCorrect = selected === question.correctAnswer;
  const isHebreu = question.entry.langue === 'hebreu';
  const accent = isHebreu ? 'amber' : 'blue';

  const handleSelect = (option: string) => {
    if (isAnswered) return;
    setSelected(option);
    setScore((s) => ({
      correct: s.correct + (option === question.correctAnswer ? 1 : 0),
      total: s.total + 1,
    }));
  };

  const handleNext = () => {
    setQuestion(buildQuestion(entries));
    setSelected(null);
  };

  const handleReset = () => {
    setQuestion(buildQuestion(entries));
    setSelected(null);
    setScore({ correct: 0, total: 0 });
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      {/* Score */}
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-mono text-gray-400 uppercase tracking-wider">
          Score : {score.correct} / {score.total}
        </span>
        <button
          onClick={handleReset}
          className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-400 hover:text-amber-600 transition-colors cursor-pointer"
        >
          <Shuffle className="h-3.5 w-3.5" /> Recommencer
        </button>
      </div>

      {/* Carte quiz — thème sombre */}
      <div className="bg-neutral-900 p-6 md:p-8 rounded-3xl border border-neutral-800 shadow-xl space-y-6">
        {/* En-tête */}
        <div className="text-center space-y-4">
          {fields.strong && (
            <span
              className={`inline-block px-4 py-1.5 rounded-lg text-xs font-bold tracking-widest uppercase font-mono ${
                isHebreu ? 'bg-amber-950/60 text-amber-300' : 'bg-blue-950/60 text-blue-300'
              }`}
            >
              Lexique {isHebreu ? 'Hébreu' : 'Grec'} • {question.entry.strong}
            </span>
          )}

          {fields.mot && (
            <h1
              className={`text-5xl md:text-6xl font-black ${
                isHebreu ? 'font-serif text-amber-100' : 'font-sans text-blue-100'
              }`}
            >
              {question.entry.mot_original}
            </h1>
          )}

          {/* Bascule des indices */}
          <button
            onClick={() => setShowHints((v) => !v)}
            className={`mx-auto flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-colors cursor-pointer ${
              isHebreu ? 'bg-amber-950/40 text-amber-400 hover:bg-amber-950/60' : 'bg-blue-950/40 text-blue-400 hover:bg-blue-950/60'
            }`}
          >
            <BookOpen className="h-4 w-4" />
            {showHints ? 'Masquer les indices' : 'Afficher les indices'}
            {showHints ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </button>
        </div>

        {/* Bloc indices */}
        <AnimatePresence initial={false}>
          {showHints && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div
                className={`p-5 rounded-2xl border space-y-4 ${
                  isHebreu ? 'border-amber-900/60 bg-amber-950/10' : 'border-blue-900/60 bg-blue-950/10'
                }`}
              >
                <div className="space-y-1.5">
                  <p className="text-[11px] font-bold tracking-widest uppercase text-neutral-500">
                    Translittération &amp; Prononciation
                  </p>
                  <p className="text-neutral-100 font-bold text-base">
                    {question.entry.translitteration} • Prononcé : « {question.entry.prononciation} »
                  </p>
                </div>

                <div className="border-t border-neutral-800" />

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-bold tracking-widest uppercase text-neutral-500">Thème</p>
                    {fields.categorie ? (
                      <span className="inline-block px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-200 text-sm font-mono">
                        {question.entry.categorie}
                      </span>
                    ) : (
                      <span className="inline-block px-3 py-1.5 rounded-lg bg-neutral-800/50 text-neutral-600 text-sm font-mono">
                        ???
                      </span>
                    )}
                  </div>
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-bold tracking-widest uppercase text-neutral-500">Occurrences</p>
                    <span className="inline-block px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-200 text-sm font-mono">
                      {question.entry.occurrences} fois
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="border-t border-neutral-800" />

        {/* Question */}
        <p className="text-center font-bold text-neutral-200 text-lg uppercase tracking-wide">{question.prompt}</p>

        {/* Options */}
        <div className="space-y-3">
          {question.options.map((option, i) => {
            const isSelected = selected === option;
            const isTheCorrectOne = option === question.correctAnswer;
            let card = 'border-neutral-800 bg-neutral-800/40 hover:border-neutral-600 hover:bg-neutral-800';
            let badge = 'bg-neutral-700 text-neutral-300';
            if (isAnswered) {
              if (isTheCorrectOne) {
                card = 'border-green-600 bg-green-950/40';
                badge = 'bg-green-600 text-white';
              } else if (isSelected) {
                card = 'border-red-600 bg-red-950/40';
                badge = 'bg-red-600 text-white';
              } else {
                card = 'border-neutral-800 bg-neutral-900 opacity-40';
              }
            }
            return (
              <button
                key={i}
                onClick={() => handleSelect(option)}
                disabled={isAnswered}
                className={`w-full text-left px-4 py-4 rounded-2xl border-2 transition-all flex items-center gap-3 ${card} ${
                  isAnswered ? 'cursor-default' : 'cursor-pointer'
                }`}
              >
                <span className={`shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm ${badge}`}>
                  {LETTERS[i]}
                </span>
                <span className="text-neutral-100 font-semibold text-base flex-1">{option}</span>
                {isAnswered && isTheCorrectOne && <CheckCircle2 className="h-5 w-5 shrink-0 text-green-500" />}
                {isAnswered && isSelected && !isTheCorrectOne && <XCircle className="h-5 w-5 shrink-0 text-red-500" />}
              </button>
            );
          })}
        </div>

        {/* Fiche de correction enrichie */}
        <AnimatePresence>
          {isAnswered && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              <div
                className={`p-5 rounded-2xl border space-y-3 ${
                  isCorrect ? 'bg-green-950/30 border-green-800' : 'bg-red-950/30 border-red-800'
                }`}
              >
                <div className={`flex items-center gap-2 font-black text-base ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                  {isCorrect ? <CheckCircle2 className="h-5 w-5 shrink-0" /> : <XCircle className="h-5 w-5 shrink-0" />}
                  {isCorrect ? 'Bonne réponse !' : 'Réponse correcte :'}
                </div>

                <div className="grid grid-cols-2 gap-x-4 gap-y-2 pt-1 text-sm text-neutral-300">
                  <div><span className="font-bold text-neutral-100">Strong :</span> {question.entry.strong}</div>
                  <div><span className="font-bold text-neutral-100">Thème :</span> {question.entry.categorie}</div>
                  <div>
                    <span className="font-bold text-neutral-100">Mot :</span>{' '}
                    <span className={isHebreu ? 'font-serif' : 'font-sans'}>{question.entry.mot_original}</span>
                  </div>
                  <div><span className="font-bold text-neutral-100">Translittération :</span> {question.entry.translitteration}</div>
                  <div className="col-span-2"><span className="font-bold text-neutral-100">Prononciation :</span> « {question.entry.prononciation} »</div>
                </div>

                <div className="pt-2 border-t border-neutral-800">
                  <div className="flex items-center gap-1.5 text-neutral-100 font-bold mb-1.5 text-sm">
                    <BookOpen className="h-4 w-4 shrink-0" /> Définition
                  </div>
                  <p className="text-neutral-300 leading-relaxed text-sm">{question.entry.definition}</p>
                </div>

                {question.entry.references.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {question.entry.references.slice(0, 5).map((ref, i) => (
                      <span key={i} className="bg-blue-950/50 text-blue-300 px-2.5 py-1 rounded-lg text-xs font-mono">
                        {ref}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleNext}
                  className="px-6 py-3.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 text-sm font-black rounded-xl shadow-lg shadow-amber-500/20 transition-all cursor-pointer flex items-center gap-2"
                >
                  Question suivante <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
