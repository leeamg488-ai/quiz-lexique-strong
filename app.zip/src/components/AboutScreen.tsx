import React from 'react';
import { X, BookOpen, ShieldCheck } from 'lucide-react';

interface AboutScreenProps {
  onClose: () => void;
  wordCount: number;
}

export default function AboutScreen({ onClose, wordCount }: AboutScreenProps) {
  return (
    <div className="fixed inset-0 z-50 bg-white overflow-y-auto">
      <div className="max-w-xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-black text-gray-900">À propos</h1>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="space-y-6 text-sm text-gray-700 leading-relaxed">
          <section>
            <h2 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
              <BookOpen className="h-4 w-4" /> Le lexique
            </h2>
            <p>
              Quiz Lexique Strong propose actuellement <strong>{wordCount} entrées</strong> du lexique
              biblique hébreu et grec, basées sur la numérotation de Strong (1890), domaine public.
            </p>
          </section>

          <section>
            <h2 className="font-bold text-gray-900 mb-2">Sources et méthodologie</h2>
            <p className="mb-2">Le contenu provient de plusieurs sources, de qualité et de niveau de détail variables :</p>
            <ul className="list-disc pl-5 space-y-1.5">
              <li>
                Fiches compilées manuellement à partir de <strong>BDB</strong> (Brown-Driver-Briggs),{' '}
                <strong>HALOT</strong> (Koehler-Baumgartner-Stamm) et <strong>Gesenius</strong>{' '}
                (trad. Tregelles), avec assistance d'une IA (Claude, Anthropic) pour la mise en forme
                et la vérification croisée.
              </li>
              <li>
                Traductions directes du dictionnaire Strong original (hébreu/grec), réalisées avec
                assistance d'une IA à partir du texte anglais source.
              </li>
            </ul>
            <p className="mt-2 text-xs text-gray-500">
              Malgré des vérifications croisées systématiques, ce travail de compilation est encore en
              cours et peut comporter des imprécisions. Signalez toute erreur constatée.
            </p>
          </section>

          <section>
            <h2 className="font-bold text-gray-900 mb-2">Versets bibliques</h2>
            <p>
              Les textes des versets utilisés dans le mode "Versets bibliques" sont tirés de la{' '}
              <strong>Bible Louis Segond (1910)</strong>, traduction appartenant au domaine public.
            </p>
          </section>

          <section>
            <h2 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4" /> Confidentialité
            </h2>
            <p>
              Cette application ne collecte aucune donnée personnelle et fonctionne entièrement hors
              ligne. Aucune information n'est envoyée à un serveur.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
