import React, { useState, useMemo } from 'react';
import { StrongEntry } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, ArrowRight, BookOpen, Shuffle } from 'lucide-react';

interface QuizGameProps {
  entries: StrongEntry[];
}

type QuestionType =
  | 'strong_to_definition'
  | 'mot_to_definition'
  | 'prononciation_to_mot'
  | 'mot_to_strong'
  | 'triple_to_categorie';

interface Question {
  entry: StrongEntry;
  type: QuestionType;
  prompt: string;
  options: string[];
  correctAnswer: string;
}

function shuffleArray<T>(array: T[]): T[] {
  return [...array].sort(() => Math.random() - 0.5);
}

function pickDistractors(
  entries: StrongEntry[],
  currentId: number,
  field: keyof StrongEntry,
  sameLangue?: 'hebreu' | 'grec'
): string[] {
  const pool = entries.filter(
    (e) =>
      e.id !== currentId &&
      (!sameLangue || e.langue === sameLangue) &&
      String(e[field]).trim().length > 0
  );
  const shuffled = shuffleArray(pool);
  const values = new Set<string>();
  for (const e of shuffled) {
    const val = String(e[field]);
    if (!values.has(val)) values.add(val);
    if (values.size >= 3) break;
  }
  // Filet de sécurité si le pool filtré est trop petit
  if (values.size < 3) {
    const fallbackPool = entries.filter((e) => e.id !== currentId && String(e[field]).trim().length > 0);
    for (const e of shuffleArray(fallbackPool)) {
      const val = String(e[field]);
      if (!values.has(val)) values.add(val);
      if (values.size >= 3) break;
    }
  }
  return Array.from(values);
}

function buildQuestion(entries: StrongEntry[]): Question {
  const entry = entries[Math.floor(Math.random() * entries.length)];
  const types: QuestionType[] = [
    'strong_to_definition',
    'mot_to_definition',
    'prononciation_to_mot',
    'mot_to_strong',
    'triple_to_categorie',
  ];
  const type = types[Math.floor(Math.random() * types.length)];

  switch (type) {
    case 'strong_to_definition':
    case 'mot_to_definition': {
      const distractors = pickDistractors(entries, entry.id, 'definition');
      return {
        entry,
        type,
        prompt: 'Quelle est la définition de ce mot ?',
        options: shuffleArray([entry.definition, ...distractors]),
        correctAnswer: entry.definition,
      };
    }
    case 'prononciation_to_mot': {
      const distractors = pickDistractors(entries, entry.id, 'mot_original', entry.langue);
      return {
        entry,
        type,
        prompt: 'Quel mot correspond à cette prononciation ?',
        options: shuffleArray([entry.mot_original, ...distractors]),
        correctAnswer: entry.mot_original,
      };
    }
    case 'mot_to_strong': {
      const distractors = pickDistractors(entries, entry.id, 'strong', entry.langue);
      return {
        entry,
        type,
        prompt: 'Quel est le numéro Strong de ce mot ?',
        options: shuffleArray([entry.strong, ...distractors]),
        correctAnswer: entry.strong,
      };
    }
    case 'triple_to_categorie': {
      const distractors = pickDistractors(entries, entry.id, 'categorie');
      return {
        entry,
        type,
        prompt: 'Quelle est la catégorie de ce mot ?',
        options: shuffleArray([entry.categorie, ...distractors]),
        correctAnswer: entry.categorie,
      };
    }
  }
}

// Détermine quels champs d'identité afficher dans l'en-tête de la question,
// en masquant le champ qui constitue la réponse à trouver.
function visibleFields(type: QuestionType) {
  return {
    strong: type !== 'mot_to_strong',
    mot: type !== 'prononciation_to_mot',
    translitteration: true,
    prononciation: true,
  };
}

export default function QuizGame({ entries }: QuizGameProps) {
  const [question, setQuestion] = useState<Question>(() => buildQuestion(entries));
  const [selected, setSelected] = useState<string | null>(null);
  const [score, setScore] = useState({ correct: 0, total: 0 });

  const fields = useMemo(() => visibleFields(question.type), [question.type]);
  const isAnswered = selected !== null;
  const isCorrect = selected === question.correctAnswer;

  const handleSelect = (option: string) => {
    if (isAnswered) return;
    setSelected(option);
    setScore((s) => ({
      correct: s.correct + (option === question.correctAnswer ? 1 : 0),
      total: s.total + 1,
    }));
  };

  const handleNext = () => {
    setQuestion(buildQuestion(entries));
    setSelected(null);
  };

  const handleReset = () => {
    setQuestion(buildQuestion(entries));
    setSelected(null);
    setScore({ correct: 0, total: 0 });
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      {/* Score */}
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-mono text-gray-400 uppercase tracking-wider">
          Score : {score.correct} / {score.total}
        </span>
        <button
          onClick={handleReset}
          className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-400 hover:text-amber-600 transition-colors cursor-pointer"
        >
          <Shuffle className="h-3.5 w-3.5" /> Recommencer
        </button>
      </div>

      {/* Carte question */}
      <div className="bg-white p-6 md:p-8 rounded-3xl border border-gray-100 shadow-md space-y-6">
        {/* En-tête : informations disponibles sur l'entrée (sauf le champ demandé) */}
        <div className="text-center space-y-2 pb-4 border-b border-gray-100">
          {fields.strong && (
            <span
              className={`inline-block px-2.5 py-0.5 rounded-md text-[10px] font-bold tracking-wider uppercase font-mono ${
                question.entry.langue === 'hebreu' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
              }`}
            >
              {question.entry.strong} • {question.entry.langue}
            </span>
          )}

          {fields.mot && (
            <h1
              className={`text-4xl md:text-5xl font-black ${
                question.entry.langue === 'hebreu' ? 'font-serif text-amber-950' : 'font-sans text-blue-950'
              }`}
            >
              {question.entry.mot_original}
            </h1>
          )}

          {(fields.translitteration || fields.prononciation) && (
            <p className="text-gray-500 text-sm italic font-medium">
              {fields.translitteration && question.entry.translitteration}
              {fields.translitteration && fields.prononciation && ' • '}
              {fields.prononciation && `Prononcé : « ${question.entry.prononciation} »`}
            </p>
          )}
        </div>

        {/* Question */}
        <p className="text-center font-bold text-gray-800 text-base">{question.prompt}</p>

        {/* Options */}
        <div className="space-y-3">
          {question.options.map((option, i) => {
            const isSelected = selected === option;
            const isTheCorrectOne = option === question.correctAnswer;
            let stateClasses = 'border-gray-200 hover:border-amber-300 hover:bg-amber-50/40';
            if (isAnswered) {
              if (isTheCorrectOne) {
                stateClasses = 'border-green-400 bg-green-50';
              } else if (isSelected) {
                stateClasses = 'border-red-300 bg-red-50';
              } else {
                stateClasses = 'border-gray-100 opacity-50';
              }
            }
            return (
              <button
                key={i}
                onClick={() => handleSelect(option)}
                disabled={isAnswered}
                className={`w-full text-left px-4 py-3.5 rounded-2xl border-2 transition-all text-sm font-semibold text-gray-800 flex items-center justify-between gap-3 ${stateClasses} ${
                  isAnswered ? 'cursor-default' : 'cursor-pointer'
                }`}
              >
                <span>{option}</span>
                {isAnswered && isTheCorrectOne && <CheckCircle2 className="h-5 w-5 shrink-0 text-green-600" />}
                {isAnswered && isSelected && !isTheCorrectOne && <XCircle className="h-5 w-5 shrink-0 text-red-500" />}
              </button>
            );
          })}
        </div>

        {/* Fiche de correction enrichie */}
        <AnimatePresence>
          {isAnswered && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              <div
                className={`p-4 rounded-2xl border text-xs space-y-2 ${
                  isCorrect ? 'bg-green-50/60 border-green-200' : 'bg-red-50/60 border-red-200'
                }`}
              >
                <div className={`flex items-center gap-1.5 font-bold text-sm ${isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                  {isCorrect ? <CheckCircle2 className="h-4 w-4 shrink-0" /> : <XCircle className="h-4 w-4 shrink-0" />}
                  {isCorrect ? 'Bonne réponse !' : 'Réponse correcte :'}
                </div>

                <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 pt-1 text-gray-700">
                  <div><span className="font-bold">Strong :</span> {question.entry.strong}</div>
                  <div><span className="font-bold">Catégorie :</span> {question.entry.categorie}</div>
                  <div>
                    <span className="font-bold">Mot :</span>{' '}
                    <span className={question.entry.langue === 'hebreu' ? 'font-serif' : 'font-sans'}>
                      {question.entry.mot_original}
                    </span>
                  </div>
                  <div><span className="font-bold">Translittération :</span> {question.entry.translitteration}</div>
                  <div className="col-span-2"><span className="font-bold">Prononciation :</span> « {question.entry.prononciation} »</div>
                </div>

                <div className="pt-2 border-t border-gray-200/70">
                  <div className="flex items-center gap-1 text-gray-700 font-bold mb-1">
                    <BookOpen className="h-3.5 w-3.5 shrink-0" /> Définition
                  </div>
                  <p className="text-gray-700 leading-relaxed text-sm">{question.entry.definition}</p>
                </div>

                {question.entry.references.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {question.entry.references.slice(0, 5).map((ref, i) => (
                      <span key={i} className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-mono">
                        {ref}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleNext}
                  className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl shadow-md shadow-amber-500/10 transition-all cursor-pointer flex items-center gap-2"
                >
                  Question suivante <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
