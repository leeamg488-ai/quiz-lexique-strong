import React, { useState } from 'react';
import { StrongEntry } from '../types';
import LexiconQuiz from './LexiconQuiz';
import VerseQuiz from './VerseQuiz';
import { Library, BookText } from 'lucide-react';

interface QuizGameProps {
  entries: StrongEntry[];
}

type Mode = 'lexique' | 'versets';

export default function QuizGame({ entries }: QuizGameProps) {
  const [mode, setMode] = useState<Mode>('lexique');

  return (
    <div className="space-y-6">
      {/* Sélecteur de mode */}
      <div className="max-w-xl mx-auto grid grid-cols-2 gap-2 p-1 bg-neutral-100 rounded-2xl">
        <button
          onClick={() => setMode('lexique')}
          className={`flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all cursor-pointer ${
            mode === 'lexique' ? 'bg-neutral-900 text-white shadow-md' : 'text-neutral-500 hover:text-neutral-700'
          }`}
        >
          <Library className="h-4 w-4" /> Lexique Strong
        </button>
        <button
          onClick={() => setMode('versets')}
          className={`flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all cursor-pointer ${
            mode === 'versets' ? 'bg-neutral-900 text-white shadow-md' : 'text-neutral-500 hover:text-neutral-700'
          }`}
        >
          <BookText className="h-4 w-4" /> Versets bibliques
        </button>
      </div>

      {mode === 'lexique' ? <LexiconQuiz entries={entries} /> : <VerseQuiz entries={entries} />}
    </div>
  );
}
