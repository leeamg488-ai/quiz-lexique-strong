import React, { useState, useEffect } from 'react';
import { StrongEntry } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Eye, ArrowRight, Shuffle, BookOpen } from 'lucide-react';

interface QuizGameProps {
  entries: StrongEntry[];
}

// Mélange un tableau (Fisher-Yates simplifié)
function shuffleArray<T>(array: T[]): T[] {
  return [...array].sort(() => Math.random() - 0.5);
}

export default function QuizGame({ entries }: QuizGameProps) {
  const [order, setOrder] = useState<StrongEntry[]>([]);
  const [index, setIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);

  // Initialise (et réinitialise) un ordre aléatoire de parcours des 152 entrées
  useEffect(() => {
    setOrder(shuffleArray(entries));
    setIndex(0);
    setRevealed(false);
  }, [entries]);

  const current = order[index];

  const handleReveal = () => setRevealed(true);

  const handleNext = () => {
    if (index + 1 >= order.length) {
      // Fin du paquet : on remélange et recommence
      setOrder(shuffleArray(entries));
      setIndex(0);
    } else {
      setIndex(index + 1);
    }
    setRevealed(false);
  };

  const handleReshuffle = () => {
    setOrder(shuffleArray(entries));
    setIndex(0);
    setRevealed(false);
  };

  if (!current) {
    return (
      <div className="text-center text-sm text-gray-400 py-12">
        Aucune entrée disponible.
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto space-y-6">
      {/* Progress */}
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-mono text-gray-400 uppercase tracking-wider">
          Carte {index + 1} / {order.length}
        </span>
        <button
          onClick={handleReshuffle}
          className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-400 hover:text-amber-600 transition-colors cursor-pointer"
        >
          <Shuffle className="h-3.5 w-3.5" /> Remélanger
        </button>
      </div>

      {/* Progress bar */}
      <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
        <motion.div
          initial={false}
          animate={{ width: `${((index + 1) / order.length) * 100}%` }}
          className="bg-amber-500 h-full"
        />
      </div>

      {/* Flashcard */}
      <div className="bg-white p-6 md:p-8 rounded-3xl border border-gray-100 shadow-md space-y-6 text-center min-h-[320px] flex flex-col justify-center">
        <span
          className={`self-center px-2.5 py-0.5 rounded-md text-[10px] font-bold tracking-wider uppercase font-mono ${
            current.langue === 'hebreu' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
          }`}
        >
          {current.strong} • {current.langue}
        </span>

        <div className="space-y-2">
          <h1
            className={`text-5xl md:text-6xl font-black ${
              current.langue === 'hebreu' ? 'font-serif text-amber-950' : 'font-sans text-blue-950'
            }`}
          >
            {current.mot_original}
          </h1>
          <p className="text-gray-500 text-sm italic font-medium">
            {current.translitteration} • Prononcé : « {current.prononciation} »
          </p>
        </div>

        <AnimatePresence mode="wait">
          {!revealed ? (
            <motion.div
              key="hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="pt-2"
            >
              <button
                onClick={handleReveal}
                className="px-6 py-3.5 bg-gray-800 hover:bg-gray-950 text-white font-black rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-2 text-xs"
              >
                <Eye className="h-4 w-4" /> Voir la réponse
              </button>
            </motion.div>
          ) : (
            <motion.div
              key="answer"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="pt-2 space-y-4 text-left"
            >
              <div className="bg-amber-50/40 border border-amber-100 p-4 rounded-2xl text-xs space-y-2">
                <div className="flex items-center gap-1 text-amber-800 font-bold">
                  <BookOpen className="h-4 w-4 shrink-0 text-amber-600" /> Définition
                </div>
                <p className="text-gray-700 leading-relaxed text-sm">
                  {current.definition}
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded font-mono">
                    {current.categorie}
                  </span>
                  <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded font-mono">
                    {current.occurrences} occurrences
                  </span>
                  {current.references.map((ref, i) => (
                    <span key={i} className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-mono">
                      {ref}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleNext}
                  className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl shadow-md shadow-amber-500/10 transition-all cursor-pointer flex items-center gap-2"
                >
                  Suivant <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
