// Utilitaires pour le mode "Versets bibliques" : convertit une référence
// française (ex: "Jean 3:16") en requête vers l'API externe Free Use Bible
// API (bible.helloao.org), qui héberge notamment la Bible Louis Segond (LSG)
// en français, en domaine public. Aucune donnée de verset n'est stockée en
// local : ce mode nécessite une connexion internet.

const BOOK_ID_BY_FRENCH_NAME: Record<string, string> = {
  'genèse': 'GEN', 'exode': 'EXO', 'lévitique': 'LEV', 'nombres': 'NUM',
  'deutéronome': 'DEU', 'josué': 'JOS', 'juges': 'JDG', 'ruth': 'RUT',
  '1 samuel': '1SA', '2 samuel': '2SA', '1 rois': '1KI', '2 rois': '2KI',
  '1 chroniques': '1CH', '2 chroniques': '2CH', 'esdras': 'EZR',
  'néhémie': 'NEH', 'esther': 'EST', 'job': 'JOB', 'psaume': 'PSA',
  'psaumes': 'PSA', 'proverbes': 'PRO', 'ecclésiaste': 'ECC',
  'cantique des cantiques': 'SNG', 'ésaïe': 'ISA', 'jérémie': 'JER',
  'lamentations': 'LAM', 'ézéchiel': 'EZK', 'daniel': 'DAN', 'osée': 'HOS',
  'joël': 'JOL', 'amos': 'AMO', 'abdias': 'OBA', 'jonas': 'JON',
  'michée': 'MIC', 'nahum': 'NAM', 'habacuc': 'HAB', 'sophonie': 'ZEP',
  'aggée': 'HAG', 'zacharie': 'ZEC', 'malachie': 'MAL',
  'matthieu': 'MAT', 'marc': 'MRK', 'luc': 'LUK', 'jean': 'JHN',
  'actes': 'ACT', 'romains': 'ROM', '1 corinthiens': '1CO',
  '2 corinthiens': '2CO', 'galates': 'GAL', 'éphésiens': 'EPH',
  'philippiens': 'PHP', 'colossiens': 'COL', '1 thessaloniciens': '1TH',
  '2 thessaloniciens': '2TH', '1 timothée': '1TI', '2 timothée': '2TI',
  'tite': 'TIT', 'philémon': 'PHM', 'hébreux': 'HEB', 'jacques': 'JAS',
  '1 pierre': '1PE', '2 pierre': '2PE', '1 jean': '1JN', '2 jean': '2JN',
  '3 jean': '3JN', 'jude': 'JUD', 'apocalypse': 'REV',
};

export interface ParsedReference {
  bookId: string;
  chapter: number;
  verse: number;
}

export function parseFrenchReference(ref: string): ParsedReference | null {
  const match = ref.trim().match(/^(.+?)\s+(\d+):(\d+)/);
  if (!match) return null;
  const [, bookName, chapter, verse] = match;
  const bookId = BOOK_ID_BY_FRENCH_NAME[bookName.trim().toLowerCase()];
  if (!bookId) return null;
  return { bookId, chapter: parseInt(chapter, 10), verse: parseInt(verse, 10) };
}

let cachedTranslationId: string | null = null;
let resolvingPromise: Promise<string | null> | null = null;

// Trouve dynamiquement l'identifiant de la traduction française Louis Segond
// disponible sur l'API (évite de coder en dur un id qui pourrait changer).
async function resolveFrenchTranslationId(): Promise<string | null> {
  if (cachedTranslationId) return cachedTranslationId;
  if (resolvingPromise) return resolvingPromise;

  resolvingPromise = (async () => {
    try {
      const res = await fetch('https://bible.helloao.org/api/available_translations.json');
      const data = await res.json();
      const translations: any[] = data.translations || [];
      const frenchOnes = translations.filter((t) => t.language === 'fra' || t.languageEnglishName === 'French');
      const segond = frenchOnes.find((t) => /segond/i.test(t.name) || /segond/i.test(t.englishName));
      const chosen = segond || frenchOnes[0];
      cachedTranslationId = chosen ? chosen.id : null;
      return cachedTranslationId;
    } catch {
      return null;
    }
  })();

  return resolvingPromise;
}

// Récupère le texte d'un verset à partir d'une référence française.
// Retourne null si la référence est invalide ou si la requête échoue
// (par exemple hors ligne) — à gérer côté appelant.
export async function fetchVerseText(ref: string): Promise<string | null> {
  const parsed = parseFrenchReference(ref);
  if (!parsed) return null;

  const translationId = await resolveFrenchTranslationId();
  if (!translationId) return null;

  try {
    const res = await fetch(
      `https://bible.helloao.org/api/${translationId}/${parsed.bookId}/${parsed.chapter}.json`
    );
    if (!res.ok) return null;
    const data = await res.json();
    const content = data?.chapter?.content as any[] | undefined;
    if (!content) return null;

    // Le contenu du chapitre est une liste d'éléments; on cherche le verset demandé.
    for (const item of content) {
      if (item?.type === 'verse' && item?.number === parsed.verse) {
        const text = (item.content || [])
          .map((c: any) => (typeof c === 'string' ? c : c?.text || ''))
          .join(' ')
          .replace(/\s+/g, ' ')
          .trim();
        return text || null;
      }
    }
    return null;
  } catch {
    return null;
  }
}
